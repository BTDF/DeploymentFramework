//-------------------------------------------------------------------------------------
// <copyright file="PartyCollection.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      A collection of BizTalk 2004 Parties.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using directives

	using System;
	using System.Collections;

	#endregion

	/// <summary>
	/// A collection of <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/> objects.
	/// </summary>
	internal class PartyCollection : CollectionBase
	{
		#region Constructors

		/// <summary>
		/// Creates a new collection of <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/> objects.
		/// </summary>
		public PartyCollection()
		{
		}

		#endregion

		#region Indexers

		/// <summary>
		/// Gets or sets the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/> at a specified 
		/// position within the collection.
		/// </summary>
		/// <param name="index">
		/// The zero based index in the collection.
		/// </param>
		/// <value>
		/// A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/>.
		/// </value>
		public Party this[int index]
		{
			get 
			{ 
				return (Party)this.List[index]; 
			}
			set 
			{ 
				this.List[index] = value; 
			}
		}

		/// <summary>
		/// Gets or sets the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/> with
		/// a particular name.
		/// </summary>
		/// <param name="name">
		/// The name of the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/>.
		/// </param>
		/// <value>
		/// A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/>.
		/// </value>
		/// <exception cref="System.ArgumentNullException">
		/// Thrown when <paramref name="name"/> is <b>null</b> or zero length.
		/// </exception>
		/// <exception cref="System.ArgumentOutOfRangeException">
		/// Thrown when no object matching <paramref name="name"/> is found in the collection.
		/// </exception>
		public Party this[string name]
		{
			get 
			{ 
				int index = this.IndexOf(name);
				if (index >= 0)
				{
					return this[index];
				}
				else
				{
					throw new ArgumentOutOfRangeException("No object with the specified name was found.", name, "name");
				}
			}
			set 
			{ 
				int index = this.IndexOf(name);
				if (index >= 0)
				{
					this[index] = value;
				}
				else
				{
					throw new ArgumentOutOfRangeException("No object with the specified name was found.", name, "name");
				}
			}
		}

		#endregion

		#region Methods

		/// <summary>
		/// Adds a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/> to the collection.
		/// </summary>
		/// <param name="party">
		/// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/> to add.
		/// </param>
		public void Add(Party party) 
		{
			this.List.Add(party);
		}

		/// <summary>
		/// Gets whether a particular <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/>
		/// is contained in the collection.
		/// </summary>
		/// <param name="party">
		/// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/> to check for.
		/// </param>
		/// <returns>
		/// <b>true</b> if <paramref name="party"/> is contained in the collection, or <b>false</b> otherwise.
		/// </returns>
		public bool Contains(Party party) 
		{
			return this.List.Contains(party);
		}

		/// <summary>
		/// Gets whether a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/> with the
		/// specified name is contained in the collection.
		/// </summary>
		/// <param name="name">
		/// The name of the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/>.
		/// </param>
		/// <returns>
		/// <b>true</b> if an object with the name is contained in the collection, or <b>false</b> otherwise.
		/// </returns>
		public bool Contains(string name)
		{
			int index = this.IndexOf(name);
			return (index != -1);
		}

		/// <summary>
		/// Copies the collection into an <see cref="System.Array"/>.
		/// </summary>
		/// <param name="objects">
		/// The <see cref="System.Array"/> to copy the collection int.
		/// </param>
		/// <param name="index">
		/// The zero based index in the array at which to begin copying.
		/// </param>
		public void CopyTo(Party[] objects, int index) 
		{
			this.List.CopyTo(objects, index);
		}

		/// <summary>
		/// Gets the index of a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/>.
		/// </summary>
		/// <param name="party">
		/// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/> to get the index of.
		/// </param>
		/// <returns>
		/// The index of <paramref name="party"/> if it is contained in the collection, or -1 otherwise.
		/// </returns>
		public int IndexOf(Party party) 
		{
			return this.List.IndexOf(party);
		}

		/// <summary>
		/// Retrieves the index of a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/> from 
		/// the collection with the specified name.
		/// </summary>
		/// <param name="name">
		/// The name of the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/>.
		/// </param>
		/// <returns>
		/// The index of the item if found, or -1 otherwise.
		/// </returns>
		public int IndexOf(string name)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			for (int index = 0; index < this.List.Count; index++)
			{
				if (((Party)this.List[index]).Name == name)
				{
					return index;
				}
			}
			return -1;
		}

		/// <summary>
		/// Inserts a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/> into the collection.
		/// </summary>
		/// <param name="index">
		/// The zero based index at which to insert <paramref name="party"/>.
		/// </param>
		/// <param name="party">
		/// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/> to insert.
		/// </param>
		public void Insert(int index, Party party) 
		{
			this.List.Insert(index, party);
		}

		/// <summary>
		/// Removes a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/> from the collection.
		/// </summary>
		/// <param name="party">
		/// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/> to remove.
		/// </param>
		public void Remove(Party party) 
		{
			this.List.Remove(party); 
		}

		#endregion
	}
}

