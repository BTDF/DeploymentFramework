﻿namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;

    #endregion

    internal class BtsReceiveLocationCollection : System.Collections.ReadOnlyCollectionBase
    {
        public BtsReceiveLocationCollection() { }

        public BtsReceiveLocation this[string name]
        {
            get
            {
                BtsReceiveLocation item = null;
                foreach (BtsReceiveLocation currentitem in this.InnerList)
                {
                    if (currentitem.Name == name)
                    {
                        item = currentitem;
                        break;
                    }
                }
                return item;

            }
        }

        public BtsReceiveLocation this[int index]
        {
            get
            {
                return (BtsReceiveLocation)this.InnerList[index];
            }
        }

        internal void Add(BtsReceiveLocation item)
        {
            this.InnerList.Add(item);
        }
    }
}
