//-----------------------------------------------------------------------
// <copyright file="ConnectToWmiTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-06-07</date>
// <summary>Tests connecting to WMI, which is a problem for a few tasks</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.Globalization;
    using System.IO;
    using System.Management;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for connecting to WMI
    /// </summary>
    [TestClass]
    public class ConnectToWmiTest
    {
        

        public ConnectToWmiTest()
        {
        }

        [TestMethod]
        [Ignore]//("Ignore a test")]
        public void TestConnectToWmi()
        {
            try
            {
                System.Management.ConnectionOptions connOptions;

                string machine = ".";
                
                connOptions = new ConnectionOptions();

                ManagementScope scope = new ManagementScope(String.Format(CultureInfo.InvariantCulture,@"\\{0}\root\CIMv2", machine), connOptions);
                scope.Connect();
                Console.WriteLine("Successfully connected");

                ManagementPath path = new ManagementPath();
                path.ClassName = "Win32_Product";
                ManagementClass win32Product = new ManagementClass(scope, path, null);
                Console.WriteLine("Successfully created management class");
            }
            catch (ManagementException e)
            {
                Console.WriteLine(e.ToString());
                Assert.Fail("Can't connect");
            }
        }
    }
}


