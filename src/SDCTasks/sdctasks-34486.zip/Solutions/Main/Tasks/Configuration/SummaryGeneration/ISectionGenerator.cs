/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Simon Ransom</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.SummaryGeneration
{
	using System;
	using System.Xml;

	/// <summary>
	/// Summary description for SectionGenerator.
	/// </summary>
	internal interface ISectionGenerator
	{
		Section GenerateSection(string sourceFolder, string fileSpec, string name);
	}
}
