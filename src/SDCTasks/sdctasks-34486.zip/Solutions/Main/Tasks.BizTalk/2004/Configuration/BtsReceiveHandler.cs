﻿namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;
    using System.Reflection;

    #endregion

    internal class BtsReceiveHandler : BtsBaseObject
    {
        /// <summary>
        /// Internal Constructor
        /// </summary>
        /// <param name="actualBtsObject">The actual Microsoft.Biztalk.ExplorerOM.BtsReceiveHandler object that object will call.</param>
        /// <param name="catalogExplorer">The Microsoft.Sdc.Tasks.Configuration.BtsCatalogExplorer object.</param>
        internal BtsReceiveHandler(object actualBtsObject, BtsCatalogExplorer catalogExplorer)
        {
            this.btsCatalogExplorer = catalogExplorer;
            this.actualBtsObject = actualBtsObject;
        }

        /// <summary>
        /// Gets the name of the receive handler.
        /// </summary>
        public string Name
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("Name", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>
        /// Gets the host to which the receive handler is associated.
        /// </summary>
        public BtsHost Host
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("Host", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (value != null) ? new BtsHost(value, this.btsCatalogExplorer) : null;
            }
        }

        /// <summary>
        /// Gets the transport type for the receive handler.
        /// </summary>
        public BtsProtocolType TransportType
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("TransportType", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (value != null) ? new BtsProtocolType(value, this.btsCatalogExplorer) : null;
            }
        }
    }
}
