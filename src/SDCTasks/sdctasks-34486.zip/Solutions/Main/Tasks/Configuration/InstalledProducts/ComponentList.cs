using System;
using System.Collections;

namespace Microsoft.Sdc.Tasks.Configuration.InstalledProducts
{
	/// <summary>
	/// A collection of components
	/// </summary>
    public class ComponentList : CollectionBase
	{
		public Component this[int index]
		{
			get { return ((Component)(List[index])); }
			set { List[index] = value; }
		}

		public int Add(Component component)
		{
			return List.Add(component);
		}

		public void Insert(int index, Component component)
		{
			List.Insert(index, component);
		}

		public void Remove(Component component)
		{
			List.Remove(component);
		}

		public bool Contains(Component component)
		{
			return List.Contains(component);
		}

		public ComponentList()
		{
		}
	}
}
