//-------------------------------------------------------------------------------------
// <copyright file="Create.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Creates a host in a BizTalk Server.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.ReceiveHandler
{
    #region Using directives

    using System;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion


    #region Class Comments
    /// <summary>
    /// Creates a host in a BizTalk Server.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2004.ReceiveHandler.Create 
    ///                HostName="HostName"
    ///                TransportType="FILE"
    ///                CustomConfiguration="an xml string"
    ///                />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>HostName (Required)</i></para>
    /// <para>
    /// The name of the host where the handler is to be added.
    /// </para>
    /// <para><i>TransportType</i></para>
    /// <para>
    /// The type of transport. E.g. FILE, SQL, SOAP. 
    /// </para>
    /// <para><i>CustomConfiguration</i></para>
    /// <para>
    /// Any custom configuration data that may be required.
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// <para><i>username</i></para>
    /// <para>
    /// The username to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// <para><i>password</i></para>
    /// <para>
    /// The password to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///            <BizTalk2004.ReceiveHandler.Create 
    ///                HostName="HostName"
    ///                TransportType="FILE"
    ///            />
    ///      </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    #endregion
    public class Create : BizTalk2004TaskBase
    {
        private string hostName;
        private string transportType;
        private string customConfiguration;


        /// <summary>
        /// The name of the host to add the handler to.
        /// </summary>
        /// <value>The name of the host.</value>
        [Required]
        public string HostName
        {
            get { return this.hostName; }
            set { this.hostName = value; }
        }

        /// <summary>
        /// The transport type, e.g. FILE, SQL, SOAP etc
        /// </summary>
        /// <value></value>
        [Required]
        public string TransportType
        {
            get { return this.transportType; }
            set { this.transportType = value; }
        }

        /// <summary>
        /// Any custom configuration data as xml
        /// </summary>
        /// <value>
        ///</value>
        public string CustomConfiguration
        {
            get { return this.customConfiguration; }
            set { this.customConfiguration = value; }
        }

        /// <summary>
        /// Initializes a new instance of the Create class.
        /// </summary>
        public Create()
        {

        }

        /// <summary>
        /// Performs the action for this task
        /// </summary>
        protected override void InternalExecute()
        {
            BizTalkInstallation installation = this.GetInstallation();
            ReceiveHandler.AddNew(installation, this.transportType, this.hostName, this.customConfiguration);

        }
    }
}
        
