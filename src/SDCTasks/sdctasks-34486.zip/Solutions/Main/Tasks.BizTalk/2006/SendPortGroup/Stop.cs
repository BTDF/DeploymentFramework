//-----------------------------------------------------------------------
// <copyright file="Stop.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup
{
    using Microsoft.BizTalk.ExplorerOM;

    /// <summary>
    /// Stop SendPortGroup
    /// </summary>
    public class Stop : Microsoft.Sdc.Tasks.BizTalk2004.SendPortGroup.Stop
    {
        private string application;

        /// <summary>
        /// Gets or sets the application.
        /// </summary>
        /// <value>The application.</value>
        public string Application
        {
            get { return this.application; }
            set { this.application = value; }
        }

        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {
            if (string.IsNullOrEmpty(this.Application))
            {
                base.InternalExecute();
            }
            else
            {
                BtsCatalogExplorer explorer = this.GetBtsCatalogExplorer(this.Server, this.Database);

                Application app = explorer.Applications[this.Application];
                if (app != null)
                {
                    SendPortGroup group = app.SendPortGroups[this.Name];
                    if (group != null)
                    {
                        group.Status = PortStatus.Stopped;
                        explorer.SaveChanges();
                    }
                    else
                    {
                        Log.LogError(string.Format(System.Globalization.CultureInfo.InvariantCulture, "SendPortGroup not found: {0} for Application: {1}", this.Name, this.Application));
                        return;
                    }
                }
                else
                {
                    Log.LogError(string.Format(System.Globalization.CultureInfo.InvariantCulture, "Application not found: {0}", this.Application));
                    return;
                }
            }
        }
    }
}
