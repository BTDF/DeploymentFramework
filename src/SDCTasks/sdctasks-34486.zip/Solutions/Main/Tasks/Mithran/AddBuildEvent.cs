﻿
namespace Microsoft.Sdc.Tasks.Mithran
{
    using System.Globalization;
    using System;
    using System.Xml;
    using Microsoft.Build.Framework;
    using System.IO;
    using Microsoft.Sdc.Tasks.Configuration;

    public class AddBuildEvent : TaskBase
    {
        private string version;
        private string productPath;
        private string projectName;
        private string solutionName;
        private string buildEvent;
        private string buildEventPosition = "End";
        private string command;
        private string parameters;
        
        /// <summary>
        /// Initializes a new instance of the AddBuildEvent class.
        /// </summary>
        public AddBuildEvent()
        {
        }

        public string Parameters
        {
            get { return (this.parameters == null ? String.Empty : this.parameters); }
            set { this.parameters = value; }
        }

        [Required]
        public string Command
        {
            get { return (this.command == null ? String.Empty : this.command); }
            set { this.command = value; }
        }

        [Required]
        public string BuildEvent
        {
            get { return (this.buildEvent == null ? String.Empty : this.buildEvent); }
            set { this.buildEvent = value; }
        }
        
        /// <summary>
        /// Defaults to 'End'
        /// </summary>
        /// <value></value>
        public string BuildEventPosition
        {
            get { return (this.buildEventPosition == null ? String.Empty : this.buildEventPosition); }
            set { this.buildEventPosition = value; }
        }

        [Required]
        public string ProductPath
        {
            get { return (this.productPath == null ? String.Empty : this.productPath); }
            set { this.productPath = value; }
        }

        [Required]
        public string ProjectName
        {
            get { return (this.projectName == null ? String.Empty : this.projectName); }
            set { this.projectName = value; }
        }       

        [Required]
        public string SolutionName
        {
            get { return (this.solutionName == null ? String.Empty : this.solutionName); }
            set { this.solutionName = value; }
        }

        [Required]
        public string Version
        {
            get { return (this.version == null ? String.Empty : this.version); }
            set { this.version = value; }
        }        

        private string BuildBuildEvent(string buildPrefix, string buildSuffix)
        {
            if (buildSuffix == "Start")
            {
                return ";%" + buildPrefix + "BuildEvent" + buildSuffix + "%&#xd;&#xa;" + this.Command + " " + this.Parameters;

            }
            return this.Command + " " + this.Parameters + "&#xd;&#xa;;%" + buildPrefix + "BuildEvent" + buildSuffix + "%";
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            string destinationFolder = Path.Combine(Path.Combine(Path.Combine(this.ProductPath, @"Main\Src\Solutions"), this.SolutionName), this.ProjectName);
          
            string projFilename = Path.Combine(destinationFolder, this.ProjectName + ".csproj");

            Xml.ModifyFile modifyFile = new Xml.ModifyFile();
            modifyFile.BuildEngine = this.BuildEngine;

            modifyFile.Path = projFilename;
            modifyFile.RegularExpression = ";%" + this.BuildEvent + "BuildEvent" + this.BuildEventPosition + "%";
            modifyFile.NewValue = this.BuildBuildEvent(this.BuildEvent, this.BuildEventPosition);
            modifyFile.Execute();
        }        
    }
}
