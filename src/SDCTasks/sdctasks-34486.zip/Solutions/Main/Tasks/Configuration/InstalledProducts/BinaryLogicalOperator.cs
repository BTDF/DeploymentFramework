using System;

namespace Microsoft.Sdc.Tasks.Configuration.InstalledProducts
{
	/// <summary>
	/// Logical operator with two operands, such as And or Or.
	/// </summary>
	public enum BinaryLogicalOperator:byte
	{
		And,
		Or
	}
}
