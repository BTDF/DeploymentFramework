/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
<Author>Simon Ransom</Author>
<Date />
<Description />
<Copyright><![CDATA[
Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.SourceSafe
{
	using System;
	using System.IO;
	using System.Text;
	using System.Globalization;
	using Microsoft.Win32;
	using Microsoft.Sdc.Tasks.Configuration.Logging;

	/// <summary>
	/// Class representing a sourcesafe database.
	/// 
	/// Create one with a constructor that takes username and password or set them afterwards.
	/// </summary>
	internal class SourceSafeDatabase : ILogMessages
	{
		#region Logging
		private ILogger _logger = new Logger();
		public ILogger Logger
		{
			get
			{
				return _logger;
			}
		}
		#endregion
		#region Constructors		
		public SourceSafeDatabase()
		{
		}

		public SourceSafeDatabase(string username, string database)
		{
			this.Username = username;
			this.Database = database;
		}

		public SourceSafeDatabase(string username,string password, string database)
		{
			this.Username = username;
			if (password != null && password.Length>0)
			{
				this.Password = password;
			}
			this.Database = database;
		}
		#endregion

		#region Public Properties
		private string _username;
		public string Username
		{
			get
			{
				return _username;
			}
			set
			{
				this._username = value;
			}
		}

		private string _password;
		public string Password
		{
			get
			{
				return _password;
			}
			set
			{
				this._password = value;
			}
		}

		private string _database;
		public string Database
		{
			get
			{
				return _database;
			}
			set
			{
				this._database = value;
			}
		}
		#endregion

		#region Private Helper Functions
		private string GetLogonFlag()
		{
			StringBuilder sb = new StringBuilder();
			sb.Append("-Y");
			sb.Append(Username);
			if (Password != null)
			{
				sb.Append(",");
				sb.Append(Password);
			}
			return sb.ToString();
		}

		private string CreateLogFileParameter(string logFile)
		{
			if (logFile==null) return "";
			return String.Format(" -O@\"{0}\" ",logFile);
		}

		private ShellExecute CreateShellExecute(string logFile)
		{
			if (logFile != null)
			{
				// Check that the logfile folder exists
				DirectoryInfo logFolder = new FileInfo(logFile).Directory;
				if (! logFolder.Exists)
				{
					throw new DirectoryNotFoundException("Could not find directory "+logFolder.FullName);
				}
			}

			RegistryKey vssKey = null;
			string pathToSourceSafe = "";

			vssKey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\VisualStudio\6.0\Setup\Microsoft Visual SourceSafe Server");
			if (vssKey == null) 
			{
				//couldn't find the Server key so try the other one
				vssKey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\VisualStudio\6.0\Setup\Microsoft Visual SourceSafe");
				if (vssKey == null) 
				{
					throw new ApplicationException("Unable to find the VSS registry key.");
				}
			}
			pathToSourceSafe = Convert.ToString(vssKey.GetValue("ProductDir"));
			vssKey.Close();
			
			ShellExecute shellExecute = new ShellExecute();
		
			shellExecute.Filename = Path.Combine(pathToSourceSafe, @"win32\ss.exe");
			shellExecute.EnvironmentVariables["SSDIR"] = Database;
			if ((Username==null) || (Username.Length == 0)) 
			{
				Username = Environment.UserName;
			}			
			shellExecute.EnvironmentVariables["SSUSER"] = Username;
			return shellExecute;
		}
		#endregion

		public void Get(string project, string label, string workingDirectory,bool recursive)
		{
			Get(project,label,workingDirectory,recursive,null);
		}

		/// <summary>
		/// Get an item/project from sourcesafe
		/// </summary>
		/// <param name="project"></param>
		/// <param name="label">Label used for both</param>		
		/// <param name="workingDirectory"></param>
		/// <param name="logDirectory">Optional log directory</param>
		public void Get(string project, string label, string workingDirectory,bool recursive, string logFile) 
		{
			// Create a shell execute object with correct environment settings
			ShellExecute shellExecute = CreateShellExecute(logFile);			
			this.VSSGet(shellExecute, project, label, workingDirectory,recursive,logFile);			
		}

		public void Label(string project, string label)
		{
			Label(project,label,null);
		}

		/// <summary>
		/// Label a project in source safe
		/// </summary>
		/// <param name="project">Path to project such as $/MyProject</param>
		/// <param name="label">New label such as MY_RELEASE_1.0</param>
		public void Label(string project, string label, string logFile)
		{
			ShellExecute shellExecute = CreateShellExecute(logFile);

			// Now label the project
			String args = String.Format(CultureInfo.InvariantCulture, "Label -I-Y {3} {0} -L\"{1}\" \"{2}\"",
				CreateLogFileParameter(logFile),
				label,
				project,
				GetLogonFlag());
			Logger.LogComment(String.Format(CultureInfo.InvariantCulture,"Creating label {0} on project {1}",label,project));
			shellExecute.Arguments = args;			
			shellExecute.Execute();
			Logger.LogOutput(shellExecute.StandardError);	
		}
		
		public void CreateProject(string projectPath, string comment)
		{
			CreateProject(projectPath,comment,null);
		}


		/// <summary>
		/// Create a new sourcesafe project		
		/// </summary>
		/// <example>
		/// CreateProject("$/WORD") creates a project under the root called "Word"
		/// </example>
		/// <example>
		/// CreateProject("WORD") creates a project under the current project called "Word"
		/// </example>
		/// <param name="projectPath">Path to project</param>
		public void CreateProject(string projectPath, string comment, string logFile)
		{
			ShellExecute shellExecute = CreateShellExecute(logFile);			
			String args = String.Format(CultureInfo.InvariantCulture, "Create \"{2}\" {3} -I-Y {0} -C\"{1}\"",
				CreateLogFileParameter(logFile),
				comment,
				projectPath,
				GetLogonFlag());
			Logger.LogComment(String.Format(CultureInfo.InvariantCulture,"Creating project: {0}",projectPath));

			shellExecute.Arguments = args;			
			shellExecute.Execute();
			Logger.LogOutput(shellExecute.StandardError);								
		}

		public bool ProjectExists(string path)
		{
			return ProjectExists(path,null);
		}

		/// <summary>
		/// See if a project exists in source safe database
		/// </summary>
		/// <param name="path">VSS path such as $/MyProject</param>
		/// <returns>true if project exists</returns>
		public bool ProjectExists(string path, string logFile)
		{			
			ShellExecute shellExecute = CreateShellExecute(logFile);			
			String args = String.Format(CultureInfo.InvariantCulture, "Dir \"{1}\" -I-Y {2} -F- {0}",
				CreateLogFileParameter(logFile),
				path, 
				GetLogonFlag());			
			Logger.LogComment(String.Format(CultureInfo.InvariantCulture,"Checking project exists: {0}",path));

			shellExecute.Arguments = args;			
			shellExecute.Execute();
			Logger.LogOutput(shellExecute.StandardError);
			
			return (shellExecute.StandardError.IndexOf("is not an existing filename or project") < 0 );
		}

		public bool FileExists(string path)
		{
			return FileExists(path,null);
		}

		public bool FileExists(string path, string logFile)
		{			
			ShellExecute shellExecute = CreateShellExecute(logFile);
			String args = String.Format(CultureInfo.InvariantCulture, "Dir \"{1}\" -I-Y {2} {0}",
				CreateLogFileParameter(logFile),
				path, 
				GetLogonFlag());
			Logger.LogComment(String.Format(CultureInfo.InvariantCulture,"Checking file exists: {0}",path));

			shellExecute.Arguments = args;			
			shellExecute.Execute();
			Logger.LogOutput(shellExecute.StandardError);
			
			return ((shellExecute.StandardError.IndexOf("is not an existing filename or project") < 0 ) &&
					(shellExecute.StandardError.IndexOf("has been deleted")<0)
				);
		}

		public bool IsCheckedOut(string path)
		{
			
			ShellExecute shellExecute = CreateShellExecute(null);			
			String args = String.Format(CultureInfo.InvariantCulture, "Status \"{0}\" -I-Y {1} ",				
				path, 
				GetLogonFlag());
			Logger.LogComment(String.Format(CultureInfo.InvariantCulture,"IsCheckedOut {0}",path));

			shellExecute.Arguments = args;			
			shellExecute.Execute();
			Logger.LogOutput(shellExecute.StandardError);
			
			return (shellExecute.StandardOutput.IndexOf("No checked out files found") < 0 );
		}

		public void UndoCheckOut(string path)
		{
			UndoCheckOut(path,null);
		}

		public void UndoCheckOut(string path, string logFile)
		{
			ShellExecute shellExecute = CreateShellExecute(logFile);			
			String args = String.Format(CultureInfo.InvariantCulture, "Undocheckout \"{1}\" {2} -I-Y {0}",
				CreateLogFileParameter(logFile),				
				path,
				GetLogonFlag());
			Logger.LogComment(String.Format(CultureInfo.InvariantCulture,"Undocheckout {0}",path));

			shellExecute.Arguments = args;			
			shellExecute.Execute();
			Logger.LogOutput(shellExecute.StandardError);
		}

		public void Recover(string path)
		{
			Recover(path,null);
		}

		public void Recover(string path, string logFile)
		{
			ShellExecute shellExecute = CreateShellExecute(logFile);
			String args = String.Format(CultureInfo.InvariantCulture, "Recover \"{1}\" {2} -I-Y {0}",
				CreateLogFileParameter(logFile),
				path,
				GetLogonFlag());
			Logger.LogComment(String.Format(CultureInfo.InvariantCulture,"Recovering {0}",path));
			shellExecute.Arguments = args;			
			shellExecute.Execute();
			Logger.LogOutput(shellExecute.StandardError);
		}
		
		public void Delete(string path)
		{
			Delete(path,null);
		}

		/// <summary>
		/// Removes files and projects from VSS Explorer, and marks them as deleted; 
		/// the items still exist, however, and can be recovered using the Recover command.
		/// </summary>
		/// <param name="path"></param>
		public void Delete(string path, string logFile)
		{
			ShellExecute shellExecute = CreateShellExecute(logFile);
			String args = String.Format(CultureInfo.InvariantCulture, "Delete \"{1}\" {2} -I-Y {0}",
				CreateLogFileParameter(logFile),
				path,
				GetLogonFlag());
			Logger.LogComment(String.Format(CultureInfo.InvariantCulture,"Deleting {0}",path));

			shellExecute.Arguments = args;			
			shellExecute.Execute();
			Logger.LogOutput(shellExecute.StandardError);				
		}

		public void Destroy(string path)
		{
			Destroy(path,null);
		}

		/// <summary>
		/// Permanently removes a file or project.
		/// </summary>
		/// <param name="path"></param>
		public void Destroy(string path, string logFile)
		{
			ShellExecute shellExecute = CreateShellExecute(logFile);
			String args = String.Format(CultureInfo.InvariantCulture, "Destroy \"{1}\" {2} -I-Y {0}",
				CreateLogFileParameter(logFile),				
				path,
				GetLogonFlag());
			Logger.LogComment(String.Format(CultureInfo.InvariantCulture,"Destroying {0}",path));

			shellExecute.Arguments = args;			
			shellExecute.Execute();
			Logger.LogOutput(shellExecute.StandardError);				
		}

		public void CheckOut(string sourceFolder, string filename)
		{
			CheckOut(sourceFolder,filename,null);
		}

		/// <summary>
		/// Check out a file to a specified folder
		/// </summary>
		/// <param name="sourceFolder">Name of folder to check item out to</param>
		/// <param name="filename">Filename of item to be checked out</param>
		public void CheckOut(string sourceFolder, string filename, string logFile)
		{
			ShellExecute shellExecute = CreateShellExecute(logFile);
			string args = String.Format(CultureInfo.InvariantCulture, "Checkout -GL\"{2}\" {3} -I-N {0} \"{1}\"",
				CreateLogFileParameter(logFile),
				filename,
				sourceFolder,
				GetLogonFlag());			
			Logger.LogComment(String.Format(CultureInfo.InvariantCulture, "Checking out '{0}'...", filename));
		
			shellExecute.Arguments = args;
			shellExecute.Execute();
			Logger.LogOutput(shellExecute.StandardError);
		}

		public void CheckIn(string sourceFolder, string filename)
		{
			CheckIn(sourceFolder,filename,null);
		}

		/// <summary>
		/// Check file in
		/// </summary>
		/// <param name="sourceFolder">Source folder on local drive</param>
		/// <param name="filename">Filename of file to check in</param>
		public void CheckIn(string sourceFolder, string filename, string logFile)
		{
			ShellExecute shellExecute = CreateShellExecute(logFile);
			String args = String.Format(CultureInfo.InvariantCulture, "Checkin -GL\"{2}\" {3} -I-N {0} \"{1}\"",
				CreateLogFileParameter(logFile),
				filename,
				sourceFolder,
				GetLogonFlag());			
			Logger.LogComment(String.Format(CultureInfo.InvariantCulture, "Checking in '{0}'...", filename));
		
			shellExecute.Arguments = args;
			shellExecute.Execute();
			Logger.LogOutput(shellExecute.StandardError);
		}

		/// <summary>
		/// Add file to the current project
		/// </summary>
		/// <param name="filepath">Local path to file</param>
		public void Add(string filepath)
		{
			Add(filepath,null,null);
		}

		/// <summary>
		/// Add file to the current project
		/// </summary>
		/// <param name="filepath">Local path to file</param>
		/// <param name="project">Project in sourcesafe</param>
		public void Add(string filepath, string project)
		{
			Add(filepath,project,null);
		}

		/// <summary>
		/// Add a file to source safe
		/// </summary>
		/// <param name="filepath">Source folder on local drive</param>
		/// <param name="project">(Optional) Project in source safe to add the file to</param>
		public void Add(string filePath, string project, string logFile)
		{
			if (project != null) SetCurrentProject(project,logFile);

			ShellExecute shellExecute = CreateShellExecute(logFile);
			String args = String.Format(CultureInfo.InvariantCulture, "Add {2} -I-N {0} \"{1}\"",
				CreateLogFileParameter(logFile),
				filePath,				
				GetLogonFlag());
			
			Logger.LogComment(String.Format(CultureInfo.InvariantCulture, "Adding '{0}'...", filePath));

			shellExecute.Arguments = args;
			shellExecute.Execute();
			Logger.LogOutput(shellExecute.StandardError);
		}

		private void SetCurrentProject(string project, string logFile)
		{
			ShellExecute shellExecute = CreateShellExecute(logFile);
			String args = String.Format(CultureInfo.InvariantCulture, "cp \"{1}\" {2} -I-N {0}",
				CreateLogFileParameter(logFile),
				project,				
				GetLogonFlag());
			
			Logger.LogComment(String.Format(CultureInfo.InvariantCulture, "Setting current project to {0}", project));

			shellExecute.Arguments = args;
			shellExecute.Execute();
			Logger.LogOutput(shellExecute.StandardError);

		}

		public bool IsProjectLabelled(string project, string label)
		{
			ShellExecute shellExecute = CreateShellExecute(null);			
			String args = String.Format(CultureInfo.InvariantCulture, "History -L \"{0}\" -I-Y {1}",				
				project, 
				GetLogonFlag());
			Logger.LogComment(String.Format(CultureInfo.InvariantCulture,"IsProjectLabelled {0} with {1}",project,label));

			shellExecute.Arguments = args;			
			shellExecute.Execute();
			Logger.LogOutput(shellExecute.StandardError);
			
			return (shellExecute.StandardOutput.IndexOf("\""+label+"\"") >= 0 );
		}
		
		private void VSSGet(ShellExecute shellExecute, string project, string label, string workingDirectory, bool recursive, string logFile) 
		{			
			if (! (label == null || label.Length == 0))
			{
				label = String.Format(CultureInfo.InvariantCulture,"-VL\"{0}\"",label); 
			}

			Directory.CreateDirectory(Path.Combine(Environment.CurrentDirectory, "Output"));
			string getLocation = null;
			if (workingDirectory != null && workingDirectory.Length > 0) 
			{
				getLocation = workingDirectory;
			}
			else 
			{
				getLocation = Path.Combine(Environment.CurrentDirectory, "..");
			}

			string args = String.Format(" Get -GL\"{0}\" {4} -I-N {5} {1} {2} \"{3}\"",
				getLocation, 
				CreateLogFileParameter(logFile), 
				label,
				project,
				GetLogonFlag(),
				recursive?"-R":"");
	
			if (label.Length == 0) 
			{
				Logger.LogComment("Getting latest version");
			} 
			else 
			{
				Logger.LogComment(String.Format(CultureInfo.InvariantCulture, "Getting '{0}'...", label.Substring(3)));
			}
            
			shellExecute.Arguments = args;
			shellExecute.Execute();			
			Logger.LogDetailed(shellExecute.StandardError);
		}

	}
}
