/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/

namespace Microsoft.Sdc.Tasks.Configuration 
{
	using System;
	using System.Diagnostics;
	/// <summary>
	/// Represents a new Process
	/// </summary>
	internal class Process : System.Diagnostics.Process 
	{
		private string fileName;
		
        public Process() 
        {
        }
		/// <summary>
		/// Represents a new Process
		/// </summary>
		/// <param name="fileName">Path to the exe to start</param>
		public Process(string fileName) : this(fileName, String.Empty) 
		{	
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="fileName">Path to the exe to start</param>
		/// <param name="arguments">Arguments to start the process with</param>
		public Process(string fileName, string arguments) 
		{	
			this.fileName = fileName;
			base.StartInfo = new ProcessStartInfo(fileName, arguments);
            //TODO Now this is a direct wrapper around the Process from Diagnostics
			//base.StartInfo.RedirectStandardError = true;
			//base.StartInfo.UseShellExecute = false;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="fileName">Path to the exe to start</param>
		/// <param name="arguments">Arguments to start the process with</param>
		/// <returns>True if the process started successfully</returns>
		public static new Process Start(string fileName, string arguments) 
		{
			Process p = new Process(fileName, arguments);
			p.Start();
			return p;
		}
		
		/// <summary>
		/// 
		/// </summary>
		/// <param name="args">The arguments to start the process with</param>
		/// <returns>True if the process started successfully</returns>
		public new bool Start(string args) 
		{
			base.StartInfo.Arguments = args;
			return base.Start();
		}
	}
}
