//-------------------------------------------------------------------------------------
// <copyright file="ReceiveLocation.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Represents a combination of a specific address where the inbound message arrives and the pipeline processes the message.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using Directives
	
	using System;

	#endregion 

	/// <summary>
	/// Defines the copy mode to use when writing a message to a file.
	/// </summary>
	public enum FileTransportCopyMode : int
	{
		/// <summary>
		/// If file does not exist, creates a new file and writes to it.
		/// </summary>
		CreateNew = 1,

		/// <summary>
		/// Opens a file if it exists and appends a message to the end of the file. If file does not exist, creates a new file and writes to it.
		/// </summary>
		Append = 0,
		
		/// <summary>
		/// Opens a file if it exists and overwrites its content. If file does not exist, creates a new file and writes to it.
		/// </summary>
		Overwrite = 2
	}
}

