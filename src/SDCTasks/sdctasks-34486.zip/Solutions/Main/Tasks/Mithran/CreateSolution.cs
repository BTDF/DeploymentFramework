﻿
namespace Microsoft.Sdc.Tasks.Mithran
{
    using System.Globalization;
    using System;
    using System.Xml;
    using Microsoft.Build.Framework;
    using System.IO;
    using Microsoft.Sdc.Tasks.Configuration;


    public class CreateSolution : TaskBase
    {
        private string productPath;
        private string solutionName;
        private string version;
        private string templatePath;

        /// <summary>
        /// Initializes a new instance of the CreateSolution class.
        /// </summary>
        public CreateSolution()
        {
        }

        [Required]
        public string ProductPath
        {
            get { return (this.productPath == null ? String.Empty : this.productPath); }
            set { this.productPath = value; }
        }

        [Required]
        public string SolutionName
        {
            get { return (this.solutionName == null ? String.Empty : this.solutionName); }
            set { this.solutionName = value; }
        }

        [Required]
        public string Version
        {
            get { return (this.version == null ? String.Empty : this.version); }
            set { this.version = value; }
        }

        /// <summary>
        /// Defaults to the folder we are running from with a Templates suffix
        /// </summary>
        /// <value></value>
        public string TemplatePath
        {
            get
            {
                if (this.templatePath == null)
                {
                    //Get our executing path and use that if not provided by the user

                    Uri uri = new Uri(this.GetType().Assembly.CodeBase);
                    this.templatePath = Path.Combine(Path.GetDirectoryName(uri.LocalPath), "Templates");
                }

                return this.templatePath;

            }
            set { this.templatePath = value; }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            // create a new solution in the path provided


            string destinationFolder = Path.Combine(Path.Combine(this.ProductPath, @"Main\Src\Solutions"), this.SolutionName);
            if (Directory.Exists(destinationFolder))
            {
                throw new TaskException("Solution.Exists");
            }

            Folder.CopyFolder copy = new Folder.CopyFolder();
            copy.BuildEngine = this.BuildEngine;

            copy.Source = Path.Combine(Path.Combine(this.TemplatePath, "BlankSolution"), this.Version);
            copy.Destination = destinationFolder;

            copy.Execute();
        }
    }
}




