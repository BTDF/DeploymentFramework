//-----------------------------------------------------------------------
// <copyright file="GrantPrivilege.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-03-23</date>
// <summary>Grants the specified privilege to the Active Directory user.</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.ActiveDirectory.User
{
    using System;
    using Microsoft.Build.Framework;
    using Microsoft.Build.Utilities;
    using System.Resources;
    using System.Reflection;
    using System.Xml;
    using System.Globalization;
    using AD = Microsoft.Sdc.Tasks.Configuration.ActiveDirectory;

    /// <summary>
    /// Grants the specified privilege to the Active Directory user.
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<ActiveDirectory.User.GrantPrivilege UserName="userName" Privilege="privilege" DomainName="domainName" />]]></code>
    /// <para>where:</para>
    /// <para><i>userName (Required)</i></para>
    /// <para>The groupname to create.</para>
    /// <para><i>privilege (Required)</i></para>
    /// <para>The privilege to be granted to the user.</para>
    /// <para><i>domainName</i></para>
    /// <para>The domain the group is to be added to. If not specified it defaults to the local machine.</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <ActiveDirectory.User.GrantPrivilege
    ///             UserName="user"
    ///             Privilege="SeNetworkLogonRight"  />
    ///             DomainName="mydomain"
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class GrantPrivilege : TaskBase
    {
        private string userName;
        private string privilege;
        private string domainName;

        /// <summary>
        /// Initializes a new instance of the GrantPrivilege class.
        /// </summary>
        public GrantPrivilege()
        {
        }
        
        /// <summary>
        /// The username of the Active Directory user that is to aquire the privilege
        /// </summary>
        /// <value>The username to grant the privilege to</value>
        [Required]
        public string UserName
        {
            get
            {
                return (this.userName == null ? String.Empty : this.userName);
            }

            set
            {
                this.userName = value;
            }
        }

        /// <summary>
        /// The privilege to grant the user
        /// </summary>
        /// <value>Any one of the following: 
        ///     
        ///     "SeInteractiveLogonRight", 
        ///     "SeNetworkLogonRight",  
        ///     "SeBatchLogonRight", 
        ///     "SeServiceLogonRight", 
        ///     "SeDenyInteractiveLogonRight",
        ///     "SeDenyNetworkLogonRight", 
        ///     "SeDenyBatchLogonRight", 
        ///     "SeDenyServiceLogonRight", 
        ///     "SeRemoteInteractiveLogonRight", 
        ///     "SeDenyRemoteInteractiveLogonRight", 
        ///     "SeIncreaseQuotaPrivilege",
        ///     "SeAuditPrivilege", 
        ///     "SeAssignPrimaryTokenPrivilege"
        /// </value>
        [Required]
        public string Privilege
        {
            get
            {
                return (this.privilege == null ? String.Empty : this.privilege);
            }

            set
            {
                this.privilege = value;
            }
        }

        /// <summary>The domain the user belongs to. If not specified it defaults to the local machine.</summary>
        /// <value>The user's domain.</value>
        public string DomainName
        {
            get
            {
                return (this.domainName == null ? String.Empty : this.domainName);
            }

            set
            {
                this.domainName = value;
            }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            #region Execute code
            Log.LogMessageFromResources("ActiveDirectory.GrantPrivilege", this.privilege, this.userName);

            if (!AD.User.Exists(this.userName, this.domainName))
            {
                throw new TaskException("ActiveDirectory.UserDoesNotExist", this.userName);
            }
            else
            {
                AD.User user = AD.User.Load(this.userName, this.domainName);
                if (!user.GrantPrivilege((AD.Privilege)Enum.Parse(typeof(AD.Privilege), this.privilege, true)))
                {
                    throw new TaskException("ActiveDirectory.CannotGrantPrivilegeToUser", this.privilege, this.userName);
                }
            }
            #endregion
        }
    }
}

