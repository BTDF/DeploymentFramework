﻿//-----------------------------------------------------------------------
// <copyright file="ShortenPath.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Giles Knap</author>
// <email>gilesk</email>
// <date>2006-03-03</date>
// <summary>
// gets various environment information
// </summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks
{
    #region Using directives
    using System;
    using System.Text;
    using System.IO;
    using Microsoft.Build.BuildEngine;
    using Microsoft.Build.Framework;
    using Microsoft.Build.Utilities;
    using Microsoft.Build.Shared;
    #endregion


    /// <summary>
    /// Retrieves information about the execution environment
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<GetEnvironment>
    ///                 <Output TaskParameter="CurrentDirectory" PropertyName="out1" />
    ///                 <Output TaskParameter="OSVersion" PropertyName="out2" />
    ///                 <Output TaskParameter="ProcessorCount" PropertyName="out3" />
    ///                 <Output TaskParameter="SystemDirectory" PropertyName="out4" />
    ///                 <Output TaskParameter="UserInteractive" PropertyName="out5" />
    ///                 <Output TaskParameter="LogicalDrives" PropertyName="out6" />
    ///                </GetEnvironment>]]></code>
    /// <para>where:</para>
    /// <para><i>CurrentDirectory</i></para>
    /// <para>Current working directory</para>
    /// <para><i>OSVersion</i></para>
    /// <para>OS Verwsion Number</para>
    /// <para><i>ProcessorCount</i></para>
    /// <para>number of processors</para>
    /// <para><i>SystemDirectory</i></para>
    /// <para>Full path to system directory</para>
    /// <para><i>UserInteractive</i></para>
    /// <para>true if the current process is running in user interactive mode</para>
    /// <para><i>LogicalDrives</i></para>
    /// <para>List of names logical drives on the system</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <GetEnvironment>
    ///                 <Output TaskParameter="CurrentDirectory" PropertyName="out1" />
    ///                 <Output TaskParameter="OSVersion" PropertyName="out2" />
    ///                 <Output TaskParameter="ProcessorCount" PropertyName="out3" />
    ///                 <Output TaskParameter="SystemDirectory" PropertyName="out4" />
    ///                 <Output TaskParameter="UserInteractive" PropertyName="out5" />
    ///                 <Output TaskParameter="LogicalDrives" PropertyName="out6" />
    ///         </GetEnvironment>
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class GetEnvironment : TaskBase
    {
        private string     currentDirectory;
        private string     oSVersion;
        private int        processorCount;
        private string     systemDirectory;
        private bool       userInteractive;
        private string[]   logicalDrives;

        [Output]
        public string CurrentDirectory
        {
            get { return currentDirectory; }
            set { currentDirectory = value; }
        }

        [Output]
        public string OSVersion
        {
            get { return oSVersion; }
            set { oSVersion = value; }
        }

        [Output]
        public int ProcessorCount
        {
            get { return processorCount; }
            set { processorCount = value; }
        }

        [Output]
        public string SystemDirectory
        {
            get { return systemDirectory; }
            set { systemDirectory = value; }
        }

        [Output]
        public bool UserInteractive
        {
            get { return userInteractive; }
            set { userInteractive = value; }
        }

        [Output]
        public string[] LogicalDrives
        {
            get { return logicalDrives; }
            set { logicalDrives = value; }
        }

        public GetEnvironment()
        {
        }


        protected override void InternalExecute()
        {
            currentDirectory = System.Environment.CurrentDirectory;
            oSVersion = System.Environment.OSVersion.ToString();
            processorCount = System.Environment.ProcessorCount;
            systemDirectory = System.Environment.SystemDirectory;
            userInteractive = System.Environment.UserInteractive;
            logicalDrives = System.Environment.GetLogicalDrives();
        }
    }
}
