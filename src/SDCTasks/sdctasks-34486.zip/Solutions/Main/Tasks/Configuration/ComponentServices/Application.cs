/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.ComponentServices 
{
	using System;
	using System.Globalization;
	using System.IO;
	using System.Runtime.InteropServices;
	using System.Reflection;
	using Microsoft.Win32;

	/// <summary>
	/// This type represents a COM+ Application.
	/// </summary>
	internal class Application 
	{
        
		private ComWrapper          cac;
		private ComWrapper          application;
		private ComWrapper          applications;
		private string              identity = "Interactive User"; //Default
		private string              password;
		private string              name;
		private bool                passwordSpecified;
		private string              machineName;
		private Guid                applicationId = Guid.NewGuid();
		private bool                accessChecksEnabled = true;
		private Activation          activation = Activation.Local;
		private ComponentCollection components;
		private int                 shutdownAfter =3; //default
		private bool                runForever; //default false
		private bool                changeable;
		private bool                deleteable;
		private bool                isDirty;
 
		internal Application(ComWrapper catalogObject, ComWrapper applicationCollection, ComWrapper catalog) 
		{
			this.application = catalogObject;
			this.applications = applicationCollection;
			this.cac = catalog;
			this.name = catalogObject.GetProperty("Name").ToString();
			applicationId = new Guid(catalogObject.GetProperty("Value", "ID").ToString());
			identity = catalogObject.GetProperty("Value", "Identity").ToString();
			this.accessChecksEnabled = Convert.ToBoolean(catalogObject.GetProperty("Value", "ApplicationAccessChecksEnabled"), CultureInfo.InvariantCulture);
			this.activation = (Activation)catalogObject.GetProperty("Value", "Activation");
			this.shutdownAfter = Convert.ToInt32(catalogObject.GetProperty("Value", "ShutdownAfter"), CultureInfo.InvariantCulture);
			this.runForever = Convert.ToBoolean(catalogObject.GetProperty("Value", "RunForever"), CultureInfo.InvariantCulture);
			this.changeable = Convert.ToBoolean(catalogObject.GetProperty("Value", "Changeable"), CultureInfo.InvariantCulture);
			this.deleteable = Convert.ToBoolean(catalogObject.GetProperty("Value", "Deleteable"), CultureInfo.InvariantCulture);
			ComWrapper componentsColl = new ComWrapper(applications.CallMethod("GetCollection", new object[] {"Components", catalogObject.GetProperty("Key")}));
			componentsColl.CallMethod("Populate");
			components = new ComponentCollection(this, componentsColl);         
			isDirty = false;
		}

		public Application()
		{
		}

		public Application(string applicationName) : this(applicationName, null)
		{
		}

		public Application(string applicationName, string machineName) 
		{
			this.name = applicationName;
			this.machineName = machineName;


            
			isDirty = true;
		}
		static public void Shutdown(string applicationName) 
		{
			ComWrapper cac = new ComWrapper("COMAdmin.COMAdminCatalog");
			cac.CallMethod("ShutdownApplication", new Object [] {applicationName});
		}

		void CreateApplication() 
		{

			cac = GetComAdminCatalog(machineName);
			applications = GetApplications(cac, machineName);            
			
			application = new ComWrapper(applications.CallMethod("Add", new object[] {}));
			//Fails, does not work, need a better way of adding a new application.
			application.SetProperty("Value", new Object[] {"Name",Name});
			application.SetProperty("Value", new Object[] {"ID",ApplicationId});
			applications.CallMethod("SaveChanges");			
		}

		public void Save() 
		{
			if (isDirty) 
			{
				if (application == null) 
				{
					CreateApplication();
				}

				bool originalChangeableValue = (bool)application.GetProperty("Value", "Changeable");
				//the logic here is
				//we are updating some properties so if original changeable is false we need to set it to true, update and then set back
                
				if (!originalChangeableValue) 
				{
					application.SetProperty("Value", new object[] {"Changeable", true});
					applications.CallMethod("SaveChanges");
				}
            
				if (passwordSpecified) 
				{
					application.SetProperty("Value", new object[] {"Password", password});
				}
				application.SetProperty("Value", new object[] {"Identity", identity});
				application.SetProperty("Value", new object[] {"ApplicationAccessChecksEnabled", accessChecksEnabled});
				application.SetProperty("Value", new object[] {"Activation", activation.ToString()});
				application.SetProperty("Value", new object[] {"RunForever", runForever});
				application.SetProperty("Value", new object[] {"ShutdownAfter", shutdownAfter});
				application.SetProperty("Value", new object[] {"Changeable", changeable});
				application.SetProperty("Value", new object[] {"Deleteable", deleteable});
				applications.CallMethod("SaveChanges");
				isDirty = false;
			}
			//Save all the components 
			foreach(Component c in Components) 
			{
				c.Save();
			}
		}

		static public Application Load(string applicationName) 
		{
			return Load(applicationName, "localhost");
		}
        
		static public Application Load(string applicationName, string machineName) 
		{
			ComWrapper cac = GetComAdminCatalog(machineName);
			ComWrapper applicationCollection = GetApplications(cac, machineName);
            
			int j = (int)applicationCollection.GetProperty("Count");
			int i = 0;          
			while (i < j)
			{
				Object objTempApp = applicationCollection.GetProperty("item", i) ;
				ComWrapper catalogObject = new ComWrapper(objTempApp);
                
				if (catalogObject.GetProperty("Name").ToString() == applicationName)
				{
					return new Application(catalogObject, applicationCollection, cac);
				}
				i = i + 1;
			}

			return null;

            
		}

		static public bool Exists(string applicationName) 
		{
			return Exists(applicationName, "localhost");            
		}

		static public bool Exists(string applicationName, string machineName) 
		{
			ComWrapper applicationCollection = GetApplications(machineName);
            
			int j = (int)applicationCollection.GetProperty("Count");
			int i = 0;
			while (i < j)
			{
				Object objTempApp = applicationCollection.GetProperty("item", i);
				ComWrapper catalogObject = new ComWrapper(objTempApp);
				string name = catalogObject.GetProperty("Name").ToString();
				if (name == applicationName) 
				{
					return true;                    
				}
				i = i + 1;
			}
			return false;
		}

		/// <summary>
		/// Deletes an application and all its components
		/// </summary>
		/// <param name="applicationName">This is case sensitive. If applicationName exists multiple times then all matches will all be deleted</param>
		/// <param name="machineName">Use localhost to check your local machine</param>
		static public void Delete(string applicationName, string machineName) 
		{
			ComWrapper applicationCollection = GetApplications(machineName);
            
			int i = ((int)applicationCollection.GetProperty("Count")) - 1;
			int j = 0;
			//count down because we are deleting them
			while (i >= j)
			{
				Object objTempApp = applicationCollection.GetProperty("item", i) ;
				ComWrapper catalogObject = new ComWrapper(objTempApp);
				string name = catalogObject.GetProperty("Name").ToString();
				if (name == applicationName) 
				{                   
					catalogObject.SetProperty("Value", new object[] {"Deleteable", true});
					applicationCollection.CallMethod("SaveChanges");
					applicationCollection.CallMethod("Remove", new Object[] {i});
					applicationCollection.CallMethod("SaveChanges");
				}

				i -=1;
			}

		}
		/// <summary>
		/// Deletes an application and all its components
		/// </summary>
		/// <param name="applicationName">This is case sensitive. If applicationName exists multiple times then all matches will all be deleted</param>
		static public void Delete(string applicationName) 
		{
			Delete(applicationName, "localhost");           
		}

		/// <summary>
		/// Adds a component to the application
		/// </summary>
		/// <param name="path">This is case sensitive. It is the fully qualified path the the dll</param>
		/// <param name="applicationName">This is case sensitive. If applicationName exists multiple times then all matches will all be deleted</param>
		static public void AddComponent(string path, string applicationName) 
		{
			AddComponent(path,applicationName, "localhost");
		}

		/// <summary>
		/// Adds a component to the application
		/// </summary>
		/// <param name="path">This is case sensitive. It is the fully qualified path the the dll</param>
		/// <param name="applicationName">This is case sensitive. If applicationName exists multiple times then all matches will all be deleted</param>
		/// <param name="machineName">Use localhost to check your local machine</param>
		static public void AddComponent(string path, string applicationName, string machineName) 
		{
            
			//call this here because we need the cac object later for the install
			ComWrapper cac = GetComAdminCatalog(machineName);
			ComWrapper applications = GetApplications(cac, machineName);
			ComWrapper appObject = null;
            
			// search my application if it is already installed
			int j = (int)applications.GetProperty("Count");
			int i = 0;
			while (i < j)
			{
				Object objTempApp = applications.GetProperty("item", i) ;
				ComWrapper catalogObject = new ComWrapper(objTempApp);
				string name = catalogObject.GetProperty("Name").ToString();
				if (name == applicationName)
				{
					appObject = catalogObject;
					break;
				}
				i = i + 1;
			}

			// Create my application, if it does not exist
			if (appObject == null) 
			{
				appObject = new ComWrapper(applications.CallMethod("Add"));
				appObject.SetProperty("Value", new object[] {"Name",applicationName});
				applications.CallMethod("SaveChanges");
			}

			if (appObject != null) 
			{
				try 
				{
					cac.CallMethod("InstallComponent", new object[] {applicationName, path, String.Empty, String.Empty});
				}
				catch (COMException ex) 
				{
					throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to add component '{0}' to application '{1}'. Check the component can be manually added to COM+ successfully.", path, applicationName), ex);
				}
			}
		}

		/// <summary>
		/// Adds a role to the application
		/// </summary>
		/// <param name="rolename">The name of the role to add</param>
		/// <param name="applicationName">This is case sensitive. If applicationName exists multiple times then all matches will all be deleted</param>
		static public void AddRole(string rolename, string applicationName) 
		{
			AddRole(rolename,applicationName,"localhost");
		}

		/// <summary>
		/// Adds a role to the application
		/// </summary>
		/// <param name="rolename">The name of the role to add</param>
		/// <param name="applicationName">This is case sensitive. If applicationName exists multiple times then all matches will all be deleted</param>
		/// <param name="machineName">Use localhost to check your local machine</param>
		static public void AddRole(string rolename, string applicationName, string machineName) 
		{            
			//call this to get the roles in this application.
			ComWrapper Roles = GetApplicationRoles(applicationName,machineName);

			if (Roles != null) 
			{
				try 
				{
					ComWrapper newRole = new ComWrapper(Roles.CallMethod("Add"));
					newRole.SetProperty("Value", new Object[] {"Name", rolename});
					Roles.CallMethod("SaveChanges");
				}
				catch (Exception ex) 
				{
					throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to add role '{0}' to application '{1}'. Check the component can be manually added to COM+ successfully.", rolename, applicationName), ex);
				}
			}
		}

		/// <summary>
		/// Returns true if the role exists in the application
		/// </summary>
		/// <param name="rolename">The name of the role to add</param>
		/// <param name="applicationName">This is case sensitive. If applicationName exists multiple times then all matches will all be deleted</param>
		static public bool RoleExists(string rolename, string applicationName) 
		{
			return RoleExists(rolename,applicationName,"localhost");
		}

		/// <summary>
		/// Returns true if the role exists in the application
		/// </summary>
		/// <param name="rolename">The name of the role to add</param>
		/// <param name="applicationName">This is case sensitive. If applicationName exists multiple times then all matches will all be deleted</param>
		/// <param name="machineName">Use localhost to check your local machine</param>
		static public bool RoleExists(string rolename, string applicationName, string machineName) 
		{
           
			//call this to get the roles in this application.
			ComWrapper Roles = GetApplicationRoles(applicationName,machineName);

			if (Roles != null) 
			{
				int j = (int)Roles.GetProperty("Count");
				int i = 0;
				while (i < j)
				{
					Object objTempApp = Roles.GetProperty("item", i) ;
					ComWrapper catalogObject = new ComWrapper(objTempApp);
					string name = catalogObject.GetProperty("Name").ToString();
					if (name == rolename)
					{
						return true;
					}
					i = i + 1;
				}

			}
			return false;

		}
				
		/// <summary>
		/// Adds a user to the application role
		/// </summary>
		/// <param name="username">The name of the user to add</param>
		/// <param name="rolename">The name of the role to add</param>
		/// <param name="applicationName">This is case sensitive. If applicationName exists multiple times then all matches will all be deleted</param>
		static public void AddUserToRole(string username, string rolename, string applicationName) 
		{
			AddUserToRole(username, rolename, applicationName, "localhost");
		}

		/// <summary>
		/// Adds a user to an application role, inside of an application.
		/// </summary>
		/// <param name="username">The name of the user to add</param>
		/// <param name="rolename">The name of the role to add</param>
		/// <param name="applicationName">This is case sensitive. If applicationName exists multiple times then all matches will all be deleted</param>
		/// <param name="machineName">Use localhost to check your local machine</param>
		static public void AddUserToRole(string username, string rolename, string applicationName, string machineName) 
		{
			//call this to get the roles in this application.
			ComWrapper Roles = GetApplicationRoles(applicationName,machineName);

			if (Roles != null) 
			{
				try 
				{
					int j = (int)Roles.GetProperty("Count");
					int i = 0;
					while (i < j)
					{
						Object objTempApp = Roles.GetProperty("item", i);
						ComWrapper catalogObject = new ComWrapper(objTempApp);
						string name = catalogObject.GetProperty("Name").ToString();
						if (name == rolename)
						{
							//Set UsersInRole = Roles.GetCollection("UsersInRole", Roles.Item(IndexComp).Key)
							ComWrapper UsersInRole = new ComWrapper(Roles.CallMethod("GetCollection", new object[] {"UsersInRole",catalogObject.GetProperty("Key")}));
							// UsersInRole.Populate
							UsersInRole.CallMethod("Populate");
							//Set NewUser = UsersInRole.Add
							ComWrapper NewUser = new ComWrapper(UsersInRole.CallMethod("Add"));
							// NewUser.Value("User") = UserName
							NewUser.SetProperty("Value", new Object[] {"User",username});
							// UsersInRole.SaveChanges
							UsersInRole.CallMethod("SaveChanges");

							break;
						}
						i = i + 1;
					}

				}
				catch (Exception ex) 
				{
					throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to find role '{0}' to application '{1}'.", rolename, applicationName), ex);
				}
			}
		}

		/// <summary>
		/// Returns true if the role exists in the application role
		/// </summary>
		/// <param name="username">The name of the user</param>
		/// <param name="rolename">The name of the role</param>
		/// <param name="applicationName">This is case sensitive. If applicationName exists multiple times then all matches will all be deleted</param>
		static public bool UserExistsInRole(string username, string rolename, string applicationName) 
		{
			return UserExistsInRole(username,rolename,applicationName,"localhost");
		}

		/// <summary>
		/// Returns true if the role exists in the application role
		/// </summary>
		/// <param name="username">The name of the user to add</param>
		/// <param name="rolename">The name of the role to add</param>
		/// <param name="applicationName">This is case sensitive. If applicationName exists multiple times then all matches will all be deleted</param>
		/// <param name="machineName">Use localhost to check your local machine</param>
		static public bool UserExistsInRole(string username, string rolename, string applicationName, string machineName) 
		{
			//call this to get the roles in this application.
			ComWrapper Roles = GetApplicationRoles(applicationName,machineName);

			if (Roles != null) 
			{
				try 
				{
					int j = (int)Roles.GetProperty("Count");
					int i = 0;
					while (i < j)
					{
						Object objTempApp = Roles.GetProperty("item", i);
						ComWrapper catalogObject = new ComWrapper(objTempApp);
						string name = catalogObject.GetProperty("Name").ToString();
						if (name == rolename)
						{
							ComWrapper UsersInRole = new ComWrapper(Roles.CallMethod("GetCollection", new object[] {"UsersInRole",catalogObject.GetProperty("Key")}));
							UsersInRole.CallMethod("Populate");
							int uCount = (int)UsersInRole.GetProperty("Count");
							int ui = 0;
							while (ui<uCount) 
							{								
								ComWrapper UserInRole = new ComWrapper(UsersInRole.GetProperty("item", ui));
								string UName = UserInRole.GetProperty("Name").ToString();
								if (UName == username)
								{		
									return true;
								}
								ui++;
							}
							break;
						}
						i = i + 1;
					}

				}
				catch (Exception ex) 
				{
					throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to find role '{0}' to application '{1}'.", rolename, applicationName), ex);
				}
			}
			return false;
		}
				
		/// <summary>
		/// Adds a role to a particular all components in an application
		/// </summary>
		/// <param name="rolename">The name of the role to add</param>
		/// <param name="applicationName">This is case sensitive. If applicationName exists multiple times then all matches will all be deleted</param>
		static public void AddRoleToComponent(string rolename, string applicationName) 
		{
			AddRoleToComponent(rolename, "", applicationName, "localhost");
		}

		/// <summary>
		/// Adds a role to a particular one component in an application
		/// </summary>
		/// <param name="rolename">The name of the role to add</param>
		/// <param name="ComponentName">The name of the component to add the role to</param>
		/// <param name="applicationName">This is case sensitive. If applicationName exists multiple times then all matches will all be deleted</param>
		static public void AddRoleToComponent(string rolename, string ComponentName, string applicationName) 
		{
			AddRoleToComponent(rolename, ComponentName, applicationName, "localhost");
		}

		/// <summary>
		/// Adds a role to a particular one or all components in an application
		/// </summary>
		/// <param name="rolename">The name of the role to add</param>
		/// <param name="ComponentName">The name of the component to add the role to, if left blank adds to all components</param>
		/// <param name="applicationName">This is case sensitive. If applicationName exists multiple times then all matches will all be deleted</param>
		/// <param name="machineName">Use localhost to check your local machine</param>
		static public void AddRoleToComponent(string rolename, string ComponentName, string applicationName, string machineName) 
		{		
			ComWrapper ComponentsInPackage = GetApplicationComponents(applicationName,machineName);
			if (ComponentsInPackage != null) 
			{

				int j = (int)ComponentsInPackage.GetProperty("Count");
				int i = 0;
				while (i < j)
				{
					ComWrapper Comp = new ComWrapper(ComponentsInPackage.GetProperty("Item",i));
					string name = (string)Comp.GetProperty("name");
					if (name==ComponentName || ComponentName=="") 
					{
						ComWrapper RolesForComponent = new ComWrapper(ComponentsInPackage.CallMethod("GetCollection", new object[] {"RolesForComponent",Comp.GetProperty("Key")}));
						ComWrapper NewComponentRoleAssociation = new ComWrapper(RolesForComponent.CallMethod("Add"));
						NewComponentRoleAssociation.SetProperty("Value", new Object[] {"Name",rolename});
						RolesForComponent.CallMethod("SaveChanges");
					}
					i++;
				}
			}
		}


		/// <summary>
		/// Does a role on a particular one or all components in an application exist?
		/// BUG: Does not work, the ability to surfice this information is not working as desired.
		/// </summary>
		/// <param name="rolename">The name of the role to add</param>
		/// <param name="ComponentName">The name of the component to add the role to</param>
		/// <param name="applicationName">This is case sensitive. If applicationName exists multiple times then all matches will all be deleted</param>
		static public bool RoleOnComponentExists(string rolename, string ComponentName, string applicationName) 
		{		
			return RoleOnComponentExists(rolename,ComponentName,applicationName,"localhost");
		}

		/// <summary>
		/// Does a role on a particular one or all components in an application exist?
		/// BUG: Does not work, the ability to surfice this information is not working as desired.
		/// </summary>
		/// <param name="rolename">The name of the role to add</param>
		/// <param name="applicationName">This is case sensitive. If applicationName exists multiple times then all matches will all be deleted</param>
		static public bool RoleOnComponentExists(string rolename, string applicationName) 
		{		
			return RoleOnComponentExists(rolename,"",applicationName,"localhost");
		}

		/// <summary>
		/// Does a role on a particular one or all components in an application exist?
		/// BUG: Does not work, the ability to surfice this information is not working as desired.
		/// </summary>
		/// <param name="rolename">The name of the role to add</param>
		/// <param name="ComponentName">The name of the component to add the role to, if blank all components will be checked.</param>
		/// <param name="applicationName">This is case sensitive. If applicationName exists multiple times then all matches will all be deleted</param>
		/// <param name="machineName">Use localhost to check your local machine</param>
		static public bool RoleOnComponentExists(string rolename, string ComponentName, string applicationName, string machineName) 
		{		
			ComWrapper ComponentsInPackage = GetApplicationComponents(applicationName,machineName);
			if (ComponentsInPackage != null) 
			{

				int j = (int)ComponentsInPackage.GetProperty("Count");
				int i = 0;
				while (i < j)
				{
					ComWrapper Comp = new ComWrapper(ComponentsInPackage.GetProperty("Item",i));
					string name = (string)Comp.GetProperty("name");
					if (name==ComponentName || ComponentName=="") 
					{
						ComWrapper RolesForComponent = new ComWrapper(ComponentsInPackage.CallMethod("GetCollection", new object[] {"RolesForComponent",Comp.GetProperty("Key")}));
						RolesForComponent = new ComWrapper(ComponentsInPackage.CallMethod("GetCollection", new object[] {"PropertyInfo",Comp.GetProperty("Key")}));
						j = (int)RolesForComponent.GetProperty("Count");
						i = 0;
						while (i < j)
						{
							ComWrapper CompRole = new ComWrapper(RolesForComponent.GetProperty("Item",i));
							name = (string)CompRole.GetProperty("name");
							if (name==rolename) 
							{
								return true;
							}
						}
					}
					i++;
				}
			}
			return false;
		}

		/// <summary>
		/// Updated the information on an application.
		/// </summary>
		/// <param name="applicationName">This is case sensitive. If applicationName exists multiple times then all matches will all be deleted</param>
		/// <param name="identity">The name of the user identity</param>
		/// <param name="password">The password of the user identity</param>
		/// <param name="enforceAccessChecks">Boolean to set enforceAccessChecks</param>
		/// <param name="activation">The type of activation, inproc or out of proc</param>
		/// <param name="runForever">Boolean to set run for ever</param>
		/// <param name="shutdownAfter">Shutdown after</param>		
		static public void UpdateApplication(string applicationName, string identity, string password, bool enforceAccessChecks, Activation activation, bool runForever, string shutdownAfter) 
		{
			Application application = Application.Load(applicationName);
			if (identity.Length > 0) 
			{
				application.Identity = identity;
				application.Password = password;
			}
			application.Activation = activation;
			application.RunForever = runForever;
			if (shutdownAfter != null && shutdownAfter.Length > 0) 
			{
				int shutdown  = Convert.ToInt32(shutdownAfter,CultureInfo.InvariantCulture);
				application.ShutdownAfter = shutdown;
			}
			application.AccessChecksEnabled = enforceAccessChecks;
			application.Save();
		}

		/// <summary>
		/// used for a .net component to add a vaild assembly, that would specify it's own application group
		/// </summary>
		/// <param name="path">The full path to the assembly dll</param>
		/// <param name="runtime">The run time version of the dll</param>
		static public bool AddComponentValidAssembly(string path, string runtime)
		{
			Application app = new Application();
			FileInfo fi = new FileInfo(path);
			//detect if its a .NET assembly or not
			if (app.IsValidAssemblyFile(fi.FullName)) 
			{
				string version;
				if (runtime.Length == 0 || runtime == "1.0") 
				{
					version = "v1.0.3705";
				} 
				else 
				{
					version = "v1.1.4322";
				}
				try 
				{
					RegistryKey runtimeKey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\.NETFramework");
					string pathToFramework = Convert.ToString(runtimeKey.GetValue("InstallRoot"));
					runtimeKey.Close();
					ShellExecute shellExecute = new ShellExecute();
					shellExecute.Filename=Path.Combine(Path.Combine(pathToFramework,version), "regsvcs.exe");
					string args;
					args = String.Format(CultureInfo.InvariantCulture, "/quiet {0}", path);
					shellExecute.Arguments=args;
					int exitcode = shellExecute.Execute();
					if (exitcode!=0) 
					{
						throw new Exception("Shell execute failed result code:"+shellExecute.StandardError);
					}
				}
				catch (Exception StandardError) 
				{
					throw StandardError;
				}
				return true;
			} 
			else 
			{
				return false;
			}
		}

		/// <summary>
		/// Used for a .net component to remove a vaild assembly, that would specify it's own application group
		/// if this returns false, call the previous version of remove component.
		/// </summary>
		/// <param name="path">The full path to the assembly dll</param>
		/// <param name="runtime">The run time version of the dll</param>
		static public bool RemoveComponentValidAssembly(string path, string runtime)
		{
			Application app = new Application();
			FileInfo fi = new FileInfo(path);
			//detect if its a .NET assembly or not
			if (app.IsValidAssemblyFile(fi.FullName)) 
			{
				try
				{
					string version;
					if (runtime.Length == 0 || runtime == "1.0") 
					{
						version = "v1.0.3705";
					} 
					else 
					{
						version = "v1.1.4322";
					}
					RegistryKey runtimeKey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\.NETFramework");
					string pathToFramework = Convert.ToString(runtimeKey.GetValue("InstallRoot"));
					runtimeKey.Close();
	                            
					ShellExecute shellExecute = new ShellExecute();
					shellExecute.Filename = Path.Combine(Path.Combine(pathToFramework,version), "regsvcs.exe");
					string args;
					args = String.Format(CultureInfo.InvariantCulture, "/quiet /u {0}", path);
					shellExecute.Arguments = args;
					int exitcode = shellExecute.Execute();
					if(exitcode != 0)
					{
						throw new Exception("Shell execute failed result code:"+shellExecute.StandardError);				
					}
				}
				catch (Exception StandardError) 
				{
					throw StandardError;
				}
				return true;
			} 
			else 
			{
				return false;
			}
		}

		static public void RemoveComponent(string path, string applicationName) 
		{
			RemoveComponent(path,applicationName,"localhost");
		}

        static public void RemoveComponent(string path, string applicationName, string machineName) 
        {
            path = path.Trim().ToLower(CultureInfo.InvariantCulture);
            ComWrapper catalog = GetComAdminCatalog(machineName);
            ComWrapper applications = GetApplications(catalog, machineName);
 
            // find application
            int totalApplications = (int)applications.GetProperty("Count");
            for (int applicationIndex = 0; applicationIndex < totalApplications; applicationIndex++)
            {
                object tempApplication = applications.GetProperty("item", applicationIndex) ;
                ComWrapper application = new ComWrapper(tempApplication);
                
                string name = application.GetProperty("Name").ToString();
                if (name == applicationName)
                {
                    ComWrapper components = new ComWrapper(applications.CallMethod("GetCollection", new object[] {"Components", application.GetProperty("Key")})) ;//(ICatalogCollection)applications.GetCollection("Components", catalogObject.Key);
                    components.CallMethod("Populate");
 
                    int componentCount = (int)components.GetProperty("Count");
                    if (componentCount > 0) 
                    {
                        for(int componentIndex = 0; componentIndex < componentCount ; componentIndex++)
                        {
                            object tempComponent = components.GetProperty("Item", componentIndex) ;
                            ComWrapper component = new ComWrapper(tempComponent);
                            string dllProperty = (string)component.GetProperty("Value", "DLL");
                            dllProperty = dllProperty.Trim().ToLower(CultureInfo.InvariantCulture);
                            if(dllProperty == path) 
                            { 
                                bool removeEnabled = Convert.ToBoolean(components.GetProperty("RemoveEnabled"));
                                if (removeEnabled)
                                {
                                    try 
                                    {
                                        //BUG: will fail in this call so catch it.
                                        catalog.CallMethod("ShutdownApplcation", new object[] {applicationName});
                                    }
                                    catch{}
                                    components.CallMethod("Remove", new object[] {componentIndex});
                                    componentCount--;
                                    componentIndex--;
                                }
                            }
                        }
                        components.CallMethod("SaveChanges");
                        break;
                    }
                }
            }
        }

        static private ComWrapper GetApplication(string applicationName,string machineName) 
		{
			ComWrapper cac = GetComAdminCatalog(machineName);
			ComWrapper applications = GetApplications(cac, machineName);
			ComWrapper appObject = null;
            
			// search my application if it is already installed
			int j = (int)applications.GetProperty("Count");
			int i = 0;
			while (i < j)
			{
				Object objTempApp = applications.GetProperty("item", i) ;
				ComWrapper catalogObject = new ComWrapper(objTempApp);
				string name = catalogObject.GetProperty("Name").ToString();
				if (name == applicationName)
				{
					appObject = catalogObject;
					break;
				}
				i = i + 1;
			}
			return appObject;
		}

		private static ComWrapper GetApplicationRoles(string applicationName, string machineName) 
		{
			ComWrapper cac = GetComAdminCatalog(machineName);
			ComWrapper applications = GetApplications(cac, machineName);
			ComWrapper appObject = null;
            
			appObject = GetApplication(applicationName, machineName);

			if (appObject != null) 
			{
				Object objTempRoles = applications.CallMethod("GetCollection",new Object[] {"Roles", appObject.GetProperty("Key")});
				ComWrapper Roles = new ComWrapper(objTempRoles);
				Roles.CallMethod("Populate");
				return Roles;
			}
			else 
			{
				return null;
			}
		}

		private static ComWrapper GetApplicationComponents(string applicationName, string machineName) 
		{
			ComWrapper cac = GetComAdminCatalog(machineName);
			ComWrapper applications = GetApplications(cac, machineName);
			ComWrapper appObject = null;
            
			appObject = GetApplication(applicationName, machineName);

			if (appObject != null) 
			{
				Object objTempComponents = applications.CallMethod("GetCollection",new Object[] {"Components", appObject.GetProperty("Key")});
				ComWrapper ComponentsInPackage = new ComWrapper(objTempComponents);
				ComponentsInPackage.CallMethod("Populate");
				return ComponentsInPackage;
			}
			else 
			{
				return null;
			}
		}

		static private ComWrapper GetComAdminCatalog() 
		{
			return GetComAdminCatalog(null);
		}

		static private ComWrapper GetComAdminCatalog(string machineName) 
		{
			ComWrapper cac = new ComWrapper("COMAdmin.COMAdminCatalog");
            
			if (machineName != null) 
			{
				machineName = machineName.Trim().ToLower(CultureInfo.InvariantCulture);
			}
			if (machineName != null && machineName != "localhost" && machineName.Length != 0) 
			{
				cac.CallMethod("Connect", new Object [] {machineName});
			}
			return cac;
		}

		static private ComWrapper GetApplications(ComWrapper catalog) 
		{
			return GetApplications(catalog, "localhost", true);
		}

		static private ComWrapper GetApplications(ComWrapper catalog, bool populate) 
		{
			return GetApplications(catalog, "localhost", populate);
		}
        
		static private ComWrapper GetApplications() 
		{
			return GetApplications(null, null, true);
		}
        
		static private ComWrapper GetApplications(bool populate) 
		{
			return GetApplications(null, null, populate);
		}

		static private ComWrapper GetApplications(string machineName) 
		{
			return GetApplications(null, machineName, true);
		}

		static private ComWrapper GetApplications(string machineName, bool populate) 
		{
			return GetApplications(null, machineName, populate);
		}

		static private ComWrapper GetApplications(ComWrapper catalog, string machineName) 
		{
			return GetApplications(catalog, machineName, true);
		}
        
		static private ComWrapper GetApplications(ComWrapper catalog, string machineName, bool populate) 
		{
			if (catalog == null) 
			{
				catalog = GetComAdminCatalog(machineName);
			}
			ComWrapper applications = new ComWrapper(catalog.CallMethod("GetCollection" , new Object [] {"Applications"} ));
        
			if (populate) 
			{
				applications.CallMethod("Populate");
			}
			return applications;
		}
		
		private bool IsValidAssemblyFile(string path) 
		{
			try 
			{
				Assembly assembly = Assembly.LoadFrom(path);
				return true;				
			}
			catch (BadImageFormatException) 
			{
				return false;
			}
		}

		/// <summary>
		/// Sets the password used by the server process to log on under the identity. Password should be set at the same time as Identity, because the password and identity are validated before being saved. If the password and identity get out of sync, the application cannot be launched until they are reset by an administrator.
		/// </summary>
		public string Password 
		{
			get 
			{
				return (password == null ? String.Empty : password);
			}
			set 
			{
				if (password != value) 
				{
					password = value;
					isDirty = true;
				}
				passwordSpecified = true;                
			}
		}
		/// <summary>
		/// Sets the server process identity for the application. Specify a valid user account or "Interactive User" to have the application assume the identity of the current logged-on user. This is not enabled for library applications, which run in the client process. The Password property should be set at the same time as Identity, because the password and identity are validated before being saved. If the password and identity get out of sync, the application cannot be launched until they are reset by an administrator. 
		/// </summary>
		public string Identity 
		{
			get 
			{
				return (identity == null ? String.Empty : identity);
			}
			set 
			{
				if (identity != value) 
				{
					identity = value;
					isDirty = true;
				}
			}
		}
		/// <summary>
		/// The name of the application. Extra spaces at the beginning and end of the string are stripped out. Unique names should be chosen for applications. If multiple applications are created with the same name, it can interfere with referencing the applications by name, resulting in unpredictable behavior. 
		/// </summary>
		public string Name 
		{
			get 
			{
				return (name == null ? String.Empty : name);
			}
			set 
			{
				if (name != value) 
				{
					name = value;
					isDirty = true;
				}
			}
		}

		public void AddComponent(string path) 
		{
			cac.CallMethod("InstallComponent", new object[] {ApplicationId, path, String.Empty, String.Empty});
		}

		public void RemoveComponent(string path) 
		{
			path = path.Trim().ToLower(CultureInfo.InvariantCulture);
			ComWrapper components = new ComWrapper(applications.CallMethod("GetCollection", new object[] {"Components", application.GetProperty("Key")}));
			components.CallMethod("Populate");
			int componentCount = (int)components.GetProperty("Count");
			if (componentCount > 0) 
			{
				for(int i = componentCount - 1; i > -1; i--)
				{

					object objTempApp = components.GetProperty("item", i) ;
					ComWrapper obj = new ComWrapper(objTempApp);
                
					string dllProperty = obj.GetProperty("Value", "DLL").ToString();
					dllProperty = dllProperty.Trim().ToLower(CultureInfo.InvariantCulture);
					if(dllProperty == path) 
					{
						bool removeEnabled = Convert.ToBoolean(components.GetProperty("RemoveEnabled"));
						if (removeEnabled)
						{
							Shutdown();
							components.CallMethod("Remove", new Object[] {i});
							components.CallMethod("SaveChanges");
						}
					}
				}
			}           
		}

		public void Shutdown() 
		{
			cac.CallMethod("ShutdownApplication",new object[] {ApplicationId});
		}

		public void Start() 
		{
			cac.CallMethod("StartApplication", new object[] {ApplicationId});
		}

		/// <summary>
		/// A GUID representing the application. ApplicationID is ReadWrite whilst creating a new Application and readonly afterwards.
		/// </summary>
		public string ApplicationId 
		{
			get 
			{
				return applicationId.ToString("B", CultureInfo.InvariantCulture);
			}
			set 
			{
				if (application == null) 
				{
					applicationId = new Guid(value);
					isDirty = true;
				} 
				else 
				{
					throw new ArgumentException("The application ID cannot be set once the Application has been saved");
				}
			}
		}
		/// <summary>
		/// Indicates whether access checks are performed for the application when clients make calls into it. 
		/// </summary>
		public bool AccessChecksEnabled 
		{
			get 
			{
				return accessChecksEnabled;
			}
			set 
			{
				if (accessChecksEnabled != value) 
				{
					accessChecksEnabled = value;
					isDirty = true;
				}
			}
		}
		/// <summary>
		/// Local activation indicates that objects within the application run within a dedicated local server process (server application). In-process activation indicates that objects run in their creator's process (library application). Defaults to local.
		/// </summary>
		public Activation Activation 
		{
			get 
			{
				return activation;
			}
			set 
			{
            
				if (!Enum.IsDefined(typeof(Microsoft.Sdc.Tasks.Configuration.ComponentServices.Activation), value)) 
				{
					throw new System.ComponentModel.InvalidEnumArgumentException("value", (int)value, typeof(Microsoft.Sdc.Tasks.Configuration.ComponentServices.Activation));
				}
				if (activation != value) 
				{
					activation = value;
					isDirty = true;
				}
			}
		}

		public ComponentCollection Components 
		{
			get 
			{
				if (components == null) 
				{
					components = new ComponentCollection(this);
				}
				return components;
			}           
		}
		/// <summary>
		/// Sets the delay before shutting down a server process after it becomes idle. Shutdown latency ranges from 0 to 1440 minutes (24 hours). If RunForever is set to True, this property is ignored. ShutdownAfter is not enabled for library (in-process) applications.
		/// </summary>
		public int ShutdownAfter 
		{
			get 
			{
				return shutdownAfter;
			}
			set 
			{
				if (shutdownAfter != value) 
				{
					shutdownAfter = value;
					isDirty = true;
				}
			}
		}
		/// <summary>
		/// Enables a server process to continue if an application is idle. If set to True, the server process does not shut down when left idle. If set to False, the process shuts down according to the value set by the ShutdownAfter property. RunForever is not enabled for library (in-process) applications.
		/// </summary>
		public bool RunForever
		{
			get 
			{
				return runForever;
			}
			set 
			{
				if (runForever != value) 
				{
					runForever = value;
					isDirty = true;
				}
			}
		}
		public bool Changeable
		{
			get 
			{
				return changeable;
			}
			set 
			{
				if (changeable != value) 
				{
					changeable = value;
					isDirty = true;
				}
			}
		}
		public bool Deleteable 
		{
			get 
			{
				return deleteable;
			}
			set 
			{
				if (deleteable != value) 
				{
					deleteable = value;
					isDirty = true;
				}
			}
		}
	}
}