/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date>October 2003</Date>
  <Description/>
  <Copyright><![CDATA[
    Copyright � 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/

namespace Microsoft.Sdc.Tasks.Configuration
{
    using System;
    using System.IO;
    using System.Diagnostics;

	using System.Collections;
	using System.Collections.Specialized;

    /// <summary>
    /// Summary description for ShellExecute.
    /// </summary>
    internal sealed class ShellExecute
    {
        private string standardOutput = String.Empty;
        private string standardError = String.Empty;
        private int exitCode;
        private string workingDirectory = String.Empty;
        private string filename = String.Empty;
        private string arguments = String.Empty;
        private string standardInput = String.Empty;
        private System.Collections.Specialized.NameValueCollection environmentVariables;
		private int waitForExit = Int32.MaxValue;
		private bool waitExpired;
    
        public ShellExecute()
        {            
        }

        public ShellExecute(string fileName, string arguments)
        {            
            this.filename = fileName;
            this.arguments = arguments;
        }

		/// <summary>
		/// Forces us to wait the specified number of milliseconds for the associated process to exit.
		/// </summary>
		public int WaitForExit
		{
			get 
			{
				return this.waitForExit;
			}
			set 
			{
				this.waitForExit = value;
			}
		}

		/// <summary>
		/// Returns true if the process waited for the time specified by WaitForExit and the process hadn't completed.
		/// </summary>
		public bool WaitExpired
		{
			get 
			{
				return this.waitExpired;
			}			
		}
		
        public System.Collections.Specialized.NameValueCollection EnvironmentVariables
        {
            get
            {				
				if (environmentVariables == null)
				{
					environmentVariables = new System.Collections.Specialized.NameValueCollection();
				}			
                return this.environmentVariables;
            }
            set
            {
                this.environmentVariables = value;
            }
        }
        public string StandardOutput 
        {
            get 
            {
                return this.standardOutput;
            }
        }

        public string StandardError 
        {
            get 
            {
                return this.standardError;
            }           
        }

        public int ExitCode 
        {
            get 
            {
                return this.exitCode;
            }
        }

        public string WorkingDirectory 
        {
            get 
            {
                return this.workingDirectory;
            }
            set 
            {
                this.workingDirectory = value;
            }
        }

        public string StandardInput
        {
            get 
            {
                return this.standardInput;
            }
            set 
            {
                this.standardInput = value;
            }
        }

        public string Filename
        {
            get
            {
                return this.filename;
            }
            set
            {
                this.filename = value;
            }
        }

        public string Arguments
        {
            get
            {
                return this.arguments;
            }
            set
            {
                this.arguments = value;
            }
        }
        public int Execute() 
        {
            this.exitCode = 0;
            this.standardError = String.Empty;
            this.standardOutput = String.Empty;

            System.Diagnostics.Process proc = null;
            string outputFile = null;
            string errorFile = null;
            string inputFile = null;

			try
			{
				outputFile = Path.GetTempFileName();
				errorFile = Path.GetTempFileName();

                FileInfo fi1 = new FileInfo(outputFile);
                FileStream fstr1 = fi1.Create();
                fstr1.Close();

                FileInfo fi2 = new FileInfo(errorFile);
                FileStream fstr2 = fi2.Create();
                fstr2.Close();
                
				string cmdPath = Utilities.GetPathToSystemFile("cmd.exe");
				string commandLine = String.Empty;
				if (this.standardInput == String.Empty)
				{
					commandLine = "/C \"" + cmdPath + " /S /C \"\"" + this.filename + "\" " + this.arguments + "\">\"" + outputFile + "\" 2>\"" + errorFile + "\"\"";
				}
				else
				{
					inputFile = Path.GetTempFileName();
					using (StreamWriter streamWriter =  File.AppendText(inputFile)) 
					{
						streamWriter.Write(this.standardInput);
					}
                    
					commandLine = "/C \"" + cmdPath + " /S /C \"\"" + this.filename + "\" " + this.arguments + "\"<\"" + inputFile +"\">\"" + outputFile + "\" 2>\"" + errorFile + "\"\"";
				}
				ProcessStartInfo startInfo = new ProcessStartInfo(cmdPath, commandLine);
				startInfo.UseShellExecute = false;
				startInfo.CreateNoWindow = true;

				// Add the environment variables to the process start info
				foreach (string key in this.EnvironmentVariables)
				{				
					startInfo.EnvironmentVariables[key] = this.EnvironmentVariables[key];
				}				
			
				startInfo.WorkingDirectory = this.workingDirectory;

				proc = System.Diagnostics.Process.Start(startInfo);

				bool returnValue = proc.WaitForExit(this.waitForExit);
                
				this.waitExpired = !returnValue;

				if (returnValue) 
				{

					using (StreamReader streamReader = File.OpenText(outputFile)) 
					{
						this.standardOutput  = streamReader.ReadToEnd();
					}
                
					using (StreamReader streamReader = File.OpenText(errorFile)) 
					{
						this.standardError  = streamReader.ReadToEnd();
					}   
				}				
			}
			finally
			{
#if !DEBUG
                // Delete the temp file used for capturing stdout.
                if (outputFile != null)
                {
                    File.Delete(outputFile);
                }

                // Delete the temp file used for capturing stderr.
                if (errorFile != null)
                {
                    File.Delete(errorFile);
                }
#endif
				// get the exit code and release the process handle
				if (proc != null)
				{
					if (!proc.HasExited)
					{
						//not exited yet within our timeout so kill the process
						proc.Kill();							
					
						while (!proc.HasExited)
						{
							System.Threading.Thread.Sleep(50);
						}						 
					}

					this.exitCode = proc.ExitCode;
					proc.Close(); 
					proc = null;
				}
			}
            return this.exitCode;
        }        
    }
}