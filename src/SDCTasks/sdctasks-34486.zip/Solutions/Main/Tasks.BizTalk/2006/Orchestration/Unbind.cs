//-----------------------------------------------------------------------
// <copyright file="UnBind.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.Orchestration
{
    using System.Globalization;
    using BizTalk.ExplorerOM;

    /// <summary>
    /// Unbind an orchestration
    /// </summary>
    public class UnBind : BizTalk2004.Orchestration.Unbind
    {
        private string application;

        /// <summary>
        /// Gets or sets the application.
        /// </summary>
        /// <value>The application.</value>
        public string Application
        {
            get { return this.application; }
            set { this.application = value; }
        }

        /// <summary>
        /// Internals the execute.
        /// </summary>
        protected override void InternalExecute()
        {
            if (string.IsNullOrEmpty(this.Application))
            {
                base.InternalExecute();
            }
            else
            {
                BtsCatalogExplorer explorer = this.GetBtsCatalogExplorer(this.Server, this.Database);

                Application app = explorer.Applications[this.Application];
                if (app != null)
                {
                    BtsOrchestration orchestration = app.Orchestrations[this.Name];
                    if (orchestration != null)
                    {
                        orchestration.Host = null;

                        foreach (OrchestrationPort port in orchestration.Ports)
                        {
                            port.SendPort = null;
                            port.ReceivePort = null;
                            port.SendPortGroup = null;
                        }

                        Log.LogMessage(string.Format(CultureInfo.InvariantCulture, "Unbinding Orchestration: {0} in Application {1}", this.Name, this.Application));
                        explorer.SaveChanges();
                    }
                    else
                    {
                        Log.LogError(string.Format(CultureInfo.InvariantCulture, "Orchestration not found: {0} for Application {1}", this.Name, this.Application));
                        return;
                    }
                }
                else
                {
                    Log.LogError(string.Format(CultureInfo.InvariantCulture, "Application not found: {0}", this.Application));
                    return;
                }
            }
        }
    }
}
