//-----------------------------------------------------------------------
// <copyright file="CheckProductInstalledTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-06-04</date>
// <summary>Tests check product installed task</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the Create Guid Task
    /// </summary>
    [TestClass]
    public class CheckProductInstalledTest
    {
        

        public CheckProductInstalledTest()
        {
        }        

        [TestMethod]
        
        [Ignore]//("Failing on 2.0 RTM")]
        public void TestCheckProductInstalled()
        {
            Tasks.GetInstalledProducts getProductsInstalledTask = new Tasks.GetInstalledProducts();
            getProductsInstalledTask.MachineName = ".";

            //NB - if machine name is "." or Environment.MachineName, then you can't 
            //set the username/password for the task, or you'll generate a
            //  "User credentials cannot be used for local connections"
            //exception. 

            bool getProductsInstalledTaskReturnValue = getProductsInstalledTask.Execute();

            Assert.IsTrue(getProductsInstalledTaskReturnValue, "GetProductsInstalledTask");

            string installedProductsXml = getProductsInstalledTask.InstalledProductsXml[0];

            Assert.IsTrue(installedProductsXml.Length > 0, "InstalledProductsXml");

            Tasks.CheckProductInstalled checkProductInstalledTask = new Tasks.CheckProductInstalled();
            
            string[] names = new string[1] { "Microsoft .NET Framework 2.0" };
            string[] versions = new string[1] { "2.0.50727" };

            string[] nameComparisonOperators = new string[1] { Microsoft.Sdc.Tasks.Configuration.InstalledProducts.BinaryComparisonOperator.Equals.ToString() };
            string[] unaryOperators = new string[1] { Microsoft.Sdc.Tasks.Configuration.InstalledProducts.UnaryLogicalOperator.None.ToString() };
            string[] versionComparisonOperators = new string[] { Microsoft.Sdc.Tasks.Configuration.InstalledProducts.BinaryComparisonOperator.Equals.ToString() };

            checkProductInstalledTask.Names = names;
            checkProductInstalledTask.Versions = versions;
            checkProductInstalledTask.InstalledProductsXml = installedProductsXml;

            checkProductInstalledTask.NameComparisonOperators = nameComparisonOperators;
            checkProductInstalledTask.UnaryOperators = unaryOperators;
            checkProductInstalledTask.VersionComparisonOperators = versionComparisonOperators;

            bool checkProductsInstalledTaskReturnValue = checkProductInstalledTask.Execute();

            Assert.IsTrue(checkProductsInstalledTaskReturnValue, "CheckProductsInstalledTask");

            Assert.IsTrue(checkProductInstalledTask.Names == names, "CheckProductInstalledTaskParameters");
            Assert.IsTrue(checkProductInstalledTask.InstalledProductsXml == installedProductsXml, "CheckProductInstalledTaskParameters");
            Assert.IsTrue(checkProductInstalledTask.Versions == versions, "CheckProductInstalledTaskParameters");
            Assert.IsTrue(checkProductInstalledTask.VersionComparisonOperators == versionComparisonOperators, "CheckProductInstalledTaskParameters");
            Assert.IsTrue(checkProductInstalledTask.UnaryOperators == unaryOperators, "CheckProductInstalledTaskParameters");
        }
    }
}


