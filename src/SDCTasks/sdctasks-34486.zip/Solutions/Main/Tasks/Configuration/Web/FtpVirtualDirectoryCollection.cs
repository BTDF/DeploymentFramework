/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/


namespace Microsoft.Sdc.Tasks.Configuration.Web 
{
    using System.Collections;
    using System;
    using System.Globalization;
    /// <summary>
    /// Summary description for FtpVirtualDirectoryCollection.
    /// </summary>
    internal class FtpVirtualDirectoryCollection : CollectionBase 
    {
        FtpSite parentFtpSite;


        internal FtpVirtualDirectoryCollection(FtpSite parent) 
        {
            parentFtpSite = parent;
        }

        public int Add(FtpVirtualDirectory directory) 
        {

            if (directory.Name.Trim().Length == 0) 
            {
                throw new ApplicationException("Virtual Directory name must be provided before adding to a collection");
            }
            int index = GetIndexFromName(directory.Name);
            if (index > -1) 
            {
                throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "A VirtualDirectory with the name '{0}' already exists.", directory.Name));
            }
            directory.Parent = parentFtpSite;
            return List.Add(directory);
        }

        public int IndexOf(FtpVirtualDirectory value) 
        {
            return( List.IndexOf(value));
        }

        public void Insert(int index, FtpVirtualDirectory value) 
        {
            value.Parent = parentFtpSite;
            List.Insert(index, value);
        }

        public void Remove(FtpVirtualDirectory value) 
        {
            List.Remove(value);
        }

        public void CopyTo(FtpVirtualDirectoryCollection collection, int index) 
        {
            if (collection == null)
                throw new ArgumentNullException("collection");
            if (index < 0)
                throw new ArgumentOutOfRangeException("index", index, "index needs to be greater than 0");
			
            int i = 0;			
            while(i < List.Count) 
            {
                collection[i+index] = (FtpVirtualDirectory)List[i];
                i++;
            }
        }	

        public bool Contains(FtpVirtualDirectory value) 
        {
            return (List.Contains(value));
        }

        public FtpVirtualDirectory this[int index] 
        {
            get 
            {
                return (FtpVirtualDirectory) List[index];
            }
            set 
            {
                List[index] = value;
            }
        }

        int GetIndexFromName(string name) 
        {
            FtpVirtualDirectory vdir;
            for(int i=0; i < List.Count; i++) 
            {
                vdir = (FtpVirtualDirectory)List[i];
                if (vdir.Name == name) 
                {
                    return i;
                }
            }		
            return -1;
        }

        public FtpVirtualDirectory this[string name] 
        {
            get 
            {
                int index = GetIndexFromName(name);
                if (index == -1) 
                {
                    return null;
                }
                return (FtpVirtualDirectory) List[index];
            }
            set 
            {
                int index = GetIndexFromName(name);
                if (index == -1) 
                {
                    throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Could not find virtual directory called {0}", name));
                }
                List[index] = value;
            }
        }
    }
}
