

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using Directives

	using System;

	#endregion

	/// <summary>
	/// Represents a set of data that identifies an entity.
	/// </summary>
	internal class CertificateInfo : BizTalkNonConfigurableEntityBase
	{
		#region member variables

		private string longName;
		private string shortName;
		private string thumbPrint;
		private CertUsageType usageType;

		#endregion 


		#region properties 

		/// <summary>
		/// Gets the long name of the certificate.
		/// </summary>
		public string LongName
		{
			get {return this.longName;}
		}

		/// <summary>
		/// Gets the short name of the certificate.
		/// </summary>
		public string ShortName
		{
			get {return this.shortName;}
		}

		/// <summary>
		/// Gets the thumbprint, or unique ID, of the certificate
		/// </summary>
		public string ThumbPrint
		{
			get {return this.thumbPrint;}
		}

		/// <summary>
		/// Gets the usage type of the certificate.
		/// </summary>
		public CertUsageType UsageType
		{
			get {return this.usageType;}
		}


		#endregion 


		#region methods 
		/// <summary>
		/// Creates a new instance of a CertificateInfo object.
		/// This constuctor is private because the object can only be created using the Load Method.
		/// </summary>
		/// <param name="installation"> the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation"/> object of this Certificate</param>
		public CertificateInfo(BizTalkInstallation installation):base(installation){}


		/// <summary>
		/// Loads a Certificate from a Biztalk installation.
		/// </summary>
		/// <param name="installation"> the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation"/> object of this Certificate</param>
		/// <param name="longName">The Long Name of the Certificate to load.</param>
		/// <returns></returns>
		public static CertificateInfo Load(BizTalkInstallation installation, string longName)
		{
			CertificateInfo certificateInfo = null;

			foreach(BtsCertificateInfo actualCertInfo in installation.CatalogExplorer.Certificates)
			{
				if (actualCertInfo.LongName == longName)
				{
					certificateInfo = new CertificateInfo(installation);
					certificateInfo.longName = actualCertInfo.LongName;
					certificateInfo.shortName = actualCertInfo.ShortName;
					certificateInfo.thumbPrint = actualCertInfo.ThumbPrint;
					certificateInfo.usageType = (CertUsageType)Enum.Parse(typeof(CertUsageType), ((int)actualCertInfo.UsageType).ToString());
					break;
				}
			}
			
			return certificateInfo;
		}


		#endregion 


	}
}

