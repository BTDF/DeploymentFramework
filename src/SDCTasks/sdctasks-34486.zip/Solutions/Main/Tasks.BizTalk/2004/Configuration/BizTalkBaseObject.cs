//-------------------------------------------------------------------------------------
// <copyright file="BizTalkBaseObject.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Base class for all entities that are part of a BizTalk installation.
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Xml.Serialization;
    using System.Reflection;

    #endregion

    /// <summary>
    /// Base class for all entities that are part of a BizTalk installation.
    /// </summary>
    internal abstract class BizTalkEntityBase
    {
        #region Member Variables

        private string nameInternal;
        private Guid id;
        private BizTalkInstallation installation;

        #endregion

        #region Constructors

        /// <summary>
        /// Creates a new <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkEntityBase"/>.
        /// </summary>
        /// <param name="installation">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation"/> that this object
        /// belongs to.
        /// </param>
        protected BizTalkEntityBase(BizTalkInstallation installation)
            : this(installation, null)
        {
        }

        /// <summary>
        /// Creates a new <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkEntityBase"/>.
        /// </summary>
        /// <param name="installation">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation"/> that this object
        /// belongs to.
        /// </param>
        /// <param name="name">
        /// The name of the object.
        /// </param>
        protected BizTalkEntityBase(BizTalkInstallation installation, string name)
        {
            if (installation == null)
            {
                throw new ArgumentNullException("installation");
            }

            this.id = Guid.NewGuid();
            this.installation = installation;
            this.nameInternal = name;
        }
        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the unique identifier for this object.
        /// </summary>
        /// <value>
        /// The unique identifier for this object.
        /// </value>
        public Guid Id
        {
            get
            {
                return this.id;
            }

            set
            {
                this.id = value;
            }
        }

        /// <summary>
        /// Gets the BizTalk installation that this object belongs to.
        /// </summary>
        /// <value>
        /// The BizTalk installation that this object belongs to.
        /// </value>
        [XmlIgnore]
        public BizTalkInstallation Installation
        {
            get
            {
                return this.installation;
            }
        }

        /// <summary>
        /// Gets or sets the name of this object.
        /// </summary>
        /// <value>
        /// The name of this object.
        /// </value>
        public string Name
        {
            get
            {
                return this.nameInternal;
            }

            set
            {
                this.nameInternal = value;
            }
        }

        #endregion

        #region Static Methods

        /// <summary>
        /// Checks if an object of the specified name exists in the BizTalk Objects collection
        /// </summary>
        /// <param name="installation">
        /// The 
        /// </param>
        /// <param name="collectionType">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.CollectionType"/> to search in
        /// </param>
        /// <param name="name">
        /// The name of the object
        /// </param>
        /// <returns>
        /// <b>true</b> if the Object exists, or <b>false</b> otherwise.
        /// </returns>
        public static bool Exists(BizTalkInstallation installation, CollectionType collectionType, string name)
        {
            bool exists = false;

            // get the collection of items
            CollectionType localCollectionType = (CollectionType)(int)collectionType;
            ICollection items = installation.CatalogExplorer.GetCollection(localCollectionType);

            // check whether the item exists
            switch (collectionType)
            {
                case CollectionType.Assembly:
                case CollectionType.Host:
                case CollectionType.ProtocolType:
                case CollectionType.ReceivePort:
                case CollectionType.SendPort:
                case CollectionType.SendPortGroup:
                case CollectionType.Party:
                    foreach (object item in items)
                    {
                        if (item.GetType().InvokeMember("Name", BindingFlags.GetProperty, null, item, null).ToString() == name)
                        {
                            exists = true;
                            break;
                        }
                    }

                    break;
                case CollectionType.Pipeline:
                    foreach (object item in items)
                    {
                        if (item.GetType().InvokeMember("FullName", BindingFlags.GetProperty, null, item, null).ToString() == name)
                        {
                            exists = true;
                            break;
                        }
                    }

                    break;
            }

            return exists;
        }

        #endregion
    }
}

