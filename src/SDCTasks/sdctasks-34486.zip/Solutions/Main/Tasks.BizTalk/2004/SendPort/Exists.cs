//-------------------------------------------------------------------------------------
// <copyright file="Delete.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Checkts whether a send port exists in BizTalk Server.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.SendPort
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Text;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion

    public class Exists : BizTalk2004TaskBase
    {
        #region Member Variables

        private string name;
        private bool exists;

        #endregion

        #region Constructors

        /// <summary>
        /// Creates a new task to Delete a send port.
        /// </summary>
        public Exists()
        {
        }

        #endregion

        #region Properties - General

        /// <summary>
        /// Gets or sets the name of the send port to delete.
        /// </summary>
        /// <value>
        /// The name of the send port to delete.
        /// </value>
        [Required]
        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }

        [Output]
        public bool SendPortExists
        {
            get { return this.exists; }
            set { this.exists = value; }
        }





        #endregion


        #region Methods

        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {
            //loading the send port
            BizTalkInstallation installation = this.GetInstallation();
            this.exists = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SendPort.Exists(installation, this.name);
        }

        #endregion
    }
}

