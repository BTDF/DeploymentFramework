//-------------------------------------------------------------------------------------
// <copyright file="CollectionType.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      The type of a collection of BizTalk objects.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	/// <summary>
	/// The type of a collection of BizTalk objects.
	/// </summary>
	public enum CollectionType
	{
		/// <summary>
		/// A collection of assemblies.
		/// </summary>
		Assembly = 1,
		/// <summary>
		/// A collection of certificates. 
		/// </summary>
		Certificate =  2,
		/// <summary>
		/// A collection of pipelines. 
		/// </summary>
		Pipeline  = 3,
		/// <summary>
		/// A collection of receive ports. 
		/// </summary>
		ReceivePort =  4,
		/// <summary>
		/// A collection of send ports. 
		/// </summary>
		SendPort =  5,
		/// <summary>
		/// A collection of parties. 
		/// </summary>
		Party =  6,
		/// <summary>
		/// A collection of send port groups. 
		/// </summary>
		SendPortGroup =  7,
		/// <summary>
		/// A collection of protocol types. 
		/// </summary>
		ProtocolType =  8,
		/// <summary>
		/// A collection of receive handlers. 
		/// </summary>
		ReceiveHandler =  9,
		/// <summary>
		/// A collection of standard aliases. 
		/// </summary>
		StandardAlias =  10,
		/// <summary>
		/// A collection of schemas. 
		/// </summary>
		Schema =  11,
		/// <summary>
		/// A collection of maps. 
		/// </summary>
		Map = 12,
		/// <summary>
		/// A collection of hosts. 
		/// </summary>
		Host = 13
	}
}

