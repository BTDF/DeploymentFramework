/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/

namespace Microsoft.Sdc.Tasks.Configuration 
{
	using System;
	/// <summary>
	/// Provides constants for external dll names
	/// </summary>
	internal class ExternalDll 
	{
		
		public const string DbNetLib = "dbnetlib.dll";
		public const string Kernel32 = "kernel32.dll";
		public const string Odbc32   = "odbc32.dll";
		public const string Oleaut32 = "oleaut32.dll";
		public const string Ole32    = "ole32.dll";
		public const string Advapi32 = "advapi32.dll";
	
		private ExternalDll() 
		{
		}
	}
}

