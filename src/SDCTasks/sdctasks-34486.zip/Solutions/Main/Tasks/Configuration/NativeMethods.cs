/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration 
{
	
	using System;
	using System.Runtime.InteropServices;
	using System.Text;

	using BOOL = System.Int32;
	using PACL = System.IntPtr;
	using DWORD = System.UInt32;
	using WORD = System.UInt16;
	using LPVOID = System.IntPtr;
	using LPCTSTR = System.String;
	using PSECURITY_DESCRIPTOR = System.IntPtr;
	using PSID = System.IntPtr;
	//using SECURITY_DESCRIPTOR_CONTROL = SecurityDescriptorControlFlags;
	using HLOCAL = System.IntPtr;
	using PUCHAR = System.IntPtr;
	using PDWORD = System.IntPtr;
	using PSID_IDENTIFIER_AUTHORITY = System.IntPtr;
	using UCHAR = System.Byte;
	using ACCESS_MASK = AccessMask;
	using BYTE = System.Byte;		
	
	internal enum SecurityDescriptorRevision 
	{
		SECURITY_DESCRIPTOR_REVISION = 1
	}

	[Flags]
	internal enum AccessMask : uint 
	{
		COM_RIGHTS_EXECUTE				= 0x00000001,
		COM_RIGHTS_SAFE_FOR_SCRIPTING   = 0x00000002,

		DELETE                          = 0x00010000,
		READ_CONTROL                    = 0x00020000,
		WRITE_DAC                       = 0x00040000,
		WRITE_OWNER                     = 0x00080000,
		SYNCHRONIZE                     = 0x00100000,

		STANDARD_RIGHTS_REQUIRED        = 0x000F0000,

		STANDARD_RIGHTS_READ            = READ_CONTROL,
		STANDARD_RIGHTS_WRITE           = READ_CONTROL,
		STANDARD_RIGHTS_EXECUTE         = READ_CONTROL,

		STANDARD_RIGHTS_ALL             = 0x001F0000,

		SPECIFIC_RIGHTS_ALL             = 0x0000FFFF,

		//
		// AccessSystemAcl access type
		//

		ACCESS_SYSTEM_SECURITY           = 0x01000000,

		//
		// MaximumAllowed access type
		//

		MAXIMUM_ALLOWED                  = 0x02000000,

		//
		//  These are the generic rights.
		//

		GENERIC_READ                     = 0x80000000,
		GENERIC_WRITE                    = 0x40000000,
		GENERIC_EXECUTE                  = 0x20000000,
		GENERIC_ALL                      = 0x10000000,
	}

	internal enum AclRevision : byte 
	{
		ACL_REVISION     = 2,
		ACL_REVISION_DS  = 4,
	}

	internal enum AceType : byte 
	{
		ACCESS_ALLOWED_ACE_TYPE                 = 0x0,
		ACCESS_DENIED_ACE_TYPE                  = 0x1,
		SYSTEM_AUDIT_ACE_TYPE                   = 0x2,
		SYSTEM_ALARM_ACE_TYPE                   = 0x3,
		//ACCESS_MAX_MS_V2_ACE_TYPE               = 0x3,

		ACCESS_ALLOWED_COMPOUND_ACE_TYPE        = 0x4,
		//ACCESS_MAX_MS_V3_ACE_TYPE               = 0x4,

		//ACCESS_MIN_MS_OBJECT_ACE_TYPE           = 0x5,
		ACCESS_ALLOWED_OBJECT_ACE_TYPE          = 0x5,
		ACCESS_DENIED_OBJECT_ACE_TYPE           = 0x6,
		SYSTEM_AUDIT_OBJECT_ACE_TYPE            = 0x7,
		SYSTEM_ALARM_OBJECT_ACE_TYPE            = 0x8,
		//ACCESS_MAX_MS_OBJECT_ACE_TYPE           = 0x8,

		//ACCESS_MAX_MS_V4_ACE_TYPE               = 0x8,
		//ACCESS_MAX_MS_ACE_TYPE                  = 0x8,

		ACCESS_ALLOWED_CALLBACK_ACE_TYPE        = 0x9,
		ACCESS_DENIED_CALLBACK_ACE_TYPE         = 0xA,
		ACCESS_ALLOWED_CALLBACK_OBJECT_ACE_TYPE = 0xB,
		ACCESS_DENIED_CALLBACK_OBJECT_ACE_TYPE  = 0xC,
		SYSTEM_AUDIT_CALLBACK_ACE_TYPE          = 0xD,
		SYSTEM_ALARM_CALLBACK_ACE_TYPE          = 0xE,
		SYSTEM_AUDIT_CALLBACK_OBJECT_ACE_TYPE   = 0xF,
		SYSTEM_ALARM_CALLBACK_OBJECT_ACE_TYPE   = 0x10,

		//ACCESS_MAX_MS_V5_ACE_TYPE               = 0x10,
	}

	[Flags]
	internal enum AceFlagsInternal : byte 
	{
		OBJECT_INHERIT_ACE                = 0x1,
		CONTAINER_INHERIT_ACE             = 0x2,
		NO_PROPAGATE_INHERIT_ACE          = 0x4,
		INHERIT_ONLY_ACE                  = 0x8,
		INHERITED_ACE                     = 0x10,
		VALID_INHERIT_FLAGS               = 0x1F,
		SUCCESSFUL_ACCESS_ACE_FLAG        = 0x40,
		FAILED_ACCESS_ACE_FLAG            = 0x80,
	}

	[Flags]
	internal enum AccessTypeInternal : uint 
	{
		DELETE                          = 0x00010000,
		READ_CONTROL                    = 0x00020000,
		WRITE_DAC                       = 0x00040000,
		WRITE_OWNER                     = 0x00080000,
		SYNCHRONIZE                     = 0x00100000,

		STANDARD_RIGHTS_REQUIRED        = 0x000F0000,

		STANDARD_RIGHTS_READ            = READ_CONTROL,
		STANDARD_RIGHTS_WRITE           = READ_CONTROL,
		STANDARD_RIGHTS_EXECUTE         = READ_CONTROL,

		STANDARD_RIGHTS_ALL             = 0x001F0000,

		SPECIFIC_RIGHTS_ALL             = 0x0000FFFF,

		//
		// AccessSystemAcl access type
		//

		ACCESS_SYSTEM_SECURITY           = 0x01000000,

		//
		// MaximumAllowed access type
		//

		MAXIMUM_ALLOWED                  = 0x02000000,

		//
		//  These are the generic rights.
		//

		GENERIC_READ                     = 0x80000000,
		GENERIC_WRITE                    = 0x40000000,
		GENERIC_EXECUTE                  = 0x20000000,
		GENERIC_ALL                      = 0x10000000,
	}

	[Flags]
	internal enum SecurityDescriptorControlFlags : ushort 
	{ 
		SE_OWNER_DEFAULTED               = 0x0001,
		SE_GROUP_DEFAULTED               = 0x0002,
		SE_DACL_PRESENT                  = 0x0004,
		SE_DACL_DEFAULTED                = 0x0008,
		SE_SACL_PRESENT                  = 0x0010,
		SE_SACL_DEFAULTED                = 0x0020,
		SE_DACL_AUTO_INHERIT_REQ         = 0x0100,
		SE_SACL_AUTO_INHERIT_REQ         = 0x0200,
		SE_DACL_AUTO_INHERITED           = 0x0400,
		SE_SACL_AUTO_INHERITED           = 0x0800,
		SE_DACL_PROTECTED                = 0x1000,
		SE_SACL_PROTECTED                = 0x2000,
		SE_RM_CONTROL_VALID              = 0x4000,
		SE_SELF_RELATIVE                 = 0x8000,
	}
	internal enum SID_NAME_USE : uint 
	{
		SidTypeUser = 1,
		SidTypeGroup,
		SidTypeDomain,
		SidTypeAlias,
		SidTypeWellKnownGroup,
		SidTypeDeletedAccount,
		SidTypeInvalid,
		SidTypeUnknown,
		SidTypeComputer
	}
	[Flags]
	internal enum SECURITY_INFORMATION : uint 
	{
		OWNER_SECURITY_INFORMATION       = 0x00000001,
		GROUP_SECURITY_INFORMATION       = 0x00000002,
		DACL_SECURITY_INFORMATION        = 0x00000004,
		SACL_SECURITY_INFORMATION        = 0x00000008,

		// Win2k only
		PROTECTED_DACL_SECURITY_INFORMATION     = 0x80000000,
		// Win2k only
		PROTECTED_SACL_SECURITY_INFORMATION     = 0x40000000,
		// Win2k only
		UNPROTECTED_DACL_SECURITY_INFORMATION   = 0x20000000,
		// Win2k only
		UNPROTECTED_SACL_SECURITY_INFORMATION   = 0x10000000,
	}

	[StructLayout(LayoutKind.Sequential)]
	internal struct SECURITY_DESCRIPTOR 
	{
		public static readonly int SizeOf = Marshal.SizeOf(typeof(SECURITY_DESCRIPTOR));

		// We do NOT expose those fields, since the Win32 doc says
		// use "SECURITY_DESCRIPTOR" as a black box.
		private BYTE  Revision;
		private BYTE  Sbz1;
		private SecurityDescriptorControlFlags Control;
		private PSID Owner;
		private PSID Group;
		private PACL Sacl;
		private PACL Dacl;
	}

	[StructLayout(LayoutKind.Sequential)]
	internal struct ACL 
	{
		public static readonly int SizeOf = Marshal.SizeOf(typeof(ACL));

		public AclRevision  AclRevision;
		public BYTE  Sbz1;
		public WORD   AclSize;
		public WORD   AceCount;
		public WORD   Sbz2;
	}

	[StructLayout(LayoutKind.Sequential)]
	internal struct ACCESS_ALLOWED_ACE 
	{
		public static readonly int SizeOf = Marshal.SizeOf(typeof(ACCESS_ALLOWED_ACE));
		public static readonly int SidOffset = Marshal.OffsetOf(typeof(ACCESS_ALLOWED_ACE), "SidStart").ToInt32();

		public ACE_HEADER Header;
		public ACCESS_MASK Mask;
		public DWORD SidStart;
	}

	[StructLayout(LayoutKind.Sequential)]
	internal struct ACCESS_DENIED_ACE 
	{
		public static readonly int SizeOf = Marshal.SizeOf(typeof(ACCESS_DENIED_ACE));
		public static readonly int SidOffset = Marshal.OffsetOf(typeof(ACCESS_DENIED_ACE), "SidStart").ToInt32();

		public ACE_HEADER Header;
		public ACCESS_MASK Mask;
		public DWORD SidStart;
	}

	[StructLayout(LayoutKind.Sequential)]
	internal struct LSA_UNICODE_STRING 
	{
		internal UInt16 Length;
		internal UInt16 MaximumLength;
		internal IntPtr Buffer;
	}

	[StructLayout(LayoutKind.Sequential)]
	internal struct LSA_OBJECT_ATTRIBUTES 
	{
		internal UInt32 Length;
		internal IntPtr RootDirectory;
		internal LSA_UNICODE_STRING ObjectName;
		internal UInt32 Attributes;
		internal IntPtr SecurityDescriptor;
		internal IntPtr SecurityQualityOfService;
	}

	[StructLayout(LayoutKind.Sequential)]
	internal struct SID_IDENTIFIER_AUTHORITY 
	{
		[MarshalAs(UnmanagedType.ByValArray, SizeConst=6)]
		public UCHAR []Value;
	}

	[StructLayout(LayoutKind.Sequential)]
	internal struct ACE_HEADER 
	{
		public static readonly int SizeOf = Marshal.SizeOf(typeof(ACE_HEADER));

		public AceType  AceType;
		public AceFlagsInternal AceFlagsInternal;
		public WORD		AceSize;
	}

	/// <summary>
	/// Provides wrappers for Win32 native methods
	/// </summary>
	internal sealed class NativeMethods 
	{

		internal const int LOGON32_LOGON_INTERACTIVE = 2;
		internal const int LOGON32_PROVIDER_DEFAULT = 0;

		internal const int STANDARD_RIGHTS_REQUIRED = 0x000F0000;
                
		internal const int POLICY_VIEW_LOCAL_INFORMATION = 1;
		internal const int POLICY_VIEW_AUDIT_INFORMATION = 2;
		internal const int POLICY_GET_PRIVATE_INFORMATION = 4;
		internal const int POLICY_TRUST_ADMIN = 8;
		internal const int POLICY_CREATE_ACCOUNT = 10;
		internal const int POLICY_CREATE_SECRET = 20;
		internal const int POLICY_CREATE_PRIVILEGE = 40;
		internal const int POLICY_SET_DEFAULT_QUOTA_LIMITS = 80;
		internal const int POLICY_SET_AUDIT_REQUIREMENTS = 100;
		internal const int POLICY_AUDIT_LOG_ADMIN = 200;
		internal const int POLICY_SERVER_ADMIN = 400;
		internal const int POLICY_LOOKUP_NAMES = 800;
		internal const int POLICY_ALL_ACCESS = POLICY_VIEW_LOCAL_INFORMATION |
			POLICY_VIEW_AUDIT_INFORMATION |
			POLICY_GET_PRIVATE_INFORMATION |
			POLICY_TRUST_ADMIN |
			POLICY_CREATE_ACCOUNT |
			POLICY_CREATE_SECRET |
			POLICY_CREATE_PRIVILEGE |
			POLICY_SET_DEFAULT_QUOTA_LIMITS |
			POLICY_SET_AUDIT_REQUIREMENTS |
			POLICY_AUDIT_LOG_ADMIN |
			POLICY_SERVER_ADMIN |
			POLICY_LOOKUP_NAMES;
		private NativeMethods() 
		{
		}
		[DllImport(ExternalDll.Advapi32, CharSet=CharSet.Auto, SetLastError=true)]
		internal static extern bool LogonUser(
			[MarshalAs(UnmanagedType.LPTStr)] string lpszUsername,
			[MarshalAs(UnmanagedType.LPTStr)] string lpszDomain,     
			[MarshalAs(UnmanagedType.LPTStr)] string lpszPassword,    
			int dwLogonType,        
			int dwLogonProvider,    
			out IntPtr phToken          
			);

		//TODO does this return an int or a bool
		//TODO Should the hToken going in be a HandleRef
		[DllImport(ExternalDll.Advapi32, CharSet=CharSet.Auto, SetLastError=true)]
		internal static extern int DuplicateToken(IntPtr hToken, int impersonationLevel,  ref IntPtr hNewToken);
    	
		[DllImport(ExternalDll.Advapi32, CharSet=CharSet.Auto, SetLastError=true)]
		internal static extern int LookupAccountName(
			[In,MarshalAs(UnmanagedType.LPTStr)] string systemName,
			[In,MarshalAs(UnmanagedType.LPTStr)] string accountName,
			IntPtr Sid,
			ref int  cbSid,
			StringBuilder domainName,
			ref int cbDomainName,
			ref int use);
		
		[DllImport(ExternalDll.Advapi32, CharSet=CharSet.Auto, PreserveSig=false)]
		internal static extern UInt32 LsaOpenPolicy(
			ref LSA_UNICODE_STRING SystemName,
			ref LSA_OBJECT_ATTRIBUTES ObjectAttributes,
			int DesiredAccess,
			out IntPtr PolicyHandle);
		
		[DllImport(ExternalDll.Advapi32, CharSet=CharSet.Auto)]
		internal static extern bool ConvertSidToStringSid(IntPtr pSID, [In,Out,MarshalAs(UnmanagedType.LPTStr)] ref string pStringSid);

		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true, CharSet=CharSet.Auto)]
		internal static extern BOOL ConvertSidToStringSid(PSID Sid, out IntPtr StringSid);

		[DllImport(ExternalDll.Advapi32, CharSet=CharSet.Auto)]
		internal static extern UInt32 LsaEnumerateAccountRights(
			IntPtr PolicyHandle,
			IntPtr AccountSid,
			out IntPtr UserRights,
			out UInt32 CountOfRights);		

		[DllImport(ExternalDll.Advapi32, CharSet=CharSet.Auto)]
		internal static extern UInt32 LsaAddAccountRights(
			IntPtr PolicyHandle,
			IntPtr AccountSid,
			ref LSA_UNICODE_STRING UserRights,
			UInt32 CountOfRights);		

		[DllImport(ExternalDll.Advapi32, CharSet=CharSet.Auto)]
		internal static extern UInt32 LsaNtStatusToWinError(
			UInt32 Status);
       
		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi)]
		internal static extern DWORD GetLengthSid(PSID pSid);
		
		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi)]
		internal static extern DWORD GetSidLengthRequired(UCHAR nSubAuthorityCount);

		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true)]
		internal static extern BOOL IsValidSid(PSID pSid);
		
		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true)]
		internal static extern PDWORD GetSidSubAuthority(PSID pSid, DWORD nSubAuthority);
		
		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true)]
		internal static extern PUCHAR GetSidSubAuthorityCount(PSID pSid);
		
		//[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true)]
		//internal static extern PSID_IDENTIFIER_AUTHORITY GetSidIdentifierAuthority(PSID pSid);
		
		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true)]
		internal static extern BOOL EqualSid(PSID pSid1, PSID pSid2);
		
		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true)]
		internal static extern BOOL EqualPrefixSid(PSID pSid1, PSID pSid2);
		
		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true)]
		internal static extern BOOL InitializeSid(PSID Sid, [In]ref SID_IDENTIFIER_AUTHORITY pIdentifierAuthority, UCHAR nSubAuthorityCount);
	
		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true)]
		internal static extern BOOL InitializeAcl(PACL pAcl, DWORD nAclLength, DWORD dwAclRevision);
		
		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true)]
		internal static extern BOOL AddAce(PACL pAcl, DWORD dwAceRevision, DWORD dwStartingAceIndex, LPVOID pAceList, DWORD nAceListLength);
					
		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true, CharSet=CharSet.Auto)]
		internal static extern BOOL LookupAccountSid(
			string lpSystemName, 
			PSID Sid,
			[Out] char[] Name,
			ref DWORD cchName,
			[Out] char [] ReferencedDomainName,
			ref DWORD cchReferencedDomainName,
			out SID_NAME_USE peUse);

		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true, CharSet=CharSet.Auto)]
		internal static extern BOOL LookupAccountName(
			string lpSystemName, 
			string lpAccountName, 
			PSID Sid, 
			ref DWORD cbSid, 
			[Out] char[] DomainName, 
			ref DWORD cbDomainName, 
			out SID_NAME_USE peUse
			);
		
		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true, CharSet=CharSet.Auto)]
		internal static extern BOOL InitializeSecurityDescriptor(PSECURITY_DESCRIPTOR pSecurityDescriptor, DWORD dwRevision);
		
		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true, CharSet=CharSet.Auto)]
		internal static extern BOOL GetSecurityDescriptorControl(
			PSECURITY_DESCRIPTOR pSecurityDescriptor, 
			out SecurityDescriptorControlFlags pControl, 
			out DWORD lpdwRevision
			);
		
		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true, CharSet=CharSet.Auto)]
		internal static extern BOOL GetSecurityDescriptorGroup(
			PSECURITY_DESCRIPTOR pSecurityDescriptor, 
			out PSID pGroup, 
			out BOOL lpbGroupDefaulted
			);

		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true, CharSet=CharSet.Auto)]
		internal static extern BOOL GetSecurityDescriptorOwner(
			PSECURITY_DESCRIPTOR pSecurityDescriptor, 
			out PSID pOwner, 
			out BOOL lpbOwnerDefaulted
			);
		
		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true, CharSet=CharSet.Auto)]
		internal static extern BOOL GetSecurityDescriptorDacl(
			PSECURITY_DESCRIPTOR pSecurityDescriptor, 
			out BOOL lpbDaclPresent, 
			ref PACL pDacl,     // By ref, because if "present" == false, value is unchanged
			out BOOL lpbDaclDefaulted
			);

		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true, CharSet=CharSet.Auto)]
		internal static extern BOOL GetSecurityDescriptorSacl(
			PSECURITY_DESCRIPTOR pSecurityDescriptor, 
			out BOOL lpbSaclPresent, 
			ref PACL pSacl,     // By ref, because if "present" == false, value is unchanged
			out BOOL lpbSaclDefaulted
			);

		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true, CharSet=CharSet.Auto)]
		internal static extern BOOL MakeAbsoluteSD(
			PSECURITY_DESCRIPTOR pSelfRelativeSD, 
			PSECURITY_DESCRIPTOR pAbsoluteSD, 
			ref DWORD lpdwAbsoluteSDSize, 
			PACL pDacl, 
			ref DWORD lpdwDaclSize, 
			PACL pSacl, 
			ref DWORD lpdwSaclSize, 
			PSID pOwner, 
			ref DWORD lpdwOwnerSize, 
			PSID pPrimaryGroup, 
			ref DWORD lpdwPrimaryGroupSize
			);
				
		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true, CharSet=CharSet.Auto)]
		internal static extern BOOL MakeSelfRelativeSD(
			PSECURITY_DESCRIPTOR pAbsoluteSD, 
			PSECURITY_DESCRIPTOR pSelfRelativeSD, 
			ref DWORD lpdwBufferLength
			);
		
		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true, CharSet=CharSet.Auto)]
		internal static extern BOOL SetSecurityDescriptorDacl(
			PSECURITY_DESCRIPTOR pSecurityDescriptor, 
			BOOL bDaclPresent, 
			PACL pDacl, 
			BOOL bDaclDefaulted
			);
		
		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true, CharSet=CharSet.Auto)]
		internal static extern BOOL GetFileSecurity(
			LPCTSTR lpFileName, 
			SECURITY_INFORMATION RequestedInformation, 
			PSECURITY_DESCRIPTOR pSecurityDescriptor, 
			DWORD nLength, 
			out DWORD lpnLengthNeeded
			);

		[DllImport(ExternalDll.Advapi32, CallingConvention=CallingConvention.Winapi, SetLastError=true, CharSet=CharSet.Auto)]
		internal static extern BOOL SetFileSecurity(
			LPCTSTR lpFileName, 
			SECURITY_INFORMATION SecurityInformation, 
			PSECURITY_DESCRIPTOR pSecurityDescriptor 
			);

		[DllImport(ExternalDll.Kernel32, CallingConvention=CallingConvention.Winapi, SetLastError=true, CharSet=CharSet.Auto)]
		internal static extern HLOCAL LocalFree(HLOCAL hMem);

		[DllImport("kernel32.dll", SetLastError=true)]
		internal static extern bool SetEnvironmentVariable(string lpName, string lpValue);

	}
		
}
