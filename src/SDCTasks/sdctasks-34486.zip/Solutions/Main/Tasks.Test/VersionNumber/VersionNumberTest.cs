//-----------------------------------------------------------------------
// <copyright file="CreateFTPTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Ashter Chomoko</author>
// <email>ashter_chomoko@charteris.com</email>
// <date>2004-06-02</date>
// <summary>Unit test for the Version Number tasks</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    //using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the Version Number tasks
    /// </summary>
    [TestClass]
    [Ignore]//("Remove hard coded paths")]
    public class VersionNumberTest
    {
        private const string TESTDATAPATHNAME = @"C:\Projects\Microsoft.Sdc.Configuration\Main\Src\Solutions\MainSolution\Microsoft.Sdc.Tasks.Configuration.Tasks.Test\TestData";
        private const string VERSIONCONFIGFILEPATH = @"\Main\Src\Build\Versioning\";
        
        public VersionNumberTest()
        {
        }
        [Ignore]//("Please complete with bug #")]
        public void General()
        {
            //
            VersionNumber.Load taskLoad = new VersionNumber.Load();
            
            taskLoad.ConfigFileLocation = @"C:\SourceDepotTest\TestProject\Main\Src\Build\Versioning\VersionNumber.exe.config";
            taskLoad.Execute();
            Console.WriteLine("Build Number...");
            Console.WriteLine(taskLoad.VersionNumber[0]);

            Console.WriteLine("Running VersionNumber.Update");
            VersionNumber.Update taskUpdate = new VersionNumber.Update();
            taskUpdate.VersionNumberConfigFileLocation = @"C:\SourceDepotTest\TestProject\Main\Src\Build\Versioning\VersionNumber.exe.config";
            taskUpdate.Execute();

            taskLoad.Execute();
            Console.WriteLine("Build Number...");
            Console.WriteLine(taskLoad.VersionNumber[0]);
        }

        [TestMethod]
        [Ignore]//("Please complete with bug #")]
        public void SourceControlVSS()
        {
            SourceSafe.GetVSSFiles taskGet = new SourceSafe.GetVSSFiles();
           
            taskGet.Database = @"\\127.0.0.1\SourceSafeTest\ConfigurationToolTest";
            taskGet.Username = "configtooltest";
            taskGet.Password = "password";
            taskGet.Project = @"$/Main";
            taskGet.VersionNumberConfigVSSLocation = @"$/Main/Src/Build/Versioning/VersionNumber.exe.config";
            taskGet.WorkingDirectory = TESTDATAPATHNAME;
            taskGet.VersionNumberConfigFileLocation = TESTDATAPATHNAME + VERSIONCONFIGFILEPATH + @"\VersionNumber.exe.config";

            taskGet.Execute();
            Console.WriteLine(taskGet.VersionNumber);

        }
    }
}
