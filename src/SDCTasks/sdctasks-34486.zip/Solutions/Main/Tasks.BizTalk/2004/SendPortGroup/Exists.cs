//-----------------------------------------------------------------------
// <copyright file="Exists.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2004.SendPortGroup
{
    #region Using directives
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    #endregion

    /// <summary>
    /// Checks if SendPortGroup exists
    /// </summary>
    public class Exists : BizTalk2004TaskBase
    {
        private string name;
        private bool exists;

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        [Required]
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [send port group exists].
        /// </summary>
        /// <value>
        /// 	<c>true</c> if [send port group exists]; otherwise, <c>false</c>.
        /// </value>
        [Output]
        public bool SendPortGroupExists
        {
            get { return this.exists; }
            protected set { this.exists = value; }
        }

        /// <summary>
        /// Executes the task
        /// </summary>
        protected override void InternalExecute()
        {
            BizTalkInstallation installation = this.GetInstallation();
            this.exists = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SendPortGroup.Exists(installation, this.name);
        }
    }
}

