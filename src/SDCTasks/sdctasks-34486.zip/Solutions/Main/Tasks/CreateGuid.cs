//-----------------------------------------------------------------------
// <copyright file="CreateGuid.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-03-25</date>
// <summary>Returns a String representation of the value of this new Guid.</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks
{
    using System;
    using System.Xml;
    using System.Globalization;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Returns a String representation of the value of this new Guid.
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[ 
    /// <CreateGuid>
    ///        <Output TaskParameter="GuidRegistryFormatString" ItemName="GuidRegistryFormatStringItem" />
    ///        <Output TaskParameter="GuidString" ItemName="GuidStringItem" />
    /// </CreateGuid>
    /// 
    /// ]]></code>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <CreateGuid>
    ///             <Output TaskParameter="GuidRegistryFormatString" ItemName="GuidRegistryFormatStringItem" />
    ///             <Output TaskParameter="GuidString" ItemName="GuidStringItem" />
    ///         </CreateGuid>
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class CreateGuid : TaskBase
    {
        private Guid guid;

        /// <summary>
        /// Initializes a new instance of the CreateGuid class.
        /// </summary>
        public CreateGuid()
        {
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            guid = Guid.NewGuid();
        }

        /// <summary>
        /// 32 digits separated by hyphens: 
        /// xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
        /// </summary>
        [Output]
        public string[] GuidRegistryFormatString
        {
            get
            {
                return new string[] { guid.ToString("D", CultureInfo.InvariantCulture) };
            }
        }

        /// <summary>
        /// 32 digits: 
        /// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
        /// </summary>
        [Output]
        public string[] GuidString
        {
            get
            {
                return new string[] { guid.ToString("N", CultureInfo.InvariantCulture) };
            }
        }
    }
}