//-------------------------------------------------------------------------------------
// <copyright file="Exists.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Checks whether an assembly is deployed in a BizTalk installation.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Assembly
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion

    #region Class Comments
    /// <summary>
    /// Checks whether an assembly is deployed in a BizTalk installation.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2004.Assembly.Exists DisplayName="displayName" Server="server" Database="database" />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>displayName (Required)</i></para>
    /// <para>
    /// The display name of the assembly to check for.
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// <para><i>username</i></para>
    /// <para>
    /// The username to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// <para><i>password</i></para>
    /// <para>
    /// The password to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <PropertyGroup>
    ///         <AssemblyExists />
    ///     </PropertyGroup>
    ///     <Target Name="Test" >
    ///         <BizTalk2004.Assembly.Exists 
    ///             DisplayName="MyAssembly, Version=1.0.40823.3, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, Custom=null"
    ///             Server="." 
    ///             Database="BizTalkMgmtDb" 
    ///              
    ///             >
    ///             <Output TaskParameter="DoesExist" PropertyName="AssemblyExists" />
    ///         </BizTalk2004.Assembly.Exists>
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    #endregion
    public class Exists : BizTalk2004TaskBase
    {
        #region Member Variables

        private string displayName;
        private bool doesExist;

        #endregion

        #region Constructors

        /// <summary>
        /// Creates a new instance of the exists task.
        /// </summary>
        public Exists()
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the display name of the assembly.
        /// </summary>
        /// <value>
        /// The display name of the assembly.
        /// </value>
        [Required]
        public string DisplayName
        {
            get
            {
                return this.displayName;
            }
            set
            {
                this.displayName = value;
            }
        }

        /// <summary>
        /// Gets whether the assembly does exist in the deployment.
        /// </summary>
        /// <value>
        /// <b>true</b> if the assembly does exist, or <b>false</b> otherwise.
        /// </value>
        [Output]
        public bool DoesExist
        {
            get
            {
                return this.doesExist;
            }
            protected set
            {
                this.doesExist = value;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {
            BizTalkInstallation installation = this.GetInstallation();
            this.doesExist = BizTalkAssembly.Exists(installation, this.displayName);
        }

        #endregion
    }
}

