﻿namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using directives

	using System;
	using System.Collections;
	using System.Text;

	#endregion

	internal class BtsSendPortGroupCollection : System.Collections.ReadOnlyCollectionBase
	{
		public BtsSendPortGroupCollection() { }

		public BtsSendPortGroup this[string name]
		{
			get
			{
				BtsSendPortGroup item = null;
				foreach (BtsSendPortGroup currentitem in this.InnerList)
				{
					if (currentitem.Name == name)
					{
						item = currentitem;
						break;
					}
				}
				return item;

			}
		}
		public BtsSendPortGroup this[int index]
		{
			get
			{
				return (BtsSendPortGroup)this.InnerList[index];
			}
		}

		internal void Add(BtsSendPortGroup item)
		{
			this.InnerList.Add(item);
		}


	}

}
