//-----------------------------------------------------------------------
// <copyright file="EmailTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>andyr</email>
// <date>2004-05-25</date>
// <summary>Tests sending an email</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the DeleteWebSiteTest Task
    /// </summary>
    [TestClass]
    public class EmailTest
    {
        public EmailTest()
        {
        }
       
        [TestMethod]
        [Ignore]//("Skip email test because it actually does send emails")]
        public void TestEmail()
        {
            //Create a temp folder and a couple of files
            string tempFolder = TaskTestUtilities.CreateTempFolder();
            string[] tempFiles = new string[2];

            tempFiles[0] = tempFolder + "\\" + TaskTestUtilities.CreateTempFileInFolder(tempFolder);
            tempFiles[1] = tempFolder + "\\" + TaskTestUtilities.CreateTempFileInFolder(tempFolder);

            try
            {
                Tasks.Email email = new Tasks.Email();
                
                //Generate a new random "to" address 
                string mailTo = Guid.NewGuid().ToString("N") + "@" + Guid.NewGuid().ToString("N") + ".com";
                email.MailTo = new string[] { mailTo };

                //Generate a new random "from" address
                string mailFrom = Guid.NewGuid().ToString("N") + "@" + Guid.NewGuid().ToString("N") + ".com";
                email.MailFrom = mailFrom;

                //Generate a new random "subject"
                string subject = "subject";
                email.Subject = subject;

                //Generate a new random "body"
                string body = "body";
                email.Body = body;

                string smtpServer = "smtphost";
                email.SmtpServer = smtpServer;

                //Set the priority and the format
                string format = "HTML";
                email.Format = format;

                string priority = "low";
                email.Priority = priority;

                email.Attachments = tempFiles;


                //Check that the property gets are the same as the property sets:
                Assert.AreEqual(email.MailFrom, mailFrom);
                Assert.AreEqual(email.MailTo[0], mailTo);
                Assert.AreEqual(email.Subject, subject);
                Assert.AreEqual(email.Body, body);
                Assert.AreEqual(email.SmtpServer, smtpServer);
                Assert.AreEqual(email.Format, format);
                Assert.AreEqual(email.Priority, priority);
                Assert.AreEqual(email.Attachments, tempFiles);

                bool emailTaskReturnValue = email.Execute();
                Assert.IsTrue(emailTaskReturnValue, "EmailTestSucceeded");
            }
            finally
            {
                Directory.Delete(tempFolder, true);
            }
        }

    }
}


