//-------------------------------------------------------------------------------------
// <copyright file="Configure.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Configures a send port.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.SendPort
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Text;
    using System.Xml;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion

    #region Class Comments
    /// <summary>
    /// Configures a send port.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2004.SendPort.Configure Name="name" Prority="priority" SendPipeline="sendPipeline" 
    /// ReceivePipeline="receivePipeline" TrackingTypes="trackingTypes" Filter="filter" InboundMaps="inboundMaps" OutboundMaps="outboundMaps" 
    /// PrimaryTransportAddress="transportAddress" PrimaryTransportDeliveryNotification="deliveryNotification" PrimaryTransportName="transportName"
    /// PrimaryTransportOrderedDelivery="orderedDelivery" PrimaryTransportProtocolName="protocolName" PrimaryTransportRetryCount="retryCount" 
    /// PrimaryTransportRetryInterval="retryInterval" PrimaryTransportServiceWindowEnabled="serviceWindowEnabled" PrimaryTransportServiceWindowStartTime="serviceWindowStartTime" 
    /// PrimaryTransportServiceWindowEndTime="serviceWindowEndTime" PrimaryTransportTransportData="transportData" 
    /// SecondaryTransportAddress="transportAddress" SecondaryTransportDeliveryNotification="deliveryNotification" SecondaryTransportName="transportName"
    /// SecondaryTransportOrderedDelivery="orderedDelivery" SecondaryTransportProtocolName="protocolName" SecondaryTransportRetryCount="retryCount" 
    /// SecondaryTransportRetryInterval="retryInterval" SecondaryTransportServiceWindowEnabled="serviceWindowEnabled" SecondaryTransportServiceWindowStartTime="serviceWindowStartTime" 
    /// SecondaryTransportServiceWindowEndTime="serviceWindowEndTime" SecondaryTransportTransportData="transportData" 
    /// Server="server" Database="database" />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>name (Required)</i></para>
    /// <para>
    /// The name of the send port.
    /// </para>
    /// <para><i>priority</i></para>
    /// <para>
    /// A number between 1 (highest) and 10 (lowest) which is the priority of the send port. The default is 5.
    /// </para>
    /// <para><i>sendPipeline (Required)</i></para>
    /// <para>
    /// The assembly qualified name of the send pipeline.
    /// </para>
    /// <para><i>receivePipeline</i></para>
    /// <para>
    /// The assembly qualified name of the receive pipeline. This must be specified if the send port is two way, and is
    /// ignored if it is one way.
    /// </para>
    /// <para><i>trackingTypes</i></para>
    /// <para>
    /// The types of tracking implemented by the port. This can be a combination of the following values seperated by
    /// commas: BeforeSendPipeline, AfterSendPipeline, BeforeReceivePipeline, AfterReceivePipeline. The default is no tracking.
    /// </para>
    /// <para><i>filter</i></para>
    /// <para>
    /// An XML string representing the filter expression for the port. See the BizTalk documentation for details of this
    /// format. The default is no filter.
    /// </para>
    /// <para><i>inboundMaps</i></para>
    /// <para>
    /// A delimited list of the assembly qualified names of inbound maps for the port. The default is no inbound maps.
    /// </para>
    /// <para><i>outboundMaps</i></para>
    /// <para>
    /// A delimited list of the assembly qualified names of outbound maps for the port. The default is no outbound maps.
    /// </para>
    /// <para><i>transportAddress (Required for primary, required for secondary if two way)</i></para>
    /// <para>
    /// The address (often called the URI) for the transport.
    /// </para>
    /// <para><i>deliveryNotification</i></para>
    /// <para>
    /// The types of delivery notification for the transport, which must be one of the following values: None, Transmitted.
    /// The default is None.
    /// </para>
    /// <para><i>transportName (Required for primary, required for secondary if two way)</i></para>
    /// <para>
    /// The name of the transport.
    /// </para>
    /// <para><i>orderedDelivery</i></para>
    /// <para>
    /// <b>true</b> to specify ordered delivery for a transport, or <b>false</b> otherwise. The default is <b>false</b>. Note
    /// that not all adapters support ordered delivery.
    /// </para>
    /// <para><i>protocolName (Required for primary, required for secondary if two way)</i></para>
    /// <para>
    /// The name of the protocol for the transport.
    /// </para>
    /// <para><i>retryCount</i></para>
    /// <para>
    /// The number of retries that the transport can use to send or receive a message.
    /// </para>
    /// <para><i>retryInterval</i></para>
    /// <para>
    /// The interval between retries of sending or receiving a message. The units of this are determined by the specific
    /// type of adapter, however minutes is the most common unit.
    /// </para>
    /// <para><i>serviceWindowEnabled</i></para>
    /// <para>
    /// <b>true</b> to enable a service window for the transport, or <b>false</b> if it is always active. If this is <b>true</b>
    /// then the start and end times for the window must be specified. The default is <b>false</b>.
    /// </para>
    /// <para><i>serviceWindowStartTime</i></para>
    /// <para>
    /// The start time for the service window in the format HH:mm:ss. This must be supplied if the service window is
    /// enabled, and is ignored if the service window is not enabled.
    /// </para>
    /// <para><i>serviceWindowEndTime</i></para>
    /// <para>
    /// The end time for the service window in the format HH:mm:ss. This must be supplied if the service window is
    /// enabled, and is ignored if the service window is not enabled.
    /// </para>
    /// <para><i>transportData</i></para>
    /// <para>
    /// An XML string of adapter specific initialization data. Some of these formats are documented in the BizTalk
    /// documentation. This data can be created by configuring a send port manually and then examining it using
    /// either the BizTalk API or the Microsoft.Sdc.Tasks.BizTalk2004.Configuration API.
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <BizTalk2004.SendPort.Configure
    ///             Name="Test Send Port 1"
    ///             Priority="3"
    ///             SendPipeline="Microsoft.BizTalk.DefaultPipelines.XMLTransmit, Microsoft.BizTalk.DefaultPipelines, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
    ///             ReceivePipeline="Microsoft.BizTalk.DefaultPipelines.XMLReceive, Microsoft.BizTalk.DefaultPipelines, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
    ///             TrackingTypes="AfterSendPipeline,AfterReceivePipeline"
    ///             Filter="&lt;Filter&gt;&lt;Group&gt;&lt;Statement Property=&quot;BTS.SendPortName&quot; Operator=&quot;0&quot; Value=&quot;SendPortA&quot;/&gt;&lt;/Group&gt;&lt;/Filter&gt;"
    ///             InboundMaps="CbrSample.Maps.VetsBillV1ToVetsBillV2, CbrSample.Maps, Version=1.0.0.0, Culture=neutral, PublicKeyToken=128bd009fce13573"
    ///             OutboundMaps="CbrSample.Maps.VetsBillV2ToVetsBillV1, CbrSample.Maps, Version=1.0.0.0, Culture=neutral, PublicKeyToken=128bd009fce13573"
    ///             PrimaryTransportAddress="http://localhost/senddata.aspx"
    ///             PrimaryTransportDeliveryNotification="Transmitted"
    ///             PrimaryTransportName="Test Transport 1"
    ///             PrimaryTransportOrderedDelivery="false"
    ///             PrimaryTransportProtocolName="HTTP"
    ///             PrimaryTransportRetryCount="10"
    ///             PrimaryTransportRetryInterval="5"
    ///             PrimaryTransportServiceWindowEnabled="true"
    ///             PrimaryTransportServiceWindowStartTime="09:00:00"
    ///             PrimaryTransportServiceWindowEndTime="17:30:00"    
    ///             PrimaryTransportTransportData="&lt;CustomProps&gt;&lt;ContentType vt=&quot;8&quot;&gt;text/xml&lt;/ContentType&gt;&lt;RequestTimeout vt=&quot;3&quot;&gt;0&lt;/RequestTimeout&gt;&lt;MaxRedirects vt=&quot;3&quot;&gt;5&lt;/MaxRedirects&gt;&lt;UseHandlerProxySettings vt=&quot;8&quot;&gt;-1&lt;/UseHandlerProxySettings&gt;&lt;UseProxy vt=&quot;8&quot;&gt;-1&lt;/UseProxy&gt;&lt;ProxyName vt=&quot;8&quot;&gt;sdfsd&lt;/ProxyName&gt;&lt;ProxyPort vt=&quot;3&quot;&gt;80&lt;/ProxyPort&gt;&lt;ProxyUsername vt=&quot;8&quot;&gt;Somename&lt;/ProxyUsername&gt;&lt;ProxyPassword vt=&quot;8&quot;&gt;Somepassword&lt;/ProxyPassword&gt;&lt;AuthenticationScheme vt=&quot;8&quot;&gt;Basic&lt;/AuthenticationScheme&gt;&lt;Username vt=&quot;8&quot;&gt;Somename&lt;/Username&gt;&lt;Password vt=&quot;8&quot;&gt;Somepassword&lt;/Password&gt;&lt;Certificate vt=&quot;8&quot;&gt;AAAA BBBB CCCC DDDD&lt;/Certificate&gt;&lt;UseSSO vt=&quot;11&quot;&gt;0&lt;/UseSSO&gt;&lt;AffiliateApplicationName vt=&quot;8&quot;&gt;Name&lt;/AffiliateApplicationName&gt;&lt;/CustomProps&gt;"
    ///             SecondaryTransportAddress="http://localhost/senddata.asmx"
    ///             SecondaryTransportDeliveryNotification="None"
    ///             SecondaryTransportName="Test Transport 2"
    ///             SecondaryTransportOrderedDelivery="false"
    ///             SecondaryTransportProtocolName="SOAP"
    ///             SecondaryTransportRetryCount="5"
    ///             SecondaryTransportRetryInterval="2"
    ///             SecondaryTransportServiceWindowEnabled="true"
    ///             SecondaryTransportServiceWindowStartTime="07:00:00"
    ///             SecondaryTransportServiceWindowEndTime="19:00:00"    
    ///             SecondaryTransportTransportData="&lt;CustomProps&gt;&lt;URI vt=&quot;8&quot;&gt;http://localhost/senddata.asmx&lt;/URI&gt;&lt;ClientCertificate vt=&quot;8&quot;&gt;AAAA BBBB CCCC DDDD&lt;/ClientCertificate&gt;&lt;Password vt=&quot;8&quot;&gt;somepassword&lt;/Password&gt;&lt;ProxyAddress vt=&quot;8&quot;&gt;http://someproxy&lt;/ProxyAddress&gt;&lt;ProxyPassword vt=&quot;8&quot;&gt;somepassword&lt;/ProxyPassword&gt;&lt;ProxyPort vt=&quot;3&quot;&gt;8080&lt;/ProxyPort&gt;&lt;ProxyUsername vt=&quot;8&quot;&gt;someuser&lt;/ProxyUsername&gt;&lt;UseProxy vt=&quot;11&quot;&gt;-1&lt;/UseProxy&gt;&lt;Username vt=&quot;8&quot;&gt;someuser&lt;/Username&gt;&lt;AffiliateApplicationName vt=&quot;8&quot;&gt;Name&lt;/AffiliateApplicationName&gt;&lt;/CustomProps&gt;" 
    ///             Server="." 
    ///             Database="BizTalkMgmtDb" 
    ///              
    ///              />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    #endregion
    public class Configure : BizTalk2004TaskBase
    {
        #region Member Variables - General

        private string filter;
        private string[] inboundMaps;
        private bool removeInboundMaps;
        private bool isTwoWay;
        private bool isDynamic;
        private string name;
        private string[] outboundMaps;
        private bool removeOutboundMaps;
        private int priority;
        private string receivePipeline;
        private string sendPipeline;
        private TrackingTypes trackingTypes;

        #endregion

        #region Member Variables - Primary Transport

        private string primaryTransportAddress;
        private string primaryTransportName;
        private NotificationTypes primaryTransportDeliveryNotification;
        private bool primaryTransportOrderedDelivery = false;
        private int primaryTransportRetryCount = 3;
        private int primaryTransportRetryInterval = 5;
        private string primaryTransportProtocolName;
        private string primaryTransportTransportData;
        private ServiceWindow primaryTransportServiceWindow = new ServiceWindow(false);

        #endregion

        #region Member Variables - Secondary Transport

        private string secondaryTransportAddress;
        private string secondaryTransportName;
        private NotificationTypes secondaryTransportDeliveryNotification;
        private bool secondaryTransportOrderedDelivery = false;
        private int secondaryTransportRetryCount = 3;
        private int secondaryTransportRetryInterval = 5;
        private string secondaryTransportProtocolName;
        private string secondaryTransportTransportData;
        private ServiceWindow secondaryTransportServiceWindow = new ServiceWindow(false);

        #endregion

        #region Constructors

        /// <summary>
        /// Creates a new task to Configure a send port.
        /// </summary>
        public Configure()
        {
        }

        #endregion

        #region Properties - General

        /// <summary>
        /// Gets or sets the XML string representing the send port filters.
        /// </summary>
        /// <value>
        /// An XML string representing the send port filters.
        /// </value>
        public string Filter
        {
            get
            {
                return this.filter;
            }
            set
            {
                this.filter = value;
            }
        }

        /// <summary>
        /// Gets or sets the display names of the inbound maps.
        /// </summary>
        /// <value>
        /// The display names of the inbound maps.
        /// </value>
        public string[] InboundMaps
        {
            get
            {
                return this.inboundMaps;
            }
            set
            {
                this.inboundMaps = value;
            }
        }

        /// <summary>
        /// Removes all InboundMaps
        /// </summary>
        /// <value>
        /// True to remove all inbound maps
        /// </value>
        public bool RemoveInboundMaps
        {
            get
            {
                return this.removeInboundMaps;
            }
            set
            {
                this.removeInboundMaps = value;
            }
        }

        /// <summary>
        /// Gets or sets the name of the send port to Configure.
        /// </summary>
        /// <value>
        /// The name of the send port to Configure.
        /// </value>
        [Required]
        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }

        /// <summary>
        /// Gets or sets whether the send port is two way.
        /// </summary>
        /// <value>
        /// <b>true</b> to make the send port two way, or <b>false</b> to make it one way.
        /// </value>
        public bool IsTwoWay
        {
            get
            {
                return this.isTwoWay;
            }

            set
            {
                this.isTwoWay = value;
            }
        }

        /// <summary>
        /// Gets or sets whether the send port is dynamic.
        /// </summary>
        /// <value>
        /// <b>true</b> to make the send port dynamic, or <b>false</b> to make it static.
        /// </value>
        public bool IsDynamic
        {
            get
            {
                return this.isDynamic;
            }
            set
            {
                this.isDynamic = value;
            }
        }

        /// <summary>
        /// Gets or sets the display names of the outbound maps.
        /// </summary>
        /// <value>
        /// The display names of the outbound maps.
        /// </value>
        public string[] OutboundMaps
        {
            get
            {
                return this.outboundMaps;
            }
            set
            {
                this.outboundMaps = value;
            }
        }

        /// <summary>
        /// Removes all OutboundMaps
        /// </summary>
        /// <value>
        /// True to remove all inbound maps
        /// </value>
        public bool RemoveOutboundMaps
        {
            get
            {
                return this.removeOutboundMaps;
            }
            set
            {
                this.removeOutboundMaps = value;
            }
        }

        /// <summary>
        /// Gets or sets the priority of the send port.
        /// </summary>
        /// <value>
        /// A value between 1 (highest priority) and 10 (lowest priority). The default is 5.
        /// </value>
        public int Priority
        {
            get
            {
                return this.priority;
            }
            set
            {
                if (value < 1 || value > 10)
                {
                    throw new ArgumentOutOfRangeException("value", value, "The priority must be between 1 (highest) and 10 (lowest).");
                }
                this.priority = value;
            }
        }

        /// <summary>
        /// Gets or sets the fully qualified name of the receive pipeline.
        /// </summary>
        /// <value>
        /// The fully qualified name of the receive pipeline.
        /// </value>
        public string ReceivePipeline
        {
            get
            {
                return this.receivePipeline;
            }
            set
            {
                this.receivePipeline = value;
            }
        }

        /// <summary>
        /// Gets or sets the fully qualified name of the send pipeline.
        /// </summary>
        /// <value>
        /// The fully qualified name of the send pipeline.
        /// </value>
        public string SendPipeline
        {
            get
            {
                return this.sendPipeline;
            }
            set
            {
                this.sendPipeline = value;
            }
        }

        /// <summary>
        /// Gets or sets the types of tracking done by the send port.
        /// </summary>
        /// <value>
        /// The types of tracking done by the send port.
        /// </value>
        public string TrackingTypes
        {
            get
            {
                return this.trackingTypes.ToString();
            }
            set
            {
                this.trackingTypes = (TrackingTypes)Enum.Parse(typeof(TrackingTypes), value);
            }
        }

        #endregion

        #region Properties - Primary Transport

        /// <summary>
        /// Gets or sets the address of the primary transport, often known as the URI.
        /// </summary>
        /// <value>
        /// The address of the primary transport, often known as the URI.
        /// </value>
        public string PrimaryTransportAddress
        {
            get
            {
                return this.primaryTransportAddress;
            }
            set
            {
                this.primaryTransportAddress = value;
            }
        }

        /// <summary>
        /// Gets or sets the delivery notifications for the primary transport.
        /// </summary>
        /// <value>
        /// The delivery notifications for the primary transport.
        /// </value>
        public string PrimaryTransportDeliveryNotification
        {
            get
            {
                return this.primaryTransportDeliveryNotification.ToString();
            }
            set
            {
                this.primaryTransportDeliveryNotification = (NotificationTypes)Enum.Parse(typeof(NotificationTypes), value);
            }
        }

        /// <summary>
        /// Gets or sets the name of the primary transport.
        /// </summary>
        /// <value>
        /// The name of the primary transport.
        /// </value>
        public string PrimaryTransportName
        {
            get
            {
                return this.primaryTransportName;
            }
            set
            {
                this.primaryTransportName = value;
            }
        }

        /// <summary>
        /// Gets or sets the XML string representing the primary transport initialization data.
        /// </summary>
        /// <value>
        /// The XML string representing the primary transport initialization data.
        /// </value>
        public string PrimaryTransportTransportData
        {
            get
            {
                return this.primaryTransportTransportData;
            }
            set
            {
                this.primaryTransportTransportData = value;
            }
        }

        /// <summary>
        /// Gets or sets the name of the protocol used by the primary transport.
        /// </summary>
        /// <value>
        /// The name of the protocol used by the primary transport.
        /// </value>
        public string PrimaryTransportProtocolName
        {
            get
            {
                return this.primaryTransportProtocolName;
            }
            set
            {
                this.primaryTransportProtocolName = value;
            }
        }

        /// <summary>
        /// Gets or sets whether the primary transport supports ordered delivery of messages.
        /// </summary>
        /// <value>
        /// <b>true</b> if the primary transport supports ordered delivery, or <b>false</b> otherwise.
        /// </value>
        public bool PrimaryTransportOrderedDelivery
        {
            get
            {
                return this.primaryTransportOrderedDelivery;
            }
            set
            {
                this.primaryTransportOrderedDelivery = value;
            }
        }

        /// <summary>
        /// Gets or sets the number of retries for the primary transport to send or receive a message.
        /// </summary>
        /// <value>
        /// The number of retries for the primary transport to send or receive a message.
        /// </value>
        public int PrimaryTransportRetryCount
        {
            get
            {
                return this.primaryTransportRetryCount;
            }
            set
            {
                this.primaryTransportRetryCount = value;
            }
        }

        /// <summary>
        /// Gets or sets the interval between retries on the primary transport.
        /// </summary>
        /// <value>
        /// The interval between retries on the primary transport.
        /// </value>
        public int PrimaryTransportRetryInterval
        {
            get
            {
                return this.primaryTransportRetryInterval;
            }
            set
            {
                this.primaryTransportRetryInterval = value;
            }
        }

        /// <summary>
        /// Gets or sets whether the service window for the primary transport is enabled.
        /// </summary>
        /// <value>
        /// <b>true</b> if it is enabled, or <b>false</b> otherwise.
        /// </value>
        public bool PrimaryTransportServiceWindowEnabled
        {
            get
            {
                return this.primaryTransportServiceWindow.Enabled;
            }
            set
            {
                this.primaryTransportServiceWindow.Enabled = value;
            }
        }

        /// <summary>
        /// Gets or sets the start time for the primary transport service window.
        /// </summary>
        /// <value>
        /// A <see cref="System.DateTime"/>.
        /// </value>
        public string PrimaryTransportServiceWindowStartTime
        {
            get
            {
                return this.primaryTransportServiceWindow.StartTime.ToString("HH:mm:ss");
            }
            set
            {
                this.primaryTransportServiceWindow.StartTime = XmlConvert.ToDateTime(value, XmlDateTimeSerializationMode.Utc);
                //this.primaryTransportServiceWindow.StartTime = DateTime.ParseExact(value, "HH:mm:ss", CultureInfo.InvariantCulture);
            }
        }

        /// <summary>
        /// Gets or sets the end time for the primary transport service window.
        /// </summary>
        /// <value>
        /// A <see cref="System.DateTime"/>.
        /// </value>
        public string PrimaryTransportServiceWindowEndTime
        {
            get
            {
                return this.primaryTransportServiceWindow.EndTime.ToString("HH:mm:ss");
            }
            set
            {
                this.primaryTransportServiceWindow.EndTime = XmlConvert.ToDateTime(value, XmlDateTimeSerializationMode.Utc);
                //this.primaryTransportServiceWindow.EndTime = DateTime.ParseExact(value, "HH:mm:ss", CultureInfo.InvariantCulture); ;
            }
        }

        #endregion

        #region Properties - Secondary Transport

        /// <summary>
        /// Gets or sets the address of the secondary transport, often known as the URI.
        /// </summary>
        /// <value>
        /// The address of the secondary transport, often known as the URI.
        /// </value>
        public string SecondaryTransportAddress
        {
            get
            {
                return this.secondaryTransportAddress;
            }
            set
            {
                this.secondaryTransportAddress = value;
            }
        }

        /// <summary>
        /// Gets or sets the delivery notifications for the secondary transport.
        /// </summary>
        /// <value>
        /// The delivery notifications for the secondary transport.
        /// </value>
        public string SecondaryTransportDeliveryNotification
        {
            get
            {
                return this.secondaryTransportDeliveryNotification.ToString();
            }
            set
            {
                this.secondaryTransportDeliveryNotification = (NotificationTypes)Enum.Parse(typeof(NotificationTypes), value);
            }
        }

        /// <summary>
        /// Gets or sets the name of the secondary transport.
        /// </summary>
        /// <value>
        /// The name of the secondary transport.
        /// </value>
        public string SecondaryTransportName
        {
            get
            {
                return this.secondaryTransportName;
            }
            set
            {
                this.secondaryTransportName = value;
            }
        }

        /// <summary>
        /// Gets or sets the XML string representing the secondary transport initialization data.
        /// </summary>
        /// <value>
        /// The XML string representing the secondary transport initialization data.
        /// </value>
        public string SecondaryTransportTransportData
        {
            get
            {
                return this.secondaryTransportTransportData;
            }
            set
            {
                this.secondaryTransportTransportData = value;
            }
        }

        /// <summary>
        /// Gets or sets the name of the protocol used by the secondary transport.
        /// </summary>
        /// <value>
        /// The name of the protocol used by the secondary transport.
        /// </value>
        public string SecondaryTransportProtocolName
        {
            get
            {
                return this.secondaryTransportProtocolName;
            }
            set
            {
                this.secondaryTransportProtocolName = value;
            }
        }

        /// <summary>
        /// Gets or sets whether the secondary transport supports ordered delivery of messages.
        /// </summary>
        /// <value>
        /// <b>true</b> if the secondary transport supports ordered delivery, or <b>false</b> otherwise.
        /// </value>
        public bool SecondaryTransportOrderedDelivery
        {
            get
            {
                return this.secondaryTransportOrderedDelivery;
            }
            set
            {
                this.secondaryTransportOrderedDelivery = value;
            }
        }

        /// <summary>
        /// Gets or sets the number of retries for the secondary transport to send or receive a message.
        /// </summary>
        /// <value>
        /// The number of retries for the secondary transport to send or receive a message.
        /// </value>
        public int SecondaryTransportRetryCount
        {
            get
            {
                return this.secondaryTransportRetryCount;
            }
            set
            {
                this.secondaryTransportRetryCount = value;
            }
        }

        /// <summary>
        /// Gets or sets the interval between retries on the secondary transport.
        /// </summary>
        /// <value>
        /// The interval between retries on the secondary transport.
        /// </value>
        public int SecondaryTransportRetryInterval
        {
            get
            {
                return this.secondaryTransportRetryInterval;
            }
            set
            {
                this.secondaryTransportRetryInterval = value;
            }
        }

        /// <summary>
        /// Gets or sets whether the service window for the secondary transport is enabled.
        /// </summary>
        /// <value>
        /// <b>true</b> if it is enabled, or <b>false</b> otherwise.
        /// </value>
        public bool SecondaryTransportServiceWindowEnabled
        {
            get
            {
                return this.secondaryTransportServiceWindow.Enabled;
            }
            set
            {
                this.secondaryTransportServiceWindow.Enabled = value;
            }
        }

        /// <summary>
        /// Gets or sets the start time for the secondary transport service window.
        /// </summary>
        /// <value>
        /// A <see cref="System.DateTime"/>.
        /// </value>
        public string SecondaryTransportServiceWindowStartTime
        {
            get
            {
                return this.secondaryTransportServiceWindow.StartTime.ToString("HH:mm:ss");
            }
            set
            {
                this.secondaryTransportServiceWindow.StartTime = XmlConvert.ToDateTime(value, XmlDateTimeSerializationMode.Utc);
            }
        }

        /// <summary>
        /// Gets or sets the end time for the secondary transport service window.
        /// </summary>
        /// <value>
        /// A <see cref="System.DateTime"/>.
        /// </value>
        public string SecondaryTransportServiceWindowEndTime
        {
            get
            {
                return this.secondaryTransportServiceWindow.EndTime.ToString("HH:mm:ss");
            }
            set
            {
                this.secondaryTransportServiceWindow.EndTime = XmlConvert.ToDateTime(value, XmlDateTimeSerializationMode.Utc);
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {
            //loading the send port
            BizTalkInstallation installation = this.GetInstallation();
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SendPort port = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SendPort.Load(installation, this.name);
            this.isDynamic = port.IsDynamic;
            this.isTwoWay = port.IsTwoWay;

            port.Priority = (this.priority != port.Priority && this.Priority > 0) ? this.priority : port.Priority;
            port.TrackingType = (this.trackingTypes != port.TrackingType) ? this.trackingTypes : port.TrackingType;

            //configure the pipelines if specified
            if (!string.IsNullOrEmpty(this.sendPipeline))
            {
                string pipelineAssemblyName;
                string pipelineTypeName;
                SplitQualifiedTypeName(this.sendPipeline, out pipelineTypeName, out pipelineAssemblyName);
                port.SendPipeline = installation.DeployedAssemblies[pipelineAssemblyName].Pipelines[pipelineTypeName];
                if (this.isTwoWay)
                {
                    SplitQualifiedTypeName(this.receivePipeline, out pipelineTypeName, out pipelineAssemblyName);
                    port.ReceivePipeline = installation.DeployedAssemblies[pipelineAssemblyName].Pipelines[pipelineTypeName];
                }
            }

            //create the filter
            if (!string.IsNullOrEmpty(this.filter))
            {
                port.Filters.PopulateFromFilterXml(this.filter);
            }

            if (!string.IsNullOrEmpty(this.primaryTransportName))
            {
                //configure the primary transport
                port.PrimaryTransport.Address = (!string.IsNullOrEmpty(primaryTransportAddress)) ? this.primaryTransportAddress : port.PrimaryTransport.Address;
                port.PrimaryTransport.Name = (!string.IsNullOrEmpty(this.primaryTransportName)) ? this.primaryTransportName : port.PrimaryTransport.Name;
                port.PrimaryTransport.OrderedDelivery = (this.primaryTransportOrderedDelivery != port.PrimaryTransport.OrderedDelivery) ? this.primaryTransportOrderedDelivery : port.PrimaryTransport.OrderedDelivery;
                port.PrimaryTransport.Protocol = (!string.IsNullOrEmpty(this.primaryTransportProtocolName)) ? installation.Protocols[this.primaryTransportProtocolName] : port.PrimaryTransport.Protocol;
                port.PrimaryTransport.RetryCount = (this.primaryTransportRetryCount != port.PrimaryTransport.RetryCount) ? this.primaryTransportRetryCount : port.PrimaryTransport.RetryCount;
                port.PrimaryTransport.RetryInterval = (this.primaryTransportRetryInterval != port.PrimaryTransport.RetryInterval) ? this.primaryTransportRetryInterval : port.PrimaryTransport.RetryInterval;

                if ((this.primaryTransportServiceWindow.Enabled != port.PrimaryTransport.ServiceWindow.Enabled) ||
                (this.primaryTransportServiceWindow.StartTime != port.PrimaryTransport.ServiceWindow.StartTime) ||
                (this.primaryTransportServiceWindow.EndTime != port.PrimaryTransport.ServiceWindow.EndTime))
                    port.PrimaryTransport.ServiceWindow = this.primaryTransportServiceWindow;

                if (!string.IsNullOrEmpty(this.primaryTransportTransportData))
                {
                    port.PrimaryTransport.TransportData = new TransportData(this.primaryTransportTransportData);
                }
            }


            if (!string.IsNullOrEmpty(this.secondaryTransportName))
            {
                //configure the secondary transport
                port.SecondaryTransport.Address = (string.IsNullOrEmpty(this.secondaryTransportAddress))?this.secondaryTransportAddress:port.SecondaryTransport.Address;
                port.SecondaryTransport.Name = (string.IsNullOrEmpty(this.secondaryTransportName))?this.secondaryTransportName:port.SecondaryTransport.Name;
                port.SecondaryTransport.OrderedDelivery =(this.secondaryTransportOrderedDelivery != port.SecondaryTransport.OrderedDelivery)?this.secondaryTransportOrderedDelivery:port.SecondaryTransport.OrderedDelivery;
                port.SecondaryTransport.Protocol = (!string.IsNullOrEmpty(this.secondaryTransportProtocolName))?installation.Protocols[this.secondaryTransportProtocolName]:port.SecondaryTransport.Protocol;
                port.SecondaryTransport.RetryCount = (this.secondaryTransportRetryCount != port.SecondaryTransport.RetryCount) ? this.secondaryTransportRetryCount : port.SecondaryTransport.RetryCount;
                port.SecondaryTransport.RetryInterval = (this.secondaryTransportRetryInterval != port.SecondaryTransport.RetryInterval) ? this.secondaryTransportRetryInterval : port.SecondaryTransport.RetryInterval;

                if ((this.secondaryTransportServiceWindow.Enabled != port.SecondaryTransport.ServiceWindow.Enabled) ||
                (this.secondaryTransportServiceWindow.StartTime != port.SecondaryTransport.ServiceWindow.StartTime) ||
                (this.secondaryTransportServiceWindow.EndTime != port.SecondaryTransport.ServiceWindow.EndTime))
                    port.SecondaryTransport.ServiceWindow = this.secondaryTransportServiceWindow;

                if (!string.IsNullOrEmpty(this.secondaryTransportTransportData))
                {
                    port.SecondaryTransport.TransportData = new TransportData(this.secondaryTransportTransportData);
                }
            }

            if (this.RemoveInboundMaps)
            {
                port.InboundMaps.Clear();
            }
            else
            {
                if (this.inboundMaps != null)
                {
                    port.InboundMaps.Clear();
                    //add the maps
                    foreach (string qualifiedMapName in this.inboundMaps)
                    {
                        string mapName;
                        string assemblyName;
                        SplitQualifiedTypeName(qualifiedMapName, out mapName, out assemblyName);
                        port.InboundMaps.Add(port.Installation.DeployedAssemblies[assemblyName].Maps[mapName]);
                    }
                }
            }

            if (this.RemoveOutboundMaps)
            {
                port.OutboundMaps.Clear();
            }
            else
            {
                if (this.outboundMaps != null)
                {
                    port.OutboundMaps.Clear();
                    //adding the maps
                    foreach (string qualifiedMapName in this.outboundMaps)
                    {
                        string mapName;
                        string assemblyName;
                        SplitQualifiedTypeName(qualifiedMapName, out mapName, out assemblyName);
                        port.OutboundMaps.Add(port.Installation.DeployedAssemblies[assemblyName].Maps[mapName]);
                    }
                }
            }

            //save the port
            port.Save();
        }

        #endregion
    }
}

