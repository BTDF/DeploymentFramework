﻿//-----------------------------------------------------------------------
// <copyright file="BtsOrchestrationPort.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <summary>BtsOrchestrationPort</summary>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;
    using System.Reflection;
    using Microsoft.BizTalk.ExplorerOM;

    #endregion

    internal class BtsOrchestrationPort : BtsBaseObject
    {
        /// <summary>
        /// Internal Constructor
        /// </summary>
        /// <param name="actualBtsObject">The actual Microsoft.Biztalk.ExplorerOM.BtsOrchestrationPort object that object will call.</param>
        /// <param name="catalogExplorer">The Microsoft.Sdc.Tasks.Configuration.BtsCatalogExplorer object.</param>
        internal BtsOrchestrationPort(object actualBtsObject, BtsCatalogExplorer catalogExplorer)
        {
            this.btsCatalogExplorer = catalogExplorer;
            this.actualBtsObject = actualBtsObject;
        }

        /// <summary>
        /// Gets the type of binding for the orchestration port.
        /// </summary>
        /// <value></value>
        public BindingType Binding
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("Binding", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (BindingType)Enum.Parse(typeof(BindingType), value.ToString());
            }
        }

        /// <summary>
        /// Gets the modifier of the orchestration port.
        /// </summary>
        /// <value></value>
        public PortModifier Modifier
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("Modifier", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (PortModifier)Enum.Parse(typeof(PortModifier), value.ToString());
            }
        }

        /// <summary>
        /// Gets the name of the orchestration port.
        /// </summary>
        /// <value></value>
        public string Name
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("Name", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>
        /// Gets the reference to the containing orchestration.
        /// </summary>
        /// <value></value>
        public BtsOrchestration Orchestration
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("Orchestration", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (value != null) ? new BtsOrchestration(value, this.btsCatalogExplorer) : null;
            }
        }

        // TODO:portType

        /// <summary>
        /// Gets or sets the receive port bound to the orchestration port.
        /// </summary>
        /// <value></value>
        public BtsReceivePort ReceivePort
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("ReceivePort", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (value != null) ? new BtsReceivePort(value, this.btsCatalogExplorer) : null;
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("ReceivePort", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? ((BtsReceivePort)value).actualBtsObject : null });
            }
        }

        /// <summary>
        /// Gets or sets the send port bound to the orchestration port.
        /// </summary>
        /// <value></value>
        public BtsSendPort SendPort
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("SendPort", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (value != null) ? new BtsSendPort(value, this.btsCatalogExplorer) : null;
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("SendPort", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? ((BtsSendPort)value).actualBtsObject : null });
            }
        }

        /// <summary>
        /// Gets or sets the send port group bound to the orchestration port.
        /// </summary>
        /// <value></value>
        public BtsSendPortGroup SendPortGroup
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("SendPortGroup", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (value != null) ? new BtsSendPortGroup(value, this.btsCatalogExplorer) : null;
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("SendPortGroup", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? ((BtsSendPortGroup)value).actualBtsObject : null });
            }
        }
    }
}
