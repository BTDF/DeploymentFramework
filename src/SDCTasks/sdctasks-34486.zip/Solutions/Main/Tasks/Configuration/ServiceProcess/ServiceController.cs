/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.ServiceProcess {
	using System;
	using System.Management;
	using System.Globalization;


	/// <summary>
	/// Summary description for ServiceController.
	/// </summary>
	internal class ServiceController : System.ServiceProcess.ServiceController {
		
		private string identity;
		
		public ServiceController() : base() {}

		public ServiceController(string name) : base(name) {		
			identity = ServiceController.GetIdentity(name, "localhost");		
		}

		public ServiceController(string name, string machineName): base(name, machineName) {
			identity = ServiceController.GetIdentity(name, machineName);
		}
		
		public static string GetIdentity(string serviceName, string machineName) {

			ManagementScope scope = CreateScope(null, null, machineName);

			SelectQuery query = new SelectQuery("Win32_Service", String.Format(CultureInfo.InvariantCulture, "Name='{0}'", serviceName));
			ManagementObjectSearcher searcher =	new ManagementObjectSearcher(scope, query);
			ManagementObjectCollection moc = searcher.Get();

			string startName = null;
			foreach (ManagementObject service in moc) {				
				startName = (string)service.GetPropertyValue("StartName");
				break;
			}
			return startName;
		}

		private static ManagementScope CreateScope(string userName, string password, string machineName) {
			//Build an options object for the connection
			ConnectionOptions options = new ConnectionOptions();
			if (machineName.Trim().ToLower(CultureInfo.InvariantCulture) != "localhost") {
				options.Username = userName;
				options.Password = password;
			}
			//Make a connection to a remote computer using these options
			ManagementScope scope = new ManagementScope(@"\\" + machineName + @"\root\cimv2", options);
			scope.Connect();
			return scope;
		}

		public static void SetIdentity(string serviceName, string identity, string password) {

			ManagementObjectSearcher searcher = new ManagementObjectSearcher(String.Format(CultureInfo.InvariantCulture, "SELECT * FROM Win32_Service WHERE Name = '{0}'", serviceName));
			ManagementObjectCollection moc = searcher.Get();

			foreach (ManagementObject service in moc) {				
				object[] changeArgs = new object[]{null, null, null, null, null, null, identity, password};
				int result = Convert.ToInt32(service.InvokeMethod("Change", changeArgs), CultureInfo.InvariantCulture);
				if (result != 0) {
					throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Error changing service identity of {0} to {1}",serviceName, identity));
				}
			}

		}

        public static void SetStartupMode(string serviceName, string mode) 
        {

            ManagementObjectSearcher searcher = new ManagementObjectSearcher(String.Format(CultureInfo.InvariantCulture, "SELECT * FROM Win32_Service WHERE Name = '{0}'", serviceName));
            ManagementObjectCollection moc = searcher.Get();

            foreach (ManagementObject service in moc) 
            {				
                object[] changeArgs = new object[]{null, null, null, null, mode};
                int result = Convert.ToInt32(service.InvokeMethod("Change", changeArgs), CultureInfo.InvariantCulture);
                if (result != 0) 
                {
                    throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Error changing startup mode of {0} to {1}",serviceName, mode));
                }
            }

        }

		public static bool Exists(string serviceName, string machineName) 
        {

			//TODO May need a different username and password to connect as

			ConnectionOptions options = new ConnectionOptions();
			
			ManagementScope scope = new ManagementScope(@"\\" + machineName + @"\root\cimv2", options);
			scope.Connect();
			
			SelectQuery query = new SelectQuery("Win32_Service", String.Format(CultureInfo.InvariantCulture, "Name='{0}'", serviceName));
			ManagementObjectSearcher searcher =	new ManagementObjectSearcher(scope, query);

			ManagementObjectCollection moc = searcher.Get();

			return moc.Count > 0 ? true : false;
		}
		
		public string Identity {
			get {
				return (identity == null ? String.Empty : identity);
			}			
		}

    public static bool IsDisabled(string serviceName)
    {
      ManagementScope scope = CreateScope(null, null, "localhost");

      SelectQuery query = new SelectQuery("Win32_Service", String.Format(CultureInfo.InvariantCulture, "Name='{0}'", serviceName));
      ManagementObjectSearcher searcher = new ManagementObjectSearcher(scope, query);
      ManagementObjectCollection moc = searcher.Get();

      string startMode = null;
      foreach (ManagementObject service in moc)
      {
        startMode = (string)service.GetPropertyValue("StartMode");
        if (startMode == "Disabled")
        {
          return true;
        }
        break;
      }
      return false;
    }
	}
}
