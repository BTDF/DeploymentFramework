/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Giles Knap/Author>
  <Date 09 JUL 2005/>
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2005 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/


namespace Microsoft.Sdc.Tasks.Configuration.Web 
{
    using System.Globalization;
    using System;
    using System.DirectoryServices;
    using System.Security.Principal;
    using System.Collections;
    using System.Runtime.InteropServices;
    using Microsoft.Sdc.Tasks.Configuration.Framework;
    using System.Text;

    /// <summary>
    /// Represents the list of configured allowable HttpHeaders in a WebSite (todo, should be a site or VDIR)
    /// </summary>
    internal class HttpHeaders 
    {
        private WebSite                     site = null;
        private DirectoryEntry              rootDe = null;
        private DirectoryEntry              siteDe = null;
        private PropertyValueCollection     headersList;

        public HttpHeaders(WebSite site) 
        {
            this.site = site;
            siteDe = site.GetDirectoryEntry();

            rootDe = siteDe.Children.Find("ROOT", "IIsWebVirtualDir");
            
            headersList = (PropertyValueCollection)rootDe.Properties["HttpCustomHeaders"];
        }

        private string CreateCustomeHeaderObject(string headerName, string headerValue)
        {            
            string header = headerName + ": " + headerValue;

            return header;
        }

        /// <summary>
        /// Check if a given mime type exists
        /// </summary>
        /// <param name="headerName"></param>
        /// <param name="headerValue">Mime type to look for</param>
        /// <returns>true if the mime type exists</returns>
        public bool Exists(string headerName, string headerValue)
        {
            string c = CreateCustomeHeaderObject(headerName, headerValue);
            return headersList.Contains(c);
        }

        public void Add(string headerName, string headerValue)
        {
            string c = CreateCustomeHeaderObject(headerName, headerValue);
            if(!headersList.Contains(c))
            {
                headersList.Add(c);
                rootDe.CommitChanges();
            }
        }

        public void Delete(string headerName, string headerValue)
        {
            string c = CreateCustomeHeaderObject(headerName, headerValue);
            headersList.Remove(c);
            rootDe.CommitChanges();      
        }
    }
}

