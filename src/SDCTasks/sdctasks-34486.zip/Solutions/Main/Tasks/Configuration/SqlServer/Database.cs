/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.SqlServer {
	using System;
    using System.Data;
    using System.Data.SqlClient;
    using System.Globalization;

	/// <summary>
	/// Utility class that can be used to determine if a database exists. 
	/// Also provides a means of disconnecting current users connected 
	/// to a database.
	/// </summary>
	internal sealed class Database {

        #region Private members

        private const string disconnectUserSql =
            "USE master;                                \r\n" +
            "DECLARE curkillproc                        \r\n" +
            "CURSOR FOR SELECT                          \r\n" +
            "   spid,dbs.name AS dbname                 \r\n" +
            "FROM                                       \r\n" +
            "   master..sysprocesses pro,               \r\n" +
            "   master..sysdatabases dbs                \r\n" +
            "WHERE                                      \r\n" +
            "   pro.dbid = dbs.dbid AND                 \r\n" +
            "   dbs.name = '{0}'                         \r\n" +
            "FOR READ ONLY                              \r\n" +
            "                                           \r\n" +
            "DECLARE @varspid AS integer                \r\n" +
            "DECLARE @vardbname AS varchar(256)         \r\n" +
            "DECLARE @numUsers AS integer               \r\n" +
            "SET @numUsers = 0                          \r\n" +
            "OPEN curkillproc                           \r\n" +
            "FETCH NEXT FROM                            \r\n" +
            "   curkillproc                             \r\n" +
            "INTO @varspid, @vardbname                  \r\n" +
            "WHILE @@fetch_status = 0                   \r\n" +
            "BEGIN                                      \r\n" +
            "   EXEC('kill ' + @varspid)                \r\n" +
            "   SET @numUsers = @numUsers + 1           \r\n" +
	        "   FETCH NEXT FROM curkillproc             \r\n" +
            "   INTO @varspid, @vardbname               \r\n" +
            "END                                        \r\n" +
            "CLOSE curkillproc                          \r\n" +
            "DEALLOCATE curkillproc                     \r\n" +
            "SELECT @numUsers as NumUsersDisconnected   \r\n";

        #endregion

        /// <summary>
        /// Default constructor
        /// </summary>
		private Database() {			
		}

        /// <summary>
        /// Determines whether a database exists on the local machine.
        /// </summary>
        /// <param name="databaseName">
        /// The name of a database whose existence needs to be determined.
        /// </param>
        /// <returns>
        /// Returns true if the datbase exist, otherwise false.
        /// </returns>
		public static bool Exists(string databaseName) {
			return Exists(databaseName, "localhost");
		}

        /// <summary>
        /// Determines whether a database exists on a specified server.
        /// </summary>
        /// <param name="databaseName">
        /// The name of a database whose existence needs to be determined.
        /// </param>
        /// <param name="serverName">
        /// The name of the SQL server to check on.
        /// </param>
        /// <returns>
        /// Returns true if the datbase exist, otherwise false.
        /// </returns>
		public static bool Exists(string databaseName, string serverName) {
            return ScriptExecutor.ExecuteExistsScript(
                "master",
                serverName,
                "SELECT CATALOG_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE CATALOG_NAME = N'{0}'",
                databaseName );
		}

        /// <summary>
        /// Disconnects user processes connected to a SQL Server database on 
        /// the local machine.
        /// </summary>
        /// <param name="databaseName">
        /// The database to disconnect the user processes from.
        /// </param>
        /// <returns>
        /// The number of users disconnected.
        /// </returns>
        public static int DisconnectUserProcesses(string databaseName) {
            return DisconnectUserProcesses(databaseName, "localhost", 30);
        }

        /// <summary>
        /// Disconnects user processes connected to a SQL Server database 
        /// specifying the time allowed for the operation to take before an 
        /// error is reported.
        /// </summary>
        /// <param name="databaseName">
        /// The database to disconnect the user processes from.
        /// </param>
        /// <param name="commandTimeout">
        /// The time in seconds for the operation to take before raising an
        /// error.
        /// </param>
        /// <returns>
        /// The number of users disconnected.
        /// </returns>
        public static int DisconnectUserProcesses(string databaseName, int commandTimeout) {
            return DisconnectUserProcesses(databaseName, "localhost", commandTimeout);
        }

        /// <summary>
        /// Disconnects user processes connected to a SQL Server database on a specific server.
        /// </summary>
        /// <param name="databaseName">
        /// The database to disconnect the user processes from.
        /// </param>
        /// <param name="serverName">
        /// The name of the server that the database exists on.
        /// </param>
        /// <returns>
        /// The number of users disconnected.
        /// </returns>
        public static int DisconnectUserProcesses(string databaseName, string serverName) {
            return DisconnectUserProcesses(databaseName, serverName, 30);
        }

        /// <summary>
        /// Disconnects user processes connected to a SQL Server database on 
        /// a specific server, specifying the time allowed for the operation 
        /// to take before an error is reported.
        /// </summary>
        /// <param name="databaseName">
        /// The database to disconnect the user processes from.
        /// </param>
        /// <param name="serverName">
        /// The name of the server that the database exists on.
        /// </param>
        /// <param name="commandTimeout">
        /// The time in seconds for the operation to take before raising an
        /// error.
        /// </param>
        /// <returns>
        /// The number of users disconnected.
        /// </returns>
        public static int DisconnectUserProcesses(
            string databaseName,
            string serverName,
            int commandTimeout ) {

            // Prepare dynamic SQL statement to disconnect current users
            string commandText = string.Format (CultureInfo.InvariantCulture, disconnectUserSql, databaseName);
            // Connect to the "master" database
            SqlConnection sqlConnection =
                       new SqlConnection(ScriptExecutor.DetermineConnectionString ("master", serverName));
            return( DoDisconnect(sqlConnection, databaseName, commandTimeout));        
        }

        /// <summary>
        /// Disconnects user processes connected to a SQL Server database on 
        /// a specific server, specifying the time allowed for the operation 
        /// to take before an error is reported.
        /// </summary>
        /// <param name="connectionString">
        /// A valid OLE/DB connection string to build the connection from.
        /// </param>
        /// <param name="databaseName">
        /// The database to disconnect the user processes from.
        /// </param>
        /// <param name="commandTimeout">
        /// The time in seconds for the operation to take before raising an
        /// error.
        /// </param>
        /// <returns>
        /// The number of users disconnected.
        /// </returns>
            public static int DisconnectUserProcessesWithConnectionString( 
            string connectionString,
            string databaseName,
            int    commandTimeout)
        {
            SqlConnection sqlConnection =
              new SqlConnection(connectionString);

            return( DoDisconnect(sqlConnection, databaseName, commandTimeout));        


        }

        /// <summary>
        /// Internal helper to actually do the disconnect
        /// </summary>
        /// <param name="sqlConnection">A valid, preopulated SqlConnection object</param>
        /// <param name="databaseName">
        /// The database to disconnect the user processes from.
        /// </param>
        /// <param name="commandTimeout">
        /// The time in seconds for the operation to take before raising an
        /// error.
        /// </param>
        /// <returns>
        /// The number of users disconnected.
        /// </returns>
        private static int DoDisconnect(SqlConnection sqlConnection, string databaseName, int commandTimeout)
        {
            // Prepare dynamic SQL statement to disconnect current users
            string commandText = string.Format (CultureInfo.InvariantCulture, disconnectUserSql, databaseName);
            // Connect to the "master" database
            SqlCommand command = new SqlCommand (commandText, sqlConnection);
            command.CommandTimeout = commandTimeout;
            sqlConnection.Open();
            // Execute and return the number of users disconnected
            return((int)command.ExecuteScalar());
        }

	}
}
