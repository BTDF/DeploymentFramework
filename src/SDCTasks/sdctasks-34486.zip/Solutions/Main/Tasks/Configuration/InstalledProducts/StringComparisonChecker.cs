using System;
using System.Reflection;

namespace Microsoft.Sdc.Tasks.Configuration.InstalledProducts
{
	/// <summary>
	/// Compares string values together. Supports equals, contains, startswith and endswith BinaryComparisonOperators.
	/// </summary>
	internal class StringComparisonChecker : IBinaryComparisonChecker
	{

		private BinaryComparisonOperator _comparisonOperator;
		public BinaryComparisonOperator Operator
		{
			get
			{
				return _comparisonOperator;
			}
			set
			{
				this._comparisonOperator = value;
			}
		}

		public bool IsMatch(object baseObject, object compareObject)
		{
			string baseString = (string)baseObject;
			string compareString = (string)compareObject;
			bool result;
			switch (Operator)
			{
				case BinaryComparisonOperator.Equals: 
					result= baseString.Equals(compareString);
					break;
				case BinaryComparisonOperator.Contains: 
					result = (baseString.IndexOf(compareString)>=0);
					break;
                case BinaryComparisonOperator.StartsWith:
                    result = baseString.StartsWith(compareString, System.StringComparison.OrdinalIgnoreCase);
                    break;
                case BinaryComparisonOperator.EndsWith:
                    result = baseString.EndsWith(compareString, System.StringComparison.OrdinalIgnoreCase);
                    break;
				default: throw new ApplicationException("Binary operator not supported in this checker:"+Operator);
			}
			return result;
		}

		public StringComparisonChecker(BinaryComparisonOperator op)
		{
			this.Operator = op;
		}
	}
}
