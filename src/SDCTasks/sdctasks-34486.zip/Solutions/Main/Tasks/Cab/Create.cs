//-----------------------------------------------------------------------
// <copyright file="Create.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Burns</author>
// <email></email>
// <date>2004-03-25</date>
// <summary>Creates the CabFile specified.</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Cab
{
    using System;
    using System.Xml;
    using System.Globalization;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Creates the CabFile specified.
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<Cab.Create PathToCabFile="pathToCabFile" />]]></code>
    /// <para>where:</para>
    /// <para><i>pathToCabFile (Required)</i></para>
    /// <para>The path to the cab file that will be created.</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <Cab.Create
    ///             PathToCabFile="C:\Archives\CabFile.cab"
    ///             PathToFile="C:\Assemblies\MyAssembly.dll"
    ///             Path="C:\CabInstall\Cabarc.exe"  />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Create : TaskBase
    {
        private string pathToCabFile = String.Empty;

        /// <summary>
        /// Initializes a new instance of the Cab.Create class.
        /// </summary>
        public Create()
        {
        }
        
        /// <summary>
        /// The path to the cab file that will be created.
        /// </summary>
        /// <value>The path to the cab file that will be created.</value>
        [Required]
        public string PathToCabFile
        {
            get
            {
                return (this.pathToCabFile == null ? String.Empty : this.pathToCabFile);
            }

            set
            {
                this.pathToCabFile = value;
            }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            #region Execute code

            Log.LogMessageFromResources("Cab.Create", this.pathToCabFile);
            Microsoft.Sdc.Tasks.Configuration.Cab.Create(this.pathToCabFile);

            #endregion
        }
    }
}