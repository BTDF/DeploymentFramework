/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Giles Knap/Author>
  <Date 09 JUL 2005/>
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2005 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/


namespace Microsoft.Sdc.Tasks.Configuration.Web 
{
    using System.Globalization;
    using System;
    using System.DirectoryServices;
    using System.Security.Principal;
    using System.Collections;
    using System.Runtime.InteropServices;
    using Microsoft.Sdc.Tasks.Configuration.Framework;
    using System.Text;

    /// <summary>
    /// Represents the list of configured SSL Certificate for a site
    /// </summary>
    internal class ServerCertificate
    {
        [Flags]
        internal enum SslAccessFlags // IIS LogExtFileFlags
        {
            SslAny = 0x00000000,
            RequireSsl = 0x00000008,
            RequireSsl128 = 0x00000100,
            MapClientCert = 0x00000080,
            RequestClientCert = 0x00000020,
            RequireClientCert = 0x00000040
        }

        private WebSite                     site = null;
        private DirectoryEntry              siteDe = null;
        private DirectoryEntry              rootDe = null;
        private PropertyValueCollection     sslCertHash;
        private PropertyValueCollection     sslStoreName;
        private PropertyValueCollection     sslFlags;

        public ServerCertificate(WebSite site) 
        {
            this.site = site;
            siteDe = site.GetDirectoryEntry();
            rootDe = siteDe.Children.Find("ROOT", "IIsWebVirtualDir");

            sslCertHash = (PropertyValueCollection)siteDe.Properties["SSLCertHash"];
            sslStoreName = (PropertyValueCollection)siteDe.Properties["SSLStoreName"];
            sslFlags = (PropertyValueCollection)rootDe.Properties["AccessSSLFlags"];
        }

        public void Update(object[] certHash, string certStoreName, SslAccessFlags flags)
        {           
            sslStoreName.Clear();
            sslCertHash.Clear();
            sslFlags.Clear(); 

            sslStoreName.Add(certStoreName);
            sslCertHash.Add((Array)certHash);
            sslFlags.Add(flags);

            rootDe.CommitChanges();
            siteDe.CommitChanges();
        }

        public void Update(string certHash, string certStoreName, SslAccessFlags flags)
        {
            // To add a binary value to the metabase we need to split the hex string
            // representation of the value into an array of strings that represent the hex
            // value of each byte then wrap each string in an object, to create an object
            // array. 
            // as per MSDN article
            // http://msdn.microsoft.com/library/default.asp?url=/library/en-us/iissdk/html/daa194c8-2458-4a86-b797-cd9bbf342c3f.asp

            int numBytes = (int)(certHash.Length / 2);
            string[] byteArray = new string[numBytes];
            for (int i = 0; i < numBytes; ++i)
            {
                byteArray[i] = certHash.Substring(i * 2, 2);
            }

            object[] newObj = new object[byteArray.Length];
            byteArray.CopyTo(newObj, 0);

            this.Update(newObj, certStoreName, flags);
        }

        public void Delete()
        {
            sslStoreName.Clear();
            sslCertHash.Clear();

            siteDe.CommitChanges();      
        }
    }
}

