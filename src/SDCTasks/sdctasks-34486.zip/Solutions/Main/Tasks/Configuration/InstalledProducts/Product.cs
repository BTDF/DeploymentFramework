using System;

namespace Microsoft.Sdc.Tasks.Configuration.InstalledProducts
{
	/// <summary>
	/// Represents an installed product
	/// </summary>
    public class Product
	{
		private string _Caption;
		private string _Description;
		private string _IdentifyingNumber;
		private string _InstallDate;
		private DateTime _InstallDate2;
		private string _InstallLocation;
		private InstallState _InstallState;
		private string _Name;
		private string _PackageCache;
		private string _SKUNumber;
		private string _Vendor;
		private string _Version;

		/// <summary>
		/// Short textual description for the product�a one-line string
		/// </summary>
		public string Caption
		{
			get
			{
				return _Caption;
			}
			set
			{
				this._Caption = value;
			}
		}

		/// <summary>
		/// Description of the product
		/// </summary>
		public string Description
		{
			get
			{
				return _Description;
			}
			set
			{
				this._Description = value;
			}
		}

		/// <summary>
		/// Product identification such as a serial number on software, or a die number on a hardware chip.
		/// </summary>
		public string IdentifyingNumber
		{
			get
			{
				return _IdentifyingNumber;
			}
			set
			{
				this._IdentifyingNumber = value;
			}
		}

		/// <summary>
		/// Date that this product is installed on the system. This property does not need a value to 
		/// indicate that the object is installed. This property is no longer supported for Win32_Product. 
		/// New implementations should use the InstallDate2 property.
		/// </summary>
		public string InstallDate
		{
			get
			{
				return _InstallDate;
			}
			set
			{
				this._InstallDate = value;
			}
		}

		/// <summary>
		/// Windows Server 2003 and Windows XP:  Date that this product was installed on the system. 
		/// This property does not need a value to indicate that the object is installed.
		/// </summary>
		public DateTime InstallDate2
		{
			get
			{
				return _InstallDate2;
			}
			set
			{
				this._InstallDate2 = value;
			}
		}

		/// <summary>
		/// Location of the installed product.
		/// </summary>
		public string InstallLocation
		{
			get
			{
				return _InstallLocation;
			}
			set
			{
				this._InstallLocation = value;
			}
		}

		/// <summary>
		/// Installed state of the product.
		/// </summary>
		public InstallState InstallState
		{
			get
			{
				return _InstallState;
			}
			set
			{
				this._InstallState =value;
			}
		}

		/// <summary>
		/// Commonly used product name.
		/// </summary>
		public string Name
		{
			get
			{
				return _Name;
			}
			set
			{
				this._Name =value;
			}
		}

		/// <summary>
		/// Location of the locally cached package for this product
		/// </summary>
		public string PackageCache
		{
			get
			{
				return _PackageCache;
			}
			set
			{
				this._PackageCache = value;
			}
		}

		/// <summary>
		/// Stock Keeping Unit
		/// </summary>
		public string SKUNumber
		{
			get
			{
				return _SKUNumber;
			}
			set
			{
				this._SKUNumber = value;
			}
		}

		/// <summary>
		/// Name of the product supplier. Corresponds to the Vendor property in the product object in the 
		/// Desktop Management Task Force (DMTF) Solution Exchange Standard.
		/// </summary>
		public string Vendor
		{
			get
			{
				return _Vendor;
			}
			set
			{
				this._Vendor = value;
			}
		}

		/// <summary>
		/// Product version information. Corresponds to the Version property in the product object in the 
		/// DMTF Solution Exchange Standard.
		/// </summary>
		public string Version
		{
			get
			{
				return _Version;
			}
			set
			{
				this._Version = value;
			}
		}

		public Product()
		{
		}

		public Product(string name)
		{
			this.Name = name;
		}

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

		public override bool Equals(Object o)
		{
			if (o is Product && o != null)
			{	
				Product compareProduct = ((Product)o);
				if (compareProduct.Name == this.Name)
				{
					
					if (this.Version != null && compareProduct.Version != null)
					{
						return (this.Version==compareProduct.Version);
					}
					else
					{
						return true;
					}
				}
			}
			return false;
		}

	}

	public enum InstallState : short
	{
		BadConfiguration=-6,
		InvalidArgument=-2,
		UnknownPackage=-1,
		Advertised=1,
		Absent=2,
		Installed=5
	}
}
