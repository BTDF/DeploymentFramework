//-----------------------------------------------------------------------
// <copyright file="Configure.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.ReceiveLocation
{
    using System;
    using System.Globalization;
    using BizTalk.ExplorerOM;

    /// <summary>
    /// Configure ReceiveLocation
    /// </summary>
    public class Configure : BizTalk2004.ReceiveLocation.Configure
    {
        private string application;
        private string description;
        private Fragmentation fragmentMessages;
        private bool isprimary;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is primary.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is primary; otherwise, <c>false</c>.
        /// </value>
        public bool IsPrimary
        {
            get { return this.isprimary; }
            set { this.isprimary = value; }
        }

        /// <summary>
        /// Gets or sets the Fragmentation
        /// </summary>
        /// <value>The fragment messages.</value>
        public Fragmentation FragmentMessages
        {
            get { return this.fragmentMessages; }
            set { this.fragmentMessages = value; }
        }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>The description.</value>
        public string Description
        {
            get { return this.description; }
            set { this.description = value; }
        }

        /// <summary>
        /// Gets or sets the application.
        /// </summary>
        /// <value>The application.</value>
        public string Application
        {
            get { return this.application; }
            set { this.application = value; }
        }

        /// <summary>
        /// Execute the task
        /// </summary>
        protected override void InternalExecute()
        {
            if (string.IsNullOrEmpty(this.Application))
            {
                base.InternalExecute();
            }
            else
            {
                BtsCatalogExplorer explorer = this.GetBtsCatalogExplorer(this.Server, this.Database);

                Application app = explorer.Applications[this.Application];
                if (app != null)
                {
                    ReceivePort port = app.ReceivePorts[this.ReceivePort];
                    if (port != null)
                    {
                        ReceiveLocation receiveLocation = port.ReceiveLocations[this.Name];
                        if (receiveLocation == null)
                        {
                            Log.LogError(string.Format(CultureInfo.InvariantCulture, "ReceiveLocation does not exist: {0} for Application: {1}", this.Name, this.Application));
                            return;
                        }
                        else
                        {
                            receiveLocation.Description = (!string.IsNullOrEmpty(this.Description)) ? this.Description : receiveLocation.Description;
                            receiveLocation.Address = (!string.IsNullOrEmpty(this.Address)) ? this.Address : receiveLocation.Address;
                            if (!string.IsNullOrEmpty(this.PublicAddress))
                            {
                                receiveLocation.PublicAddress = this.PublicAddress;
                            }

                            receiveLocation.Enable = this.Enable;
                            receiveLocation.FragmentMessages = this.FragmentMessages;

                            if (!string.IsNullOrEmpty(this.ReceiveHandler))
                            {
                                foreach (ReceiveHandler handler in explorer.ReceiveHandlers)
                                {
                                    if (handler.Name == this.ReceiveHandler && handler.TransportType.Name == this.TransportType)
                                    {
                                        receiveLocation.ReceiveHandler = handler;
                                        break;
                                    }
                                }
                            }

                            if (!string.IsNullOrEmpty(this.ReceivePipeline))
                            {
                                string pipelineName;
                                string assemblyName;
                                SplitQualifiedTypeName(this.ReceivePipeline, out pipelineName, out assemblyName);

                                receiveLocation.ReceivePipeline = explorer.Pipelines[pipelineName, assemblyName];
                            }

                            receiveLocation.StartDateEnabled = this.StartDateEnabled;
                            receiveLocation.StartDate = (!string.IsNullOrEmpty(this.StartDate)) ? DateTime.Parse(this.StartDate) : receiveLocation.StartDate;

                            receiveLocation.EndDateEnabled = this.EndDateEnabled;
                            receiveLocation.EndDate = (!string.IsNullOrEmpty(this.EndDate)) ? DateTime.Parse(this.EndDate) : receiveLocation.EndDate;

                            if (!string.IsNullOrEmpty(this.TransportType))
                            {
                                receiveLocation.TransportType = explorer.ProtocolTypes[this.TransportType];
                            }

                            receiveLocation.TransportTypeData = (!string.IsNullOrEmpty(this.TransportTypeData)) ? this.TransportTypeData : receiveLocation.TransportTypeData;

                            receiveLocation.ServiceWindowEnabled = this.ServiceWindowEnabled;
                            Log.LogMessage(string.Format(CultureInfo.InvariantCulture, "Configuring RecieveLocation: {0} for RecievePort: {1} in Application {2}", this.Name, this.ReceivePort, this.Application));
                            explorer.SaveChanges();
                        }
                    }
                    else
                    {
                        Log.LogError(string.Format(CultureInfo.InvariantCulture, "ReceivePort does not exist: {0} for Application: {1}", this.ReceivePort, this.Application));
                        return;
                    }
                }
                else
                {
                    Log.LogError(string.Format(CultureInfo.InvariantCulture, "Application not found: {0}", this.Application));
                    return;
                }
            }
        }
    }
}
