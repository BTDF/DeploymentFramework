/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Giles Knap/Author>
  <Date 22 Nov 2005/>
  <Description modifies logging settings for a website />
  <Copyright><![CDATA[
    Copyright � 2001 - 2005 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/


namespace Microsoft.Sdc.Tasks.Configuration.Web 
{
    using System.Globalization;
    using System;
    using System.DirectoryServices;
    using System.Security.Principal;
    using System.Collections;
    using System.Runtime.InteropServices;
    using Microsoft.Sdc.Tasks.Configuration.Framework;
    using System.Text;

    /// <summary>
    /// Represents the list of allowable LogFileSettings in a WebSite 
    /// </summary>
    internal class LogFileSettings 
    {
        [Flags]
        internal enum LogExtFlags // IIS LogExtFileFlags
        {
            LogExtFileDate = 0x00000001, // Log date
            LogExtFileTime = 0x00000002, // Log time
            LogExtFileClientIp = 0x00000004, // Log client IP address
            LogExtFileUserName = 0x00000008, // Log user name
            LogExtFileSiteName = 0x00000010, // Log site name
            LogExtFileComputerName = 0x00000020, // Log computer name
            LogExtFileServerIp = 0x00000040, // Log server's own IP address
            LogExtFileMethod = 0x00000080, // Log protocol method
            LogExtFileUriStem = 0x00000100, // Log URI stem
            LogExtFileUriQuery = 0x00000200, // Log URI query
            LogExtFileHttpStatus = 0x00000400, // Log HTTP status
            LogExtFileWin32Status = 0x00000800, // Log WIN32 status
            LogExtFileBytesSent = 0x00001000, // Log total bytes sent
            LogExtFileBytesRecv = 0x00002000, // Log total bytes received
            LogExtFileTimeTaken = 0x00004000, // Log total time elapsed
            LogExtFileServerPort = 0x00008000, // Log server port
            LogExtFileUserAgent = 0x00010000, // Log user agent
            LogExtFileCookie = 0x00020000, // Log cookie
            LogExtFileReferer = 0x00040000, // Log referrer
            LogExtFileProtocolVersion = 0x00080000, // Log client server protocol version

            // default settings: or this with the settings you want to add to the default set
            LogExtDefault = 0x00218fdf,

            // The following values are not available for IIS 5.0 (Windows 2000)
            LogExtFileHost = 0x00100000, // [IIS 5.1][IIS 6.0] Log the name of host server.
            LogExtFileHttpSubStatus = 0x00200000, // [IIS 6.0] Log the sub-status code of the HTTP error. For example, for the 500.18 HTTP error, the status code is 500 and the sub-status code is 18.

            LogExtFileAll_2000 = 0xFFFFF, // [IIS 5.0] Log everything
            LogExtFileAll_XP = 0x1FFFFF, // [IIS 5.1] Log everything
            LogExtFileAll = 0x3FFFFF // [IIS 6.0] Log everything (This seems to work fine on IIS 5.0 and IIS 5.1 also)
        }

        internal enum LogPeriod // IIS logFilePeriod
        {
            LogPeriodDay = 0x00000001,
            LogPeriodWeek = 0x00000002,
            LogPeriodMonth = 0x00000003,
            LogPeriodFileSize = 0x00000000
        }

        private WebSite site = null;
        private DirectoryEntry siteDe = null;

        // default values for these 4 settings as per IIS 6
        private LogExtFlags logExtFileFlags = (LogExtFlags) 0x00218fdf;
        private LogPeriod logFilePeriod = LogPeriod.LogPeriodDay;
        private int logFileTruncateSize = 0x1400000;
        private bool logFileLocaltimeRollover = false;

        private PropertyValueCollection fileFlags;
        private PropertyValueCollection filePeriod;
        private PropertyValueCollection fileTruncateSize;
        private PropertyValueCollection fileLocaltimeRollover;

        public LogExtFlags LogExtFileFlags
        {
            get { return logExtFileFlags; }
            set { logExtFileFlags = value; }
        }
        public LogPeriod LogFilePeriod
        {
            get { return logFilePeriod; }
            set { logFilePeriod = value; }
        }
        public int LogFileTruncateSize
        {
            get { return logFileTruncateSize; }
            set { logFileTruncateSize = value; }
        }
        public bool LogFileLocaltimeRollover
        {
            get { return logFileLocaltimeRollover; }
            set { logFileLocaltimeRollover = value; }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="site">Web Site object to be updated</param>
        public LogFileSettings(WebSite site) 
        {
            this.site = site;
            siteDe = site.GetDirectoryEntry();

            fileFlags = (PropertyValueCollection)siteDe.Properties["LogExtFileFlags"];
            filePeriod = (PropertyValueCollection)siteDe.Properties["logFilePeriod"];
            fileTruncateSize = (PropertyValueCollection)siteDe.Properties["logFileTruncateSize"];
            fileLocaltimeRollover = (PropertyValueCollection)siteDe.Properties["logFileLocaltimeRollover"];

            // If the site already has values for these properties then override the defaults for our properties.
            // If not then the values stay as default.
            // The caller is then at liberty to set these properties as required before calling Update.
            if (fileFlags.Count > 0) logExtFileFlags = (LogExtFlags)fileFlags[0];
            if (filePeriod.Count > 0) logFilePeriod = (LogPeriod)filePeriod[0];
            if (fileTruncateSize.Count > 0) logFileTruncateSize = (int)fileTruncateSize[0];
            if (fileLocaltimeRollover.Count > 0) logFileLocaltimeRollover = (bool)fileLocaltimeRollover[0];
        }
        
        public void Update()
        {
            fileFlags.Clear();
            filePeriod.Clear();
            fileTruncateSize.Clear();
            fileLocaltimeRollover.Clear();

            fileFlags.Add(logExtFileFlags);
            filePeriod.Add(logFilePeriod);
            fileTruncateSize.Add(logFileTruncateSize);
            fileLocaltimeRollover.Add(logFileLocaltimeRollover);

            siteDe.CommitChanges();
        }
    }
}

