//-----------------------------------------------------------------------
// <copyright file="RemoveReferences.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.Application
{
    using BizTalk2004;
    using System.Globalization;
    using BizTalk.ExplorerOM;
    using Build.Framework;

    /// <summary>
    /// Removes a reference from an application
    /// </summary>
    public class RemoveReferences : BizTalk2004TaskBase
    {
        private string application;
        private ITaskItem[] referenceApplications;

        /// <summary>
        /// Gets or sets the reference applications.
        /// </summary>
        /// <value>The reference applications.</value>
        [Required]
        public ITaskItem[] ReferenceApplications
        {
            get { return this.referenceApplications; }
            set { this.referenceApplications = value; }
        }

        /// <summary>
        /// Gets or sets the application.
        /// </summary>
        /// <value>The application.</value>
        [Required]
        public string Application
        {
            get { return this.application; }
            set { this.application = value; }
        }

        /// <summary>
        /// This is the main execute method that all tasks should implement
        /// </summary>
        /// <remarks>
        /// TaskException should be thrown in the event of errors
        /// </remarks>
        protected override void InternalExecute()
        {
            BtsCatalogExplorer explorer = this.GetBtsCatalogExplorer(this.Server, this.Database);

            Application app = explorer.Applications[this.Application];
            if (app != null)
            {
                foreach (ITaskItem item in this.ReferenceApplications)
                {
                    string refName = item.GetMetadata("ApplicationName");
                    Application refApp = explorer.Applications[refName];
                    if (refApp != null)
                    {
                        Log.LogMessage(string.Format(CultureInfo.InvariantCulture, "Removing Reference Application: {0} from Application: {1}", refName, this.Application));
                        app.RemoveReference(refApp);
                    }
                    else
                    {
                        Log.LogError(string.Format(CultureInfo.InvariantCulture, "Reference Application not found: {0}", refName));
                        return;
                    }
                }

                explorer.SaveChanges();
            }
            else
            {
                Log.LogError(string.Format(CultureInfo.InvariantCulture, "Application not found: {0}", this.Application));
                return;
            }
        }
    }
}
