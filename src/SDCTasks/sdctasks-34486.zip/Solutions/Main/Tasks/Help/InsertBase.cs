﻿//-----------------------------------------------------------------------
// <copyright file="InsertBase.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-07-01</date>
// <summary>Inserts a node into a hhc file</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Help
{
    #region Using directives
    using System;
    using System.Xml;
    using System.Globalization;
    using System.IO;
    using System.Text.RegularExpressions;
    using Microsoft.Win32;
    using Microsoft.Build.Framework;
    using Microsoft.Build.Tasks;
    #endregion
    /// <summary>
    /// Inserts a node into a hhc project.
    /// </summary>          
    /// <remarks>
    /// <code><![CDATA[
    /// <Help.CreateProject SourceFolder="folder" />
    /// ]]></code>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public abstract class InsertBase : Microsoft.Sdc.Tasks.TaskBase
    {
        private string contentsFilePath;
        private string startNodeName;
        private string startNodeLocal;
        private string insertNodeName;
        private string insertNodeLocal;

        /// <summary>
        /// The filename of the hhc file holding the contents
        /// </summary>
        /// <value>Must be a filename i.e. documentation.hhc.</value>
        [Required]
        public string ContentsFilePath
        {
            get { return this.contentsFilePath; }
            set { this.contentsFilePath = value; }
        }

        /// <summary>
        /// The Name of the Node to insert the parent around
        /// </summary>
        /// <value>Must be a valid Node Name.</value>
        [Required]
        public string StartNodeName
        {
            get { return this.startNodeName; }
            set { this.startNodeName = value; }
        }

        /// <summary>
        /// The Name of the Node to insert the parent around
        /// </summary>
        /// <value>Must be a valid Node Local value.</value>
        [Required]
        public string StartNodeLocal
        {
            get { return this.startNodeLocal; }
            set { this.startNodeLocal = value; }
        }

        /// <summary>
        /// The Name of the Node to insert the parent around
        /// </summary>
        /// <value>Must be a valid Node Name.</value>
        [Required]
        public string InsertNodeName
        {
            get { return this.insertNodeName; }
            set { this.insertNodeName = value; }
        }

        /// <summary>
        /// The Name of the Node to insert the parent around
        /// </summary>
        /// <value>Must be a valid Node Local value.</value>
        [Required]
        public string InsertNodeLocal
        {
            get { return this.insertNodeLocal; }
            set { this.insertNodeLocal = value; }
        }


        protected static string BuildSearchString(string name, string local)
        {
            return "<LI>" + BuildObjectString(name, local) + "</LI>";
        }

        private static string BuildObjectString(string name, string local)
        {
            return "<OBJECT type=\"text/sitemap\"><param name=\"Name\" value=\"" + name + "\" /><param name=\"Local\" value=\"" + local + "\" /></OBJECT>";
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="contents"></param>
        /// <param name="insertParent">TRUE if you are inserting as a parent so it can append a UL tag on the end</param>
        /// <param name="insertAfter">TRUE if you are inserting after the found node, FALSE to insert before it</param>
        /// <returns></returns>
        protected string InsertStart(string contents, bool insertParent, bool insertAfter)
        {
            string searchString = null;

            if (this.StartNodeName == "-1")
            {
                //this is a special value to indicate add the Start at the very top of the first <UL>
                searchString = "<LI>"; // find the first <LI> entry
            }
            else
            {
                searchString = BuildSearchString(this.StartNodeName, this.StartNodeLocal);
            }
            string insertStartString = "<LI>" + BuildObjectString(this.InsertNodeName, this.InsertNodeLocal)+ "</LI>";

            if (insertParent)
            {
                insertStartString += "<UL>";
            }
            int location = contents.IndexOf(searchString);
            if (location == -1)
            {
                throw new TaskException("Help.Insert.MissingSearchString");
            }
            if (insertAfter)
            {
                location += searchString.Length;
            }
            return contents.Insert(location, insertStartString);
        }           
    }
}
