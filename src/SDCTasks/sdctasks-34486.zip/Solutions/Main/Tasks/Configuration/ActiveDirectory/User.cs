/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.ActiveDirectory
{
    using System;
    using System.DirectoryServices;
    using System.Security.Principal;
    using System.Collections;
    using System.Runtime.InteropServices;
    using System.Globalization;

    using Microsoft.Sdc.Tasks.Configuration.Framework;
    /// <summary>
    /// This represents a User in the Active Directory.
    /// </summary>
    internal class User
    {
        static readonly string DefaultLoginPath = "WinNT://" + Environment.MachineName + ",computer";
        #region Private Fields
        string loginPath = "WinNT://" + Environment.MachineName + ",computer";
        string loginDomainName = null;
        string loginUsername = null;
        string loginPassword = null;
        AuthenticationTypes loginAuthenticationType = AuthenticationTypes.None;
        DirectoryEntry AD = null;
        bool connected = false;
        WindowsImpersonationContext impersonationContext;
        bool impersonateUser = false;
        //object groups = null;
        string path;
        string domainName;
        bool isValidInDirectory = false;
        DirectoryEntry userDirectoryEntry = null;
        string username = null;
        string fullName = null;
        string password = null;
        string description = null;
        int passwordExpired = 0;
        int maxStorage = -1;
        int passwordAge = 1;
        int badPasswordAttempts = 0;
        string homeDirectory = null;
        string loginScript = null;
        string homeDirDrive = null;
        int minPasswordLength = 0;
        long maxPasswordAge = 3710851;
        long minPasswordAge = 0;
        long passwordHistoryLength = 0;
        long autoUnlockInterval = 1800;
        long lockoutObservationInterval = 1800;
        long maxBadPasswordsAllowed = 0;
        UserAccountFlags userFlags = 0;

        #endregion
        #region Constructors
        internal User(DirectoryEntry user)
        {
            this.path = user.Path;
            this.Username = user.Name;
            //TODO Seems to throw errors when reading the password
            //this.Password = user.Password;
            try
            {
                this.FullName = Convert.ToString(user.Invoke("Get", new object[] { "FullName" }), CultureInfo.InvariantCulture);
                this.Description = Convert.ToString(user.Invoke("Get", new object[] { "Description" }), CultureInfo.InvariantCulture);
                this.PasswordExpired = Convert.ToInt32(user.Invoke("Get", new object[] { "PasswordExpired" }), CultureInfo.InvariantCulture);
                //this.RasPermissions=Convert.ToInt32(user.Invoke("Get", new object[] {"RasPermissions"}));
                this.MaxStorage = Convert.ToInt32(user.Invoke("Get", new object[] { "MaxStorage" }), CultureInfo.InvariantCulture);
                this.PasswordAge = Convert.ToInt32(user.Invoke("Get", new object[] { "PasswordAge" }), CultureInfo.InvariantCulture);
                this.HomeDirectory = Convert.ToString(user.Invoke("Get", new object[] { "HomeDirectory" }), CultureInfo.InvariantCulture);
                this.LoginScript = Convert.ToString(user.Invoke("Get", new object[] { "LoginScript" }), CultureInfo.InvariantCulture);
                this.HomeDirDrive = Convert.ToString(user.Invoke("Get", new object[] { "HomeDirDrive" }), CultureInfo.InvariantCulture);
                this.userFlags = (UserAccountFlags)Convert.ToInt32(user.Invoke("Get", new object[] { "UserFlags" }), CultureInfo.InvariantCulture);

                this.UserDirectoryEntry = user;
            }
            catch (Exception e)
            {
                throw new ApplicationException("Could not load user from given DirectoryEntry", e);
            }
        }

        /// <summary>
        /// Instantiates a default instance of the User type 
        /// </summary>
        public User()
            : this(null, null, null)
        {
        }

        /// <summary>
        /// Instantiates an instance of the User type with the given parameter
        /// </summary>
        /// <param name="username">The username for this user</param>
        public User(string username)
            : this(username, null, null)
        {
        }

        /// <summary>
        /// Instantiates an instance of the User type with the given parameters
        /// </summary>
        /// <param name="username">The username for this user</param>
        /// <param name="password">The password</param>
        public User(string username, string password)
            : this(username, password, null)
        {
        }
        /// <summary>
        /// Instantiates an instance of the User type with the given parameters
        /// </summary>
        /// <param name="username">The username for this user</param>
        /// <param name="password">The password</param>
        /// <param name="domainName">The domain name for this user</param>
        public User(string username, string password, string domainName)
        {
            if (domainName == null || domainName.Length == 0)
            {
                this.domainName = Environment.MachineName;
            }
            else
            {
                this.domainName = domainName;
            }
            this.username = username;
            this.password = password;
        }

        #endregion
        #region Public Properties
        /*
        public object Groups {
            get {
                return groups;
            } 
            set {
                groups = value;
            }
        }
        */

        public string DomainName
        {
            get
            {
                return domainName;
            }
            set
            {
                domainName = value;
            }
        }

        public bool IsValidInDirectory
        {
            get
            {
                return isValidInDirectory;
            }
            set
            {
                isValidInDirectory = value;
            }
        }

        public DirectoryEntry UserDirectoryEntry
        {
            get
            {
                return userDirectoryEntry;
            }
            set
            {
                userDirectoryEntry = value;
            }
        }

        public string Username
        {
            get
            {
                return username;
            }
            set
            {
                username = value;
            }
        }

        public string FullName
        {
            get
            {
                return fullName;
            }
            set
            {
                fullName = value;
            }
        }

        public string Password
        {
            get
            {
                return password;
            }
            set
            {
                password = value;
            }
        }
        public string Description
        {
            get
            {
                return description;
            }
            set
            {
                description = value;
            }
        }
        public int PasswordExpired
        {
            get
            {
                return passwordExpired;
            }
            set
            {
                passwordExpired = value;
            }
        }
        //public int RasPermissions{get{return rasPermissions;}set{rasPermissions=value;}}
        public int MaxStorage
        {
            get
            {
                return maxStorage;
            }
            set
            {
                maxStorage = value;
            }
        }

        public int PasswordAge
        {
            get
            {
                return passwordAge;
            }
            set
            {
                passwordAge = value;
            }
        }

        public int BadPasswordAttempts
        {
            get
            {
                return badPasswordAttempts;
            }
            set
            {
                badPasswordAttempts = value;
            }
        }
        public string HomeDirectory
        {
            get
            {
                return homeDirectory;
            }
            set
            {
                homeDirectory = value;
            }
        }
        public string LoginScript
        {
            get
            {
                return loginScript;
            }
            set
            {
                loginScript = value;
            }
        }
        public string HomeDirDrive
        {
            get
            {
                return homeDirDrive;
            }
            set
            {
                homeDirDrive = value;
            }
        }
        public int MinPasswordLength
        {
            get
            {
                return minPasswordLength;
            }
            set
            {
                minPasswordLength = value;
            }
        }
        public long MaxPasswordAge
        {
            get
            {
                return maxPasswordAge;
            }
            set
            {
                maxPasswordAge = value;
            }
        }
        public long MinPasswordAge
        {
            get
            {
                return minPasswordAge;
            }
            set
            {
                minPasswordAge = value;
            }
        }
        public long PasswordHistoryLength
        {
            get
            {
                return passwordHistoryLength;
            }
            set
            {
                passwordHistoryLength = value;
            }
        }
        public long AutoUnlockInterval
        {
            get
            {
                return autoUnlockInterval;
            }
            set
            {
                autoUnlockInterval = value;
            }
        }
        public long LockoutObservationInterval
        {
            get
            {
                return lockoutObservationInterval;
            }
            set
            {
                lockoutObservationInterval = value;
            }
        }
        public long MaxBadPasswordsAllowed
        {
            get
            {
                return maxBadPasswordsAllowed;
            }
            set
            {
                maxBadPasswordsAllowed = value;
            }
        }

        public string LoginDomainName
        {
            get
            {
                return loginDomainName;
            }
            set
            {
                loginDomainName = value;
            }
        }

        public string LoginPath
        {
            get
            {
                return loginPath;
            }
            set
            {
                loginPath = value;
            }
        }

        public string LoginUsername
        {
            get
            {
                return loginUsername;
            }
            set
            {
                loginUsername = value;
            }
        }

        public string LoginPassword
        {
            get
            {
                return loginPassword;
            }
            set
            {
                loginPassword = value;
            }
        }

        public AuthenticationTypes LoginAuthenticationType
        {
            get
            {
                return loginAuthenticationType;
            }
            set
            {
                loginAuthenticationType = value;
            }
        }


        public bool PasswordChangeable
        {
            get
            {

                if ((userFlags & UserAccountFlags.ADS_UF_PASSWD_CANT_CHANGE) == UserAccountFlags.ADS_UF_PASSWD_CANT_CHANGE)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            set
            {

                if (value)
                {
                    userFlags &= ~UserAccountFlags.ADS_UF_PASSWD_CANT_CHANGE;
                }
                else
                {
                    userFlags |= UserAccountFlags.ADS_UF_PASSWD_CANT_CHANGE;
                }
            }
        }

        public bool PasswordExpires
        {
            get
            {

                if ((userFlags & UserAccountFlags.ADS_UF_DONT_EXPIRE_PASSWD) == UserAccountFlags.ADS_UF_DONT_EXPIRE_PASSWD)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            set
            {

                if (value)
                {
                    userFlags &= ~UserAccountFlags.ADS_UF_DONT_EXPIRE_PASSWD;
                }
                else
                {
                    userFlags |= UserAccountFlags.ADS_UF_DONT_EXPIRE_PASSWD;
                }
            }
        }




        #endregion
        #region Static Methods

        /// <summary>
        /// Returns an instance of the User type for the given username
        /// </summary>
        /// <param name="username">The username to load from the Active Directory</param>
        /// <param name="domainName">The domain name to check in</param>
        /// <returns></returns>
        static public User Load(string username, string domainName)
        {
            //Connect(DefaultLoginPath);
            //ImpersonateIfRequired();
            if (domainName == null || domainName.Length == 0)
            {
                return Load(username);
            }
            using (DirectoryEntry AD = new DirectoryEntry("WinNT://" + domainName + ",domain"))
            {
                DirectoryEntry user = AD.Children.Find(username, "User");
                //ImpersonateUndo();
                if (user != null)
                {
                    User u = new User(user);
                    u.DomainName = domainName;
                    return u;
                }
                else
                {
                    return null;
                }

            }
        }


        //TODO Add overloads to provide login name,etc.
        /// <summary>
        /// Returns an instance of the User type for the given username
        /// </summary>
        /// <param name="username">The username to load from the Active Directory</param>
        /// <returns>An instance of the User type for the username provided</returns>
        static public User Load(string username)
        {
            //Connect(DefaultLoginPath);
            //ImpersonateIfRequired();  
            using (DirectoryEntry AD = new DirectoryEntry(DefaultLoginPath))
            {
                DirectoryEntry user = AD.Children.Find(username, "User");
                //ImpersonateUndo();
                if (user != null)
                {
                    User u = new User(user);
                    u.DomainName = Environment.MachineName;
                    return u;
                }
                else
                {
                    return null;
                }

            }
        }

        /// <summary>
        /// This checks the provided Active Directory for the username provided
        /// </summary>
        /// <param name="username">The username to check for</param>
        /// <param name="domainName">The domain name to check in</param>
        /// <returns></returns>
        static public bool Exists(string username, string domainName)
        {
            //Connect(DefaultLoginPath);
            //ImpersonateIfRequired();
            if (domainName == null || domainName.Length == 0)
            {
                return Exists(username);
            }
            using (DirectoryEntry AD = new DirectoryEntry("WinNT://" + domainName + ",domain"))
            {
                try
                {
                    DirectoryEntry user = AD.Children.Find(username, "User");
                    //ImpersonateUndo();
                    if (user != null)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                catch (COMException e)
                {
                    if (e.ErrorCode == -2147022675)
                    {
                        return false;
                    }
                    throw e;
                }
            }
        }
        /// <summary>
        /// This checks the Active Directory for the username provided.
        /// </summary>
        /// <param name="username">The username to check in the Active Directory</param>
        /// <returns>TRUE is the username provided exists</returns>
        static public bool Exists(string username)
        {
            //Connect(DefaultLoginPath);
            //ImpersonateIfRequired();  
            using (DirectoryEntry AD = new DirectoryEntry(DefaultLoginPath))
            {
                try
                {
                    DirectoryEntry user = AD.Children.Find(username, "User");
                    //ImpersonateUndo();
                    if (user != null)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                catch (COMException e)
                {
                    if (e.ErrorCode == -2147022675)
                    {
                        return false;
                    }
                    throw e;
                }
            }
        }
        #endregion
        #region Private Methods
        private void ImpersonateIfRequired()
        {
            if (impersonateUser || loginUsername != null)
            {
                impersonationContext = AdvApi32.ImpersonateUser(this.loginUsername, this.loginDomainName, this.loginPassword);
                if (impersonationContext == null)
                {
                    throw new ApplicationException("Unable to impersonate supplied credentials.");
                }
                impersonateUser = true;
            }
        }

        private void ImpersonateUndo()
        {
            if (impersonateUser)
            {
                impersonationContext.Undo();
            }
        }

        void InvokeProperty(string objectName, string objectValue)
        {
            try
            {
                if (objectValue != null && Convert.ToString(objectValue, CultureInfo.InvariantCulture).Length != 0)
                {
                    userDirectoryEntry.Invoke("Put", new object[] { objectName, objectValue });
                }
            }
            catch
            {

            }
        }

        void InvokeProperty(string objectName, int objectValue)
        {
            try
            {
                if (Convert.ToString(objectValue, CultureInfo.InvariantCulture).Length != 0)
                {
                    userDirectoryEntry.Invoke("Put", new object[] { objectName, objectValue });
                }
            }
            catch
            {

            }
        }
        #endregion
        #region Public Methods

        public bool IsInGroup(string groupName)
        {
            Connect();
            object groups = userDirectoryEntry.Invoke("Groups");
            foreach (object group in (IEnumerable)groups)
            {
                DirectoryEntry groupEntry = new DirectoryEntry(group);
                if (groupEntry.Name == groupName) return true;
            }

            return false;
        }

        public bool IsInGroup(string groupName, string machineName)
        {
            DirectoryEntry machine = null;
            bool returnValue = false;
            try
            {
                machine = new DirectoryEntry("WinNT://" + machineName + ",computer");

                foreach (DirectoryEntry dir in machine.Children)
                {
                    if (dir.SchemaClassName == "Group" && dir.Name == groupName)
                    {
                        ComWrapper o = new ComWrapper(dir.NativeObject);
                        returnValue = (bool)o.CallMethod("IsMember", new object[] { userDirectoryEntry.Path });
                        break;
                    }
                }
            }
            finally
            {
                if (machine != null)
                {
                    machine.Close();
                }
            }
            return returnValue;
        }

        public bool IsInDomainGroup(string groupName, string domainName)
        {
            DirectoryEntry domain = null;
            bool returnValue = false;
            try
            {
                domain = new DirectoryEntry("WinNT://" + domainName + ",domain");

                foreach (DirectoryEntry dir in domain.Children)
                {
                    if (dir.SchemaClassName == "Group" && dir.Name == groupName)
                    {
                        ComWrapper o = new ComWrapper(dir.NativeObject);
                        returnValue = (bool)o.CallMethod("IsMember", new object[] { userDirectoryEntry.Path });
                        break;
                    }
                }
            }
            finally
            {
                if (domain != null)
                {
                    domain.Close();
                }
            }
            return returnValue;
        }

        public DirectoryEntry[] GetGroups(string machineName)
        {
            DirectoryEntry machine = null;
            DirectoryEntry[] ret;
            try
            {
                machine = new DirectoryEntry("WinNT://" + machineName + ",computer");

                ArrayList groups = new ArrayList();
                foreach (DirectoryEntry dir in machine.Children)
                {
                    if (dir.SchemaClassName == "Group")
                    {
                        ComWrapper o = new ComWrapper(dir.NativeObject);
                        bool returnValue = (bool)o.CallMethod("IsMember", new object[] { userDirectoryEntry.Path });
                        if (returnValue)
                        {
                            groups.Add(dir);
                        }
                    }
                }

                ret = new DirectoryEntry[groups.Count];
                groups.CopyTo(ret);
            }
            finally
            {
                if (machine != null)
                {
                    machine.Close();
                }
            }
            return ret;
        }

        public DirectoryEntry[] GetGroups()
        {
            Connect();
            ArrayList returnGroups = new ArrayList();

            object groups = userDirectoryEntry.Invoke("Groups");

            foreach (object group in (IEnumerable)groups)
            {
                DirectoryEntry groupEntry = new DirectoryEntry(group);
                returnGroups.Add(groupEntry);
            }
            DirectoryEntry[] ret = new DirectoryEntry[returnGroups.Count];
            returnGroups.CopyTo(ret);
            return ret;
        }

        /// <summary>
        /// Query the directory and return all the groups
        /// </summary>
        /// <returns></returns>
        public DirectoryEntry[] GetGroupsInDirectory()
        {
            Connect();
            ArrayList groups = new ArrayList();
            foreach (DirectoryEntry dir in AD.Children)
            {
                if (dir.SchemaClassName == "Group")
                {
                    groups.Add(dir);
                }
            }
            DirectoryEntry[] returnGroups = new DirectoryEntry[groups.Count];
            groups.CopyTo(returnGroups);
            return returnGroups;
        }

        /// <summary>
        /// Connect to the default AD login path
        /// </summary>
        /// <returns></returns>
        public bool Connect()
        {
            return Connect(DefaultLoginPath);
        }
        /// <summary>
        /// Connect to the specified AD login path
        /// </summary>
        /// <returns></returns>
        public bool Connect(string loginPath)
        {
            if (!connected)
            {
                try
                {
                    ImpersonateIfRequired();
                    AD = new DirectoryEntry(loginPath);
                    ImpersonateUndo();
                    connected = true;
                }
                catch (Exception e)
                {
                    throw new ApplicationException("Unable to connect to directory", e);
                }
            }
            return connected;
        }

        public bool AddToGroup(string groupName)
        {
            if (IsInGroup(groupName))
            {
                return true;
            }
            else
            {
                try
                {
                    DirectoryEntry group;
                    group = AD.Children.Find(groupName, "Group");

                    if (group != null)
                    {
                        ImpersonateIfRequired();
                        group.Invoke("Add", new object[] { UserDirectoryEntry.Path.ToString(CultureInfo.InvariantCulture) });
                        ImpersonateUndo();
                    }
                    return true;

                }
                catch (Exception e)
                {
                    //TODO Throws an exception if already in the group
                    throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to add user '{0}' to group '{1}'.", this.username, groupName), e);
                }
            }
        }

        public bool AddToGroup(string groupName, string machineName)
        {
            if (IsInGroup(groupName, machineName))
            {
                return true;
            }
            else
            {
                try
                {
                    Connect("WinNT://" + machineName + ",computer");
                    DirectoryEntry group;
                    group = AD.Children.Find(groupName, "Group");

                    if (group != null)
                    {
                        ImpersonateIfRequired();
                        group.Invoke("Add", new object[] { UserDirectoryEntry.Path.ToString(CultureInfo.InvariantCulture) });
                        ImpersonateUndo();
                    }
                    return true;

                }
                catch (Exception e)
                {
                    //TODO Throws an exception if already in the group
                    throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to add user '{0}' to group '{1}'.", this.username, groupName), e);
                }
            }
        }

        public bool AddToDomainGroup(string groupName, string domainName)
        {
            if (IsInDomainGroup(groupName, domainName))
            {
                return true;
            }
            else
            {
                try
                {
                    Connect("WinNT://" + domainName + ",domain");
                    DirectoryEntry group;
                    group = AD.Children.Find(groupName, "Group");

                    if (group != null)
                    {
                        ImpersonateIfRequired();
                        group.Invoke("Add", new object[] { UserDirectoryEntry.Path.ToString(CultureInfo.InvariantCulture) });
                        ImpersonateUndo();
                    }
                    return true;

                }
                catch (Exception e)
                {
                    //TODO Throws an exception if already in the group
                    throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to add user '{0}' to group '{1}'.", this.username, groupName), e);
                }
            }
        }

        public bool Save()
        {

            try
            {
                if (this.domainName != null && this.domainName.Length > 0 &&
                    this.domainName.ToUpper() != Environment.MachineName.ToUpper())
                {
                    // Only connect to the domain if we have been given a domain, and it is
                    // not the same as the current machine
                    Connect("WinNT://" + this.domainName + ",domain");
                }
                else
                {
                    Connect(DefaultLoginPath);
                }
                ImpersonateIfRequired();
                if (userDirectoryEntry == null)
                {
                    try
                    {
                        userDirectoryEntry = AD.Children.Find(username, "User");
                    }
                    catch
                    {
                        userDirectoryEntry = AD.Children.Add(username, "User");
                    }
                }

                if (password != null && password.Length != 0)
                {
                    userDirectoryEntry.Invoke("SetPassword", new object[] { password });
                }
                InvokeProperty("FullName", fullName);
                InvokeProperty("Description", description);
                InvokeProperty("PasswordExpired", passwordExpired);
                InvokeProperty("MaxStorage", maxStorage);
                InvokeProperty("PasswordAge", passwordAge);
                InvokeProperty("HomeDirectory", homeDirectory);
                InvokeProperty("LoginScript", loginScript);
                InvokeProperty("HomeDirDrive", homeDirDrive);
                InvokeProperty("UserFlags", Convert.ToInt32(userFlags));

                userDirectoryEntry.CommitChanges();
                isValidInDirectory = true;
                ImpersonateUndo();
                return true;

            }
            catch (Exception e)
            {
                throw new ApplicationException("Unable to save user to directory", e);
            }
        }

        public bool GrantPrivilege(Privilege privilege)
        {

            string privilegeText = privilege.ToString();
            return AdvApi32.GrantPrivilege(domainName, username, privilegeText, Environment.MachineName);
        }

        public Privilege[] GetPrivileges()
        {
            string[] privileges = AdvApi32.GetPrivileges(domainName, username);
            Privilege[] privs = new Privilege[privileges.Length];
            for (int i = 0; i < privileges.Length; i++)
            {
                privs[i] = (Privilege)Enum.Parse(typeof(Privilege), privileges[i]);

            }
            return privs;
        }

        public bool HasPrivilege(Privilege privilege)
        {
            string[] privileges = AdvApi32.GetPrivileges(domainName, username);
            if (privileges == null || privileges.Length == 0) return false;
            Privilege[] privs = new Privilege[privileges.Length];
            for (int i = 0; i < privileges.Length; i++)
            {
                if ((Privilege)Enum.Parse(typeof(Privilege), privileges[i]) == privilege)
                {
                    return true;
                }
            }
            return false;
        }

        public bool Delete()
        {
            try
            {
                if (this.domainName != null && this.domainName.Length > 0 &&
                    this.domainName.ToUpper() != Environment.MachineName.ToUpper())
                {
                    // Only connect to the domain if we have been given a domain, and it is
                    // not the same as the current machine
                    Connect("WinNT://" + this.domainName + ",domain");
                }
                else
                {
                    Connect(DefaultLoginPath);
                }
                ImpersonateIfRequired();
                AD.Children.Remove(UserDirectoryEntry);
                ImpersonateUndo();
                return true;

            }
            catch (Exception e)
            {
                throw new ApplicationException("Unable to delete user", e);
            }
        }
        #endregion
    }
}
