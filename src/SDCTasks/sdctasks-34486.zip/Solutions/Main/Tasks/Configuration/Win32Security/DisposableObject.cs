/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/


namespace Microsoft.Sdc.Tasks.Configuration.Win32Security {
    using System;
    /// <summary>
    ///  Abstract base class for any disposable object.
    ///  Handle the finalizer and the call the Gc.SuppressFinalize.
    ///  Derived classes must implement "Dispose(bool disposing)".
    /// </summary>
    internal abstract class DisposableObject : IDisposable {
        ~DisposableObject() {
            Dispose(false);
        }
        public void Dispose() {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected abstract void Dispose(bool disposing);
    }
}
