//-------------------------------------------------------------------------------------
// <copyright file="Exists.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//     Checkts if a party exists in a Biztalk Server
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2004.Party
{
    #region Using directives
    using Microsoft.Build.Framework;
    #endregion

    /// <summary>
    /// Checks is Party exists
    /// </summary>
    public class Exists : BizTalk2004TaskBase
    {
        private string name;
        private bool exists;

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        [Required]
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [party exists].
        /// </summary>
        /// <value><c>true</c> if [party exists]; otherwise, <c>false</c>.</value>
        [Output]
        public bool PartyExists
        {
            get { return this.exists; }
            set { this.exists = value; }
        }

        /// <summary>
        /// This is the main execute method that all tasks should implement
        /// </summary>
        protected override void InternalExecute()
        {
            this.PartyExists = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party.Exists(this.GetInstallation(), this.Name);
        }
    }
}

