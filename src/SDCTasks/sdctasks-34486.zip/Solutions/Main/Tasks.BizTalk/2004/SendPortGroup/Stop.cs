﻿//-------------------------------------------------------------------------------------
// <copyright file="Stop.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Stops the given instance of the BizTalk send port group.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.SendPortGroup
{
    #region Using directives

    using System;
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion


    #region Class Comments
    /// <summary>
    /// Stops the given instance of the BizTalk send port group.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2004.SendPortGroup.Stop Name="name" Server="server" Database="database" />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>name (Required)</i></para>
    /// <para>
    /// The name of the send port group to stop.
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server containing the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// <para><i>username</i></para>
    /// <para>
    /// The username to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// <para><i>password</i></para>
    /// <para>
    /// The password to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///            <BizTalk2004.SendPortGroup.Stop
    ///                Name="SendPortGroup1" />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    #endregion
    public class Stop : BizTalk2004TaskBase
    {
        #region Member Variables

        private string name;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the name of the send port group.
        /// </summary>
        /// <value>
        /// The name of the send port group.
        /// </value>
        [Required]
        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }


        #endregion

        #region Constructors

        /// <summary>
        /// Creates a new instance of the Stop task.
        /// </summary>
        public Stop()
        {
        }

        #endregion

        #region Methods

        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {
            BizTalkInstallation installation = this.GetInstallation();
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SendPortGroup sendportgroup = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SendPortGroup.Load(installation, this.name);

            if (sendportgroup != null)
                sendportgroup.Stop();
            else
                throw new InvalidOperationException(string.Format("SendPortGroup {0} does not exist.", this.name));

        }
        #endregion

    }
}

