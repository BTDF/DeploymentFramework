/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/


namespace Microsoft.Sdc.Tasks.Configuration.Win32Security {
    using System;
    /// <summary>
    /// Summary description for Acl.
    /// </summary>
    internal sealed class Acl {
        private Acl() {			
        }
		
        public static bool AceExists(string userOrGroup, string path, AceFlags flags, AccessTypes accessTypes) {

            bool returnValue = false;
			#region Calculate the AceFlagsInternal based on the AceFlags passed in
            AceFlagsInternal aceFlagsInternal = 0;
            if (flags == 0) {
                aceFlagsInternal = AceFlagsInternal.OBJECT_INHERIT_ACE | AceFlagsInternal.CONTAINER_INHERIT_ACE;
            } else {
                if (!((flags & AceFlags.ThisFolder) == AceFlags.ThisFolder)) {
                    aceFlagsInternal = aceFlagsInternal | AceFlagsInternal.INHERIT_ONLY_ACE;
                }
                if ((flags & AceFlags.SubFolders) == AceFlags.SubFolders) {
                    aceFlagsInternal = aceFlagsInternal | AceFlagsInternal.CONTAINER_INHERIT_ACE;
                }
                if ((flags & AceFlags.Files) == AceFlags.Files) {
                    aceFlagsInternal = aceFlagsInternal | AceFlagsInternal.OBJECT_INHERIT_ACE;
                }
            }
			#endregion
				
            Sid sidOfUSerGroup = new Sid(userOrGroup);

									
            SecurityDescriptor secDesc = SecurityDescriptor.GetFileSecurity (path, SECURITY_INFORMATION.DACL_SECURITY_INFORMATION);
            using (secDesc) {
                Dacl dacl = secDesc.Dacl;

                foreach(Ace ace in dacl) {
                    if (ace.Type == AceType.ACCESS_ALLOWED_ACE_TYPE && ace.Sid.Equals(sidOfUSerGroup) && ace.Flags == aceFlagsInternal && ace.AccessType == (AccessTypeInternal)accessTypes) {
                        returnValue = true;
                        break;
                    }
                }				
            }
            return returnValue;
        }

        public static void AddAce(string userOrGroup, string path, AceFlags flags, AccessTypes accessTypes) {

			#region Calculate the AceFlagsInternal based on the AceFlags passed in
            AceFlagsInternal aceFlagsInternal = 0;
            if (flags == 0) {
                aceFlagsInternal = AceFlagsInternal.OBJECT_INHERIT_ACE | AceFlagsInternal.CONTAINER_INHERIT_ACE;
            } else {
                if (!((flags & AceFlags.ThisFolder) == AceFlags.ThisFolder)) {
                    aceFlagsInternal = aceFlagsInternal | AceFlagsInternal.INHERIT_ONLY_ACE;
                }
                if ((flags & AceFlags.SubFolders) == AceFlags.SubFolders) {
                    aceFlagsInternal = aceFlagsInternal | AceFlagsInternal.CONTAINER_INHERIT_ACE;
                }
                if ((flags & AceFlags.Files) == AceFlags.Files) {
                    aceFlagsInternal = aceFlagsInternal | AceFlagsInternal.OBJECT_INHERIT_ACE;
                }
            }
			#endregion
						
									
            SecurityDescriptor secDesc = SecurityDescriptor.GetFileSecurity (path, SECURITY_INFORMATION.DACL_SECURITY_INFORMATION);
            using (secDesc) {
                Dacl dacl = secDesc.Dacl;
                dacl.AddAce (new AceAccessAllowed(new Sid(userOrGroup), (AccessTypeInternal)accessTypes, aceFlagsInternal));
                secDesc.SetDacl(dacl);
                secDesc.SetFileSecurity(path, SECURITY_INFORMATION.DACL_SECURITY_INFORMATION);
            }
        }

        public static void Remove(string userOrGroup, string path) {
            SecurityDescriptor secDesc = SecurityDescriptor.GetFileSecurity (path, SECURITY_INFORMATION.DACL_SECURITY_INFORMATION);
            using (secDesc) {
                Dacl dacl = secDesc.Dacl;
                dacl.RemoveAces(new Sid(userOrGroup));
                secDesc.SetDacl(dacl);
                secDesc.SetFileSecurity(path, SECURITY_INFORMATION.DACL_SECURITY_INFORMATION);
            }
        }
    }
}
