﻿//-------------------------------------------------------------------------------------
// <copyright file="BtsCertificateInfo.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      BtsCertificateInfo
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;
    using System.Reflection;

    #endregion

    internal class BtsCertificateInfo : BtsBaseObject
    {
        /// <summary>
        /// Internal Constructor
        /// </summary>
        /// <param name="actualBtsObject">The actual Microsoft.Biztalk.ExplorerOM.BtsCertificateInfo object that object will call.</param>
        /// <param name="catalogExplorer">The Microsoft.Sdc.Tasks.Configuration.BtsCatalogExplorer object.</param>
        internal BtsCertificateInfo(object actualBtsObject, BtsCatalogExplorer catalogExplorer)
        {
            this.btsCatalogExplorer = catalogExplorer;
            this.actualBtsObject = actualBtsObject;
        }

        /// <summary>Gets the long name of the certificate.</summary>
        public string LongName
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("LongName", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>Gets the short name of the certificate.</summary>
        public string ShortName
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("ShortName", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>Gets the thumbprint of the certificate.</summary>
        public string ThumbPrint
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("ThumbPrint", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>Gets the certificate usage type.</summary>
        public CertUsageType UsageType
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("UsageType", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (CertUsageType)Enum.Parse(typeof(CertUsageType), value.ToString());
            }
        }
    }
}
