﻿//-------------------------------------------------------------------------------------
// <copyright file="BtsCertificateInfoCollection.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      BtsCertificateInfoCollection
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;

    #endregion

    internal class BtsCertificateInfoCollection : System.Collections.ReadOnlyCollectionBase
    {
        /// <summary>
        /// BtsCertificateInfoCollection
        /// </summary>
        public BtsCertificateInfoCollection()
        {
        }

        /// <summary>
        /// BtsCertificateInfo
        /// </summary>
        /// <param name="longName">string</param>
        /// <returns>BtsCertificateInfo</returns>
        public BtsCertificateInfo this[string longName]
        {
            get
            {
                BtsCertificateInfo item = null;
                foreach (BtsCertificateInfo currentitem in this.InnerList)
                {
                    if (currentitem.LongName == longName)
                    {
                        item = currentitem;
                        break;
                    }
                }
                return item;
            }
        }

        /// <summary>
        /// Indexer
        /// </summary>
        /// <param name="index">int</param>
        /// <returns>BtsCertificateInfo</returns>
        public BtsCertificateInfo this[int index]
        {
            get
            {
                return (BtsCertificateInfo)this.InnerList[index];
            }
        }

        internal void Add(BtsCertificateInfo item)
        {
            this.InnerList.Add(item);
        }
    }
}
