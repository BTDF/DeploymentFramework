﻿namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using directives

	using System;
	using System.Collections;
	using System.Text;

	#endregion

	internal class BtsTransformCollection : System.Collections.ReadOnlyCollectionBase
	{
		public BtsTransformCollection() { }

		public BtsTransform this[string fullName]
		{
			get
			{
				BtsTransform item = null;
				foreach (BtsTransform currentitem in this.InnerList)
				{
					if (currentitem.FullName == fullName)
					{
						item = currentitem;
						break;
					}
				}
				return item;

			}
		}

		public BtsTransform this [string fullName, string assemblyName]
		{
			get
			{
				BtsTransform item = null;
				foreach (BtsTransform currentitem in this.InnerList)
				{
					if (currentitem.FullName == fullName && currentitem.BtsAssembly.DisplayName == assemblyName)
					{
						item = currentitem;
						break;
					}
				}
				return item;

			}
		}


		public BtsTransform this[int index]
		{
			get
			{
				return (BtsTransform)this.InnerList[index];
			}
		}

		internal void Add(BtsTransform item)
		{
			this.InnerList.Add(item);
		}


	}

}
