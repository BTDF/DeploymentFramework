
namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	using System;

	/// <summary>
	/// The type of the Host
	/// </summary>
	public enum HostType
	{

		/// <summary>
		///This type of host represents service instances that are created, deleted, and fully controlled by administration.
		///Any orchestration can be enlisted into In-Process hosts.
		///Any send handler can be hosted by an In-Process host.
		///Only those receive handlers for In-Process-type adapters can be hosted by In-Process hosts; these adapters are: File and BizTalk Message Queuing adapters.
		/// </summary>
		InProcess  = 1,
	
		/// <summary>
		/// A host that is not valid.
		/// </summary>
		Invalid  = 0,

		/// <summary>
		///This type of host represents service instances that are created, deleted, and controlled outside of administration tools, but still need the benefit of some of the host configuration performed by the tools (such as service account and authentication trust).  Isolated hosts are primarily intended to host those adapters that need to run outside of the normal BizTalk runtime process.  They are not intended as a way to host orchestrations outside the normal (In-Process) runtime. 
		///No orchestrations can be enlisted into Isolated Hosts.  
		///No send handler can be configured to be hosted in an Isolated host.
		///Only those receive handlers for Isolated-type adapters can be hosted by Isolated hosts; these adapters are: HTTP/S and SOAP.
		///Isolated hosts cannot host tracking.
		///Isolated hosts cannot act as the default (since they cannot host orchestrations).
		/// </summary>
		Isolated  = 2

	}

}

