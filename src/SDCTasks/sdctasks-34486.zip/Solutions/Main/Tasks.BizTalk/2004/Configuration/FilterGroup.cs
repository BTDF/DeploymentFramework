//-------------------------------------------------------------------------------------
// <copyright file="FilterGroup.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      A group of filter conditions.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using directives

	using System;
	using System.IO;
	using System.Xml.Serialization;

	#endregion

	/// <summary>
	/// A group of filter conditions.
	/// </summary>
	[Serializable]
	[XmlType("Group")]
    public class FilterGroup
	{
		#region Member Variables

		private FilterCollection filters = new FilterCollection();

		#endregion

		#region Constructors

		/// <summary>
		/// Creates a new filter group.
		/// </summary>
		public FilterGroup()
		{
		}

		#endregion

		#region Properties

		/// <summary>
		/// Gets the collection of filters.
		/// </summary>
		[XmlElement("Statement")]
		public FilterCollection Filters
		{
			get 
			{ 
				return this.filters; 
			}
		}

		#endregion
	}
}

