//-------------------------------------------------------------------------------------
// <copyright file="CreateAlias.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Creates an Alias for a Party in Biztalk
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2004.Party
{
    #region Using directives
    using System;
    using Microsoft.Build.Framework;
    #endregion

    /// <summary>
    /// CreateAlias for Party
    /// </summary>
    public class CreateAlias : BizTalk2004TaskBase
    {
        #region member variables 

        private string partyname;
        private string name;
        private string qualifier;
        private string value;
        
        #endregion 

        #region properties 
        
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        [Required]
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        /// <summary>
        /// Gets or sets the qualifier.
        /// </summary>
        /// <value>The qualifier.</value>
        [Required]
        public string Qualifier
        {
            get { return this.qualifier; }
            set { this.qualifier = value; }
        }

        [Required]
        public string Value
        {
            get { return this.value; }
            set { this.value = value; }
        }

        [Required] 
        public string PartyName
        {
            get { return this.partyname; }
            set { this.partyname = value; }

        }


        #endregion 

        /// <summary>
        /// This is the main execute method that all tasks should implement
        /// </summary>
        /// <remarks>
        /// TaskException should be thrown in the event of errors
        /// </remarks>
        protected override void InternalExecute()
        {

            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation installation = this.GetInstallation();
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party party = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party.Load(installation, this.partyname);

            if (party != null)
                party.AddNewAlias(this.name, this.qualifier, this.value);
            else
                throw new InvalidOperationException("Party does not exist.");

        }
    }
}

