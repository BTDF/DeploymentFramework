//-----------------------------------------------------------------------
// <copyright file="TaskTestUtilities.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>andyr</email>
// <date>2004-05-25</date>
// <summary>Tests sending an email</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{    
    using System;
    using System.Collections;
    using System.IO;
    using System.Collections.Generic;
    using System.Text;
    
    /// <summary>
    /// Static class with general utility methods for task unit tests.
    /// </summary>
    internal static class TaskTestUtilities
    {
        /// <summary>
        /// Generates a new GUID
        /// </summary>
        /// <returns>A GUID (in hyphenated form)</returns>
        internal static string GenerateNewGuid()
        {
            Guid guid = Guid.NewGuid();
            return guid.ToString();
        }

        /// <summary>
        /// Generates a temporary directory path
        /// </summary>
        /// <returns>A path to a temporary directory</returns>
        internal static string GenerateTempDirectoryPath()
        {
            return System.Environment.ExpandEnvironmentVariables(@"%TEMP%\" + TaskTestUtilities.GenerateNewGuid());
        }

        /// <summary>
        /// Generates a temporary filename with a .temp extension
        /// </summary>
        /// <returns>The temporary filename</returns>
        internal static string GenerateTempFilename()
        {
            return TaskTestUtilities.GenerateTempFilename("temp");
        }

        /// <summary>
        /// Generates a temporary filename with the specified file extension
        /// </summary>
        /// <param name="fileExtension">The extension to apply to the filename</param>
        /// <returns>A temporary filename with the specified file extension</returns>
        internal static string GenerateTempFilename(string fileExtension)
        {
            return TaskTestUtilities.GenerateNewGuid() + "." + fileExtension;
        }

        /// <summary>
        /// Creates a .temp file with a random name in the folder specified. The temp file is
        /// given a GUID as content.
        /// </summary>
        /// <param name="folder">The folder in which the file is to be created</param>
        /// <returns>The name of the created file</returns>
        internal static string CreateTempFileInFolder(string folder)
        {
            return CreateTempFileInFolder(TaskTestUtilities.GenerateNewGuid(), folder);
        }

        /// <summary>
        /// Creates a file with the given name in the folder specified. The temp file is
        /// given a GUID as content.
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="folder"></param>
        /// <returns></returns>
        internal static string CreateTempFileInFolder(string filename, string folder)
        {
            if (filename == String.Empty)
            {
                filename = TaskTestUtilities.GenerateNewGuid();
            }
            string tempFilename = filename + ".temp";
            string tempFileFullPath = folder + "\\" + tempFilename;

            //Create a new file
            System.IO.FileStream newFile = System.IO.File.Create(tempFileFullPath);

            // Add some information to the file.
            Byte[] info = new UTF8Encoding(true).GetBytes(TaskTestUtilities.GenerateNewGuid());
            newFile.Write(info, 0, info.Length);
            newFile.Close();

            return tempFilename;

        }

        /// <summary>
        /// Creates a temporary folder
        /// </summary>
        /// <returns>The full path to the created temporary folder</returns>
        internal static string CreateTempFolder()
        {
            string folder = TaskTestUtilities.GenerateTempDirectoryPath();

            // Ensure it doesn't exist
            if (Directory.Exists(folder))
            {
                throw new ApplicationException("Temporary folder already exists");
            }

            //Create the folder
            Directory.CreateDirectory(folder);

            // Ensure it now exist
            if (!(Directory.Exists(folder)))
            {
                throw new ApplicationException("Temporary folder not created");
            }

            return folder;
        }

        /// <summary>
        /// Deletes the folder and all its contents including any subfolder
        /// </summary>
        /// <param name="folder">The folder to delete.</param>
        internal static void DeleteFolder(string folder)
        {
            System.IO.Directory.Delete(folder, true);
        }

        /// <summary>
        /// Creates a temporary folder with spaces in its folder name
        /// </summary>
        /// <returns></returns>
        internal static string CreateTempFolderWithSpaces()
        {
            //Create a GUID as 32 digits
            string newFolderName = Guid.NewGuid().ToString("N");

            //Insert a space in the middle
            newFolderName = newFolderName.Insert(15, " ");
            string folder = System.Environment.ExpandEnvironmentVariables(@"%TEMP%\" + newFolderName);

            // Ensure it doesn't exist
            if (Directory.Exists(folder))
            {
                throw new ApplicationException("Temporary folder already exists");
            }

            //Create the folder
            Directory.CreateDirectory(folder);

            // Ensure it now exist
            if (!(Directory.Exists(folder)))
            {
                throw new ApplicationException("Temporary folder not created");
            }

            return folder;
        }
    }
}

