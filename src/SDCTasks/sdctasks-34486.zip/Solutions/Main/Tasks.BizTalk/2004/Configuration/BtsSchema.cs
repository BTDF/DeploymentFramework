﻿namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;
    using System.Reflection;

    #endregion

    internal class BtsSchema : BtsBaseObject
    {
        /// <summary>
        /// Internal Constructor
        /// </summary>
        /// <param name="actualBtsObject">The actual Microsoft.Biztalk.ExplorerOM.BtsSchema object that object will call.</param>
        /// <param name="catalogExplorer">The Microsoft.Sdc.Tasks.Configuration.BtsCatalogExplorer object.</param>
        internal BtsSchema(object actualBtsObject, BtsCatalogExplorer catalogExplorer)
        {
            this.btsCatalogExplorer = catalogExplorer;
            this.actualBtsObject = actualBtsObject;
        }

        /// <summary>
        /// Gets the assembly qualified name of the schema.
        /// </summary>
        /// <value></value>
        public string AssemblyQualifiedName
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("AssemblyQualifiedName", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>
        /// Gets the reference to the containing assembly.
        /// </summary>
        /// <value></value>
        public BtsAssembly BtsAssembly
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("BtsAssembly", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return new BtsAssembly(value, this.btsCatalogExplorer);
            }
        }

        /// <summary>
        /// Gets the full name of the schema.
        /// </summary>
        /// <value></value>
        public string FullName
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("FullName", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>
        /// Gets the collection of properties of the property schema.
        /// </summary>
        /// <value></value>
        public System.Collections.IDictionary Properties
        {
            get
            {
                return (System.Collections.IDictionary)this.actualBtsObject.GetType().InvokeMember("Properties", BindingFlags.GetProperty, null, this.actualBtsObject, null);

            }
        }

        /// <summary>
        /// Gets the schema type.
        /// </summary>
        /// <value></value>
        public SchemaType Type
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("Type", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (SchemaType)Enum.Parse(typeof(SchemaType), value.ToString());
            }
        }

        /// <summary>
        /// Gets the XML content of the schema.
        /// </summary>
        /// <value></value>
        public string XmlContent
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("XmlContent", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }
    }
}