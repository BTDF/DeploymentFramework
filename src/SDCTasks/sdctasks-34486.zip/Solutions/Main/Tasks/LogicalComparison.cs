﻿//-----------------------------------------------------------------------
// <copyright file="LogicalComparison.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-11-09</date>
// <summary>
// Compares the 2 params according to Comparison and returns result
// </summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks
{
    #region Using directives
    using System;
    using System.Text;
    using Microsoft.Build.BuildEngine;
    using Microsoft.Build.Framework;
    using Microsoft.Build.Utilities;
    using Microsoft.Build.Shared;
    #endregion

    public class LogicalComparison : TaskBase
    {
        private long param1;
        private long param2;
        private string comparison;
        private bool result;

        public LogicalComparison()
        {
        }

        [Output]
        public bool Result
        {
            get { return this.result; }
            set { this.result = value; }
        }

        public long Param1
        {
            get { return this.param1; }
            set { this.param1 = value; }
        }

        public long Param2
        {
            get { return this.param2; }
            set { this.param2 = value; }
        }

        /// <summary>
        /// Supports 'GreaterThan', 'LessThan', 'GreaterThanOrEquals', 'LessThanOrEquals'
        /// </summary>
        /// <value></value>
        public string Comparison
        {
            get { return this.comparison; }
            set { this.comparison = value; }
        }     

        protected override void InternalExecute()
        {
            this.result = false;

            switch (this.comparison.ToLowerInvariant())
            {
                case "greaterthan":
                    {
                        if (this.param1 > this.param2)
                        {
                            this.result = true;
                        }
                        break;
                    }

                case "lessthan":
                    {
                        if (this.param1 < this.param2)
                        {
                            this.result = true;
                        }
                        break;
                    }

                case "greaterthanorequals":
                    {
                        if (this.param1 >= this.param2)
                        {
                            this.result = true;
                        }
                        break;
                    }

                case "lessthanorequals":
                    {
                        if (this.param1 <= this.param2)
                        {
                            this.result = true;
                        }
                        break;
                    }            
            }
        }
    }
}
