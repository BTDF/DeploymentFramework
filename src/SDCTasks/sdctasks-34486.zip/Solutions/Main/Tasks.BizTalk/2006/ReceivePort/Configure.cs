//-----------------------------------------------------------------------
// <copyright file="Configure.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.ReceivePort
{
    using System;
    using System.Globalization;
    using BizTalk.ExplorerOM;

    /// <summary>
    /// Configures an existing receive port
    /// </summary>
    public class Configure : BizTalk2004.ReceivePort.Configure
    {
        private string application;
        private bool routeFailedMessages;

        /// <summary>
        /// The application that this send port belongs to. If this is not specified, the BizTalk 2004 code 
        /// is executed.
        /// </summary>
        public string Application
        {
            get { return this.application; }
            set { this.application = value; }
        }

        /// <summary>
        /// Indicates whether or not failed messages are routed to failed message subscribers.
        /// </summary>
        public bool RouteFailedMessages
        {
            get { return this.routeFailedMessages; }
            set { this.routeFailedMessages = value; }
        }

        /// <summary>
        /// Executes the task
        /// </summary>
        protected override void InternalExecute()
        {
            if (string.IsNullOrEmpty(this.Application))
            {
                base.InternalExecute();
            }
            else
            {
                BtsCatalogExplorer explorer = this.GetBtsCatalogExplorer(this.Server, this.Database);

                Application app = explorer.Applications[this.Application];
                if (app != null)
                {
                    ReceivePort receivePort = app.ReceivePorts[this.Name];
                    if (receivePort != null)
                    {
                        receivePort.Authentication = (this.AuthenticationType != null) ?
                            (AuthenticationType)Enum.Parse(typeof(AuthenticationType), this.AuthenticationType) :
                            Microsoft.BizTalk.ExplorerOM.AuthenticationType.NotRequired;

                        receivePort.Tracking = (this.TrackingTypes != null) ?
                            (TrackingTypes)Enum.Parse(typeof(TrackingTypes), this.TrackingTypes) :
                            receivePort.Tracking;

                        receivePort.RouteFailedMessage = this.RouteFailedMessages;

                        // inbound maps
                        if (this.RemoveInboundMaps)
                        {
                            receivePort.InboundTransforms.Clear();
                        }
                        else
                        {
                            if (this.InboundMaps != null)
                            {
                                receivePort.InboundTransforms.Clear();
                                foreach (string fullMapName in this.InboundMaps)
                                {
                                    string mapName;
                                    string assemblyName;
                                    SplitQualifiedTypeName(fullMapName, out mapName, out assemblyName);

                                    Transform trans = explorer.Transforms[mapName, assemblyName];
                                    receivePort.InboundTransforms.Add(trans);
                                }
                            }
                        }

                        if (this.RemoveOutboundMaps)
                        {
                            receivePort.OutboundTransforms.Clear();
                        }
                        else
                        {
                            if (receivePort.IsTwoWay)
                            {
                                // send pipeline
                                if (!string.IsNullOrEmpty(this.SendPipeline))
                                {
                                    string pipelineName;
                                    string assemblyName;
                                    SplitQualifiedTypeName(this.SendPipeline, out pipelineName, out assemblyName);

                                    Pipeline p = explorer.Pipelines[pipelineName, assemblyName];

                                    if (p != null)
                                    {
                                        receivePort.SendPipeline = p;
                                    }
                                }

                                // outbound maps
                                if (this.OutboundMaps != null)
                                {
                                    receivePort.OutboundTransforms.Clear();
                                    foreach (string fullMapName in this.OutboundMaps)
                                    {
                                        string mapName;
                                        string assemblyName;
                                        SplitQualifiedTypeName(fullMapName, out mapName, out assemblyName);

                                        Transform t = explorer.Transforms[mapName, assemblyName];
                                        receivePort.OutboundTransforms.Add(t);
                                    }
                                }
                            }
                        }

                        explorer.SaveChanges();
                    }
                    else
                    {
                        Log.LogError(string.Format(CultureInfo.InvariantCulture, "ReceivePort not found: {0} for Application: {1}", this.Name, this.Application));
                        return;
                    }
                }
                else
                {
                    Log.LogError(string.Format(CultureInfo.InvariantCulture, "Application not found: {0}", this.Application));
                    return;
                }
            }
        }
    }
}
