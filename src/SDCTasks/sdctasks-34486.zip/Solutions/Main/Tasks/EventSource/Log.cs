﻿//-----------------------------------------------------------------------
// <copyright file="Log.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Mark Phillips</author>
// <email></email>
// <date>2004-03-25</date>
// <summary>Logs an event to an Event Source.</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.EventSource
{
  using System;
  using Microsoft.Build.Framework;

  /// <summary>
  /// Logs an event to a Event Source.  A TaskException will be thrown if the source does not exist.
  /// </summary>
  /// <remarks>
  /// <code><![CDATA[<EventSource.Log Source="source" EventId="eventid" Description="description" RemoteMachine="remotemachine" />]]></code>
  /// <para>where:</para>
  /// <para><i>source (Required)</i></para>
  /// <para>The source name by which the application is registered on the computer being logged against.</para>
  /// <para><i>eventid (Required)</i></para>
  /// <para>The event id of the log record.</para>
  /// <para><i>description (Required)</i></para>
  /// <para>The description of the log record.</para>
  /// <para><i>remotemachine (Optional)</i></para>
  /// <para>The machine to receive the log record.  If not specified, defaults to the local machine. (Optional)</para>
  /// </remarks>
  /// <example>
  /// <code><![CDATA[
  /// <Project>
  ///     <Target Name="Test" >
  ///         <EventSource.Log
  ///             Source="MyEventSource"
  ///             EventId="10000"
  ///             Description="MyDescription" />
  ///     </Target>
  /// </Project>
  /// ]]></code>    
  /// </example>
  public class Log : TaskBase
  {
    private string source = String.Empty;
    private string eventId = String.Empty;
    private string description = String.Empty;
    private string remoteMachine = String.Empty;
    private System.Diagnostics.EventLogEntryType logType = System.Diagnostics.EventLogEntryType.Error;

    /// <summary>
    /// The source name by which the application is registered on the local computer (or th remote computer if RemoteMachine is specified).
    /// </summary>
    /// <value>The source parameter can be any string, although often it will be the name of your application or a component of your application. The source must be unique on the local computer.</value>
    [Required]
    public string Source
    {
      get
      {
        return (this.source ?? String.Empty);
      }

      set
      {
        this.source = value;
      }
    }

    /// <summary>
    /// The Log Record's event id.
    /// </summary>
    /// <value>An integer.</value>
    [Required]
    public string EventId
    {
      get
      {
        return (this.eventId ?? String.Empty);
      }

      set
      {
        this.eventId = value;
      }
    }

    /// <summary>
    /// The Log Record's description.
    /// </summary>
    /// <value>A text description of the event.</value>
    [Required]
    public string Description
    {
      get
      {
        return (this.description ?? String.Empty);
      }

      set
      {
        this.description = value;
      }
    }

    /// <summary>
    /// The Event Log Entry Type.
    /// </summary>
    /// <value>The type of the event.  Possible values are: Error, FailureAudit, Information, SuccessAudit, Warning.</value>
    public string LogType
    {
      get
      {
        return this.logType.ToString();
      }

      set
      {
        this.logType = (System.Diagnostics.EventLogEntryType)Enum.Parse(typeof(System.Diagnostics.EventLogEntryType), value);
      }
    }

    /// <summary>
    /// The Remote Machine.
    /// </summary>
    /// <value>The machine name where the event log exists.</value>
    public string RemoteMachine
    {
      get
      {
        return (this.remoteMachine ?? String.Empty);
      }

      set
      {
        this.remoteMachine = value;
      }
    }

    /// <summary>
    /// Performs the action of this task.
    /// </summary>
    protected override void InternalExecute()
    {
      Log.LogMessage(MessageImportance.Low, "EventSource.Log", new object[] { this.source, this.eventId, this.description });
      if (!System.Diagnostics.EventLog.SourceExists(this.source, (this.RemoteMachine == String.Empty) ? "localhost" : this.RemoteMachine))
      {
        throw new TaskException("EventSource.DoesNotExist", this.source, (this.RemoteMachine == String.Empty) ? "localhost" : this.RemoteMachine);
      }
      else
      {
        System.Diagnostics.EventLog log = new System.Diagnostics.EventLog("Application", (this.RemoteMachine == String.Empty) ? "localhost" : this.RemoteMachine, this.source);
        log.WriteEntry(this.description, this.logType, Int32.Parse(this.eventId));
      }
    }
  }
}
