﻿
namespace Microsoft.Sdc.Tasks.BizTalk2004
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;

    #endregion

    public class Clean : BizTalk2004TaskBase
    {
        public Clean(){}

        protected override void InternalExecute()
        {
            this.GetInstallation().Clean();
        }
    }
}
