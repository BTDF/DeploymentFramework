/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andrew Burns</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/

namespace Microsoft.Sdc.Tasks.Configuration 
{
	using System;
	using System.IO;
	using System.Collections;
	using System.Globalization;
	using Microsoft.Win32;
	using System.Text.RegularExpressions;
    using System.Diagnostics;
	
	/// <summary>
	/// Provides methods for manipulating Zip files
	/// </summary>
	internal sealed class Cab 
	{
		private Cab() 
		{			
		}

		
		public static bool Create(string pathToCabFile) 
		{
			if(!(File.Exists(pathToCabFile)))
			{
				Stream cabStream = File.Create(pathToCabFile);
                cabStream.Close();
                return true;
			}
			else
			{
				throw new ApplicationException("File already exists");
			}	
		}

		public static bool Add(string pathToCabFile, string pathToFile) 
		{
			return Add(pathToCabFile, new string[] {pathToFile},null,false);
		}

		public static bool Add(string pathToCabFile, string[] filePaths) 
		{
			return Add(pathToCabFile,filePaths,null,false);
		}
		
		public static bool Add(string pathToCabFile, string pathToFile,string path) 
		{
			return Add(pathToCabFile, new string[] {pathToFile},path,false);
		}

		public static bool Add(string pathToCabFile, string[] filePaths,string path) 
		{
			return Add(pathToCabFile,filePaths,path,false);
		}

		public static bool Add(string pathToCabFile, string pathToFile,string path,bool overwrite) 
		{
			return Add(pathToCabFile, new string[] {pathToFile},path,overwrite);
		}
				
        public static bool Add(string pathToCabFile, string[] filePaths,string path,bool overwrite) 
        {
            ShellExecute shellExecute = new ShellExecute();
            shellExecute.Filename = GetPathToCabArc(path);
            //create a unique temporary directory to extract files so that they are not deleted.
            string g = Guid.NewGuid().ToString() + "\\";
            string tempDir = Path.Combine(Path.GetTempPath(),g);
			
            ExtractWithAppPath(pathToCabFile,tempDir,path,false);

            //create lists of all old files and new files						
            string relativePath = null;
            Hashtable newFiles = new Hashtable();
            DirectoryInfo pathDirectory;

            foreach(string pathToFile in filePaths)
            {
                if(Path.GetExtension(pathToFile) == @".*" || Path.GetFileNameWithoutExtension(pathToFile) == @"*")
                {
                    pathDirectory = new DirectoryInfo(Path.GetDirectoryName(pathToFile));
                    foreach (FileInfo pathFile in pathDirectory.GetFiles(Path.GetFileName(pathToFile)))
                    {
                        relativePath = pathFile.FullName.ToString().ToLower();
                        relativePath = relativePath.Remove(0,Path.GetPathRoot(pathToFile).Length);
                        newFiles.Add(relativePath,null);
                    }

                    foreach (object o in GetAllFiles(pathToFile,Path.GetFileName(pathToFile)))
                    {
                        relativePath = ((FileInfo)o).FullName.ToLower();
                        relativePath = relativePath.Remove(0,Path.GetPathRoot(pathToFile).Length);
                        newFiles.Add(relativePath,null);
                    }
                }
                else if(File.Exists(pathToFile))
                {
                    relativePath = pathToFile.Remove(0,Path.GetPathRoot(pathToFile).Length);
                    newFiles.Add(relativePath.ToLower(),null);
                }
                else
                {
                    throw new ApplicationException(String.Format(CultureInfo.InvariantCulture,"File name {0} is invalid.",pathToFile));
                }
						
				//Create a list of the files currently archived
                Hashtable tempFiles = new Hashtable();
                pathDirectory = new DirectoryInfo(Path.GetDirectoryName(tempDir));
                foreach (FileInfo tempRoot in pathDirectory.GetFiles(Path.GetFileName(pathToFile)))
                {
                    relativePath = tempRoot.FullName.ToString().ToLower();
                    relativePath = relativePath.Remove(0,tempDir.Length);
                    tempFiles.Add(relativePath,null);
                }
                foreach (object o in GetAllFiles(tempDir,Path.GetFileName(pathToFile)))
                {
                    relativePath = ((FileInfo)o).FullName.ToLower();
                    relativePath = relativePath.Remove(0,tempDir.Length);
                    tempFiles.Add(relativePath,null);
                }
						
                if (tempFiles.Count > 0)
                {
                    //Compare each file and delete any duplicates in the list
                    //if overwrite enabled delete old files, otherwise throw exception
                    foreach (DictionaryEntry de in newFiles)
                    {
                        if(tempFiles.ContainsKey(de.Key))
                        {
                            if(overwrite)
                            {
                                File.Delete(tempDir+de.Key);
                                tempFiles.Remove(de.Key);
                            }
                            else
                            {
                                throw new ApplicationException(String.Format(CultureInfo.InvariantCulture,"File {0} already exists in archive. Overwrite function disabled.",de.Key.ToString()));
                            }
                        }
                    }
                }
                //Create the updated cab file
                string args = String.Format(CultureInfo.InvariantCulture," -r -p -P {0} n {1} {2}*.* {3}",tempDir.Remove(0,3),pathToCabFile,tempDir,pathToFile);
			    shellExecute.Arguments = args;
                int exitCode = shellExecute.Execute();
                string standardOut = shellExecute.StandardOutput;
                //delete the temporary directory
                Directory.Delete(tempDir, true);
                if (exitCode != 0) 
                {
                    string error = shellExecute.StandardError;
                    return false;
                }   
            }
		    return true;    
        }
		
		public static bool Extract(string pathToCabFile, string pathToFiles, string fileToExtract) 
		{            
			return ExtractInternal(pathToCabFile, pathToFiles, new string[] {fileToExtract}, null,false);
		}

		public static bool Extract(string pathToCabFile, string pathToFiles) 
		{
			return ExtractInternal(pathToCabFile, pathToFiles, null, null,false);            
		}        
        
		public static bool Extract(string pathToCabFile, string pathToFiles, string[] filesToExtract) 
		{
			return ExtractInternal(pathToCabFile, pathToFiles,filesToExtract, null,false);
		}

		public static bool Extract(string pathToCabFile, string pathToFiles, string fileToExtract,bool overwrite) 
		{            
			return ExtractInternal(pathToCabFile, pathToFiles, new string[] {fileToExtract}, null,overwrite);
		}

		public static bool Extract(string pathToCabFile, string pathToFiles,bool overwrite) 
		{
			return ExtractInternal(pathToCabFile, pathToFiles, null, null,overwrite);            
		}        
        
		public static bool Extract(string pathToCabFile, string pathToFiles, string[] filesToExtract,bool overwrite) 
		{
			return ExtractInternal(pathToCabFile, pathToFiles,filesToExtract, null,overwrite);
		}

		public static bool ExtractWithAppPath(string pathToCabFile, string pathToFiles, string fileToExtract,string path) 
		{            
			return ExtractInternal(pathToCabFile, pathToFiles, new string[] {fileToExtract}, path,false);
		}

		public static bool ExtractWithAppPath(string pathToCabFile, string pathToFiles,string path) 
		{
			return ExtractInternal(pathToCabFile, pathToFiles, null, path,false);            
		}        
        
		public static bool ExtractWithAppPath(string pathToCabFile, string pathToFiles, string[] filesToExtract,string path) 
		{
			return ExtractInternal(pathToCabFile, pathToFiles,filesToExtract, path,false);
		}

		public static bool ExtractWithAppPath(string pathToCabFile, string pathToFiles, string fileToExtract,string path,bool overwrite) 
		{            
			return ExtractInternal(pathToCabFile, pathToFiles, new string[] {fileToExtract}, path,overwrite);
		}

		public static bool ExtractWithAppPath(string pathToCabFile, string pathToFiles,string path,bool overwrite) 
		{
			return ExtractInternal(pathToCabFile, pathToFiles, null, path,overwrite);            
		}        
        
		public static bool ExtractWithAppPath(string pathToCabFile, string pathToFiles, string[] filesToExtract,string path,bool overwrite) 
		{
			return ExtractInternal(pathToCabFile, pathToFiles,filesToExtract, path,overwrite);
		}

		private static bool ExtractInternal(string pathToCabFile, string pathToFiles, string[] filesToExtract,string path,bool overwrite) 
		{
			ShellExecute shellExecute = new ShellExecute();
			shellExecute.Filename = GetPathToCabArc(path);
            if (!(pathToFiles.EndsWith(@"\")))
            {
                pathToFiles += @"\";
            }
			if (!(Directory.Exists(pathToFiles)))
			{
				Directory.CreateDirectory(pathToFiles);	
			}

			string extractFilesArg = null;
			if(filesToExtract != null)
			{
				foreach(string fileToExtract in filesToExtract)
				{
					extractFilesArg += " "+fileToExtract;
				}
			}
			string args = String.Format(CultureInfo.InvariantCulture," -p x {0} {1} {2}",pathToCabFile,extractFilesArg,pathToFiles);
			
			if(overwrite)
			{
				args = args.Insert(0," -o");
			}
            shellExecute.Arguments = args;
            int exitCode = shellExecute.Execute();
            string standardOut = shellExecute.StandardOutput;
            if (exitCode != 0) 
            {
                string error = shellExecute.StandardError;
                return false;
            }
            return true;
		}

		private static string GetPathToCabArc(string path) 
		{
			if(path != null && path.Length >0)
			{
				if(File.Exists(path))
				{
					return path;
				}
			}

			string defaultLocation = System.Environment.ExpandEnvironmentVariables(@"%ProgramFiles%\CabArc\Cabarc.exe");
			if(File.Exists(defaultLocation))
			{
				return defaultLocation;
			}
			else
			{
				throw new ApplicationException(String.Format(CultureInfo.InvariantCulture,"Cannot find executable at location: {0}",defaultLocation));	
			}
		}

		private static ArrayList GetAllFiles(string pathToFile,string searchString)
		{
			ArrayList fileList = new ArrayList();
			DirectoryInfo pathDirectory = new DirectoryInfo(Path.GetDirectoryName(pathToFile));
			foreach (DirectoryInfo subDirectory in pathDirectory.GetDirectories())
			{
				fileList.AddRange(subDirectory.GetFiles(searchString));
				if (subDirectory.GetDirectories().Length > 0)
				{
					fileList.AddRange(GetAllFiles(subDirectory.FullName+"\\",searchString));
				}
				
			}
			return fileList;
		}

	}
}
