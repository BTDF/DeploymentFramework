/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Patrick Long</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/


namespace Microsoft.Sdc.Tasks.Configuration.Web 
{
    using System;
    using System.DirectoryServices;
    using System.Collections;
    using System.Runtime.InteropServices;
    using Microsoft.Sdc.Tasks.Configuration.Framework;

    internal class HttpError 
    {

        int httpErrorCode;
        string httpSubErrorCode;
        string  type;
        string  uri;
        
        internal HttpError(int httpErrorCode, string httpSubErrorCode, string type, string Uri) 
        {
            this.httpErrorCode = httpErrorCode;
            this.httpSubErrorCode = httpSubErrorCode;
            this.type = type;
            this.uri = Uri;
        }
        
        //de.Dispose();    

        public int HttpErrorCode 
        {
            get 
            {
                return httpErrorCode ;
            }
        }

        public string HttpSubErrorCode 
        {
            get 
            {
                return httpSubErrorCode;
            }
        }

        public string Type 
        {
            get 
            {
                return type;
            }
            set 
            { 
                if(value == null || value.Length == 0)
                {
                    throw new ArgumentOutOfRangeException("The Type of a HttpError cannot be null or empty");
                }
                else
                {
                    type = value;
                }
            }
        }   

        public string Uri
        {
            get 
            {
                return uri;
            }

            set
            {
                if(value == null || value.Length == 0)
                {
                    throw new ArgumentOutOfRangeException("The URI of a HttpError cannot be null or empty");
                }
                else
                {
                    uri = value;
                }
            }
        }
    }
}

