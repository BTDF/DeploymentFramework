//-----------------------------------------------------------------------
// <copyright file="Bind.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.Orchestration
{
    using System;
    using System.Globalization;
    using BizTalk.ExplorerOM;
    using Build.Framework;

    /// <summary>
    /// Binds an orchestration
    /// </summary>
    public class Bind : BizTalk2004.Orchestration.Bind
    {
        private string application;

        /// <summary>
        /// Gets or sets the application.
        /// </summary>
        /// <value>The application.</value>
        public string Application
        {
            get { return this.application; }
            set { this.application = value; }
        }

        /// <summary>
        /// InternalExecute
        /// </summary>
        protected override void InternalExecute()
        {
            if (string.IsNullOrEmpty(this.Application))
            {
                base.InternalExecute();
            }
            else
            {
                BtsCatalogExplorer explorer = this.GetBtsCatalogExplorer(this.Server, this.Database);

                Application app = explorer.Applications[this.Application];
                if (app != null)
                {
                    BtsOrchestration orchestration = app.Orchestrations[this.Name];
                    orchestration.Host = (!string.IsNullOrEmpty(this.HostName)) ? explorer.Hosts[this.HostName] : orchestration.Host;
                    if (this.OrchestrationPorts != null)
                    {
                        foreach (ITaskItem item in this.OrchestrationPorts)
                        {
                            string orchPortName = item.GetMetadata("orchestrationPortName");
                            string receivePortName = item.GetMetadata("receivePort");
                            string sendPortName = item.GetMetadata("sendPort");
                            string sendPortGroupName = item.GetMetadata("sendPortGroup");

                            OrchestrationPort orchPort = orchestration.Ports[orchPortName];
                            if (orchPort == null)
                            {
                                Log.LogError(string.Format(CultureInfo.InvariantCulture, "Orchestration Port not found: {0} in this Orchestration: {1}", this.Application, this.Name));
                                return;
                            }

                            orchPort.SendPort = (!string.IsNullOrEmpty(sendPortName)) ? explorer.SendPorts[sendPortName] : orchPort.SendPort;
                            orchPort.ReceivePort = (!string.IsNullOrEmpty(receivePortName)) ? explorer.ReceivePorts[receivePortName] : orchPort.ReceivePort;
                            orchPort.SendPortGroup = (!string.IsNullOrEmpty(sendPortGroupName)) ? explorer.SendPortGroups[sendPortGroupName] : orchPort.SendPortGroup;
                        }
                    }

                    Log.LogMessage(string.Format(CultureInfo.InvariantCulture, "Binding Orchestration: {0} in Application {1}", this.Name, this.Application));
                    explorer.SaveChanges();
                }
                else
                {
                    Log.LogError(string.Format(CultureInfo.InvariantCulture, "Application not found: {0}", this.Application));
                    return;
                }
            }
        }
    }
}
