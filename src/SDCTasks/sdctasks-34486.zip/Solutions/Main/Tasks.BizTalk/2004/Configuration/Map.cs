//-------------------------------------------------------------------------------------
// <copyright file="Map.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      A map which does document transformations.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using directives

    using System;

	#endregion

	/// <summary>
	/// A map which does document transformations.
	/// </summary>
	internal sealed class Map : BizTalkNonConfigurableEntityBase
	{
		#region Member Variables

		private BizTalkAssembly assembly;
		private string assemblyQualifiedName;
		private Schema sourceSchema;
		private Schema targetSchema;
		private string xmlContent = String.Empty;

		#endregion

		#region Constructors

		/// <summary>
		/// Creates a new map instance. This is private because instance of this class can only be created with
		/// the Load method, as you cannot add maps to an installation.
		/// </summary>
		/// <param name="assembly">
		/// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> that the map belongs to.
		/// </param>
		/// <param name="name">
		/// The name of the map.
		/// </param>
        private Map(BizTalkAssembly assembly, string name) 
			: base(assembly.Installation, name)
        {
        }

		#endregion

		#region Properties

		/// <summary>
		/// Gets the assembly that the map belongs to.
		/// </summary>
		/// <value>
		/// A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/>.
		/// </value>
		public BizTalkAssembly Assembly
		{
			get
			{
				return this.assembly;
			}
		}

		/// <summary>
		/// Gets the assembly qualified name of the map.
		/// </summary>
		/// <value>
		/// The assembly qualified name of the map.
		/// </value>
		public string AssemblyQualifiedName
		{
			get
			{
				return this.assemblyQualifiedName;
			}
		}

		/// <summary>
		/// Gets the source schema for the map.
		/// </summary>
		/// <value>
		/// The name of the source schema.
		/// </value>
		public Schema SourceSchema
		{
			get 
			{ 
				return this.sourceSchema; 
			}
		}

		/// <summary>
		/// Gets the target schema for the map.
		/// </summary>
		/// <value>
		/// The name of the target schema.
		/// </value>
        public Schema TargetSchema
        {
            get 
			{ 
				return this.targetSchema; 
			}
        }

		/// <summary>
		/// Gets the XML content of the map.
		/// </summary>
		public string XmlContent
		{
			get
			{
				return this.xmlContent;
			}
		}

		#endregion

		#region Static Methods

		/// <summary>
		/// Loads the details of a map.
		/// </summary>
        /// <param name="assembly">
		/// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> that the map belongs to.
		/// </param>
		/// <param name="name">
		/// The name of the map.
		/// </param>
		/// <returns>
		/// A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Map"/>.
		/// </returns>
		/// <exception cref="System.InvalidOperationException">
		/// Thrown when the map does not exist in the BizTalk Server installation.
		/// </exception>
		public static Map Load(BizTalkAssembly assembly, string name)
		{
			//check inputs
			if (assembly == null)
			{
				throw new ArgumentNullException("assembly");
			}
			if (name == null || name.Length == 0)
			{
				throw new ArgumentNullException("name");
			}

			//load the actual map
			BtsTransform actualMap = Map.GetActualMap(assembly, name, true);

			//load the details into a new config map
			Map configMap = new Map(assembly, name);
			configMap.assembly = assembly;
			configMap.assemblyQualifiedName = actualMap.AssemblyQualifiedName;
			configMap.sourceSchema = assembly.Installation.DeployedAssemblies[actualMap.SourceSchema.BtsAssembly.DisplayName].Schemas[actualMap.SourceSchema.FullName];
			configMap.targetSchema = assembly.Installation.DeployedAssemblies[actualMap.TargetSchema.BtsAssembly.DisplayName].Schemas[actualMap.TargetSchema.FullName];
			//configMap.xmlContent = actualMap.XmlContent;	//TODO: Investigate - calling this causes a failure in BizTalk API

			//return the map
			return configMap;
		}

		/// <summary>
		/// Gets the actual map object that is deployed in BizTalk.
		/// </summary>
		/// <param name="assembly">
		/// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> object that contains this 
		/// map.
		/// </param>
		/// <param name="name">
		/// The name of the map to load.
		/// </param>
		/// <param name="throwIfNotFound">
		/// <b>true</b> to throw an error if the map is not found, or <b>false</b> otherwise.
		/// </param>
		/// <returns>
		/// A <see cref="BtsTransform"/> object. 
		/// </returns>
		/// <exception cref="System.InvalidOperationException">
		/// Thrown when <paramref name="throwIfNotFound"/> is <b>true</b> and the map does not exist 
		/// in the BizTalk Server installation.
		/// </exception>
		private static BtsTransform GetActualMap(BizTalkAssembly assembly, string name, bool throwIfNotFound)
		{
			BtsTransform actualMap = assembly.Installation.CatalogExplorer.Transforms[name, assembly.Name];
			if (throwIfNotFound && actualMap == null)
			{
				throw new InvalidOperationException("The map does not exist in the BizTalk Server installation.");
			}
			return actualMap;
		}

		#endregion
	}
}

