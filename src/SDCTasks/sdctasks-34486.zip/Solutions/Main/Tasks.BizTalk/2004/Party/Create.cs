//-------------------------------------------------------------------------------------
// <copyright file="Deploy.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Deploys an assembly into BizTalk.
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2004.Party
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion

    public class Create : BizTalk2004TaskBase
    {
        private string name;
        private string[] sendPorts;
        private string signatureCert;


        [Required]
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        public string[] SendPorts
        {
            get { return this.sendPorts; }
            set { this.sendPorts = value; }
        }

        public string SignatureCert
        {
            get { return this.signatureCert; }
            set { this.signatureCert = value; }
        }

        public Create(){}


        protected override void InternalExecute()
        {

            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation installation = this.GetInstallation();
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party party = new Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party(installation, this.name);


            if (this.sendPorts != null)
            {
                foreach (string sendPort in this.sendPorts)
                    party.SendPorts.Add(installation.SendPorts[sendPort]);
            }

            if (!string.IsNullOrEmpty(this.signatureCert))
                party.SignatureCert = installation.Certificates[this.signatureCert];

            party.Save();

        }
    }
}

