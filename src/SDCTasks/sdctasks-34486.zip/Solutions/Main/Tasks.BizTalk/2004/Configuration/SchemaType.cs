
namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    using System;

    public enum SchemaType
    {
        Document = 0,
        Property = 1
    }
}

