/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.Web
{
    using System;
    using System.DirectoryServices;
    using System.ComponentModel;
    using System.Text;
    using System.Collections;


    /// <summary>
    /// Summary description for RestartTime.
    /// </summary>
    internal class RestartTime {

        /// <summary>
        /// Initialize a RestartTime type at the time specified
        /// </summary>
        /// <param name="time">A time in the format hh:mm</param>
        public RestartTime(string time) {
            if (time.Length != 5) {
                throw new ArgumentException("The time must be specified as hh:mm", "time");
            }
            this.Hours = Convert.ToInt32(time.Substring(0,2));
            this.Minutes = Convert.ToInt32(time.Substring(3,2));
        }

        public RestartTime(int hours, int minutes) {
            this.Hours = hours;
            this.Minutes = minutes;
        }

        public RestartTime() {
        }

        private int hours;
        private int minutes;

        public int Hours {
            get {
                return hours;
            }
            set {
                if (value < 0 || value > 23) {
                    throw new ArgumentOutOfRangeException("value",value, "Hours should be between 0 and 23 inclusive.");
                }
                hours = value;
            }
        }

        public int Minutes {
            get {
                return minutes;
            }
            set {
                if (value < 0 || value > 59) {
                    throw new ArgumentOutOfRangeException("value",value, "Minutes should be between 0 and 59 inclusive.");
                }
                minutes = value;
            }
        }

        public override string ToString() {
            return hours.ToString("00") + ":" + minutes.ToString("00");
        }
    }   
}
