/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Simon Ransom</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.SummaryGeneration
{
	using System;
	using System.IO;
	using System.Xml;

	/// <summary>
	/// Summary description for Report.
	/// </summary>
	internal class Report
	{
		public void Add(string sectionXml, string reportFile)
		{
			XmlDocument document = new XmlDocument();
			document.LoadXml(sectionXml);
			Section section = new Section(document);
			Add(section,reportFile);
		}

		//TODO: allow custom DLLs to be specified
		/// <summary>
		/// Create a section using a section generator from this assembly
		/// </summary>
		/// <param name="generatorClass">full class name of section generator class</param>
		/// <param name="sourceFolder"></param>
        /// <param name="fileSpec"></param>
        /// <param name="name"></param>
		/// <returns></returns>
		public Section CreateSection(string generatorClass, string sourceFolder, string fileSpec, string name)
		{
			// Create the generator class
			Type generatorType = this.GetType().Assembly.GetType(generatorClass,true,true);
			ISectionGenerator generator = (ISectionGenerator)generatorType.GetConstructor(new Type[]{}).Invoke(new object[]{});
			
			// Call GenerateSection
			return generator.GenerateSection(sourceFolder,fileSpec,name);						
		}

		public void Add(Section section, string reportFile)
		{
			// If the report doesn't exist then create it
			XmlDocument report = new XmlDocument();
			if (File.Exists(reportFile))
			{
				report.Load(reportFile);				
			}
			else
			{
				report.AppendChild(report.CreateElement("Report"));
				report.DocumentElement.SetAttribute("Created",DateTime.Now.ToLongDateString());
			}
			// Append the section to the report
			report.DocumentElement.AppendChild(report.ImportNode(section.Xml.DocumentElement,true));
			report.Save(reportFile);
		}

		public Report()
		{			
		}
	}
}
