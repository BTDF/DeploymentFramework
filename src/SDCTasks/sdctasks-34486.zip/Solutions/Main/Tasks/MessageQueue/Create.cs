//-----------------------------------------------------------------------
// <copyright file="Create.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-03-25</date>
// <summary>Creates a new Message Queue.</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.MessageQueue
{
    using System;
    using System.Xml;
    using System.Globalization;
    using System.Messaging;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Creates a new Message Queue.
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<MessageQueue.Create QueuePath="queuePath" QueueLabel="queueLabel" TransactionsEnabled="transactionsEnabled" />]]></code>
    /// <para>where:</para>
    /// <para><i>queuePath (Required)</i></para>
    /// <para>
    /// The path of the queue to create. An exception will be thrown if the queue already exists at the specified path.
    /// The path must be prefixed by the machine name (or "." to represent the local computer). See <see cref="System.Messaging.MessageQueue.Path"/> for more details.
    /// </para>
    /// <para><i>queueLabel</i></para>
    /// <para>
    /// The label for the message queue. The maximum length of a message queue label is 124 characters.
    /// </para>
    /// <para><i>transactionsEnabled</i></para>
    /// <para>
    /// True to create a transactional queue; false to create a nontransactional queue. Defaults to false.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test">
    ///         <MessageQueue.Create
    ///             QueuePath=".\\TempQueue"
    ///             QueueLabel="MyQueueLabel1" />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Create : TaskBase
    {
        private string queuePath;
        private string queueLabel;
        private bool transactionsEnabled;

        /// <summary>
        /// Initializes a new instance of the Create class.
        /// </summary>
        public Create()
        {
        }

        #region Public Properties

        /// <summary>
        /// The path of the queue to create.
        /// </summary>
        /// <value>The path of the queue to create. An exception will be thrown if the queue already exists at the specified path.</value>
        [Required]
        public string QueuePath
        {
            get
            {
                return (this.queuePath == null ? String.Empty : this.queuePath);
            }

            set
            {
                this.queuePath = value;
            }
        }

        /// <summary>
        /// The label for the message queue. 
        /// </summary>
        /// <value>The label for the message queue. The maximum length of a message queue label is 124 characters.</value>
        public string QueueLabel
        {
            get
            {
                return (this.queueLabel == null ? String.Empty : this.queueLabel);
            }

            set
            {
                this.queueLabel = value;
            }
        }

        /// <summary>
        /// Determines whether the created queue will support transactions.
        /// </summary>
        /// <value>True to create a transactional queue; false to create a nontransactional queue. Defaults to false.</value>
        public bool TransactionsEnabled
        {
            get
            {
                return (this.transactionsEnabled);
            }

            set
            {
                this.transactionsEnabled = value;
            }
        }

        #endregion

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            MessageQueue queue = null;

            Log.LogMessageFromResources("Msmq.Create", this.queuePath);
            queue = MessageQueue.Create(this.queuePath, this.transactionsEnabled);
            if (this.queueLabel.Length > 0)
            {
                queue.Label = this.queueLabel;
            }
            queue.Close();
        }
    }
}

