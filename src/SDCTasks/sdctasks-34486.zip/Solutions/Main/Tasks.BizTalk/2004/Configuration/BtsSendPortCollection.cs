﻿namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;

    #endregion

    internal class BtsSendPortCollection : System.Collections.ReadOnlyCollectionBase
    {
        public BtsSendPortCollection() { }

        public BtsSendPort this[string name]
        {
            get
            {
                BtsSendPort item = null;
                foreach (BtsSendPort currentitem in this.InnerList)
                {
                    if (currentitem.Name == name)
                    {
                        item = currentitem;
                        break;
                    }
                }
                return item;

            }
        }

        public BtsSendPort this[int index]
        {
            get
            {
                return (BtsSendPort)this.InnerList[index];
            }
        }

        internal void Add(BtsSendPort item)
        {
            this.InnerList.Add(item);
        }
    }
}
