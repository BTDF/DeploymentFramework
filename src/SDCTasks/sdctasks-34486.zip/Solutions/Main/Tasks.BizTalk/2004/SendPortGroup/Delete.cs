
namespace Microsoft.Sdc.Tasks.BizTalk2004.SendPortGroup
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;

    #endregion

    public class Delete : BizTalk2004TaskBase
    {
        private string name;

        [Required]
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        public Delete()
        {
        }

        protected override void InternalExecute()
        {
            BizTalkInstallation installation = this.GetInstallation();
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SendPortGroup.Delete(installation, this.name);
        
        }
    }
}

