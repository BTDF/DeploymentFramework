/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.Framework {
	using System;
	using System.Security.Principal;
	using System.Runtime.InteropServices;
	using System.Text;
	using System.Collections;
	using System.Globalization;
	
	internal sealed class AdvApi32 {
	
		private sealed class SE_PRIVILEGE {			
			private SE_PRIVILEGE() {
			}
			internal const string SE_INTERACTIVE_LOGON_NAME             = "SeInteractiveLogonRight";
			internal const string SE_NETWORK_LOGON_NAME                 = "SeNetworkLogonRight";
			internal const string SE_BATCH_LOGON_NAME                   = "SeBatchLogonRight";
			internal const string SE_SERVICE_LOGON_NAME                 = "SeServiceLogonRight";
			internal const string SE_DENY_INTERACTIVE_LOGON_NAME        = "SeDenyInteractiveLogonRight";
			internal const string SE_DENY_NETWORK_LOGON_NAME            = "SeDenyNetworkLogonRight";
			internal const string SE_DENY_BATCH_LOGON_NAME              = "SeDenyBatchLogonRight";
			internal const string SE_DENY_SERVICE_LOGON_NAME            = "SeDenyServiceLogonRight";
			internal const string SE_REMOTE_INTERACTIVE_LOGON_NAME      = "SeRemoteInteractiveLogonRight";
			internal const string SE_DENY_REMOTE_INTERACTIVE_LOGON_NAME = "SeDenyRemoteInteractiveLogonRight";
            internal const string SE_INCREASE_QUOTA_PRIVILEGE           = "SeIncreaseQuotaPrivilege";
            internal const string SE_AUDIT_PRIVILEGE                    = "SeAuditPrivilege";
            internal const string SE_ASSIGN_PRIMARY_TOKEN_PRIVILEGE     = "SeAssignPrimaryTokenPrivilege";

		}

		static LSA_UNICODE_STRING CreateLsaString(string inputString) {
			
			LSA_UNICODE_STRING lsaString = new LSA_UNICODE_STRING();
			
			if (inputString == null) {
				lsaString.Buffer = IntPtr.Zero;
				lsaString.Length = 0;
				lsaString.MaximumLength = 0;
			} else {

				lsaString.Buffer = Marshal.StringToHGlobalAuto(inputString);
				lsaString.Length = (UInt16)(inputString.Length * UnicodeEncoding.CharSize);
				lsaString.MaximumLength = (UInt16)((inputString.Length + 1) * UnicodeEncoding.CharSize);
			}
			return lsaString;
		}


		static string RetrieveLsaString(LSA_UNICODE_STRING value) {			
			if (value.Length == 0 || value.MaximumLength == 0) {
				return null;
			} else {
				return Marshal.PtrToStringAuto(value.Buffer);
			}			
		}

		static internal string[] GetPrivileges(string machineName, string userName) {
			
			int cbSid = 0;
			IntPtr sid = IntPtr.Zero;
			StringBuilder sb = new StringBuilder();
			StringBuilder domainName = null;
			int  cbDomainName = 0;
			UInt32 result;
			int returnValue;
			
			int use = 0;
			IntPtr policyHandle = new IntPtr();

			try {
				NativeMethods.LookupAccountName(machineName, userName, sid, ref cbSid, domainName, ref cbDomainName, ref use);
				domainName = new StringBuilder(cbDomainName);
				sid = Marshal.AllocHGlobal(cbSid);
				returnValue = NativeMethods.LookupAccountName(machineName, userName, sid, ref cbSid, domainName, ref cbDomainName, ref use);
			
				if (returnValue == 0) {
					return null;
				}

				LSA_OBJECT_ATTRIBUTES objectAttributes = new LSA_OBJECT_ATTRIBUTES();
				objectAttributes.Length = 0;
				objectAttributes.RootDirectory = IntPtr.Zero;
				objectAttributes.Attributes = 0;
				objectAttributes.SecurityDescriptor = IntPtr.Zero;
				objectAttributes.SecurityQualityOfService = IntPtr.Zero;
			
				LSA_UNICODE_STRING machineNameLSA = CreateLsaString(machineName);
						
				int desiredAccess =	NativeMethods.POLICY_CREATE_SECRET;
				
				result = NativeMethods.LsaOpenPolicy(ref machineNameLSA, ref objectAttributes, desiredAccess, out policyHandle);
				if (result != 0) {
					return null;
				}

				
				UInt32 countOfRights = 0;
				IntPtr privPtr;
				result = NativeMethods.LsaEnumerateAccountRights(policyHandle, sid, out privPtr, out countOfRights);
							
				if (result != 0) {
					return null;
				}

				ArrayList a = new ArrayList();

				for (int i = 0; i < countOfRights; i++) {
					LSA_UNICODE_STRING lsaString;
					lsaString = (LSA_UNICODE_STRING)Marshal.PtrToStructure(privPtr, typeof(LSA_UNICODE_STRING));
					a.Add(RetrieveLsaString(lsaString));
					privPtr = new IntPtr(privPtr.ToInt32() + Marshal.SizeOf(typeof(LSA_UNICODE_STRING)));
				}
				
				string[] returnArray = new String[a.Count];
				a.CopyTo(returnArray);
				return returnArray;

			} catch (Exception e) {
				throw e;

			} finally {			
				result = SafeNativeMethods.LsaClose(policyHandle);
				Marshal.FreeHGlobal(sid);
				//TODO Free string buffers
			}
		}

		
		static internal bool GrantPrivilege(string domainName, string userName, string privilege, string machineName) {
			
			if (privilege != SE_PRIVILEGE.SE_BATCH_LOGON_NAME &&
				privilege != SE_PRIVILEGE.SE_DENY_BATCH_LOGON_NAME &&
				privilege != SE_PRIVILEGE.SE_DENY_INTERACTIVE_LOGON_NAME &&
				privilege != SE_PRIVILEGE.SE_DENY_NETWORK_LOGON_NAME &&
				privilege != SE_PRIVILEGE.SE_DENY_REMOTE_INTERACTIVE_LOGON_NAME &&
				privilege != SE_PRIVILEGE.SE_DENY_SERVICE_LOGON_NAME &&
				privilege != SE_PRIVILEGE.SE_INTERACTIVE_LOGON_NAME &&
				privilege != SE_PRIVILEGE.SE_NETWORK_LOGON_NAME &&
				privilege != SE_PRIVILEGE.SE_REMOTE_INTERACTIVE_LOGON_NAME &&
				privilege != SE_PRIVILEGE.SE_SERVICE_LOGON_NAME &&
                privilege != SE_PRIVILEGE.SE_INCREASE_QUOTA_PRIVILEGE &&
                privilege != SE_PRIVILEGE.SE_AUDIT_PRIVILEGE &&
                privilege != SE_PRIVILEGE.SE_ASSIGN_PRIMARY_TOKEN_PRIVILEGE ) {
				throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unknown privilege specified as {0}.", privilege));
			}

			int cbSid = 0;
			IntPtr sid = IntPtr.Zero;
			StringBuilder sb = new StringBuilder();
			StringBuilder domainNameInternal = null;
			int  cbDomainName = 0;
			UInt32 result;
			int returnValue;
			
			int use = 0;
			IntPtr policyHandle = new IntPtr();

            try {
                if (domainName == null || domainName.Length == 0) {
                    domainName = machineName;
                }
                domainNameInternal = new StringBuilder(domainName);

                NativeMethods.LookupAccountName(machineName, userName, sid, ref cbSid, domainNameInternal, ref cbDomainName, ref use);
                domainNameInternal = new StringBuilder(cbDomainName);
                sid = Marshal.AllocHGlobal(cbSid);
                returnValue = NativeMethods.LookupAccountName(machineName, userName, sid, ref cbSid, domainNameInternal, ref cbDomainName, ref use);
			
                if (returnValue == 0) {
                    return false;
                }


                

                LSA_OBJECT_ATTRIBUTES objectAttributes = new LSA_OBJECT_ATTRIBUTES();
                objectAttributes.Length = 0;
                objectAttributes.RootDirectory = IntPtr.Zero;
                objectAttributes.Attributes = 0;
                objectAttributes.SecurityDescriptor = IntPtr.Zero;
                objectAttributes.SecurityQualityOfService = IntPtr.Zero;
			
                LSA_UNICODE_STRING machineNameLSA = CreateLsaString(machineName);
						
                int desiredAccess =	NativeMethods.POLICY_CREATE_SECRET;
				
                result = NativeMethods.LsaOpenPolicy(ref machineNameLSA, ref objectAttributes, desiredAccess, out policyHandle);
                if (result != 0) {
                    return false;
                }

                LSA_UNICODE_STRING privilegeString = CreateLsaString(privilege);
			
                result = NativeMethods.LsaAddAccountRights(policyHandle, sid, ref privilegeString, 1);
                if (result != 0) {
                    return false;
                }

                return true;

            } catch (Exception e) {
                throw e;

            } finally {			
                result = SafeNativeMethods.LsaClose(policyHandle);
                Marshal.FreeHGlobal(sid);
                //TODO Free string buffers
            }
		}

		private AdvApi32() {
		}

		static internal WindowsImpersonationContext ImpersonateUser(string userName, string domain, string password) {
			WindowsImpersonationContext impersonationContext;
			WindowsIdentity tempWindowsIdentity;
			IntPtr token = IntPtr.Zero;
			IntPtr tokenDuplicate = IntPtr.Zero;

			if(NativeMethods.LogonUser(userName, domain, password, NativeMethods.LOGON32_LOGON_INTERACTIVE, NativeMethods.LOGON32_PROVIDER_DEFAULT, out token)) {
				if(NativeMethods.DuplicateToken(token, 2, ref tokenDuplicate) != 0) {
					tempWindowsIdentity = new WindowsIdentity(tokenDuplicate);
					impersonationContext = tempWindowsIdentity.Impersonate();
					
					return impersonationContext;
					 
				} else {
					return null;
				}
			} else {
				return null;
			}
		}
	}
}
