//-----------------------------------------------------------------------
// <copyright file="Start.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-03-23</date>
// <summary>Starts CodeCoverage according to its config file</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.CodeCoverage
{
    using System;

    /// <summary>
    /// Begins code coverage analysis using CoverageEye
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<CodeCoverage.Start />]]></code>
    /// <para>There are no properties associated with this task. Code coverage will commence on the assemblies specified in the "CoverageConfig.xml" file located in the CoverageEye configuration folder</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <CodeCoverage.Start />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Start : TaskBase
    {
        /// <summary>
        /// Initializes a new instance of the Start class.
        /// </summary>
        public Start()
        {
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            string key1 = @"SYSTEM\CurrentControlSet\Control\Session Manager\Environment";
            Microsoft.Win32.RegistryKey regKey = Microsoft.Win32.Registry.LocalMachine.CreateSubKey(key1);
            regKey.SetValue("Cor_Enable_Profiling", "1");
            regKey.Close();

            Microsoft.Win32.RegistryKey regKey2 = Microsoft.Win32.Registry.LocalMachine.CreateSubKey(key1);
            regKey2.SetValue("Cor_Profiler", "{18656C37-035D-41CD-82C2-85DEF2DD5F7B}");
            regKey2.Close();

            int result = NativeMethods.SendMessageTimeout(
                NativeMethods.HWND_BROADCAST,
                NativeMethods.WM_SETTINGCHANGE,
                0,
                "Environment",
                NativeMethods.SMTO_ABORTIFHUNG,
                0,
                0);
            NativeMethods.SetEnvironmentVariableEx("Cor_Enable_Profiling", "1");
            NativeMethods.SetEnvironmentVariableEx("Cor_Profiler", "{18656C37-035D-41CD-82C2-85DEF2DD5F7B}");
        }
    }
}