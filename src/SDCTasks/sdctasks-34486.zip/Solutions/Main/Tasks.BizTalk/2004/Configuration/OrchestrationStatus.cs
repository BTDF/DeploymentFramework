﻿using System;

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	/// <summary>
	///Denotes the status of an orchestration. 
	/// </summary>

	public enum OrchestrationStatus : int
	{
		/// <summary>
		/// The orchestration is enlisted, and subscriptions are created but they are deactivated.
		/// </summary>
		Enlisted = 2,

		/// <summary>
		/// The orchestration is started, and subscriptions are activated.
		/// </summary>
		Started = 3,

		/*
		/// <summary>
		/// The orchestration is stopping.
		/// </summary>
		Stopping = 4,
		*/

		/// <summary>
		/// The orchestration is unenlisted, and no subscriptions are created.
		/// </summary>
		Unenlisted = 1

	}
}

