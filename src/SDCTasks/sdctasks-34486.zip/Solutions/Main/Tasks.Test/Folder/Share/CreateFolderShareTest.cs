//-----------------------------------------------------------------------
// <copyright file="CreateFolderShareTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-05-27</date>
// <summary>Tests folder sharing</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    using System.Management;

    /// <summary>
    /// Unit test for the create folder share
    /// </summary>
    [TestClass]
    public class CreateFolderShareTest
    {
        

        private const string MACHINE_NAME = ".";
        private const string FOLDER_SHARE_DESCRIPTION = "Temporary share for unit testing";
        private const string FOLDER_SHARE_NAME = "UnitTest";

        public CreateFolderShareTest()
        {
        }

        [TestMethod]
        public void TestCreateFolderShare()
        {
            Tasks.Folder.Share.Create createFolderShareTask = new Tasks.Folder.Share.Create();

            Tasks.Folder.Share.DeleteShare deleteFolderShareTask = new Tasks.Folder.Share.DeleteShare();
            
            string tempDirectory = TaskTestUtilities.CreateTempFolder();

            try
            {
                //NB - if machine name is "." or Environment.MachineName, then you can't 
                //set the username/password for the task, or you'll generate a
                //  "User credentials cannot be used for local connections"
                //exception. 

                createFolderShareTask.Machine = MACHINE_NAME;
                createFolderShareTask.Path = tempDirectory;
                createFolderShareTask.Description = FOLDER_SHARE_DESCRIPTION;
                createFolderShareTask.ShareName = FOLDER_SHARE_NAME;

                bool createTaskReturnValue = createFolderShareTask.Execute();

                //Test the folder share was created
                Assert.IsTrue(createTaskReturnValue);

                //NB S.Bell
                //========
                //Checks removed for performance

//              //Ensure that this share really has been created using the System.Management namespace
//              PropertyDataCollection createdShareData = FindShare(createFolderShareTask);
//              Assertion.AssertNotNull("Failed to find shared folder after create task", createdShareData);
//
//              //Ensure the properties of the share were set correctly
//              PropertyDataCollection.PropertyDataEnumerator shareDataEnumerator = createdShareData.GetEnumerator();
//              while (shareDataEnumerator.MoveNext())
//              {
//                  PropertyData propertyData = (PropertyData) shareDataEnumerator.Current;
//                  if (propertyData.Name == "Name")
//                  {
//                      Assert.AreEqual("Created folder share name", propertyData.Value, createFolderShareTask.ShareName);
//                  }
//
//                  if (propertyData.Name == "Path")
//                  {
//                      Assert.AreEqual("Created folder share path", propertyData.Value, createFolderShareTask.Path);
//                  }
//
//                  if (propertyData.Name == "Description")
//                  {
//                      Assert.AreEqual("Created folder share description", propertyData.Value, createFolderShareTask.Description);
//                  }
//              }

                //Delete the share
                deleteFolderShareTask.Machine = MACHINE_NAME;
                deleteFolderShareTask.ShareName = FOLDER_SHARE_NAME;

                bool deleteTaskReturnValue = deleteFolderShareTask.Execute();
                //Test the folder share was deleted
                Assert.IsTrue(deleteTaskReturnValue);

                //Ensure that the share has been deleted
                //PropertyDataCollection deletedShareData = FindShare(deleteFolderShareTask);
                //Assertion.AssertNull("Found shared folder after delete task", deletedShareData);
            }
            finally
            {
                Directory.Delete(tempDirectory, true);
            }
        }

        private PropertyDataCollection FindShare(Microsoft.Sdc.Tasks.Folder.Share.ShareTaskBase task)
        {
            ConnectionOptions shareConnection = new ConnectionOptions();

            ManagementScope shareScope = new ManagementScope(@"\\" + task.Machine + @"\Root\CIMv2", shareConnection);
            ObjectQuery shareQuery = new ObjectQuery("Select * from Win32_Share");
            ManagementObjectSearcher shareSearch = new ManagementObjectSearcher(shareScope, shareQuery);
            ManagementObjectCollection shareResults = shareSearch.Get();

            PropertyDataCollection sharePropertyData = null;

            foreach (ManagementObject searchObject in shareResults)
            {
                PropertyDataCollection searchResultProperties = searchObject.Properties;

                PropertyDataCollection.PropertyDataEnumerator propertyEnumerator = searchResultProperties.GetEnumerator();
                while (propertyEnumerator.MoveNext())
                {
                    PropertyData propertyData = (PropertyData) propertyEnumerator.Current;
                    if ((propertyData.Name == "Name") && (propertyData.Value.ToString() == task.ShareName))
                    {
                        sharePropertyData = searchResultProperties;
                    }
                }
            }

            return sharePropertyData;
        }
    }
}


