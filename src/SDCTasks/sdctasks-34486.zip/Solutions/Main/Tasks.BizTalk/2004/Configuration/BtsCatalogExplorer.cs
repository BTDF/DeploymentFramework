﻿//-------------------------------------------------------------------------------------
// <copyright file="BtsCatalogExplorer.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      BtsCatalogExplorer
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;
    using System.Reflection;

    #endregion
    internal class BtsCatalogExplorer : BtsBaseObject
    {
        #region constants

        /// <summary>
        /// the AssemblyName of the BizTalk 2004 Explorer OM Assembly
        /// </summary>
        private const string BTSASSEMBLYNAME = "Microsoft.BizTalk.ExplorerOM, Version=3.0.1.0, Culture=Neutral, PublicKeyToken=31bf3856ad364e35";

        #endregion

        #region member variables
        private Assembly biztalkOMAssembly;
        #endregion

        /// <summary>Initializes a new instance of the BtsCatalogExplorer object.</summary>
        public BtsCatalogExplorer()
        {
            // creating the actual BtsCatalogExplorer Object
            Assembly assembly = Assembly.Load(BTSASSEMBLYNAME);
            Type btsCatalogExplorerType = assembly.GetType("Microsoft.BizTalk.ExplorerOM.BtsCatalogExplorer");
            this.actualBtsObject = Activator.CreateInstance(btsCatalogExplorerType);
            this.btsCatalogExplorer = this;
            this.biztalkOMAssembly = assembly;
        }

        #region BizTalk Properties

        /// <summary>
        /// Gets the BizTalk assemblies deployed in the Partner Management database.
        /// </summary>
        public BtsAssemblyCollection Assemblies
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("Assemblies", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsAssemblyCollection assemblycollection = new BtsAssemblyCollection();

                    foreach (object item in ((IEnumerable)actualCollection))
                    {
                        BtsAssembly assembly = new BtsAssembly(item, this);
                        assemblycollection.Add(assembly);
                    }
                    return assemblycollection;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Gets the certificates installed in the AddressBook store of the local computer.
        /// </summary>
        public BtsCertificateInfoCollection Certificates
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("Certificates", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsCertificateInfoCollection certificates = new BtsCertificateInfoCollection();

                    foreach (object item in ((IEnumerable)actualCollection))
                    {
                        BtsCertificateInfo certificate = new BtsCertificateInfo(item, this);
                        certificates.Add(certificate);
                    }
                    return certificates;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Gets or sets the string used to open the Partner Management database.
        /// </summary>
        public string ConnectionString
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("ConnectionString", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("ConnectionString", BindingFlags.SetProperty, null, this.actualBtsObject, new string[] { value });
            }
        }

        /// <summary>
        /// Gets the Admin Group name.
        /// </summary>
        public string GroupName
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("GroupName", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>
        /// Gets the collection of hosts contained in the database.
        /// </summary>
        /// <value></value>
        public BtsHostCollection Hosts
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("Hosts", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsHostCollection hosts = new BtsHostCollection();

                    foreach (object item in ((IEnumerable)actualCollection))
                    {
                        BtsHost host = new BtsHost(item, this);
                        hosts.Add(host);
                    }
                    return hosts;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Gets the collection of parties contained in the database.
        /// </summary>
        public BtsPartyCollection Parties
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("Parties", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsPartyCollection parties = new BtsPartyCollection();

                    foreach (object item in ((IEnumerable)actualCollection))
                    {
                        BtsParty party = new BtsParty(item, this);
                        parties.Add(party);
                    }
                    return parties;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Gets the collection of pipelines contained in the database.
        /// </summary>
        public BtsPipelineCollection Pipelines
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("Pipelines", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsPipelineCollection pipelines = new BtsPipelineCollection();

                    foreach (object item in ((IEnumerable)actualCollection))
                    {
                        BtsPipeline pipeline = new BtsPipeline(item, this);
                        pipelines.Add(pipeline);
                    }
                    return pipelines;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Gets the collection of adapter types contained in the database.
        /// </summary>
        public BtsProtocolTypeCollection ProtocolTypes
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("ProtocolTypes", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsProtocolTypeCollection protocolTypes = new BtsProtocolTypeCollection();

                    foreach (object item in ((IEnumerable)actualCollection))
                    {
                        BtsProtocolType protocolType = new BtsProtocolType(item, this);
                        protocolTypes.Add(protocolType);
                    }
                    return protocolTypes;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Gets the collection of receive handlers contained in the database.
        /// </summary>
        public BtsReceiveHandlerCollection ReceiveHandlers
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("ReceiveHandlers", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsReceiveHandlerCollection receiveHandlers = new BtsReceiveHandlerCollection();

                    foreach (object item in ((IEnumerable)actualCollection))
                    {
                        BtsReceiveHandler receiveHandler = new BtsReceiveHandler(item, this);
                        receiveHandlers.Add(receiveHandler);
                    }
                    return receiveHandlers;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Gets the collection of receive ports contained in the database.
        /// </summary>
        /// <value></value>
        public BtsReceivePortCollection ReceivePorts
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("ReceivePorts", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsReceivePortCollection receivePorts = new BtsReceivePortCollection();

                    foreach (object item in ((IEnumerable)actualCollection))
                    {
                        BtsReceivePort port = new BtsReceivePort(item, this);
                        receivePorts.Add(port);
                    }
                    return receivePorts;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Gets the collection of schemas contained in the database.
        /// </summary>
        /// <value></value>
        public BtsSchemaCollection Schemas
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("Schemas", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsSchemaCollection schemas = new BtsSchemaCollection();

                    foreach (object item in ((IEnumerable)actualCollection))
                    {
                        BtsSchema schema = new BtsSchema(item, this);
                        schemas.Add(schema);
                    }
                    return schemas;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Gets the collection of send port groups contained in the database.
        /// </summary>
        /// <value></value>
        public BtsSendPortGroupCollection SendPortGroups
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("SendPortGroups", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsSendPortGroupCollection sendPortGroups = new BtsSendPortGroupCollection();

                    foreach (object item in ((IEnumerable)actualCollection))
                    {
                        BtsSendPortGroup sendPortGroup = new BtsSendPortGroup(item, this);
                        sendPortGroups.Add(sendPortGroup);
                    }
                    return sendPortGroups;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Gets the collection of send ports contained in the database.
        /// </summary>
        /// <value></value>
        public BtsSendPortCollection SendPorts
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("SendPorts", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsSendPortCollection sendports = new BtsSendPortCollection();

                    foreach (object item in ((IEnumerable)actualCollection))
                    {
                        BtsSendPort sendPort = new BtsSendPort(item, this);
                        sendports.Add(sendPort);
                    }
                    return sendports;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Gets the collection of standard aliases that can be used for a party.
        /// </summary>
        /// <value></value>
        public ICollection StandardAliases
        {
            get
            {
                return (ICollection)this.actualBtsObject.GetType().InvokeMember("StandardAliases", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>
        /// Gets the collection of transforms contained in the database.
        /// </summary>
        /// <value></value>
        public BtsTransformCollection Transforms
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("Transforms", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsTransformCollection transforms = new BtsTransformCollection();

                    foreach (object item in ((IEnumerable)actualCollection))
                    {
                        BtsTransform transform = new BtsTransform(item, this);
                        transforms.Add(transform);
                    }
                    return transforms;
                }
                else
                {
                    return null;
                }
            }
        }

        #endregion

        /// <summary>
        /// The BizTalk 2004 Explorer OM Assembly
        /// </summary>
        /// <value></value>
        internal Assembly BizTalkExplorerOMAssembly
        {
            get { return this.biztalkOMAssembly; }
        }

        /// <summary>
        /// Commits all BtsCatalogExplorer object changes to the database.
        /// </summary>
        public void SaveChanges()
        {
            this.actualBtsObject.GetType().InvokeMember("SaveChanges", BindingFlags.InvokeMethod, null, this.actualBtsObject, null);
        }

        /// <summary>
        /// Rejects all BtsCatalogExplorer object changes to the database.
        /// </summary>
        public void DiscardChanges()
        {
            this.actualBtsObject.GetType().InvokeMember("DiscardChanges", BindingFlags.InvokeMethod, null, this.actualBtsObject, null);
        }

        /// <summary>
        /// Creates and adds a party object to the party collection.
        /// </summary>
        /// <returns>BtsParty</returns>
        public BtsParty AddNewParty()
        {
            object actualParty = this.actualBtsObject.GetType().InvokeMember("AddNewParty", BindingFlags.InvokeMethod, null, this.actualBtsObject, null);
            return new BtsParty(actualParty, this);
        }

        /// <summary>
        /// Removes a party from the party collection.
        /// </summary>
        /// <param name="party">BtsParty</param>
        public void RemoveParty(BtsParty party)
        {
            this.actualBtsObject.GetType().InvokeMember("RemoveParty", BindingFlags.InvokeMethod, null, this.actualBtsObject, new object[] { party.actualBtsObject });
        }

        /// <summary>
        /// Gets the collection of a particular type.
        /// </summary>
        /// <param name="collectionType">A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.CollectionType"/> enum.</param>
        /// <returns>An <see cref="System.Collections.ICollection"/> object. </returns>
        public ICollection GetCollection(CollectionType collectionType)
        {
            Type actualEnumCollectionType = this.biztalkOMAssembly.GetType("Microsoft.BizTalk.ExplorerOM.CollectionType");
            object actualValue = Enum.Parse(actualEnumCollectionType, collectionType.ToString());

            return (ICollection)this.actualBtsObject.GetType().InvokeMember("GetCollection", BindingFlags.InvokeMethod, null, this.actualBtsObject, new object[] { actualValue });
        }

        /// <summary>
        /// Creates and adds a receive port to the receive port collection.
        /// </summary>
        /// <param name="twoWay"><b>true</b> to create a two-way receive port; <b>false</b> to create a one-way receive port.</param>
        /// <returns> a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BtsReceivePort"/> object.</returns>
        public BtsReceivePort AddNewReceivePort(bool twoWay)
        {
            object actualReceivePort = this.actualBtsObject.GetType().InvokeMember("AddNewReceivePort", BindingFlags.InvokeMethod, null, this.actualBtsObject, new object[] { twoWay });
            return new BtsReceivePort(actualReceivePort, this);
        }

        /// <summary>
        /// Removes the specified receive port from the receive port collection.
        /// </summary>
        /// <param name="receivePort">BtsReceivePort</param>
        public void RemoveReceivePort(BtsReceivePort receivePort)
        {
            this.actualBtsObject.GetType().InvokeMember("RemoveReceivePort", BindingFlags.InvokeMethod, null, this.actualBtsObject, new object[] { receivePort.actualBtsObject });
        }

        /// <summary>
        /// Creates and adds a send port to the send port collection.
        /// </summary>
        /// <param name="dynamicPort"><b>true</b> if the send port is dynamic <b>false</b> to create a static send port. </param>
        /// <param name="twoWay"><b>true</b> if the send port is two-way; <b>false</b> to create a one-way send port. </param>
        /// <returns>BtsSendPort</returns>
        public BtsSendPort AddNewSendPort(bool dynamicPort, bool twoWay)
        {
            object actualSendPort = this.actualBtsObject.GetType().InvokeMember("AddNewSendPort", BindingFlags.InvokeMethod, null, this.actualBtsObject, new object[] { dynamicPort, twoWay });
            return new BtsSendPort(actualSendPort, this);
        }

        /// <summary>
        /// Removes the specified send port from the send port collection.
        /// </summary>
        /// <param name="sendPort">BtsSendPort</param>        
        public void RemoveSendPort(BtsSendPort sendPort)
        {
            this.actualBtsObject.GetType().InvokeMember("RemoveSendPort", BindingFlags.InvokeMethod, null, this.actualBtsObject, new object[] { sendPort.actualBtsObject });
        }

        /// <summary>
        /// ates and adds a send port group to the send port group collection.
        /// </summary>
        /// <returns>BtsSendPortGroup</returns>
        public BtsSendPortGroup AddNewSendPortGroup()
        {
            object actualSendPortGroup = this.actualBtsObject.GetType().InvokeMember("AddNewSendPort", BindingFlags.InvokeMethod, null, this.actualBtsObject, null);
            return new BtsSendPortGroup(actualSendPortGroup, this);
        }

        /// <summary>
        /// Removes the specified send port group from the send port group collection.
        /// </summary>
        /// <param name="sendPortGroup">BtsSendPortGroup</param>
        public void RemoveSendPortGroup(BtsSendPortGroup sendPortGroup)
        {
            this.actualBtsObject.GetType().InvokeMember("RemoveSendPortGroup", BindingFlags.InvokeMethod, null, this.actualBtsObject, new object[] { sendPortGroup.actualBtsObject });
        }

        /// <summary>
        /// Refreshes the cache.
        /// </summary>
        public void Refresh()
        {
            this.actualBtsObject.GetType().InvokeMember("Refresh", BindingFlags.InvokeMethod, null, this.actualBtsObject, null);
        }
    }
}