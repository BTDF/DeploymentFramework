/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Mark Phillips</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.Web 
{
    using System;
    using System.DirectoryServices;
    using System.Security.Principal;
    using System.Collections;
    using System.Net;
    using System.Runtime.InteropServices;
    using System.Globalization;

    /// <summary>
    /// Summary description for FtpSite.
    /// </summary>
    internal class FtpSite 
    {
        const int DEFAULT_PORT = 21;
        const IPAddress DEFAULT_IPADDRESS = null;
        
        int                            port;
        int                            identifier;
        System.Net.IPAddress           ipAddress;
        string                         hostName;
        string                         path;
        string                         description;
        string                         machineName = "localhost";
        FtpVirtualDirectory            root;
        DirectoryEntry                 directoryEntry;
        FtpVirtualDirectoryCollection  virtualDirectories;
        AccessFlags                    accessFlags;
        bool                           allowAnonymous = true;
        string                         anonymousUserName;
        string                         anonymousUserPass;
        int userIsolationMode = 0;

        public FtpSite(string description, string path, IPAddress ipAddress, int port, string hostName, int identifier) 
        {
            this.description = description;
            this.path = path;
            this.ipAddress = ipAddress;
            this.port = port;
            this.hostName = hostName;
            this.identifier = identifier;
        }

        public FtpSite(string description, string path): this(description, path, DEFAULT_IPADDRESS, DEFAULT_PORT, String.Empty, 0) 
        {
        }

        public FtpSite() 
        {
            
        }
        private FtpSite(DirectoryEntry ftpsite) 
        {
            try 
            {
                Initialize(ftpsite);                
            } 
            catch (Exception e) 
            {
                throw new ApplicationException("Could not load ftpsite from given DirectoryEntry", e);
            }
        }

        public void Start() 
        {
            directoryEntry.Invoke("Start", null);
        }
        public void Stop() 
        {
            directoryEntry.Invoke("Stop", null);
        }
        public void Pause() 
        {
            directoryEntry.Invoke("Pause", null);
        }
        public void Continue() 
        {
            directoryEntry.Invoke("Continue", null);
        }

        

        public void AddBinding (string ipAddress, string port)
        {
            AddBinding(ipAddress,port,null);
        }
        
        public void AddBinding( string ipAddress, string port,string hostName )
        {
            if( ipAddress != String.Empty )
            {
                try
                {
                    IPAddress ip = System.Net.IPAddress.Parse( ipAddress );
                }
                catch( FormatException )
                {
                    throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Specified IP '{0}' cannot be parsed, it is not a valid IP address", ipAddress));
                }
            }

            string newBinding = ipAddress + ":" + port + ":";

            if(hostName != null)
            {
                newBinding += hostName;
            }

            directoryEntry.Properties["ServerBindings"].Add( newBinding );
        }
        
        void Initialize(DirectoryEntry de) 
        {
            directoryEntry = de;
            identifier = Convert.ToInt32(de.Name);
            description = Convert.ToString(de.Properties["ServerComment"][0]);
            
            machineName = de.Path.Substring(6).Split('/')[0];

            accessFlags = (AccessFlags)de.Properties["AccessFlags"][0];
            allowAnonymous = Convert.ToBoolean(de.Properties["AllowAnonymous"][0]);
            anonymousUserName = Convert.ToString(de.Properties["AnonymousUserName"][0]);
            anonymousUserPass = Convert.ToString(de.Properties["AnonymousUserPass"][0]);

            string bindings  = Convert.ToString(de.Properties["ServerBindings"][0]);

            string[] bindingsSplit = bindings.Split(':');
            //IP:Port:Hostname
            if (bindingsSplit[0].Length != 0) 
            {
                ipAddress = System.Net.IPAddress.Parse(bindingsSplit[0]);
            }
            if (bindingsSplit[1].Length != 0) 
            {
                port = Convert.ToInt32(bindingsSplit[1]);
            }
            hostName = bindingsSplit[2];
            if (root == null) 
            {
                DirectoryEntry rootDE = new DirectoryEntry(de.Path + "/ROOT"); 
                root = new FtpVirtualDirectory(rootDE, this);
            }
            if (virtualDirectories == null) 
            {
                // Load all the ftps
                DirectoryEntry rootDE = new DirectoryEntry(de.Path + "/ROOT"); 
                foreach(DirectoryEntry vdir in rootDE.Children) 
                {

                    if (vdir.SchemaClassName == "IIsFtpVirtualDir") 
                    {
                        VirtualDirectories.Add(new FtpVirtualDirectory(vdir, this));
                    }
                }
            }
        }

        static public void Delete(string description, string machineName) 
        {
            int identifier = GetIdentifierFromDescription(machineName, description);
            Delete(identifier, machineName);
        }           
        
        static public void Delete(string description) 
        {
            Delete(description, "localhost");       
        }

        static public void Delete(int identifier, string machineName) 
        {
            DirectoryEntry ftp = new DirectoryEntry("IIS://" + machineName + "/MSFTPSVC"); 
            
            if (ftp == null) 
            {
                throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to load ftpsite {0} when trying to delete it", identifier));
            } 
            else 
            {
                object[] args = {"IIsFtpServer", identifier};
                ftp.Invoke("Delete", args);
                ftp.Dispose();
            }           
        }

        static public void Delete(int identifier) 
        {
            Delete(identifier, "localhost");        
        }       

        static public int GetIdentifierFromDescription(string description) 
        {
            return GetIdentifierFromDescription("localhost", description);
        }

        static public int GetIdentifierFromDescription(string machineName, string description) 
        {

            //load the MSFTPSVC and check all the children for a property that matches

            DirectoryEntry de = null;
            de = new DirectoryEntry("IIS://" + machineName + "/MSFTPSVC");
                    
            foreach(DirectoryEntry o in de.Children) 
            {
                if (o.SchemaClassName == "IIsFtpServer") 
                {
                    if ((string)o.Properties["ServerComment"][0] == description) 
                    {
                        return Convert.ToInt32(o.Name);
                    }
                }
            }
            return 0;
        }

        static public FtpSite Load(string machineName, int identifier) 
        {

            DirectoryEntry ftp = new DirectoryEntry("IIS://" + machineName + "/MSFTPSVC/" + Convert.ToString(identifier)); 
                        
            if (ftp != null) 
            {
                return new FtpSite(ftp);
            } 
            else 
            {
                return null;
            }           
        }

        static public FtpSite Load(int identifier) 
        {
            return Load("localhost", identifier);
        }

        static public FtpSite Load(string machineName, string description) 
        {

            //load the MSFTPSVC and check all the children for a property that matches

            int identifier = GetIdentifierFromDescription(machineName, description);

            if (identifier == 0) 
            {
                throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to load ftpsite {0}", description));
            }

            DirectoryEntry o = new DirectoryEntry("IIS://" + machineName + "/MSFTPSVC/" + Convert.ToString(identifier));
            return new FtpSite(o);
        }

        static public FtpSite Load(string description) 
        {
            return Load("localhost", description);
        }

        void CreateNewSite() 
        {
            DirectoryEntry de = null;
            DirectoryEntry de2 = null;

            // Save the current account info as we need to create the site and read it first before we can set the data.
            bool allowAnonymousCopy = allowAnonymous;
            string anonymousUserNameCopy = anonymousUserName;
            string anonymousUserPassCopy = anonymousUserPass;

            if (Description.Length == 0 || Path.Length == 0) 
            {
                throw new ApplicationException("You must provide a description and a path before saving a FtpSite.");
            }
            try 
            {
                de = new DirectoryEntry("IIS://" + machineName + "/MSFTPSVC");
                string binding = String.Empty;
                if (ipAddress != null) 
                {
                    binding = IPAddress.ToString();
                }
            
                binding += ":" + Port.ToString() + ":" + HostName;

                DirectoryEntry oServer = null;
                
                bool bDone = false;
                int nIndex;
                if (identifier == 0) 
                {
                    nIndex = 1;
                } 
                else 
                {
                    nIndex = identifier;
                }
                while (!bDone) 
                {
                    DirectoryEntry oSite = new DirectoryEntry("IIS://" + machineName + "/MSFTPSVC/"+ nIndex);

                    try 
                    {
                        object oTemp = oSite.NativeObject;
                        nIndex++;
                        
                    }
                    catch (COMException) 
                    {
                        object[] args = new object[2];
                        args[0] = (object)"IIsFtpServer";
                        args[1] = (object)nIndex;
                        try 
                        {     
                            oServer = (DirectoryEntry)de.Invoke("Create", args);
                            oServer.CommitChanges(); 
                            DirectoryEntry oSite2 = new DirectoryEntry("IIS://" + machineName + "/MSFTPSVC/"+ nIndex);
                            try 
                            {
                                object oTemp = oSite.NativeObject;
                                bDone = true;
                                break;
                            }
                            catch 
                            {
                                nIndex++;
                            }
                        }
                        catch 
                        {
                            nIndex++; 
                        }
                    }                    
                    
                    if (nIndex >1000) 
                    {
                        throw new ApplicationException("Unable to create new ftpsite");
                    }
    
                }
                DirectoryEntry oRootDir = (DirectoryEntry)oServer.Invoke("Create","IIsFtpVirtualDir", "ROOT");
                
                oRootDir.Properties["Path"][0] = Path;

                oRootDir.CommitChanges();

                oRootDir.Properties["AccessFlags"][0] = accessFlags;
                oRootDir.CommitChanges();    

                de2 = new DirectoryEntry("IIS://" + machineName + "/MSFTPSVC/" + nIndex); 

                de2.Properties["ServerComment"][0] = Description;

                allowAnonymous = allowAnonymousCopy;
                anonymousUserName = anonymousUserNameCopy;
                anonymousUserPass = anonymousUserPassCopy;

                if (anonymousUserName != String.Empty && anonymousUserName != null && anonymousUserName.Length > 0)
                {
                    de2.Properties["AnonymousUserName"][0] = anonymousUserName;
                }

                if (anonymousUserPass != String.Empty && anonymousUserPass != null && anonymousUserPass.Length > 0)
                {
                    de2.Properties["AnonymousUserPass"][0] = anonymousUserPass;
                }

                de2.Properties["AllowAnonymous"][0] = (allowAnonymous == true ? "TRUE" : "FALSE");

                // This property is only for IIS6 and above
                if (de2.Properties.Contains("UserIsolationMode"))
                {
                    de2.Properties["UserIsolationMode"][0] = userIsolationMode;
                }

                ComWrapper obj = new ComWrapper(de2.NativeObject);
                obj.CallMethod("Put", new Object[] {"ServerBindings", binding});
                de2.CommitChanges();
                Initialize(de2);

            }

            catch(COMException) 
            {
            }

            catch(Exception e) 
            {
                throw new ApplicationException("Unable to create new ftpsite", e);
            }
        
            finally 
            {
                de.Dispose();
                
            }           
        }       

        static public bool Exists(string machineName, int identifier) 
        {
            try 
            {
                if (DirectoryEntry.Exists("IIS://" + machineName + "/MSFTPSVC/" + identifier)) 
                {
                    return true;
                }
            }
            catch 
            {
                return false;
            }
            return false;
        }

        static public bool Exists(int identifier) 
        {
            return Exists("localhost", identifier);         
        }

        static public bool Exists(string description) 
        {
            return Exists("localhost", description);
        }

        static public bool Exists(string machineName, string description) 
        {
            int identifier = GetIdentifierFromDescription(machineName, description);
            return Exists(machineName, identifier);
        }

        public bool Save() 
        {            
            // if we don't have a directory entry
            // and if the identifier is zero
            // then try and create a new site
            // otherwise if no dir entry but identifier is set check to see if the site exists
            // if it does throw an exception (as you should have called load)
            // otherwise try to create it with the identifier provided
            if (directoryEntry == null) 
            {               
                if (identifier == 0) 
                {
                    //we don't have an identifier so try and create it
                    CreateNewSite();                        
                } 
                else 
                {
                    if (Exists(machineName, identifier)) 
                    {
                        throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "The FtpSite '{0}' already exists. Use FtpSite.Load to load it first", identifier));
                    } 
                    else 
                    {
                        //couldn't load the site with that identifier so try and create it now
                        CreateNewSite();
                    }
                }               
            }

            directoryEntry.CommitChanges();             
                
            // Now save the root ftpsite
            root.Parent = this;
            root.Save();

            foreach(FtpVirtualDirectory vdir in VirtualDirectories) 
            {
                vdir.Parent = this;
                vdir.Save();
            }
            return true;            
        }

        public int Port 
        {
            get 
            {
                return port;
            }
            set 
            {
                port = value;
            }
        }

        public System.Net.IPAddress IPAddress 
        {
            get 
            {
                return ipAddress;
            }
            set 
            {
                ipAddress = value;
            }
        }

        public string HostName 
        {
            get 
            {
                return (hostName == null ? String.Empty : hostName);
            }
            set 
            {
                hostName = value;
            }
        }

        public string Path 
        {
            get 
            {
                return (path == null ? String.Empty : path);
            }
            set 
            {
                path = value;
            }
        }

        public string Description 
        {
            get 
            {
                return (description == null ? String.Empty : description);
            }
            set 
            {
                description = value;
            }
        }

        public int Identifier 
        {
            get 
            {
                return identifier ;
            }
            set 
            {
                identifier = value;
            }
        }

        public FtpVirtualDirectory Root 
        {
            get 
            {
                if (root == null) 
                {
                    root = new FtpVirtualDirectory("ROOT", this);
                }
                return root ;
            }           
        }

        public FtpVirtualDirectoryCollection VirtualDirectories 
        {
            get 
            {
                if (virtualDirectories == null) 
                {
                    virtualDirectories = new FtpVirtualDirectoryCollection(this);

                }
                return virtualDirectories ;
            }
            /*
            made readonly for FxCop
            set {
                virtualDirectories = value;
            }
            */
        }

        public AccessFlags RootAccessFlags 
        {
            get 
            {
                return accessFlags ;
            }
            set 
            {
                accessFlags = value;
            }
        }   

        public bool AllowAnonymous
        {
            get
            {
                return allowAnonymous;
            }
            set
            {
                allowAnonymous = value;
            }
        }

        public int UserIsolationMode
        {
            get
            {
                return userIsolationMode;
            }
            set
            {
                if ((userIsolationMode >= 0) || (userIsolationMode <= 2))
                {
                    userIsolationMode = value;
                }
            }
        }

        public string AnonymousUserName
        {
            get
            {
                return (anonymousUserName == null ? String.Empty : anonymousUserName);
            }
            set
            {
                anonymousUserName = value;
            }
        }

        public string AnonymousUserPass
        {
            get
            {
                return (anonymousUserPass == null ? String.Empty : anonymousUserPass);
            }
            set
            {
                anonymousUserPass = value;
            }
        }

        internal DirectoryEntry GetDirectoryEntry() 
        {
            return directoryEntry ;
        }
    }
}
