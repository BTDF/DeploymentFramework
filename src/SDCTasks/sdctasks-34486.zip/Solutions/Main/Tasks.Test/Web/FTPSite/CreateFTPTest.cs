//-----------------------------------------------------------------------
// <copyright file="CreateFTPTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Ashter Chomoko</author>
// <email>ashter_chomoko@charteris.com</email>
// <date>2004-05-26</date>
// <summary>Unit test for the CreateFTP Task.</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the CreateFTPTest Task
    /// </summary>
    [TestClass]
    public class CreateFtpTest
    { 
        public CreateFtpTest()
        {
        }

        [TestMethod]
        public void TestErrorCondition()
        {
            Microsoft.Sdc.Tasks.Web.FtpSite.Create task = new Microsoft.Sdc.Tasks.Web.FtpSite.Create();
           
            Guid guid = Guid.NewGuid();
            string guidString = guid.ToString();

            // Deliberately bad path
            string path = "XX:\\";
            string description = guidString;

            task.Path = path;
            task.Description = description;
            try
            {
                bool taskReturnValue = task.Execute();
                Assert.Fail("Should not have returned true when creating this FTP site.");
            }
            catch (ApplicationException)
            {
                string lastMessage = ((PseudoBuildEngine)task.BuildEngine).PreviousMessage;

                //string lastMessage = e.Message;

                // Make sure the error message matches what was expected
                bool foundInMessage1 = (lastMessage.IndexOf("The given path's format is not supported.") >= 0);
                bool foundInMessage2 = (lastMessage.IndexOf("The system cannot find the path specified.") >= 0);

                Assert.IsTrue(foundInMessage1 | foundInMessage2, "CreateFTPError did not return 1 of the messages expected");
                Console.WriteLine("Correctly threw ApplicationException on attempting to create a ftp site with a bad path.");
            }
        }

        [Ignore]//("Throwing some weird error on Beta2")]
        [TestMethod]
        public void TestCreateFtp()
        {
            Microsoft.Sdc.Tasks.Web.FtpSite.Create task = new Microsoft.Sdc.Tasks.Web.FtpSite.Create();
           
            Guid guid = Guid.NewGuid();
            string guidString = guid.ToString();
            string path = System.Environment.ExpandEnvironmentVariables(@"%TEMP%\" + guidString + @"\");
            
            task.Path = path;
            task.Description = guidString;
            try
            {
                bool exists = Microsoft.Sdc.Tasks.Configuration.Web.FtpSite.Exists(guidString);
                Assert.IsFalse(exists, "FTP does not Exists");
                bool taskReturnValue = task.Execute();
                Assert.IsTrue(taskReturnValue, "task.Execute() returns true");
            }
            catch (ApplicationException e)
            {
                string lastMessage = ((PseudoBuildEngine) task.BuildEngine).PreviousMessage;
                if (lastMessage.IndexOf("The system cannot find the path specified") >= 0)
                {
                    Console.WriteLine("FTP server may not be installed on test server");
                }
                throw e;
            }

            Assert.IsTrue(Microsoft.Sdc.Tasks.Configuration.Web.FtpSite.Exists(guidString), "FTP Exists");

            //Delete FTP Site
            Microsoft.Sdc.Tasks.Web.FtpSite.DeleteFtpSite taskDelete = new Microsoft.Sdc.Tasks.Web.FtpSite.DeleteFtpSite();
            taskDelete.Description = guidString;
            bool taskReturnValue2 = taskDelete.Execute();

            Assert.IsTrue(taskReturnValue2, "Delete task returns true");

            //Microsoft.Sdc.Tasks.Configuration.Web.FtpSite.Delete(guidString);

            Assert.IsFalse(Microsoft.Sdc.Tasks.Configuration.Web.FtpSite.Exists(guidString), "FTP site does not exist");

        }

    }
}
