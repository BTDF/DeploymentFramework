/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.Web {
    using System;
    using System.DirectoryServices;
    using System.ComponentModel;
    using System.Text;
    using System.Collections;

    /// <summary>
    /// Summary description for Health.
    /// </summary>
    internal class Health {

        private bool pingEnabled = true;
        private int  pingInterval = 30;
        private bool rapidFailProtectionEnabled = true;
        private int  rapidFailProtectionMaximumFailures = 5;
        private int  rapidFailProtectionInterval = 5;
        private int  startupTimeLimit = 90;
        private int  shutdownTimeLimit = 90;

        internal Health() {
        }

        public bool PingEnabled {
            get {
                return pingEnabled ;
            }
            set {
                pingEnabled = value;
            }
        }

        public int PingInterval {
            get {
                return pingInterval ;
            }
            set {
                pingInterval = value;
            }
        }

        public int RapidFailProtectionInterval {
            get {
                return rapidFailProtectionInterval ;
            }
            set {
                rapidFailProtectionInterval = value;
            }
        }

        public int StartupTimeLimit {
            get {
                return startupTimeLimit ;
            }
            set {
                startupTimeLimit = value;
            }
        }

        public int ShutdownTimeLimit {
            get {
                return shutdownTimeLimit ;
            }
            set {
                shutdownTimeLimit = value;
            }
        }

        public bool RapidFailProtectionEnabled {
            get {
                return rapidFailProtectionEnabled ;
            }
            set {
                rapidFailProtectionEnabled = value;
            }
        }

        public int RapidFailProtectionMaximumFailures {
            get {
                return rapidFailProtectionMaximumFailures ;
            }
            set {
                rapidFailProtectionMaximumFailures = value;
            }
        }
    }   
}
