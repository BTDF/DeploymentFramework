//-------------------------------------------------------------------------------------
// <copyright file="Exists.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//     Checks if a Host Exists in Biztalk.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Host
{
    #region Using directives

    using System;
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion


    #region Class Comments
    /// <summary>
    /// Checks whether a Host exists in a BizTalk installation.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2004.Host.Exists DisplayName="displayName" Server="server" Database="database" />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>displayName (Required)</i></para>
    /// <para>
    /// The display name of the assembly to check for.
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// <para><i>username</i></para>
    /// <para>
    /// The username to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// <para><i>password</i></para>
    /// <para>
    /// The password to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <PropertyGroup>
    ///         <BTSAppHostExists />
    ///     </PropertyGroup>
    ///     <Target Name="Test" >
    ///            <BizTalk2004.Host.Exists 
    ///                DisplayName="BizTalkServerApplication">
    ///                <Output TaskParameter="HostExists" PropertyName="BTSAppHostExists" />
    ///            </BizTalk2004.Host.Exists>
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
        #endregion
    public class Exists : BizTalk2004TaskBase
    {
        #region Member Variables

        private string displayName;
        private bool hostExists;

        #endregion

        #region Constructors 

        /// <summary>
        /// Creates a new instance of the exists task.
        /// </summary>
        public Exists()
        {
        }

        #endregion 

        #region Properties

        /// <summary>
        /// Gets or sets the display name of the Host.
        /// </summary>
        /// <value>
        /// The display name of the Host.
        /// </value>
        [Required]
        public string DisplayName
        {
            get
            {
                return this.displayName;
            }
            set
            {
                this.displayName = value;
            }
        }

        /// <summary>
        /// Gets whether the Host does exist in the deployment.
        /// </summary>
        /// <value>
        /// <b>true</b> if the Host does exist, or <b>false</b> otherwise.
        /// </value>
        [Output]
        public bool HostExists
        {
            get
            {
                return this.hostExists;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {
            BizTalkInstallation installation = this.GetInstallation();
            this.hostExists = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Host.Exists(installation, this.displayName);
        }
        #endregion

    }
}
            
