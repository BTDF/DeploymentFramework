//-----------------------------------------------------------------------
// <copyright file="DevEnvTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-06-04</date>
// <summary>Unit test for the DevEnv Tools Tasks.</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the DevEnv Test Task
    /// </summary>
    [TestClass]
    public class DevEnvTest
    { 
        public DevEnvTest()
        {
        }

        [TestMethod]
        [Ignore]//("Remove hard coded paths")]
        public void TestSuccess()
        {
            Tools.DevEnv devEnvTask = new Tools.DevEnv();
            
            string visualStudio = "7.1";
            string solutionName = "NDocUnitTestAssembly.sln";
            string solutionPath = @"C:\Projects\TaskUnitTest\NDocUnitTestAssembly\";
            string path = solutionPath + solutionName;
            string config = "Release";
            string outputFolder = TaskTestUtilities.CreateTempFolder();
            bool clean = true;

            try
            {
                devEnvTask.VisualStudio = visualStudio;
                devEnvTask.Path = path;
                devEnvTask.Config = config;
                devEnvTask.OutputFolder = outputFolder;
                devEnvTask.Clean = clean;

                DateTime buildStartTime = DateTime.Now;

                bool devEnvSuccess = devEnvTask.Execute();
                Assert.IsTrue(devEnvSuccess);

                //Test the properties of the task
                Assert.IsTrue(devEnvTask.VisualStudio == visualStudio, "DevEnv build task properties");
                Assert.IsTrue(devEnvTask.Path == path, "DevEnv build task properties");
                Assert.IsTrue(devEnvTask.Config == config, "DevEnv build task properties");
                Assert.IsTrue(devEnvTask.OutputFolder == outputFolder, "DevEnv build task properties");
                Assert.IsTrue(devEnvTask.Clean == clean, "DevEnv build task properties");

                //Ensure that we got a build report
                string buildReport = solutionName + "." + config + ".txt";
                if (!(System.IO.File.Exists(outputFolder + "\\" + buildReport)))
                {
                    Assert.Fail("Failed to find build report at: " + outputFolder + "\\" + buildReport);
                }

                string generatedAssemblyFolder = solutionPath + "NDocUnitTestAssembly\\bin\\" + config;

                //We should have a dll in here more recent than buildStartTime
                DateTime buildEndTime = System.IO.File.GetLastWriteTime(generatedAssemblyFolder);

                Assert.IsTrue(buildEndTime.CompareTo(buildStartTime) > 0, "AssembliesBuilt");

            }
            finally
            {
                Directory.Delete(outputFolder, true);
            }

        }
    }
}