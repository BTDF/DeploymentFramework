//-----------------------------------------------------------------------
// <Deleteright file="ReceiveHandlerTests.cs" company="Microsoft">
// Deleteright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </Deleteright>
// <author>Thomas Manson</author>
// <email>tmanson</email>
// <date>2006-02-16</date>
// <summary>Tests BizTalk 2004 Receive Handler tasks</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test.BizTalk2006
{
    using System;
    using System.Text;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Sdc.Tasks.BizTalk2006;
    using System.Management;

    /// <summary>
    /// Tests the BizTalk 2006 assembly tasks
    /// </summary>
    [TestClass]
    public class SendPortTests
    {
        private const string AppName = "Send Port Test App";
        const string hostName = "TestHost";

        public SendPortTests()
        {
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext)
        {
            Microsoft.Sdc.Tasks.BizTalk2006.Application.Create createTask = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Create();
            createTask.Application = AppName;
            createTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2004.Host.Create createHost = new Microsoft.Sdc.Tasks.BizTalk2004.Host.Create();
            createHost.GroupName = "BizTalk Application Users";
            createHost.HostType = "InProcess";
            createHost.HostServerName = Environment.MachineName;
            createHost.HostUsername = @"bts2006rc0\BTSService";
            createHost.HostPassword = "password";
            createHost.Name = hostName;
            createHost.Execute();

            const string transportType = "FILE";
            Microsoft.Sdc.Tasks.BizTalk2006.SendHandler.Create createSTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendHandler.Create();
            createSTask.HostName = hostName;
            createSTask.TransportType = transportType;
            createSTask.Execute();


        }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        [ClassCleanup()]
        public static void MyClassCleanup()
        {
            Microsoft.Sdc.Tasks.BizTalk2006.Application.Stop stopAppTask = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Stop();
            stopAppTask.Application = AppName;
            stopAppTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.SendHandler.Delete delTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendHandler.Delete();
            delTask.HostName = hostName;
            delTask.TransportType = "FILE";
            delTask.Execute();


            Microsoft.Sdc.Tasks.BizTalk2004.Host.Delete delHost = new Microsoft.Sdc.Tasks.BizTalk2004.Host.Delete();
            delHost.Name = hostName;
            delHost.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.Application.Delete deleteTask = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Delete();
            deleteTask.Application = AppName;
            deleteTask.Execute();
        }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void TestSendPortActions()
        {
            Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Create createTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Create();
            createTask.Name = "Test Send Port";
            createTask.Application = AppName;
            createTask.IsDynamic = false;
            createTask.IsTwoWay = false;
            createTask.PrimaryTransportAddress = @"C:\temp\test.xml";
            createTask.PrimaryTransportProtocolName = "FILE";
            createTask.PrimaryTransportRetryCount = 5;
            createTask.PrimaryTransportRetryInterval = 30;
            createTask.PrimaryTransportOrderedDelivery = false;
            createTask.PrimaryTransportTransportData = @"<CustomProps><BatchSize vt='19'>20</BatchSize><FileMask vt='8'>*.xml</FileMask><FileNetFailRetryCount vt='19'>5</FileNetFailRetryCount><FileNetFailRetryInt vt='19'>5</FileNetFailRetryInt></CustomProps>";
            createTask.PrimaryTransportSendPortHandler = hostName;
            createTask.SendPipeline = "Microsoft.BizTalk.DefaultPipelines.XMLTransmit, Microsoft.BizTalk.DefaultPipelines, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35";
            createTask.SecondaryTransportAddress = @"FORMATNAME:DIRECT=OS:.\PRIVATE$\TOFACILITIESQ";
            createTask.SecondaryTransportProtocolName = "MSMQ";
            createTask.SecondaryTransportOrderedDelivery = false;
            createTask.SecondaryTransportRetryCount = 30;
            createTask.SecondaryTransportRetryInterval = 200;
            createTask.TrackingTypes = "AfterSendPipeline;BeforeSendPipeline;TrackPropertiesAfterSendPipeline;TrackPropertiesBeforeSendPipeline";
            createTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Exists existsTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Exists();
            existsTask.Application = AppName;
            existsTask.Name = "Test Send Port";
            existsTask.Execute();
            if (!existsTask.SendPortExists)
            {
                Assert.Fail("SendPort was not created");
            }

            Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Configure configureTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Configure();
            configureTask.Name = "Test Send Port";
            configureTask.Application = AppName;
            configureTask.SecondaryTransportProtocolName = null;
            configureTask.TrackingTypes = string.Empty;
            configureTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Enlist enlistTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Enlist();
            enlistTask.Application = AppName;
            enlistTask.Name = "Test Send Port";
            enlistTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Start startTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Start();
            startTask.Name = "Test Send Port";
            startTask.Application = AppName;
            startTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Stop stopTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Stop();
            stopTask.Application = AppName;
            stopTask.Name = "Test Send Port";
            stopTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.SendPort.UnEnlist unenlistTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendPort.UnEnlist();
            unenlistTask.Application = AppName;
            unenlistTask.Name = "Test Send Port";
            unenlistTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Delete deleteTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Delete();
            deleteTask.Application = AppName;
            deleteTask.Name = "Test Send Port";
            deleteTask.Execute();

            existsTask.Execute();
            if (existsTask.SendPortExists)
            {
                Assert.Fail("Send Port was not deleted");
            }

        }
    }
}
