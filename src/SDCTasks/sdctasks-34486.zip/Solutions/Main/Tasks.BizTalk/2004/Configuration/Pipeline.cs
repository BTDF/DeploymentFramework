//-------------------------------------------------------------------------------------
// <copyright file="Pipeline.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      A pipeline which performs processing on documents.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using directives

    using System;


	#endregion

	/// <summary>
	/// A pipeline which performs processing on documents.
	/// </summary>
	internal class Pipeline : BizTalkNonConfigurableEntityBase
	{
		#region Member Variables

		private BizTalkAssembly assembly;
		private string assemblyQualifiedName;
		private PipelineType type;

		#endregion

		#region Constructors

		/// <summary>
		/// Creates a new pipeline instance. This is private because instance of this class can only be created with
		/// the Load method, as you cannot add pipelines to an installation.
		/// </summary>
		/// <param name="assembly">
		/// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> that the pipeline belongs to.
		/// </param>
		/// <param name="name">
		/// The name of the pipeline.
		/// </param>
        private Pipeline(BizTalkAssembly assembly, string name)
			: base(assembly.Installation, name)
        {
        }

		#endregion

		#region Properties

		/// <summary>
		/// Gets the assembly that the pipeline belongs to.
		/// </summary>
		/// <value>
		/// A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/>.
		/// </value>
		public BizTalkAssembly Assembly
		{
			get
			{
				return this.assembly;
			}
		}

		/// <summary>
		/// Gets the assembly qualified name of the pipeline.
		/// </summary>
		/// <value>
		/// The assembly qualified name of the pipeline.
		/// </value>
		public string AssemblyQualifiedName
		{
			get
			{
				return this.assemblyQualifiedName;
			}
		}

		/// <summary>
		/// Gets the type of the pipeline.
		/// </summary>
		/// <value>
		/// One of the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.PipelineType"/> values.
		/// </value>
        public PipelineType Type
        {
            get 
			{ 
				return this.type; 
			}
        }

		#endregion

		#region Static Methods

		/// <summary>
		/// Loads the details of a pipeline.
		/// </summary>
        /// <param name="assembly">
		/// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> that the pipeline belongs to.
		/// </param>
		/// <param name="name">
		/// The name of the pipeline.
		/// </param>
		/// <returns>
		/// A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Pipeline"/>.
		/// </returns>
		public static Pipeline Load(BizTalkAssembly assembly, string name)
		{
			//check inputs
			if (assembly == null)
			{
				throw new ArgumentNullException("assembly");
			}
			if (name == null || name.Length == 0)
			{
				throw new ArgumentNullException("name");
			}

			//load the actual pipeline
			BtsPipeline actualPipeline = assembly.Installation.CatalogExplorer.Pipelines[name, assembly.Name];
			if (actualPipeline == null)
			{
				throw new ArgumentException("The pipeline does not exist.", "name");
			}

			//load the details into a new config pipeline
			Pipeline configPipeline = new Pipeline(assembly, name);
			configPipeline.assembly = assembly;
			configPipeline.assemblyQualifiedName = actualPipeline.AssemblyQualifiedName;
			configPipeline.type = (PipelineType)(int)actualPipeline.Type;

			//return the pipeline
			return configPipeline;
		}

		#endregion
	}
}

