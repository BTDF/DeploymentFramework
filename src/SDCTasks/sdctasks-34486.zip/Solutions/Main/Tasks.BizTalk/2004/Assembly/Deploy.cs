//-------------------------------------------------------------------------------------
// <copyright file="Deploy.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Deploys an assembly into BizTalk.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Assembly
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;

    #endregion

    #region Class Comments
    /// <summary>
    /// Deploys an assembly into BizTalk.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2004.Assembly.Deploy AssemblyPath="assemblyPath" InstallInGac="installInGac" BindingPath="bindingPath" LogPath="logPath" Server="server" Database="database" />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>assemblyPath (Required)</i></para>
    /// <para>
    /// The path to the assembly to deploy.
    /// </para>
    /// <para><i>installInGac</i></para>
    /// <para>
    /// <b>true</b> to install the assembly in the GAC, or <b>false</b> otherwise. The default is <b>false</b>.
    /// </para>
    /// <para><i>bindingPath</i></para>
    /// <para>
    /// The path to the XML bindings file for the assembly. The default is no binding file.
    /// </para>
    /// <para><i>logPath</i></para>
    /// <para>
    /// The path to the log file for the installation. The default is no log file.
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <BizTalk2004.Assembly.Deploy 
    ///             AssemblyPath="C:\Build\Output\MyAssembly.dll" 
    ///             InstallInGac="true"
    ///             BindingPath="C:\Build\Config\MyAssemblyBindings.xml" 
    ///             LogPath="C:\Build\Logs\MyAssemblyInstall.log" 
    ///             Server="." 
    ///             Database="BizTalkMgmtDb" 
    ///              
    ///              />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    #endregion
    public class Deploy : BizTalk2004TaskBase
    {
        #region Member Variables

        private string assemblyPath;
        private string bindingPath;
        private bool installInGac;
        private string logPath;

        #endregion

        #region Constructors

        /// <summary>
        /// Creates a new instance of the deploy task.
        /// </summary>
        public Deploy()
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the path to the assembly to deploy.
        /// </summary>
        /// <value>
        /// The path to the assembly to deploy.
        /// </value>
        [Required]
        public string AssemblyPath
        {
            get
            {
                return this.assemblyPath;
            }
            set
            {
                this.assemblyPath = value;
            }
        }

        /// <summary>
        /// Gets or sets the path to the assembly binding XML file.
        /// </summary>
        /// <value>
        /// The path to the assembly binding XML file.
        /// </value>
        public string BindingPath
        {
            get
            {
                return this.bindingPath;
            }
            set
            {
                this.bindingPath = value;
            }
        }

        /// <summary>
        /// Gets or sets whether the assembly will be installed into the Global Assembly Cache (GAC).
        /// </summary>
        /// <value>
        /// <b>true</b> to install the assembly into the GAC, or <b>false</b> otherwise. The default is
        /// <b>false</b>.
        /// </value>
        public bool InstallInGac
        {
            get
            {
                return this.installInGac;
            }
            set
            {
                this.installInGac = value;
            }
        }

        /// <summary>
        /// Gets or sets the path to the log file for the installation.
        /// </summary>
        /// <value>
        /// The path to the log file for the installation.
        /// </value>
        public string LogPath
        {
            get
            {
                return this.logPath;
            }
            set
            {
                this.logPath = value;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {
            /*
            BizTalkAssembly assembly = new BizTalkAssembly();
            if (string.IsNullOrEmpty(this.BindingPath))
            {
                assembly.Deploy(false, this.Server, this.Database, this.AssemblyPath, null, null, null);
            }
            else
            {
                assembly.DeployWithBinding(this.Server, this.Database, null, this.AssemblyPath, this.BindingPath, null, null);
            }*/
            BizTalkInstallation installation = this.GetInstallation();
            BizTalkAssembly.Deploy(installation, this.assemblyPath, this.installInGac, this.bindingPath, this.logPath);
        }

        #endregion
    }
}

