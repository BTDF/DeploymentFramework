//-----------------------------------------------------------------------
// <copyright file="AddReferences.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.Application
{
    using System.Globalization;
    using Microsoft.Sdc.Tasks.BizTalk2004;
    using Microsoft.BizTalk.ExplorerOM;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Adds a reference to an application.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2006.Application.AddReferences Application="application name" ReferenceApplications="referenced applications" Server="server" Database="database" />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>Application (Required)</i></para>
    /// <para>
    /// The name of the application that requires a reference.
    /// </para>
    /// <para><i>ReferenceApplications (Required)</i></para>
    /// <para>
    /// A list of application names to add as references.
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// <para><i>username</i></para>
    /// <para>
    /// The username to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// <para><i>password</i></para>
    /// <para>
    /// The password to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <ItemGroup>
    ///         <ApplicationsToReference Include="Application to reference">
    ///         </ApplicationsToReference>
    ///     </ItemGroup>
    ///     <Target Name="AddApplicationReference" >
    ///         <BizTalk2006.Application.AddReferences 
    ///             Application="Test Application"
    ///             ReferenceApplications="@(ApplicationsToReference)"
    ///             Server="." 
    ///             Database="BizTalkMgmtDb" />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class AddReferences : BizTalk2004TaskBase
    {
        private string application;
        private ITaskItem[] referenceApplications;

        /// <summary>
        /// Gets or sets the reference applications.
        /// </summary>
        /// <value>The reference applications.</value>
        [Required]
        public ITaskItem[] ReferenceApplications
        {
            get { return this.referenceApplications; }
            set { this.referenceApplications = value; }
        }

        /// <summary>
        /// Gets or sets the application.
        /// </summary>
        /// <value>The application.</value>
        [Required]
        public string Application
        {
            get { return this.application; }
            set { this.application = value; }
        }

        /// <summary>
        /// This is the main execute method that all tasks should implement
        /// </summary>
        /// <remarks>
        /// TaskException should be thrown in the event of errors
        /// </remarks>
        protected override void InternalExecute()
        {
            BtsCatalogExplorer explorer = this.GetBtsCatalogExplorer(this.Server, this.Database);

            Microsoft.BizTalk.ExplorerOM.Application app = explorer.Applications[this.Application];
            if (app != null)
            {
                foreach (ITaskItem item in this.ReferenceApplications)
                {
                    string refName = item.GetMetadata("ApplicationName");
                    if (string.IsNullOrEmpty(refName))
                    {
                        refName = item.GetMetadata("Identity");
                    }

                    Microsoft.BizTalk.ExplorerOM.Application refApp = explorer.Applications[refName];
                    if (refApp != null)
                    {
                        Log.LogMessage(string.Format(CultureInfo.InvariantCulture, "Adding Reference Application: {0} to Application: {1}", refName, this.Application)); 
                        app.AddReference(refApp);
                    }
                    else
                    {
                        Log.LogError(string.Format(CultureInfo.InvariantCulture, "Reference Application not found: {0}", refName));
                        return;
                    }
                }

                explorer.SaveChanges();
            }
            else
            {
                Log.LogError(string.Format(CultureInfo.InvariantCulture, "Application not found: {0}", this.Application));
                return;
            }
        }
    }
}
