//-----------------------------------------------------------------------
// <copyright file="MergeByOrder.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Vivek Adholia</author>
// <email>vadholia</email>
// <date>2005-11-30</date>
// <summary>
// Merges two itemlists together. Assumes that the two itemlists have the same number 
// of items.
// </summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks
{
    #region Using directives
    using System;
    using System.Text;
    using System.Collections;
    using System.IO;
    using Microsoft.Build.BuildEngine;
    using Microsoft.Build.Framework;
    using Microsoft.Build.Utilities;
    using Microsoft.Build.Shared;
    #endregion

    /// <summary>
    /// Takes two item lists as input and merges them together.
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<MergeByOrder ItemList1="@(list1)" ItemList2="@(list2)">
    ///                 <Output TaskParameter="MergedList" ItemName="MergedList" />
    ///                </MergeByOrder>]]></code>
    /// <para>where:</para>
    /// <para><i>list1 (Required)</i></para>
    /// <para>The first ItemList to be merged</para>
    /// <para><i>list2 (Required)</i></para>
    /// <para>The second ItemList to be merged</para>
    /// <para><i>MergedList (Output)</i></para>
    /// <para>The merged ItemList </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <MergeByOrder
    ///             ItemList1="@(SharesToCreate)"
    ///             ItemList2="@(SharesExists)"/>
    ///                 <Output TaskParameter="MergedList" PropertyName="SharesToReallyCreate" />
    ///         </ShortenPath>
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class MergeByOrder : TaskBase
    {
        #region member variables
        private ITaskItem[] itemList1;
        private ITaskItem[] itemList2;
        private ITaskItem[] mergedList;
        #endregion

        /// <summary>
        /// MergeByOrder
        /// </summary>
        public MergeByOrder()
        {
        }

        #region properties 
        
        /// <summary>
        /// he first ItemList to be merged 
        /// </summary>
        [Required]
        public ITaskItem[] ItemList1
        {
            get { return this.itemList1; }
            set { this.itemList1 = value; }
        }

        /// <summary>
        /// The second ItemList to be merged 
        /// </summary>
        [Required]
        public ITaskItem[] ItemList2
        {
            get { return this.itemList2; }
            set { this.itemList2 = value; }
        }

        /// <summary>
        /// The merged ItemList.
        /// </summary>
        [Output]
        public ITaskItem[] MergedList
        {
            get { return this.mergedList; }
            set { this.mergedList = value; }
        }
        
        #endregion

        /// <summary>
        /// InternalExecute
        /// </summary>
        protected override void InternalExecute()
        {

            //Check if list1 and list2 have the same number of items
            if (itemList1.Length != itemList2.Length)
                return;

            //Create a new ItemList
            int count = itemList1.Length;
            mergedList = new ITaskItem[count];


            for (int ii = 0; ii < count; ii++)
            {
                mergedList[ii] = new TaskItem(itemList1[ii].ItemSpec, itemList1[ii].CloneCustomMetadata());
                
                //Add ItemList2's identity
                mergedList[ii].SetMetadata("ItemList2_Identity", itemList2[ii].ItemSpec);

                //Get custom metadata dictionary for itemlist2.
                IDictionary dict = itemList2[ii].CloneCustomMetadata();

                //Iterate through dictionary and prefix ItemList2_ to metadatanames
                foreach(object key in dict.Keys)
                {
                    string metadataName = "ItemList2_" + key.ToString();
                    string value = dict[key].ToString();
                    mergedList[ii].SetMetadata(metadataName, value);
                }

                //itemList2[ii].CopyMetadataTo(mergedList[ii]);
             }

        }
    }
}
