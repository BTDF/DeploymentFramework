//-------------------------------------------------------------------------------------
// <copyright file="ImportBindings.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Imports the bindings of an assembly into BizTalk from an XML file.
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.Assembly
{
    #region Using directives
    using BizTalk.Deployment;
    using System.Globalization;
    #endregion

    /// <summary>
    /// Imports the bindings of an assembly into BizTalk from an XML file.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2004.Assembly.ImportBindings BindingPath="bindingPath" AssemblyPath="assemblyPath" InstallInGac="installInGac" LogPath="logPath" Server="server" Database="database" />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>bindingPath (Required)</i></para>
    /// <para>
    /// The path to the XML file containing the bindings.
    /// </para>
    /// <para><i>assemblyPath (Required)</i></para>
    /// <para>
    /// The path to the assembly to have its bindings imported.
    /// </para>
    /// <para><i>installInGac</i></para>
    /// <para>
    /// <b>true</b> to install the assembly in the GAC, or <b>false</b> otherwise. The default is <b>false</b>.
    /// </para>
    /// <para><i>logPath</i></para>
    /// <para>
    /// The path to the log file for the binding import. The default is no log file.
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// <para><i>username</i></para>
    /// <para>
    /// The username to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// <para><i>password</i></para>
    /// <para>
    /// The password to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <BizTalk2004.Assembly.ImportBindings 
    ///             AssemblyPath="C:\Build\Output\MyAssembly.dll" 
    ///             BindingPath="C:\Build\Bindings\MyAssemblyBindings.xml"
    ///             LogPath="C:\Build\Logs\MyAssemblyImportBindings.log" 
    ///             Server="." 
    ///             Database="BizTalkMgmtDb" 
    ///              
    ///              />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class ImportBindings : BizTalk2004.Assembly.ImportBindings
    {
        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {
            BizTalk2004.Configuration.BizTalkInstallation installation = this.GetInstallation();

            Deployer deployer = new Deployer();
            deployer.SetConnection(installation.Server, installation.Database);
            Log.LogMessage(string.Format(CultureInfo.InvariantCulture, "Importing Binding: {0} to Database: {1}, Server: {2}", this.BindingPath, installation.Server, installation.Database));
            deployer.ImportBinding(installation.Server, installation.Database, this.BindingPath, null);            
        }
    }
}

