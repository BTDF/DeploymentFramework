﻿namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using directives

	using System;
	using System.Collections;
	using System.Text;
	using System.Reflection;

	#endregion

	internal class BtsSendPortGroup : BtsBaseObject
	{
		/// <summary>
		/// Internal Constructor
		/// </summary>
		/// <param name="actualBtsObject">The actual Microsoft.Biztalk.ExplorerOM.BtsSendPortGroup object that object will call.</param>
		/// <param name="catalogExplorer">The Microsoft.Sdc.Tasks.Configuration.BtsCatalogExplorer object.</param>
		internal BtsSendPortGroup(object actualBtsObject, BtsCatalogExplorer catalogExplorer)
		{
			this.btsCatalogExplorer = catalogExplorer;
			this.actualBtsObject = actualBtsObject;

		}

		/// <summary>
		/// Gets or sets the custom data for a send port group.
		/// </summary>
		/// <value></value>
		public string CustomData
		{
			get
			{
				return (string)this.actualBtsObject.GetType().InvokeMember("CustomData", BindingFlags.GetProperty, null, this.actualBtsObject, null);
			}
			set
			{
				this.actualBtsObject.GetType().InvokeMember("CustomData", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });
			}
		}

		/// <summary>
		/// Gets or sets the filter expression on the send port group. 
		/// </summary>
		/// <value></value>
		public string Filter
		{
			get
			{
				return (string)this.actualBtsObject.GetType().InvokeMember("Filter", BindingFlags.GetProperty, null, this.actualBtsObject, null);
			}
			set
			{
				this.actualBtsObject.GetType().InvokeMember("Filter", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });
			}
		}

		/// <summary>
		///Gets or sets the name of the send port group.
		/// </summary>
		/// <value></value>
		public string Name
		{
			get
			{
				return (string)this.actualBtsObject.GetType().InvokeMember("Name", BindingFlags.GetProperty, null, this.actualBtsObject, null);
			}
			set
			{
				this.actualBtsObject.GetType().InvokeMember("Name", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });
			}
		}

		/// <summary>
		/// Gets the collection of static send ports in the send port group. 
		/// </summary>
		/// <value></value>
		public IList SendPorts
		{
			get
			{
				return (IList)this.actualBtsObject.GetType().InvokeMember("SendPorts", BindingFlags.GetProperty, null, this.actualBtsObject, null);
				}

		}

		/// <summary>
		/// Gets or sets the status of the send port. 
		/// </summary>
		/// <value></value>
		public PortStatus Status
		{
			get
			{
				object value = this.actualBtsObject.GetType().InvokeMember("Status", BindingFlags.GetProperty, null, this.actualBtsObject, null);
				return (PortStatus)Enum.Parse(typeof(PortStatus), value.ToString());
			}
			set
			{
				object actualValue = Enum.Parse(this.btsCatalogExplorer.BizTalkExplorerOMAssembly.GetType("Microsoft.BizTalk.ExplorerOM.PortStatus"), value.ToString());
				this.actualBtsObject.GetType().InvokeMember("Status", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { actualValue });
			}
		}


	}
}
