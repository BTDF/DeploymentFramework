//-----------------------------------------------------------------------
// <copyright file="CreateGuidTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-05-25</date>
// <summary>Tests guid creation</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the Create Guid Task
    /// </summary>
    [TestClass]
    public class CreateGuidTest
    {
        public CreateGuidTest()
        {
        }

        [TestMethod]
        public void TestCreateGuid()
        {

            Tasks.CreateGuid task = new Tasks.CreateGuid();
           

            bool taskReturnValue = task.Execute();

            //Test the new GUID was created
            Assert.IsTrue(taskReturnValue);

            //Test that the formatters are correct
            Assert.AreEqual(task.GuidString[0].Length, 32);

            string registryFormatGuid = task.GuidRegistryFormatString[0];
            string[] splitRegistryFormatGuid = registryFormatGuid.Split('-');

            Assert.AreEqual(splitRegistryFormatGuid.Length, 5);

            Assert.AreEqual(splitRegistryFormatGuid[0].Length, 8);
            Assert.AreEqual(splitRegistryFormatGuid[1].Length, 4);
            Assert.AreEqual(splitRegistryFormatGuid[2].Length, 4);
            Assert.AreEqual(splitRegistryFormatGuid[3].Length, 4);
            Assert.AreEqual(splitRegistryFormatGuid[4].Length, 12);

        }
    }
}


