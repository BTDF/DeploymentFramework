//-----------------------------------------------------------------------
// <copyright file="Create.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-03-25</date>
// <summary>Creates a new Code CoverageConfiguration file</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.CodeCoverage
{
    using System;
    using System.IO;
    using Microsoft.Build.Framework;
    using System.Globalization;

    /// <summary>
    /// Creates a new CodeCoverage configuration file. The created file will be called "CoverageConfiguration.xml" and will be located in the
    /// "Configuration" folder of the CoverageEye executable, unless an alternate path is specified.
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<CodeCoverage.Create Path="path"/>]]></code>
    /// <para>where:</para>
    /// <para><i>path</i></para>
    /// <para>The absolute path to the folder for the CodeCoverage configuration file. This defaults to the default location retrieved from the registry.</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <CodeCoverage.Create
    ///             Path="C:\CoverageEyeInstallation\Configuration"  />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Create : TaskBase
    {
        private string path = String.Empty;

        /// <summary>
        /// Initializes a new instance of the Create class.
        /// </summary>
        public Create()
        {
        }

        /// <summary>
        /// The absolute path to the folder containing the CodeCoverage configuration file. This defaults to the default location retrieved from the registry.
        /// </summary>
        /// <value>The absolute path to the folder containing the CodeCoverage configuration file.</value>
        public string Path
        {
            get
            {
                return (this.path == null ? String.Empty : this.path);
            }

            set
            {
                this.path = value;
            }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            #region Execute code

            if (this.path == null || this.path.Length == 0)
            {
                //config file to be created automagically in correct position.
                //it should be in the configiguration folder under
                //the codecoverage dll                  

                string key1 = @"CLSID\{18656C37-035D-41CD-82C2-85DEF2DD5F7B}\InprocServer32";
                Microsoft.Win32.RegistryKey regKey = null;
                regKey = Microsoft.Win32.Registry.ClassesRoot.OpenSubKey(key1);

                if (regKey != null)
                {
                    string regValue = null;
                    regValue = regKey.GetValue(null).ToString();
                    if (regValue != null)
                    {
                        string pathToConfig = String.Empty;

                        System.IO.FileInfo fileinfo = new FileInfo(regValue);
                        pathToConfig = (fileinfo.DirectoryName + "\\Configuration\\");
                        this.path = pathToConfig;
                    }
                    else
                    {
                        throw new TaskException("CodeCoverage.NotRegistered");
                    }
                    regKey.Close();
                }
                else
                {
                    throw new TaskException("CodeCoverage.NotRegistered");
                }
            }

            using (StreamWriter sw = new StreamWriter(this.path + "CoverageConfiguration.xml"))
            {
                /*
                <?xml version="1.0"?>
                <c:CoverageConfiguration xmlns:c="urn:CoverageConfiguration">
                    <Assembly
                        Owner="codecoverage@microsoft.com"
                        Description="Test Assembly"
                        AssemblyName="consoleapplication1.exe"
                        ReportDirectory="c:\temp">
                    </Assembly>
                </c:CoverageConfiguration>
                */

                // Add some text to the file.
                sw.WriteLine("<?xml version=\"1.0\"?>");
                sw.WriteLine("<c:CoverageConfiguration xmlns:c=\"urn:CoverageConfiguration\">");
                sw.WriteLine("</c:CoverageConfiguration>");
            }
            #endregion
        }
    }
}