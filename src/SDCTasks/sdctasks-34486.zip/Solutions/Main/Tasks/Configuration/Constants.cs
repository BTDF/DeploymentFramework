/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/

namespace Microsoft.Sdc.Tasks.Configuration 
{
	using System;
	/// <summary>
	/// Provides all the constants for this assembly
	/// </summary>
	internal sealed class Constants 
	{		
		public const string BuildNamespaceUri = "urn:Microsoft:Sdc:Configuration:Build:1.2";
		public const string BuildSchema = "Microsoft.Sdc.Tasks.Configuration.Build.1.2.xsd";
		public const string BizTalkSchema = "Microsoft.Sdc.Tasks.Configuration.BizTalk.1.1.xsd";
		
		private Constants() 
		{
		}
	}
}
