//-------------------------------------------------------------------------------------
// <copyright file="OrchestrationPort.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      An Orchestration Port belonging to an Orchestration
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives 

    using System;

	#endregion 

	/// <summary>
	/// An Orchestration Port belonging to an Orchestration
	/// </summary>
	internal class OrchestrationPort : BizTalkNonConfigurableEntityBase 
	{
		#region Member Variables
 
		private Orchestration parentOrchestration;
        private BindingType bindingType;
        private SendPort sendPort;
        private SendPortGroup sendPortGroup;
        private ReceivePort receivePort;
		
		#endregion 


		#region properties 

		/// <summary>
		/// Gets the type of binding for the orchestration port.
		/// </summary>
		/// <value>The BindingType object</value>
        public BindingType BindingType
        {
            get { return this.bindingType; }
        }

        /// <summary>
        /// Gets the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SendPort"/> bound to the orchestration port.
        /// </summary>
        /// <value>The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SendPort"/> object</value>
        public SendPort SendPort
        {
            get { return this.sendPort; }
			set { this.sendPort = value;}
        }
        /// <summary>
        /// Gets the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SendPortGroup"/> bound to the orchestration port.
        /// </summary>
        ///<value>The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SendPortGroup"/> object</value>
        public SendPortGroup SendPortGroup
        {
            get { return this.sendPortGroup; }
			set { this.sendPortGroup = value;}

		}
        
		/// <summary>
		/// Getst the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.ReceivePort"/> bound to the orchestration port.
		/// </summary>
		/// <value>The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.ReceivePort"/> object</value>
        public ReceivePort ReceivePort
        {
            get { return this.receivePort; }
			set { this.receivePort = value;}

		}
		/// <summary>
		/// Gets the reference to the containing Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchstration object.
		/// </summary>
		/// <value>The Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchstration object</value>
		public Orchestration Orchestration
		{
			get {return this.parentOrchestration;}
		}

		#endregion 

		#region methods 

		/// <summary>
		/// Creates a orchestration port instance. This is private because instance of this class can only be created with
		/// the Load method
		/// </summary>
		/// <param name="orchestration"> A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/> object. </param>
		private OrchestrationPort(Orchestration orchestration):this(orchestration, null){}

		/// <summary>
		/// Creates a orchestration port instance. This is private because instance of this class can only be created with
		/// the Load method
        /// </summary>
		/// <param name="orchestration">A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/> object.</param>
		/// <param name="name">The name of the orchestration port.</param>
		private OrchestrationPort(Orchestration orchestration, string name) : base(orchestration.Assembly.Installation, name)
		{
			this.parentOrchestration = orchestration;
			this.Name = name;
		}


		/// <summary>
		/// Loads the details of an orchestration port
		/// </summary>
		/// <param name="orchestration">The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/> that the port belongs to.</param>
		/// <param name="name">The name of the port.</param>
		/// <returns>A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.OrchestrationPort"/>.</returns>
        public static OrchestrationPort Load(Orchestration orchestration, string name)
        {
			//check inputs
			if (orchestration == null) throw new ArgumentException("orchestration");
			if (name == null || name.Length == 0) throw new ArgumentException("name");


		//load the native orchestration port
		BtsOrchestrationPort btsOrchPort = orchestration.Assembly.Installation.CatalogExplorer.Assemblies[orchestration.Assembly.Name].Orchestrations[orchestration.Name].Ports[name];

			if (btsOrchPort != null)
			{
				OrchestrationPort  orchPort = new OrchestrationPort(orchestration, name);
				
				orchPort.bindingType = (BindingType)Enum.Parse(typeof(BindingType), ((int)btsOrchPort.Binding).ToString());
				orchPort.sendPort  = (btsOrchPort.SendPort != null? SendPort.Load(orchPort.Installation, btsOrchPort.SendPort.Name):null);
				orchPort.sendPortGroup = (btsOrchPort.SendPortGroup != null? SendPortGroup.Load(orchPort.Installation, btsOrchPort.SendPortGroup.Name):null);
				orchPort.receivePort = (btsOrchPort.ReceivePort != null? ReceivePort.Load(orchPort.Installation, btsOrchPort.ReceivePort.Name):null);

				return orchPort;
			}
			else
				return null;
        }

		#endregion 
	}
}

