//-----------------------------------------------------------------------
// <Deleteright file="ReceiveHandlerTests.cs" company="Microsoft">
// Deleteright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </Deleteright>
// <author>Thomas Manson</author>
// <email>tmanson</email>
// <date>2006-02-16</date>
// <summary>Tests BizTalk 2004 Receive Handler tasks</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test.BizTalk2006
{
    using System;
    using System.Text;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Sdc.Tasks.BizTalk2006;
    using System.Management;

    /// <summary>
    /// Tests the BizTalk 2006 assembly tasks
    /// </summary>
    [TestClass]
    public class ReceivePortTests
    {
        private const string AppName = "Receive Port Test App";

        public ReceivePortTests()
        {
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext)
        {
            Microsoft.Sdc.Tasks.BizTalk2006.Application.Create createTask = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Create();
            createTask.Application = AppName;
            createTask.Execute();
        }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        [ClassCleanup()]
        public static void MyClassCleanup()
        {
            Microsoft.Sdc.Tasks.BizTalk2006.Application.Stop stopAppTask = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Stop();
            stopAppTask.Application = AppName;
            stopAppTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.Application.Delete deleteTask = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Delete();
            deleteTask.Application = AppName;
            deleteTask.Execute();
        }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void TestReceivePortActions()
        {
            Microsoft.Sdc.Tasks.BizTalk2006.ReceivePort.Create createTask = new Microsoft.Sdc.Tasks.BizTalk2006.ReceivePort.Create();
            createTask.Name = "OneWayTestReceivePort";
            createTask.Application = AppName;
            createTask.TwoWay = false;
            createTask.TrackingTypes = "AfterReceivePipeline;TrackPropertiesAfterReceivePipeline";
            createTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.ReceivePort.Exists existsTask = new Microsoft.Sdc.Tasks.BizTalk2006.ReceivePort.Exists();
            existsTask.Name = "OneWayTestReceivePort";
            existsTask.Application = AppName;
            existsTask.Execute();
            if (!existsTask.ReceivePortExists)
            {
                Assert.Fail("ReceivePort was not created");
            }

            Microsoft.Sdc.Tasks.BizTalk2006.ReceivePort.AddReceiveLocation addRecLocTask = new Microsoft.Sdc.Tasks.BizTalk2006.ReceivePort.AddReceiveLocation();
            addRecLocTask.Name = "TestReceiveLocation";
            addRecLocTask.Application = AppName;
            addRecLocTask.ReceivePort = "OneWayTestReceivePort";
            addRecLocTask.IsPrimary = true;
            addRecLocTask.ReceiveHandler = "BizTalkServerApplication";
            addRecLocTask.ReceivePipeline = "Microsoft.BizTalk.DefaultPipelines.XMLReceive, Microsoft.BizTalk.DefaultPipelines, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35";
            addRecLocTask.Address = @"C:\temp\*.xml";
            addRecLocTask.TransportTypeData = @"<CustomProps><BatchSize vt='19'>20</BatchSize><FileMask vt='8'>*.xml</FileMask><FileNetFailRetryCount vt='19'>5</FileNetFailRetryCount><FileNetFailRetryInt vt='19'>5</FileNetFailRetryInt></CustomProps>";
            addRecLocTask.TransportType = "FILE";
            addRecLocTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.ReceiveLocation.Configure configureTask = new Microsoft.Sdc.Tasks.BizTalk2006.ReceiveLocation.Configure();
            configureTask.Application = AppName;
            configureTask.ReceivePort = "OneWayTestReceivePort";
            configureTask.Name = "TestReceiveLocation";
            configureTask.TransportTypeData = @"<CustomProps><BatchSize vt='19'>20</BatchSize><FileMask vt='8'>*.xml</FileMask><FileNetFailRetryCount vt='19'>15</FileNetFailRetryCount><FileNetFailRetryInt vt='19'>5</FileNetFailRetryInt></CustomProps>";
            configureTask.TransportType = "FILE";
            configureTask.Enable = false;
            configureTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.ReceivePort.AddReceiveLocation addMsmqRecLockTask = new Microsoft.Sdc.Tasks.BizTalk2006.ReceivePort.AddReceiveLocation();
            addMsmqRecLockTask.Name = "TestReceiveLocationMSMQ";
            addMsmqRecLockTask.Application = AppName;
            addMsmqRecLockTask.ReceivePort = "OneWayTestReceivePort";
            addMsmqRecLockTask.IsPrimary = false;
            addMsmqRecLockTask.ReceiveHandler = "BizTalkServerApplication";
            addMsmqRecLockTask.ReceivePipeline = "Microsoft.BizTalk.DefaultPipelines.XMLReceive, Microsoft.BizTalk.DefaultPipelines, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35";
            addMsmqRecLockTask.Address = @"FORMATNAME:DIRECT=OS:.\PRIVATE$\FROMFIXEDORDERSQ2";
            addMsmqRecLockTask.TransportType = "MSMQ";
            addMsmqRecLockTask.TransportTypeData = @"<CustomProps><AdapterConfig vt='8'>&lt;Config xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:xsd='http://www.w3.org/2001/XMLSchema'&gt;&lt;queue&gt;FORMATNAME:DIRECT=OS:.\PRIVATE$\FROMFACILITIESQ&lt;/queue&gt;&lt;uri&gt;FORMATNAME:DIRECT=OS:.\PRIVATE$\FROMFACILITIESQ&lt;/uri&gt;&lt;batchSize&gt;20&lt;/batchSize&gt;&lt;transactional&gt;true&lt;/transactional&gt;&lt;serialProcessing&gt;false&lt;/serialProcessing&gt;&lt;onFailure&gt;suspendResumable&lt;/onFailure&gt;&lt;/Config&gt;</AdapterConfig></CustomProps>";
            addMsmqRecLockTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.ReceiveLocation.Exists recLocExistsTest = new Microsoft.Sdc.Tasks.BizTalk2006.ReceiveLocation.Exists();
            recLocExistsTest.Application = AppName;
            recLocExistsTest.ReceivePort = "OneWayTestReceivePort";
            recLocExistsTest.Name = "TestReceiveLocationMSMQ";
            recLocExistsTest.Execute();
            if (!recLocExistsTest.ReceiveLocationExists)
            {
                Assert.Fail("ReceiveLocation not added");
            }

            Microsoft.Sdc.Tasks.BizTalk2006.ReceivePort.RemoveReceiveLocation removeRecLocTask = new Microsoft.Sdc.Tasks.BizTalk2006.ReceivePort.RemoveReceiveLocation();
            removeRecLocTask.Application = AppName;
            removeRecLocTask.ReceivePort = "OneWayTestReceivePort";
            removeRecLocTask.Name = "TestReceiveLocationMSMQ";
            removeRecLocTask.Execute();

            recLocExistsTest.Execute();
            if (recLocExistsTest.ReceiveLocationExists)
            {
                Assert.Fail("ReceiveLocation was not removed");
            }

            Microsoft.Sdc.Tasks.BizTalk2006.ReceivePort.Create create2WayTask = new Microsoft.Sdc.Tasks.BizTalk2006.ReceivePort.Create();
            create2WayTask.TwoWay = true;
            create2WayTask.Name = "Test Twoway ReceivePort";
            create2WayTask.Application = AppName;
            create2WayTask.TrackingTypes = "AfterReceivePipeline;AfterSendPipeline;BeforeReceivePipeline;BeforeSendPipeline;TrackPropertiesAfterReceivePipeline;TrackPropertiesAfterSendPipeline;TrackPropertiesBeforeReceivePipeline;TrackPropertiesBeforeSendPipeline";
            create2WayTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.ReceivePort.Exists existsTask2 = new Microsoft.Sdc.Tasks.BizTalk2006.ReceivePort.Exists();
            existsTask2.Name = "Test Twoway ReceivePort";
            existsTask2.Application = AppName;
            existsTask2.Execute();
            if (!existsTask2.ReceivePortExists)
            {
                Assert.Fail("ReceivePort was not created");
            }

            Microsoft.Sdc.Tasks.BizTalk2006.ReceivePort.Delete deleteTask = new Microsoft.Sdc.Tasks.BizTalk2006.ReceivePort.Delete();
            deleteTask.Application = AppName;
            deleteTask.Name = "OneWayTestReceivePort";
            deleteTask.Execute();

            existsTask.Execute();
            if (existsTask.ReceivePortExists)
            {
                Assert.Fail("ReceivePort was not deleted");
            }
        }
    }
}
