//-----------------------------------------------------------------------
// <copyright file="ToolsTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-03-23</date>
// <summary>Unit test for the Tools Tasks.</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the ToolsTest Task
    /// </summary>
    [TestClass]
    public class ToolsTest
    {
        

        /// <summary>
        /// Initializes a new instance of the ToolsTest class.
        /// </summary>
        public ToolsTest()
        {
        }        

        /// <summary>
        /// Tests FxCop
        /// </summary>
        [Ignore]//("a")]
        public void TestFxCop()
        {
            string tempFile = null;
            string tempOutFile = null;

            try
            {
                tempFile = Guid.NewGuid().ToString();
                tempOutFile = Guid.NewGuid().ToString();

                Tools.FxCop task = new Tools.FxCop();
                task.Assemblies = new string[] { "Microsoft.Sdc.Tasks.Configuration.Test.ComAssembly.dll" };
                task.ProjectFilePath = tempFile;
                task.ProjectTemplateFilePath = @"TestData\Test.FxCop";
                task.OutFileName = tempOutFile;

                bool taskReturnValue = task.Execute();
                Assert.IsTrue(taskReturnValue);

                //There should be 2 violations in the ComAssembly.dll
                Assert.AreEqual(task.TotalViolations, 2);
            }
            finally
            {
                if (tempFile != null) { File.Delete(tempFile); }
                if (tempOutFile != null) { File.Delete(tempOutFile); }
            }
        }

        /// <summary>
        /// Tests NDoc 
        /// </summary>
        [TestMethod]
        [Ignore]//("Failing on move to RTM")]
        public void TestNDoc()
        {
            string tempFile = null;

            try
            {
                tempFile = Guid.NewGuid().ToString();

                Tools.NDoc task = new Tools.NDoc();
                task.ToolPath = Path.Combine(Environment.CurrentDirectory, @"..\..\Build\Tools\Ndoc\1.3.1811");
                task.Assemblies = new string[] { Path.Combine(Environment.CurrentDirectory, @"TestData\Microsoft.Sdc.Tasks.Configuration.Test.ComAssembly.dll") };
                task.ProjectFilePath = Path.Combine(Environment.CurrentDirectory, @"TestData\Test.NDoc");
                task.OutputFilePath = Path.Combine(Environment.CurrentDirectory, tempFile);

                bool taskReturnValue = task.Execute();
                Assert.IsTrue( taskReturnValue);

                //check for something that should have happened here
                //currently 38 files inc 1 called TestDocumentation.chm of 19021 bytes
                System.IO.DirectoryInfo di = new DirectoryInfo(Path.Combine(Environment.CurrentDirectory, tempFile));
                FileInfo[] fis = di.GetFiles();

                Assert.AreEqual( 38, fis.Length);
                FileInfo fi = new FileInfo(Path.Combine(Path.Combine(Environment.CurrentDirectory, tempFile), "TestDocumentation.chm"));

                Assert.AreEqual( 19021, fi.Length, 100);
            }
            finally
            {
                if (tempFile != null) { Directory.Delete(Path.Combine(Environment.CurrentDirectory, tempFile), true); }
            }
        }        
    }
}