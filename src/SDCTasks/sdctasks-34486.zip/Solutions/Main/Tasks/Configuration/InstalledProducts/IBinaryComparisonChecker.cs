using System;

namespace Microsoft.Sdc.Tasks.Configuration.InstalledProducts
{
	/// <summary>
	/// Interface for classes that check for matches
	/// </summary>
	/// <example>
	/// <see cref="StringComparisonChecker"/>
	/// <see cref="VersionComparisonChecker"/>
	/// </example>
	public interface IBinaryComparisonChecker
	{
		BinaryComparisonOperator Operator{get;set;}
		bool IsMatch(object baseObject, object compareObject);
	}
}
