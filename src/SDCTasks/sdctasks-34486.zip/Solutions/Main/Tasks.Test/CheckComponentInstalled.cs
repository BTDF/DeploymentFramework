//-----------------------------------------------------------------------
// <copyright file="CheckComponentInstalledTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-06-07</date>
// <summary>Tests check component installed task</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the Create Guid Task
    /// </summary>
    [TestClass]
    public class CheckComponentInstalledTest
    {
        

        public CheckComponentInstalledTest()
        {
        }

        [TestMethod]        
        [Ignore]//("failing on 2.0 RTM")]
        public void TestCheckComponentInstalled()
        {
            try
            {
                Tasks.GetInstalledComponents getComponentsInstalledTask = new Tasks.GetInstalledComponents();
                
                bool getComponentsInstalledTaskReturnValue = getComponentsInstalledTask.Execute();

                Assert.IsTrue( getComponentsInstalledTaskReturnValue);

                string installedComponentsXml = getComponentsInstalledTask.InstalledComponentsXml[0];

                Assert.IsTrue(installedComponentsXml.Length > 0);

                Tasks.CheckComponentInstalled checkComponentInstalledTask = new Tasks.CheckComponentInstalled();
                
                string[] ids = new string[1] { "aspnet" };

                string[] idsComparisonOperators = new string[1] { Microsoft.Sdc.Tasks.Configuration.InstalledProducts.BinaryComparisonOperator.Equals.ToString() };
                string[] unaryOperators = new string[1] { Microsoft.Sdc.Tasks.Configuration.InstalledProducts.UnaryLogicalOperator.None.ToString() };

                checkComponentInstalledTask.Ids = ids;
                checkComponentInstalledTask.IdComparisonOperators = idsComparisonOperators;
                checkComponentInstalledTask.UnaryOperators = unaryOperators;

                checkComponentInstalledTask.InstalledComponentsXml = installedComponentsXml;


                bool checkComponentsInstalledTaskReturnValue = checkComponentInstalledTask.Execute();

                Assert.IsTrue( checkComponentsInstalledTaskReturnValue);

                Assert.IsTrue( checkComponentInstalledTask.Ids == ids);
                Assert.IsTrue(checkComponentInstalledTask.InstalledComponentsXml == installedComponentsXml);
                Assert.IsTrue(checkComponentInstalledTask.IdComparisonOperators == idsComparisonOperators);
                Assert.IsTrue( checkComponentInstalledTask.UnaryOperators == unaryOperators);
            }

            finally
            {
            }
        }
    }
}


