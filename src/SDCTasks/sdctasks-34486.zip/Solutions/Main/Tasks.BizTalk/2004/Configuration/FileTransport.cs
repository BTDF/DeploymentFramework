//-------------------------------------------------------------------------------------
// <copyright file="ReceiveLocation.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Represents a combination of a specific address where the inbound message arrives and the pipeline processes the message.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using Directives

	using System;
	
	#endregion 

	/// <summary>
	/// FileTransport Wrapper class.
	/// </summary>
	internal class FileTransport : TransportData
	{
		public const string Name = "FILE";

		#region Constructor

		/// <summary>
		/// Creates a new instance of the File Transport Object
		/// </summary>
		/// <param name="parentType"> A Microsoft.Sdc.Tasks.BizTalk2004.Configuration.TransportDataParentType specifying the parent type.</param>
		public FileTransport(TransportDataParentType parentType)
		{
			this.ParentType = parentType;
		}

		/// <summary>
		/// Creates a new instance of the File Transport Object
		/// </summary>
        /// <param name="parentType"> A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.TransportDataParentType"/> specifying the parent type</param>
		/// <param name="transportDataXml">A string containing the TransportData Xml.</param>
		public FileTransport(TransportDataParentType parentType, string transportDataXml)
		{
			this.ParentType = parentType;
			this.InitializeFromXml(transportDataXml);
		}
		
		#endregion 

		#region send port properties

		/// <summary>
		/// the name of the file where the file send port writes the message.
		/// </summary>
		public string FileName
		{
			get
			{
				return this.Items["FileName"].Value.ToString();
			}
			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{

					if(!this.Items.Contains("FileName"))
						this.Items.Add(new TransportDataItem("FileName", typeof(string), value));
					else
						this.Items["FileName"].Value = value;
				}
				else
					throw new InvalidOperationException("The FileName property can only be set for a send port.");
			}
		}


		/// <summary>
		/// Defines the copy mode to use when writing a message to a file.
		/// </summary>
		public FileTransportCopyMode CopyMode
		{
			get
			{
				return (FileTransportCopyMode)Enum.Parse(typeof(FileTransportCopyMode), this.Items["CopyMode"].Value.ToString());
			}
			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("CopyMode"))
						this.Items.Add(new TransportDataItem("CopyMode", typeof(long), value.ToString()));
					else
						this.Items["CopyMode"].Value = value.ToString();
				}
				else
					throw new InvalidOperationException("The CopyMode property can only be set for a send port.");
			}
		}

		
		/// <summary>
		/// Define whether to use file system caching when writing a message to a file. 
		/// </summary>
		public bool AllowCacheOnWrite
		{
			get
			{
				return (bool) this.Items["AllowCacheOnWrite"].Value;
			}
			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{

					if(!this.Items.Contains("AllowCacheOnWrite"))
						this.Items.Add(new TransportDataItem("AllowCacheOnWrite", typeof(bool), value));
					else
						this.Items["AllowCacheOnWrite"].Value = value;
				}
				else
					throw new InvalidOperationException("The AllowCacheOnWrite property can only be set for a send port.");

			}
		}


		#endregion

		#region receive location properties 

		/// <summary>
		/// The mask for the files to configure the receive location. This mask can contain the standard wildcard value.
		/// </summary>
		public string FileMask
		{
			get
			{
				return this.Items["FileMask"].Value.ToString();
			}
			set
			{
				if (this.ParentType == TransportDataParentType.ReceiveLocation)
				{
					if(!this.Items.Contains("FileMask"))
						this.Items.Add(new TransportDataItem("FileMask", typeof(string), value));
					else
						this.Items["FileMask"].Value = value;
				}
				else
					throw new InvalidOperationException("The FileMask property can only be set for a receive location.");
			}
		}

		
		/// <summary>
		/// Specify the maximum number of files that the receive handler can submit in one batch.
		/// </summary>
		public long BatchSize
		{
			get
			{
				return Convert.ToInt32(this.Items["BatchSize"].Value);
			}
			set
			{
				if (this.ParentType == TransportDataParentType.ReceiveLocation)
				{
					if(!this.Items.Contains("BatchSize"))
						this.Items.Add(new TransportDataItem("BatchSize", typeof(long), value));
					else
						this.Items["BatchSize"].Value = value;
				}
				else
					throw new InvalidOperationException("The BatchSize property can only be set for a receive location.");
			}


		}


		/// <summary>
		/// Specify the number of attempts to access the receive location on a network share if it is temporarily unavailable. 
		/// </summary>
		public long RetryCount
		{
			get
			{
				return Convert.ToInt32(this.Items["FileNetFailRetryCount"].Value);
			}
			set
			{
				if (this.ParentType == TransportDataParentType.ReceiveLocation)
				{
					if(!this.Items.Contains("FileNetFailRetryCount"))
						this.Items.Add(new TransportDataItem("FileNetFailRetryCount", typeof(long), value));
					else
						this.Items["FileNetFailRetryCount"].Value = value;
				}
				else
					throw new InvalidOperationException("The RetryCount property can only be set for a receive location.");

			}
		}

		
		/// <summary>
		/// Specify the retry interval time (in minutes) between attempts to access the receive location on the network share if it is temporarily unavailable.
		/// </summary>
		public long RetryInterval
		{
			get
			{
				return Convert.ToInt32(this.Items["FileNetFailRetryInt"]);
			}
			set
			{
				if (this.ParentType == TransportDataParentType.ReceiveLocation)
				{
					if(!this.Items.Contains("FileNetFailRetryInt"))
						this.Items.Add(new TransportDataItem("FileNetFailRetryInt", typeof(long), value));
					else
						this.Items["FileNetFailRetryInt"].Value = value;
				}
				else
					throw new InvalidOperationException("The RetryInterval property can only be set for a receive location.");
			}
		}

		
		#endregion 
	}
}

