/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date><Date/>
  <Description>Implementation of the Service Task <Description/>
  <Copyright><![CDATA[
    Copyright � 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.Configuration.ComponentServices;

    /// <summary>
    /// Unit test for the UpdateComponentServicesComponentTest Task
    /// </summary>
    [TestClass]
    public class UpdateComponentServicesComponentTest
    {
        public UpdateComponentServicesComponentTest()
        {           
        }

        [TestMethod]
        public void TestUpdateComponentServicesComponent()
        {
            string applicationName = "IIS Out-Of-Process Pooled Applications";
            string componentName = "IISWAM.OutofProcessPool";

            Tasks.ComponentServices.Component.Update task = new Tasks.ComponentServices.Component.Update();
           

            task.ApplicationName = applicationName;
            task.ComponentName = componentName;
            task.ConstructorString = "bob";

            bool taskReturnValue = task.Execute();
            Assert.IsTrue(taskReturnValue, "UpdateComponentServicesApplicationTest");

            //Check the COM+ Component is now updated
            Application app = Application.Load(applicationName);
            Component c = app.Components[componentName];
            Assert.IsTrue(c.ConstructionEnabled, "TestUpdateComponentServicesComponent");
            Assert.AreEqual("bob", c.Constructor);

            //Now set it back
            task.ConstructorString = "";

            taskReturnValue = task.Execute();
            Assert.IsTrue(taskReturnValue, "UpdateComponentServicesApplicationTest");

            //Check the COM+ Component is now updated
            app = Application.Load(applicationName);
            c = app.Components[componentName];
            Assert.IsFalse(c.ConstructionEnabled, "TestUpdateComponentServicesComponent");
            Assert.AreEqual(String.Empty, c.Constructor);

        }
    }
}



