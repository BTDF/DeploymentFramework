/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.Web {
    
    using System;
    using System.DirectoryServices;
    using System.ComponentModel;
    using System.Text;
    using System.Collections;

    /// <summary>
    /// Summary description for Performance.
    /// </summary>
    internal class Performance {

        private int       idleTimeout = 20;
        private int       requestQueueLimit = 1000;
        private int       cpuMaximumUse;
        private int       cpuRefreshInterval;
        private CpuAction cpuAction;
        private int       workerProcesses = 1;
        
        internal Performance() {
        }
        /// <summary>
        /// Idle Timeout in minutes. Default is 20.
        /// </summary>
        public int IdleTimeout {
            get {
                return idleTimeout ;
            }
            set {
                idleTimeout = value;
            }
        }
        /// <summary>
        /// Kernal Request Queue limit in number of requests. Default is 1000.
        /// </summary>
        public int RequestQueueLimit {
            get {
                return requestQueueLimit ;
            }
            set {
                requestQueueLimit = value;
            }
        }
        /// <summary>
        /// Maximum CPU use (percentage). Set to 0 to disable CPU monitoring.
        /// </summary>
        public int CpuMaximumUse {
            get {
                return cpuMaximumUse ;
            }
            set {
                cpuMaximumUse = value;
            }
        }

        /// <summary>
        /// Refresh CPU usage numbers (in minutes). Set to 0 to disable CPU monitoring.
        /// </summary>
        public int CpuRefreshInterval {
            get {
                return cpuRefreshInterval ;
            }
            set {
                cpuRefreshInterval = value;
            }
        }

        public Microsoft.Sdc.Tasks.Configuration.Web.CpuAction CpuAction {
            get {
                return cpuAction ;
            }
            set {
            
                if (!Enum.IsDefined(typeof(Microsoft.Sdc.Tasks.Configuration.Web.CpuAction), value)) {
                    throw new System.ComponentModel.InvalidEnumArgumentException("value", (int)value, typeof(Microsoft.Sdc.Tasks.Configuration.Web.CpuAction));
                }
                if (cpuAction != value) {
                    cpuAction = value;
                }
            }
        }
        /// <summary>
        /// Maximum number of worker processes. Default is 1.
        /// </summary>
        public int WorkerProcesses {
            get {
                return workerProcesses ;
            }
            set {
                workerProcesses = value;
            }
        }
    }
}
