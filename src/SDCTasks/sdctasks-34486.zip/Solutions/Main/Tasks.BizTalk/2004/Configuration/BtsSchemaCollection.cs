﻿namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;

    #endregion

    internal class BtsSchemaCollection : System.Collections.ReadOnlyCollectionBase
    {
        public BtsSchemaCollection() { }

        public BtsSchema this[string fullName]
        {
            get
            {
                BtsSchema item = null;
                foreach (BtsSchema currentitem in this.InnerList)
                {
                    if (currentitem.FullName == fullName)
                    {
                        item = currentitem;
                        break;
                    }
                }
                return item;

            }
        }

        public BtsSchema this[int index]
        {
            get
            {
                return (BtsSchema)this.InnerList[index];
            }
        }

        internal void Add(BtsSchema item)
        {
            this.InnerList.Add(item);
        }
    }
}
