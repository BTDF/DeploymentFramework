//-----------------------------------------------------------------------
// <copyright file="Exists.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.Application
{
    using BizTalk2004;
    using BizTalk.ExplorerOM;
    using Build.Framework;

    /// <summary>
    /// Checks if an application exists
    /// </summary>
    public class Exists : BizTalk2004TaskBase
    {
        private string application;
        private bool doesExist;

        /// <summary>
        /// Gets or sets a value indicating whether [does exist].
        /// </summary>
        /// <value><c>true</c> if [does exist]; otherwise, <c>false</c>.</value>
        [Output]
        public bool DoesExist
        {
            get { return this.doesExist; }
            protected set { this.doesExist = value; }
        }

        /// <summary>
        /// Gets or sets the application.
        /// </summary>
        /// <value>The application.</value>
        [Required]
        public string Application
        {
            get { return this.application; }
            set { this.application = value; }
        }

        /// <summary>
        /// This is the main execute method that all tasks should implement
        /// </summary>
        /// <remarks>
        /// TaskException should be thrown in the event of errors
        /// </remarks>
        protected override void InternalExecute()
        {
            BtsCatalogExplorer explorer = this.GetBtsCatalogExplorer(this.Server, this.Database);

            if (explorer.Applications[this.Application] != null)
            {
                this.DoesExist = true;
            }
        }
    }
}
