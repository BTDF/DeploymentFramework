//-----------------------------------------------------------------------
// <copyright file="ServiceProcessTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-06-04</date>
// <summary>Tests service process tasks</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.ServiceProcess;

    using System.IO;
    using System.Threading;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the service process tasks
    /// </summary>
    [TestClass]
    public class ServiceProcessTest
    {
        public ServiceProcessTest()
        {
        }       

        [TestMethod]
        [Ignore]//("The Start task fails if the service is ServiceControllerStatus.StopPending")]
        public void TestSuccess()
        {
            string serviceName = "W3SVC";

            ServiceExists(serviceName);

            System.ServiceProcess.ServiceController sc = new System.ServiceProcess.ServiceController(serviceName);
            Console.WriteLine("Current service status: " + sc.Status.ToString());
            if (sc.Status == ServiceControllerStatus.Running)
            {
                Console.WriteLine("Stopping and starting...");
                //Stop the service
                StopService(serviceName);

                Console.WriteLine("Post stop, current service status: " + sc.Status.ToString());

                // THIS WILL FAIL
                StartService(serviceName);
            }
            else if (sc.Status == ServiceControllerStatus.Stopped)
            {
                Console.WriteLine("Starting and stopping...");
                StartService(serviceName);
                StopService(serviceName);
            }
        }

        private void ServiceExists(string serviceName)
        {
          Tasks.ServiceProcess.Exists serviceExistsTask = new Tasks.ServiceProcess.Exists();

          serviceExistsTask.ServiceName = serviceName;

          bool serviceExistsTaskReturnValue = serviceExistsTask.Execute();

          //Check the task executed
          Assert.IsTrue(serviceExistsTaskReturnValue, "ServiceExists");

          Assert.IsTrue(serviceExistsTask.DoesExist, "ServiceExists");

          bool exists = serviceExistsTask.IsDisabled;

        }

        private void StartService(string serviceName)
        {
            Tasks.ServiceProcess.Start startServiceTask = new Tasks.ServiceProcess.Start();
            
            startServiceTask.ServiceName = serviceName;

            bool startServiceTaskReturnValue = startServiceTask.Execute();

            //Check the task executed
            Assert.IsTrue(startServiceTaskReturnValue, "StartServiceTask");

            //Check the properties of the task remain the same
            Assert.IsTrue(startServiceTask.ServiceName == serviceName, "StartServiceTask");
        }

        private void StopService(string serviceName)
        {
            Tasks.ServiceProcess.Stop stopServiceTask = new Tasks.ServiceProcess.Stop();
           
            stopServiceTask.ServiceName = serviceName;

            bool stopServiceTaskReturnValue = stopServiceTask.Execute();

            //Check the task executed
            Assert.IsTrue(stopServiceTaskReturnValue, "StopServiceTask");

            //Check the properties of the task remain the same
            Assert.IsTrue(stopServiceTask.ServiceName == serviceName, "StopServiceTask");
        }
    }
}


