//-----------------------------------------------------------------------
// <Deleteright file="ReceiveHandlerTests.cs" company="Microsoft">
// Deleteright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </Deleteright>
// <author>Thomas Manson</author>
// <email>tmanson</email>
// <date>2006-02-16</date>
// <summary>Tests BizTalk 2004 Receive Handler tasks</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test.BizTalk2004
{
    using System;
    using System.Text;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Sdc.Tasks.BizTalk2004;
    using Microsoft.Sdc.Tasks.Configuration;
    using System.Management;

    /// <summary>
    /// ReceiveHandlerTests tests the ReceiveHandler BizTalk 2004 tasks
    /// </summary>
    [TestClass]
    public class ReceiveHandlerTests
    {
        private const string hostName = "NewTesthost";
        private const string transport = "FILE";
        public ReceiveHandlerTests()
        {
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext)
        {
            // create the host we need for the tests
            Microsoft.Sdc.Tasks.BizTalk2004.Host.Create createHost = new Microsoft.Sdc.Tasks.BizTalk2004.Host.Create();
            createHost.Name = hostName;
            createHost.HostType = "InProcess";
            createHost.HostUsername = "BizTalkService";
            createHost.GroupName = "BizTalk Application Users";
            createHost.HostType = "InProcess";
            createHost.HostServerName = Environment.MachineName;
            createHost.HostPassword = "1234$abcd";
            createHost.Trusted = false;
            createHost.Tracking = false;
            createHost.IsDefault = false;
            createHost.Execute();

        }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        [ClassCleanup()]
        public static void MyClassCleanup()
        {
            Microsoft.Sdc.Tasks.BizTalk2004.Host.Delete deleteHost = new Microsoft.Sdc.Tasks.BizTalk2004.Host.Delete();
            deleteHost.Name = hostName;
            deleteHost.Execute();
        }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void TestReceiveHandlerActions()
        {
            Microsoft.Sdc.Tasks.BizTalk2004.ReceiveHandler.Create task = new Microsoft.Sdc.Tasks.BizTalk2004.ReceiveHandler.Create();
            task.HostName = hostName;
            task.TransportType = transport;
            task.Execute();

            Microsoft.Sdc.Tasks.BizTalk2004.ReceiveHandler.Exists existT = new Microsoft.Sdc.Tasks.BizTalk2004.ReceiveHandler.Exists();
            existT.HostName = hostName;
            existT.TransportType = transport;
            existT.Execute();
            if (!existT.HandlerExists)
            {
                Assert.Fail("There is no FILE ReceiveHandler in host: NewTestHost. This should have been created");
            }

            Microsoft.Sdc.Tasks.BizTalk2004.ReceiveHandler.Delete deleteT = new Microsoft.Sdc.Tasks.BizTalk2004.ReceiveHandler.Delete();
            deleteT.HostName = hostName;
            deleteT.TransportType = transport;
            deleteT.Execute();

            existT = new Microsoft.Sdc.Tasks.BizTalk2004.ReceiveHandler.Exists();
            existT.HostName = hostName;
            existT.TransportType = transport;
            existT.Execute();
            if (existT.HandlerExists)
            {
                Assert.Fail("The FILE ReceiveHandler in host: NewTestHost should have been deleted, but still exists");
            }
        }
    }
}
