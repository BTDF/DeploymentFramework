/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/

namespace Microsoft.Sdc.Tasks.Configuration.Win32Security {
    using System;
    [Flags]
    public enum AccessTypes : int {

        FullControl                = 0x001F01FF,
        TraverseFolderExecuteFile  = 0x00100020,
        ListFolderReadData         = 0x00100001,
        ReadAttributes             = 0x00100080,
        ReadExtendedAttributes     = 0x00100008,
        CreateFilesWriteData       = 0x00100002,
        CreateFoldersAppendData    = 0x00100004,
        WriteAttributes            = 0x00100100,
        WriteExtendedAttributes    = 0x00100010,
        DeleteSubfoldersAndFiles   = 0x00100040, 
        Delete                     = 0x00110000,
        ReadPermissions            = 0x00120000,
        ChangePermissions          = 0x00140000,
        TakeOwnership              = 0x00180000,
				
        Modify                     = 0x001301BF,
        ReadAndExecute             = 0x001200A9,
        ListFolderContents         = 0x001200A9,
        Read                       = 0x00120089,
        Write                      = 0x00100116
    }
}
