//-----------------------------------------------------------------------
// <copyright file="AddAssembly.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Jason Birth [4 Feb 08: Mike Fourie - Updated]</author>
// <email>jasonbi</email>
// <date>2004-06-18</date>
// <summary>Adds an assembly to the GAC.</summary>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.GlobalAssemblyCache
{
    using System.IO;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Adds an assembly to the GAC
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<GlobalAssemblyCache.AddAssembly AssemblyPath="assemblyPath" Force="force"/>]]></code>
    /// <para>where:</para>
    /// <para><i>assemblyPath (Required)</i></para>
    /// <para>
    /// The path to the assembly to be added the GAC
    /// </para>
    /// <para><i>force</i></para>
    /// <para>        
    /// Normally if the assembly is already installed in the GAC and the
    /// file version numbers of the assembly being installed are the same
    /// or later, the files are replaced. If force is true the files of an
    /// existing assembly are overwritten regardless of their version
    /// number.
    /// </para>
    /// 
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test">
    ///         <GlobalAssemblyCache.AddAssembly
    ///             AssemblyPath="C:\Temp\sampleAssembly.dll" />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class AddAssembly : TaskBase
    {
        private string assemblyPath;
        private bool force;

        /// <summary>
        /// The path to the assembly to be added the GAC
        /// </summary>
        /// <value>The path to the assembly to be added the GAC</value>
        [Required]
        public string AssemblyPath
        {
            get { return this.assemblyPath; }
            set { this.assemblyPath = value; }
        }

        /// <summary>
        /// Normally if the assembly is already installed in the GAC and the
        /// file version numbers of the assembly being installed are the same
        /// or later, the files are replaced. If force is true the files of an
        /// existing assembly are overwritten regardless of their version
        /// number.
        /// </summary>
        /// <value>
        /// Normally if the assembly is already installed in the GAC and the
        /// file version numbers of the assembly being installed are the same
        /// or later, the files are replaced. If force is true the files of an
        /// existing assembly are overwritten regardless of their version
        /// number.
        /// </value>
        public bool Force
        {
            get { return this.force; }
            set { this.force = value; }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            if (File.Exists(this.AssemblyPath) == false)
            {
                Log.LogError(string.Format("The AssemblyPath was not found: {0}", this.AssemblyPath));
            }
            else
            {
                GacHelper.Install(this.AssemblyPath, this.Force);
            }
        }
    }
}