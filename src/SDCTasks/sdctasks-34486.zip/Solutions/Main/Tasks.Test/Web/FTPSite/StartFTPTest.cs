//-----------------------------------------------------------------------
// <copyright file="CreateFTPTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Ashter Chomoko</author>
// <email>ashter_chomoko@charteris.com</email>
// <date>2004-05-26</date>
// <summary>Unit test for the CreateFTP Task.</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.Globalization;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the CreateFTPTest Task
    /// </summary>
    [TestClass]
    public class StartFtpTest
    {
        private const string MACHINENAME = "localhost";
        

        public StartFtpTest()
        {
        }

        [TestMethod]
        [Ignore]//("Please complete with bug #")]
        public void TestErrorCondition()
        {
            Microsoft.Sdc.Tasks.Web.FtpSite.Start task = new Microsoft.Sdc.Tasks.Web.FtpSite.Start();
           
            Guid guid = Guid.NewGuid();
            string guidString = guid.ToString();

            // Deliberately bad path
            string description = guidString;

            task.Description = description;
            try
            {
                bool taskReturnValue = task.Execute();
                Assert.IsFalse(taskReturnValue, "Should not have returned true when starting this FTP site.");
            }
            catch (ApplicationException)
            {
                string lastMessage = ((PseudoBuildEngine) task.BuildEngine).PreviousMessage;

                // TODO
                // Make sure the error message matches what was expected
                Assert.IsTrue(lastMessage.IndexOf("The given path's format is not supported") >= 0);
            }
        }

        [TestMethod]
        [Ignore]//("Please complete with bug #")]
        public void TestStartFtp()
        {
            //Create FTP Site
            Microsoft.Sdc.Tasks.Web.FtpSite.Create task = new Microsoft.Sdc.Tasks.Web.FtpSite.Create();
           
            Guid guid = Guid.NewGuid();
            string guidString = guid.ToString();
            string path = System.Environment.ExpandEnvironmentVariables(@"%TEMP%\" + guidString + @"\");

            task.Path = path;
            task.Description = guidString;
            task.Execute();

            //Create Virtual Directory
            Microsoft.Sdc.Tasks.Web.FtpSite.CreateVirtualDirectory taskCreateVirtualDirectory = new Microsoft.Sdc.Tasks.Web.FtpSite.CreateVirtualDirectory();
            
            string guidString2 = Guid.NewGuid().ToString();
            Assert.IsFalse(ExistsVirtualDirectory(guidString, guidString2), "Virtual Directory does not exist before Create");
            taskCreateVirtualDirectory.FtpSiteName = guidString;
            taskCreateVirtualDirectory.VirtualDirectoryName = guidString2;
            taskCreateVirtualDirectory.Path = path;
            bool taskReturnValue = taskCreateVirtualDirectory.Execute();
            Assert.IsTrue(taskReturnValue, "CreateVirtualDirectory task returns true");
            Assert.IsTrue(ExistsVirtualDirectory(guidString, guidString2), "Virtual Directory exist after Create");

            //Delete Virtual Directory
            Microsoft.Sdc.Tasks.Web.FtpSite.DeleteVirtualDirectory taskDeleteVirtualDirectory = new Microsoft.Sdc.Tasks.Web.FtpSite.DeleteVirtualDirectory();
            taskDeleteVirtualDirectory.FtpSiteName = guidString;
            taskDeleteVirtualDirectory.VirtualDirectoryName = guidString2;
            taskReturnValue = taskDeleteVirtualDirectory.Execute();
            Assert.IsTrue(taskReturnValue, "DeleteVirtualDirectory task returns true");
            Assert.IsFalse(ExistsVirtualDirectory(guidString, guidString2), "Virtual Directory does not exist after Delete");

            //Start FTP Site
            Microsoft.Sdc.Tasks.Web.FtpSite.Start taskStart = new Microsoft.Sdc.Tasks.Web.FtpSite.Start();
            taskStart.Description = guidString;
            taskReturnValue = taskStart.Execute();
            Assert.IsTrue(taskReturnValue, "Start task returns true");

            //Stop FTP Site
            Microsoft.Sdc.Tasks.Web.FtpSite.Stop taskStop = new Microsoft.Sdc.Tasks.Web.FtpSite.Stop();
            taskStop.Description = guidString;
            bool taskReturnValue2 = taskStop.Execute();
            Assert.IsTrue(taskReturnValue2, "Stop task returns true");

            //Delete FTP Site
            Microsoft.Sdc.Tasks.Web.FtpSite.DeleteFtpSite taskDelete = new Microsoft.Sdc.Tasks.Web.FtpSite.DeleteFtpSite();
            taskDelete.Description = guidString;
            bool taskReturnValue3 = taskStop.Execute();
            Assert.IsTrue(taskReturnValue3, "Delete task returns true");

            //Check site does not exist
            Assert.IsFalse(Microsoft.Sdc.Tasks.Configuration.Web.FtpSite.Exists(guidString), "FTP Exists");

        }

        internal bool ExistsVirtualDirectory(string siteName, string virtualDirectory)
        {
            int identifier = Microsoft.Sdc.Tasks.Configuration.Web.FtpSite.GetIdentifierFromDescription(MACHINENAME, siteName);

            //VirtualDirectory.Exists always returns FALSE?? 
            //bool exists = Microsoft.Sdc.Tasks.Configuration.Web.VirtualDirectory.Exists(virtualDirectory, identifier, MACHINENAME);

            //but its implementation below works fine??
            try
            {
                if (System.DirectoryServices.DirectoryEntry.Exists("IIS://" + MACHINENAME + "/MSFTPSVC/" + Convert.ToString(identifier, CultureInfo.InvariantCulture) + "/root/" + virtualDirectory))
                {
                    return true;
                }
            }
            catch
            {
                return false;
            }
            return false;           
        }
    }
}
