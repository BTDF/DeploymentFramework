//-------------------------------------------------------------------------------------
// <copyright file="Exists.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//     Checks if a ReceiveHandler Exists in Biztalk.
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.SendHandler
{
    #region Using directives
    using Microsoft.Sdc.Tasks.BizTalk2004;
    using Microsoft.BizTalk.ExplorerOM;
    using Microsoft.Build.Framework;
    #endregion

    /// <summary>
    /// Checks whether a SendHandler exists in a BizTalk installation.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2006.SendHandler.Exists 
    ///         HostName="hostname" 
    ///         TransportType="FILE" 
    ///         Server="server" 
    ///         Database="database" />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>HostName (Required)</i></para>
    /// <para>
    /// The host to check for the handler.
    /// </para>
    /// <para><i>TransportType (Required)</i></para>
    /// <para>
    /// The transport type of the handler - FILE, FTP etc
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <PropertyGroup>
    ///         <BTSReceivHandlerExists />
    ///     </PropertyGroup>
    ///     <Target Name="Test" >
    ///            <BizTalk2006.SendHandler.Exists 
    ///                HostName="BizTalkServerApplication" 
    ///                TransportType="FILE" >
    ///                <Output TaskParameter="HandlerExists" PropertyName="BTSReceivHandlerExists" />
    ///            </BizTalk2006.ReceiveHandler.Exists>
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Exists : BizTalk2004TaskBase
    {
        private string hostName;
        private string transportType;
        private bool handlerExists;

        /// <summary>
        /// The name of the host that should be checked for the handler
        /// </summary>
        /// <value>The name of the host.</value>
        [Required]
        public string HostName
        {
            get { return this.hostName; }
            set { this.hostName = value; }
        }

        /// <summary>
        /// The transport type, e.g. FILE, SQL, SOAP etc
        /// </summary>
        /// <value>The type of the transport.</value>
        [Required]
        public string TransportType
        {
            get { return this.transportType; }
            set { this.transportType = value; }
        }

        /// <summary>
        /// Called to determine if the handler exists
        /// </summary>
        [Output]
        public bool HandlerExists
        {
            get { return this.handlerExists; }
        }

        #region Methods

        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {
            BtsCatalogExplorer explorer = this.GetBtsCatalogExplorer(this.Server, this.Database);

            this.handlerExists = false;
            foreach (SendHandler sh in explorer.SendHandlers)
            {
                if (sh.Host.Name == this.hostName && sh.TransportType.Name == this.TransportType)
                {
                    this.handlerExists = true;
                    return;
                }
            }
        }
        #endregion
    }
}
            
