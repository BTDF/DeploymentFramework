/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.Web {
    using System;
    using System.DirectoryServices;
    using System.ComponentModel;
    using System.Text;
    using System.Collections;


    /// <summary>
    /// Summary description for Recycling.
    /// </summary>
    internal class Recycling {

        private int                   restartTime = 1740;
        private int                   restartRequests = 0;
        private RestartTimeCollection restartSchedule;
        private int                   maximumVirtualMemory;
        private int                   maximumUsedMemory;


        internal Recycling() {
        }

        /// <summary>
        /// This is 'Recycle worker processes (in minutes)'.Default is 1740 minutes. Set to 0 to disable.
        /// </summary>
        public int RestartTime {
            get {
                return restartTime ;
            }
            set {
                restartTime = value;
            }
        }
        /// <summary>
        /// This is 'Recycle worker processes (number of requests)'.Default is 35000 requests. Set to 0 to disable.
        /// </summary>
        public int RestartRequests {
            get {
                return restartRequests ;
            }
            set {
                restartRequests = value;
            }
        }

        /// <summary>
        /// An array of times when the worker process will be restarted.
        /// </summary>
        public RestartTimeCollection RestartSchedule {
            get {
                if (restartSchedule == null) {
                    restartSchedule = new RestartTimeCollection();
                }
                return restartSchedule ;
            }
            /*
            made readonly for FxCop
            set {
                restartSchedule = value;
            }
            */
        }

        internal void SetRestartScheduleArray(Array value) {

            if (value == null || value.Length == 0) {
                return;
            }
            
            foreach(object o in value) {
                RestartSchedule.Add(new RestartTime(o.ToString()));                    
            }           
        }
        /// <summary>
        /// The maximum virtual memory (in megabytes). 0 to disable
        /// </summary>
        public int MaximumVirtualMemory {
            get {
                return maximumVirtualMemory ;
            }
            set {
                maximumVirtualMemory = value;
            }
        }

        /// <summary>
        /// The maximum used memory (in megabytes). 0 to disable
        /// </summary>
        
        public int MaximumUsedMemory {
            get {
                return maximumUsedMemory ;
            }
            set {
                maximumUsedMemory = value;
            }
        }
    }
    
    
}
