using System;
using System.IO;
using System.Diagnostics;
using System.Resources;
using System.Reflection;
using System.Globalization;
using System.Collections;
using Microsoft.Build.Framework;
using Microsoft.Build.Utilities;

namespace Microsoft.Sdc.Tasks
{
    sealed internal class Culture
    {
        private Culture()
        {
        }        
        
        public struct ItemCultureInfo
        {
            public string culture;
            public string cultureNeutralFilename;
        };

        public static ItemCultureInfo GetItemCultureInfo(string name)
        {
            ItemCultureInfo info;
            info.culture = null;

            // If the item is defined as "Strings.en-US.resx", then ...

            // ... base file name will be "Strings.en-US" ...
            string baseFileNameWithCulture = Path.GetFileNameWithoutExtension(name);

            // ... and cultureName will be ".en-US".
            string cultureName = Path.GetExtension(baseFileNameWithCulture);

            // See if this is a valid culture name.
            bool validCulture = false;
            if ((cultureName != null) && (cultureName.Length > 1))
            {
                // ... strip the "." to make "en-US"
                cultureName = cultureName.Substring(1);
                validCulture = CultureStringUtilities.IsValidCultureString(cultureName);
            }

            if (validCulture)
            {
                // A valid culture was found.
                if (info.culture == null || info.culture.Length == 0)
                {
                    info.culture = cultureName;
                }

                // Copy the assigned file and make it culture-neutral
                string extension = Path.GetExtension(name);
                string baseFileName = Path.GetFileNameWithoutExtension(baseFileNameWithCulture);
                string baseFolder = Path.GetDirectoryName(name);
                string fileName = baseFileName + extension;
                info.cultureNeutralFilename = Path.Combine(baseFolder, fileName);
            }
            else
            {
                // No valid culture was found. In this case, the culture-neutral
                // name is the just the original file name.
                info.cultureNeutralFilename = name;
            }

            return info;
        }
    }    
}