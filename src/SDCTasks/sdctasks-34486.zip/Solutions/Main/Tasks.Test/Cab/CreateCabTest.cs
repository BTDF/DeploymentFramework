//-----------------------------------------------------------------------
// <copyright file="CreateCabTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-05-27</date>
// <summary>Tests cab file creation</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the create cab task
    /// </summary>
    [TestClass]
    public class CreateCabTest
    {
        //'Dummy' build engine for testing purposes
        

        /// <summary>
        /// Default constructor
        /// </summary>
        public CreateCabTest()
        {
        }

        /// <summary>
        /// Test the create cab task
        /// </summary>
        [TestMethod]
        public void TestCreateCab()
        {
            //Create a temporary folder and a cab file name
            string cabFolder = TaskTestUtilities.CreateTempFolder();
            string pathToCabFile = cabFolder + "\\" + TaskTestUtilities.GenerateTempFilename("cab");

            try
            {
                //Execute the task
                Tasks.Cab.Create task = new Tasks.Cab.Create();
               
                task.PathToCabFile = pathToCabFile;

                bool taskReturnValue = task.Execute();

                //Test the new cab file was created
                Assert.IsTrue(taskReturnValue);

                Assert.IsTrue(System.IO.File.Exists(pathToCabFile));
            }
            finally
            {
                //Tidy up
                Directory.Delete(cabFolder, true);
            }
        }
    }
}


