﻿//-----------------------------------------------------------------------
// <copyright file="CreateProject.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-07-01</date>
// <summary>Creates a hhp project file from a given decompiled help project folder.</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Help
{
    #region Using directives
    using System;
    using System.Xml;
    using System.Globalization;
    using System.IO;
    using System.Text.RegularExpressions;
    using Microsoft.Win32;
    using Microsoft.Build.Framework;
    using Microsoft.Build.Tasks;
    #endregion
    /// <summary>
    /// Creates a hhp project file from a given decompiled help project folder.
    /// </summary>          
    /// <remarks>
    /// <code><![CDATA[
    /// <Help.CreateProject SourceFolder="folder" />
    /// ]]></code>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class CreateProject : Microsoft.Sdc.Tasks.TaskBase
    {
        private string sourceFolder;
        private string contentsFilename;
        private string chmFilename;
        private string title;
        private string startPage;
        private string projectFilename;

        /// <summary>
        /// Initializes a new instance of the CreateProject class.
        /// </summary>
        public CreateProject()
        {
        }

        /// <summary>
        /// The folder where the decompiled help is located.
        /// </summary>
        /// <value>Must be a full path.</value>
        [Required]
        public string SourceFolder
        {
            get { return this.sourceFolder; }
            set { this.sourceFolder = value; }
        }

        /// <summary>
        /// The filename of the hhc file holding the contents
        /// </summary>
        /// <value>Must be a filename i.e. documentation.hhc.</value>
        [Required]
        public string ContentsFilename
        {
            get { return this.contentsFilename; }
            set { this.contentsFilename = value; }
        }

        /// <summary>
        /// Chm filename
        /// </summary>
        /// <value>Must be a filename i.e. test.chm.</value>
        [Required]
        public string ChmFilename
        {
            get { return this.chmFilename; }
            set { this.chmFilename = value; }
        }

        /// <summary>
        /// Title of the help
        /// </summary>
        /// <value>A valid help title string</value>
        [Required]
        public string Title
        {
            get { return this.title; }
            set { this.title = value; }
        }

        /// <summary>
        /// The start page for the help
        /// </summary>
        /// <value>A valid help htm page name</value>
        [Required]
        public string StartPage
        {
            get { return this.startPage; }
            set { this.startPage = value; }
        }

        /// <summary>
        /// Project file filename
        /// </summary>
        /// <value>A valid hhp filename</value>
        [Required]
        public string ProjectFilename
        {
            get { return this.projectFilename; }
            set { this.projectFilename = value; }
        }
        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            StreamWriter stream = System.IO.File.CreateText(Path.Combine(this.SourceFolder, this.ProjectFilename));
            stream.WriteLine("[OPTIONS]");
            stream.WriteLine("Binary Index=No");
            stream.WriteLine("Compatibility=1.1 or later");
            stream.WriteLine("Compiled file=" + this.ChmFilename);
            stream.WriteLine("Contents file=" + this.ContentsFilename);
            stream.WriteLine("Default Window=MsdnHelp");
            stream.WriteLine("Display compile progress=No");
            stream.WriteLine("Error log file=errors.log");
            stream.WriteLine("Full-text search=Yes");
            stream.WriteLine("Language=0x809 English (United Kingdom)");
            stream.WriteLine("Title=" + this.Title);
            stream.WriteLine("[WINDOWS]");
            stream.WriteLine("MsdnHelp=\"" + this.Title + "\",\"" + this.ContentsFilename + "\",,\"" + this.StartPage + "\", \"" + this.StartPage + "\",,,,,0x62520,220,0x387e,[86,51,872,558],,,,,,,0");
            stream.WriteLine("[FILES]");
            stream.WriteLine("[INFOTYPES]");
            stream.WriteLine("");
            stream.WriteLine("");
            stream.WriteLine("");
            stream.WriteLine("");
            stream.Close();
        }
    }
}