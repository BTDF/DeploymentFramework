//-----------------------------------------------------------------------
// <Deleteright file="ReceiveHandlerTests.cs" company="Microsoft">
// Deleteright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </Deleteright>
// <author>Thomas Manson</author>
// <email>tmanson</email>
// <date>2006-02-16</date>
// <summary>Tests BizTalk 2004 Receive Handler tasks</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test.BizTalk2006
{
    using System;
    using System.Text;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Sdc.Tasks.BizTalk2006;
    using System.Management;

    /// <summary>
    /// Tests the BizTalk 2006 assembly tasks
    /// </summary>
    [TestClass]
    public class ApplicationTests
    {
        public ApplicationTests()
        {
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext)
        {
        }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        [ClassCleanup()]
        public static void MyClassCleanup()
        {
        }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void TestApplicationActions()
        {
            Microsoft.Sdc.Tasks.BizTalk2006.Application.Create createTask = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Create();
            createTask.Application = "MyTestApp";
            createTask.Description = "This is a test app";
            createTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.Application.Exists existsTask = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Exists();
            existsTask.Application = "MyTestApp";
            existsTask.Execute();
            if (!existsTask.DoesExist)
            {
                Assert.Fail("Application does not exist");
            }

            Microsoft.Sdc.Tasks.BizTalk2006.Application.Delete deleteTask = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Delete();
            deleteTask.Application = "MyTestApp";
            deleteTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.Application.Exists existsTask2 = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Exists();
            existsTask2.Application = "MyTestApp";
            existsTask2.Execute();
            if (existsTask2.DoesExist)
            {
                Assert.Fail("Application should not exist, but does.");
            }
        }
    }
}
