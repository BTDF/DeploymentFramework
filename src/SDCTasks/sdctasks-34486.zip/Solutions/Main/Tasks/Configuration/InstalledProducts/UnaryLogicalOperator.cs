using System;

namespace Microsoft.Sdc.Tasks.Configuration.InstalledProducts
{
	/// <summary>
	/// Represents a unary operator (only takes one operand) such as "Not"
	/// </summary>
	public enum UnaryLogicalOperator : byte
	{
		None,
		Not
	}
}
