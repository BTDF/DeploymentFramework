﻿//-------------------------------------------------------------------------------------
// <copyright file="Unbind.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//     Binds the Orchestration SendPorts, ReceivePorts and Host to actual Send Ports Receive Ports and Host
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Orchestration
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;

    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Build.Framework;

    #endregion

    public class Unbind : BizTalk2004TaskBase
    {

        #region member variables 

        private string name;
        private string assemblyName;

        #endregion

        #region properties 

        /// <summary>
        /// The name of the orchestration to configure.
        /// </summary>
        /// <value></value>
        [Required]
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }

        }

        /// <summary>
        /// The name of the assembly that contains the orchestration.
        /// </summary>
        /// <value></value>
        public string AssemblyName
        {
            get { return this.assemblyName; }
            set { this.assemblyName = value; }

        }
        #endregion

        #region methods 

        public Unbind(){}

        protected override void InternalExecute()
        {
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation installation = this.GetInstallation();
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration orchestration = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration.Load(installation.DeployedAssemblies[this.assemblyName], this.name);

            if (orchestration != null)
            {

                //setting the host if specified
                orchestration.Host = null;
                orchestration.Ports.Clear();

                orchestration.Save();
            }
            else
                throw new InvalidOperationException(string.Format("Orchestration {0} does not exist.", this.name));



        }

        #endregion 

    }
}
