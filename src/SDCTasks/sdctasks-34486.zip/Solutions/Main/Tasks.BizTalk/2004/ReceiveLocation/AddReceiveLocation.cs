﻿//-------------------------------------------------------------------------------------
// <copyright file="AddReceiveLocation.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Adds a ReceiveLocation in a BizTalk Server.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.ReceiveLocation
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion
    /// <summary>
    /// Add a Receive Location
    /// </summary>
    public class AddReceiveLocation : BizTalk2004TaskBase
    {
        #region member variables

        private string name;
        private string address;
        private string publicAddress;
        private bool enable = true;

        private string receiveHandler;
        private string receivePipeline;
        private string receivePort;

        private bool endDateEnabled = false;
        private string endDate;

        private bool startDateEnabled = false;
        private string startDate;
        
        private string transportType;
        private string transportTypeData;
        
        private bool serviceWindowEnabled = false;
        private string startTime;
        private string endTime;

        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        public AddReceiveLocation()
        {
        }

        #region properties

        /// <summary>
        /// Gets or sets the name of the receive location.
        /// </summary>
        /// <value>A string representing the name of this receive location.</value>
        [Required]
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        /// <summary>
        /// Gets or sets the address of the receive location.
        /// </summary>
        /// <value>A string representing the address of this receive location.</value>
        [Required]
        public string Address
        {
            get { return this.address; }
            set { this.address = value; }
        }

        /// <summary>
        /// Gets or sets the public address of the receive location.
        /// </summary>
        public string PublicAddress
        {
            get { return this.publicAddress; }
            set { this.publicAddress = value; }
        }

        /// <summary>
        /// Gets and sets the field to enable the receive location.
        /// An enabled receive location cannot be deleted.
        /// </summary>
        public bool Enable
        {
            get { return this.enable; }
            set { this.enable = value; }
        }

        /// <summary>
        /// Gets or sets the receive handler to use for this receive location.
        /// </summary>
        [Required]
        public string ReceiveHandler
        {
            get { return this.receiveHandler; }
            set { this.receiveHandler = value; }
        }

        /// <summary>
        /// Gets or sets the receive pipeline to use to receive messages at this receive location.
        /// </summary>
        [Required]
        public string ReceivePipeline
        {
            get { return this.receivePipeline; }
            set { this.receivePipeline = value; }
        }

        /// <summary>
        /// Gets the receive port that this receive location belongs to.
        /// </summary>
        [Required]
        public string ReceivePort
        {
            get { return this.receivePort; }
            set { this.receivePort = value; }
        }

        /// <summary>
        /// Gets and sets the transport type for this receive location.
        /// </summary>
        [Required]
        public string TransportType
        {
            get { return this.transportType; }
            set { this.transportType = value; }
        }

        /// <summary>
        /// Gets or sets the transport type properties of the receive location.
        /// </summary>
        [Required]
        public string TransportTypeData
        {
            get { return this.transportTypeData; }
            set { this.transportTypeData = value; }
        }

        /// <summary>
        /// Gets or sets the start date of the service window.
        /// </summary>
        public bool StartDateEnabled
        {
            get { return this.startDateEnabled; }
            set { this.startDateEnabled = value; }
        }

        /// <summary>
        /// Gets or sets the start date of the service window.
        /// </summary>
        public string StartDate
        {
            get { return this.startDate; }
            set { this.startDate = value; }
        }

        /// <summary>
        /// Gets or sets the field to enable the end date of the service window.
        /// </summary>
        public bool EndDateEnabled
        {
            get { return this.endDateEnabled; }
            set { this.endDateEnabled = value; }
        }

        /// <summary>
        /// Gets or sets the end date of the service window.
        /// </summary>
        public string EndDate
        {
            get { return this.endDate; }
            set { this.endDate = value; }
        }

        /// <summary>
        /// Gets the service window of this receive location.
        /// </summary>
        public bool ServiceWindowEnabled
        {
            get { return this.serviceWindowEnabled; }
            set { this.serviceWindowEnabled = value; }
        }

        /// <summary>
        /// Gets or sets the start time of the service window.
        /// </summary>
        public string StartTime
        {
            get { return this.startTime; }
            set { this.startTime = value; }
        }

        /// <summary>
        /// Gets or sets the end time of the service window.
        /// </summary>
        public string EndTime
        {
            get { return this.endTime; }
            set { this.endTime = value; }
        }

        #endregion
        
        /// <summary>
        /// The execute method
        /// </summary>
        protected override void InternalExecute()
        {
            // loading
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation installation = this.GetInstallation();
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.ReceivePort receivePort = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.ReceivePort.Load(installation, this.receivePort);

            if (receivePort == null)
            {
                throw new InvalidOperationException("Receive Port does not exist.");
            }

            if (this.receiveHandler != null && (this.transportType == null || this.transportTypeData == null))
            {
                throw new InvalidOperationException("If the ReceiveHandler is specficied, the TransportType and TransportTypeData must also be specified");
            }

            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.ReceiveLocation receiveLocation = new Microsoft.Sdc.Tasks.BizTalk2004.Configuration.ReceiveLocation(receivePort, this.name);

            // setting the properties 
            receiveLocation.Name = this.name;
            receiveLocation.Address = this.address;
            receiveLocation.PublicAddress = this.publicAddress;
            receiveLocation.Enable = this.enable;

            receiveLocation.ReceiveHandler = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.ReceiveHandler.Load(installation, this.receiveHandler, this.transportType);
            if (!string.IsNullOrEmpty(this.receivePipeline))
            {
                string pipelineName;
                string assemblyName;
                SplitQualifiedTypeName(this.receivePipeline, out pipelineName, out assemblyName);

                Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly assembly = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly.Load(installation, assemblyName);
                receiveLocation.ReceivePipeline = assembly.Pipelines[pipelineName];
            }

            receiveLocation.StartDateEnabled = this.startDateEnabled;
            receiveLocation.StartDate = (!string.IsNullOrEmpty(this.startDate)) ? DateTime.Parse(this.startDate) : receiveLocation.StartDate;

            receiveLocation.EndDateEnabled = this.endDateEnabled;
            receiveLocation.EndDate = (!string.IsNullOrEmpty(this.endDate)) ? DateTime.Parse(this.endDate) : receiveLocation.EndDate;

            receiveLocation.TransportType = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Protocol.Load(installation, this.transportType);
            receiveLocation.TransportTypeData = new Microsoft.Sdc.Tasks.BizTalk2004.Configuration.TransportData(this.transportTypeData);

            if (this.serviceWindowEnabled)
            {
                receiveLocation.ServiceWindow = new Microsoft.Sdc.Tasks.BizTalk2004.Configuration.ServiceWindow(true, DateTime.Parse(this.startTime), DateTime.Parse(this.endTime));
            }
            else
            {
                receiveLocation.ServiceWindow = new Microsoft.Sdc.Tasks.BizTalk2004.Configuration.ServiceWindow(false);
            }

            // saving
            receivePort.AddNewReceiveLocation(receiveLocation);
        }
    }
}

