﻿namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using directives

	using System;
	using System.Collections;
	using System.Text;

	#endregion

	internal class BtsRoleCollection : System.Collections.ReadOnlyCollectionBase
	{
		public BtsRoleCollection() { }

		public BtsRole this[string name]
		{
			get
			{
				BtsRole item = null;
				foreach (BtsRole currentitem in this.InnerList)
				{
					if (currentitem.Name == name)
					{
						item = currentitem;
						break;
					}
				}
				return item;

			}
		}
		public BtsRole this[int index]
		{
			get
			{
				return (BtsRole)this.InnerList[index];
			}
		}

		internal void Add(BtsRole item)
		{
			this.InnerList.Add(item);
		}


	}

}
