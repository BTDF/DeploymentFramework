
namespace Microsoft.Sdc.Tasks.BizTalk2004.ReceiveLocation
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion
    
    public class Exists : BizTalk2004TaskBase
    {
        #region member variables

        private string name;
        private string receiveport;
        private bool exists;

        #endregion
        
        #region properties

        /// <summary>
        /// Gets or sets the name of the receive location.
        /// </summary>
        /// <value>A string representing the name of this receive location.</value>
        [Required]
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        /// <summary>
        /// The receive port that this receive location belongs to.
        /// </summary>
        [Required]
        public string ReceivePort
        {
            get { return this.receiveport; }
            set { this.receiveport = value; }
        }

        /// <summary>
        /// Gets whether the receive receive location does exist in the installation
        /// </summary>
        /// <value><b>true</b> if the recive location is exists <b>false</b> otherwise.</value>
        [Output]
        public bool ReceiveLocationExists
        {
            get { return this.exists; }
            protected set { this.exists = value; }
        }


        #endregion
        
        public Exists()
        {
        }

        protected override void InternalExecute()
        {
            //getting the installation and creating the new receive port.
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation installation = this.GetInstallation();
            this.exists = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.ReceiveLocation.Exists(installation, this.receiveport, this.name);
        }
    }
}

