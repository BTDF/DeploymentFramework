﻿//-------------------------------------------------------------------------------------
// <copyright file="BtsPipeline.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      BtsPipeline
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;
    using System.Reflection;

    #endregion

    internal class BtsPipeline : BtsBaseObject
    {
        /// <summary>
        /// Internal Constructor
        /// </summary>
        /// <param name="actualBtsObject">The actual Microsoft.Biztalk.ExplorerOM.BtsPipeline object that object will call.</param>
        /// <param name="catalogExplorer">The Microsoft.Sdc.Tasks.Configuration.BtsCatalogExplorer object.</param>
        internal BtsPipeline(object actualBtsObject, BtsCatalogExplorer catalogExplorer)
        {
            this.btsCatalogExplorer = catalogExplorer;
            this.actualBtsObject = actualBtsObject;
        }

        /// <summary>
        /// Gets the fully qualified name of the pipeline, which includes the name of the assembly that the pipeline was deployed as a part of.
        /// </summary>
        public string AssemblyQualifiedName
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("AssemblyQualifiedName", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>
        /// Gets the full name of the pipeline.
        /// </summary>
        public string FullName
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("FullName", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>
        /// Gets the reference to the containing assembly.
        /// </summary>
        public BtsAssembly BtsAssembly
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("BtsAssembly", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                BtsAssembly assembly = new BtsAssembly(value, this.btsCatalogExplorer);
                return assembly;
            }
        }

        /// <summary>
        /// Gets the type of the pipeline.
        /// </summary>
        public PipelineType Type
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("Type", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (PipelineType)Enum.Parse(typeof(PipelineType), value.ToString());
            }
        }
    }
}
