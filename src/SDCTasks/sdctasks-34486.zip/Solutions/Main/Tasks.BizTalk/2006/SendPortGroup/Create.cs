//-----------------------------------------------------------------------
// <copyright file="Create.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup
{
    using Microsoft.BizTalk.ExplorerOM;

    /// <summary>
    /// Creates a new Send Port Group. This will fail if the group already exists.
    /// </summary>
    public class Create : Microsoft.Sdc.Tasks.BizTalk2004.SendPortGroup.Create
    {
        private string application;
        private string customData;
        private string description;

        /// <summary>
        /// The description of the Send Port Group
        /// </summary>
        public string Description
        {
            get { return this.description; }
            set { this.description = value; }
        }

        /// <summary>
        /// The custom data with the send port group. 
        /// </summary>
        public string CustomData
        {
            get { return this.customData; }
            set { this.customData = value; }
        }

        /// <summary>
        /// The application that this send port belongs to. If this is not specified, the BizTalk 2004 code 
        /// is executed.
        /// </summary>
        public string Application
        {
            get { return this.application; }
            set { this.application = value; }
        }

        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {
            if (string.IsNullOrEmpty(this.Application))
            {
                base.InternalExecute();
            }
            else
            {
                BtsCatalogExplorer explorer = this.GetBtsCatalogExplorer(this.Server, this.Database);

                Application app = explorer.Applications[this.Application];
                if (app != null)
                {
                    SendPortGroup group = app.AddNewSendPortGroup();
                    group.Filter = (!string.IsNullOrEmpty(this.Filter)) ? this.Filter : group.Filter;
                    group.Name = this.Name;
                    group.CustomData = this.CustomData;
                    group.Description = this.Description;
                    foreach (string port in this.SendPorts)
                    {
                        group.SendPorts.Add(explorer.SendPorts[port]);
                    }

                    explorer.SaveChanges();
                }
                else
                {
                    Log.LogError(string.Format(System.Globalization.CultureInfo.InvariantCulture, "Application not found: {0}", this.Application));
                    return;
                }
            }
        }
    }
}
