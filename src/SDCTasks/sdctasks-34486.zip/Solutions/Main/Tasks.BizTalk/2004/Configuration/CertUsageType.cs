

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region using directives
	
	using System;
	
	#endregion

	/// <summary>
	/// Denotes the intended usage of a certificate. 
	/// </summary>
	public enum CertUsageType : int
	{
		/// <summary>
		/// Intended for Encryption and Signature.
		/// </summary>
		Both = 3,
		
		/// <summary>
		/// Intended for Encryption only.
		/// </summary>
		Encryption = 1,
		
		/// <summary>
		/// Not intended for Encryption or Signature.
		/// </summary>
		None = 0,
		
		/// <summary>
		/// Intended for Signature only.
		/// </summary>
		Signature = 2

	}
}

