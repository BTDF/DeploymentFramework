﻿//-----------------------------------------------------------------------
// <copyright file="IsapiFilterTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Giles Knap</author>
// <email>gilesk</email>
// <date>2004-12-07</date>
// <summary>tests for Adding and removing and testing for exististence of ISAPI filters</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Unit test for starting, stopping and pausing web sites
    /// </summary>
    [TestClass]
    public class IsapiFilterTest
    {       
        public IsapiFilterTest()
        {
        }

        [TestMethod]
        public void TestIsapiFilterTests()
        {
            bool result;

            //Add a Filter
            AddFilter("localhost", "Default Web Site", "MyExistsFilter", @"c:\program files\test\test.dll");

            // Test if fiter exists
            result = ExistsFilter("localhost", "Default Web Site", "MyExistsFilter");
            Assert.IsTrue(result, "TestIsapiFilterTests");

            // Delete the filter
            DeleteFilter("localhost", "Default Web Site", "MyExistsFilter");

            // Test if the filter does not exist
            result = ExistsFilter("localhost", "Default Web Site", "MyExistsFilter");
            Assert.IsFalse(result, "TestIsapiFilterTests");

        }

        private void AddFilter(string hostName, string webSiteName, string filterName, string filterPath)
        {
            Tasks.Web.WebSite.AddFilter addFilterTask = new Tasks.Web.WebSite.AddFilter();
            addFilterTask.Description = webSiteName;
            // addFilterTask.HostName = hostName;
            addFilterTask.FilterName = filterName;
            addFilterTask.FilterPath = filterPath;

            bool addFilterTaskReturnValue = addFilterTask.Execute();
            Assert.IsTrue(addFilterTaskReturnValue, "TestAddFilter");
        }

        private bool ExistsFilter(string hostName, string webSiteName, string filterName)
        {
            Tasks.Web.WebSite.FilterExists ExistsFilterTask = new Tasks.Web.WebSite.FilterExists();
            ExistsFilterTask.Description = webSiteName;
           // ExistsFilterTask.HostName = hostName;
            ExistsFilterTask.FilterName = filterName;

            bool ExistsFilterReturnValue = ExistsFilterTask.Execute();
            Assert.IsTrue(ExistsFilterReturnValue, "TestAddFilter");
            return ExistsFilterTask.DoesExist;
        }

        private void DeleteFilter(string hostName, string webSiteName, string filterName)
        {
            Tasks.Web.WebSite.DeleteFilter deleteFilterTask = new Tasks.Web.WebSite.DeleteFilter();
            deleteFilterTask.Description = webSiteName;
           // deleteFilterTask.HostName = hostName;
            deleteFilterTask.FilterName = filterName;

            bool deleteFilterTaskReturnValue = deleteFilterTask.Execute();
            Assert.IsTrue(deleteFilterTaskReturnValue, "TestAddFilter");
        }
    }
}