/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.Web {
    using System;
    using System.DirectoryServices;
    using System.ComponentModel;
    using System.Text;
    using System.Collections;


    /// <summary>
    /// Summary description for Identity.
    /// </summary>
    internal class Identity {

        private AppPoolIdentityType type = AppPoolIdentityType.NetworkService;
        private string              name;
        private string              password;
        internal bool               passwordSpecified;

        internal Identity(){
        }
        /// <summary>
        ///Default to NetworkService
        /// </summary>
        public Microsoft.Sdc.Tasks.Configuration.Web.AppPoolIdentityType Type {
            get {
                return type ;
            }
            set {
            
                if (!Enum.IsDefined(typeof(Microsoft.Sdc.Tasks.Configuration.Web.AppPoolIdentityType), value)) {
                    throw new System.ComponentModel.InvalidEnumArgumentException("value", (int)value, typeof(Microsoft.Sdc.Tasks.Configuration.Web.AppPoolIdentityType));
                }
                if (type != value) {
                    type = value;
                }
            }
        }

        public string Name {
            get {
                return (name == null ? String.Empty : name);
            }
            set {
                name = value;
            }
        }

        public string Password {
            get {
                return (password == null ? String.Empty : password);
            }
            set {
                passwordSpecified = true;
                password = value;
            }
        }
    }
}
