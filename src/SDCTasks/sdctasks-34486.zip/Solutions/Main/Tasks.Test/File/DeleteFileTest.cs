//-----------------------------------------------------------------------
// <Deleteright file="DeleteFileTest.cs" company="Microsoft">
// Deleteright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </Deleteright>
// <author>Simon Bell</author>
// <email>andyr</email>
// <date>2004-05-25</date>
// <summary>Tests file Delete task</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;
    using Microsoft.Build.Utilities;

    /// <summary>
    /// Unit test for the Create Guid Task
    /// </summary>
    [TestClass]
    public class DeleteFileTest
    {
        

        public DeleteFileTest()
        {
        }

        

        /// <summary>
        /// Creates a temporary folder and file, runs the File.Delete task, and
        /// independently checks that the file was deleted.
        /// </summary>
        [TestMethod]
        public void TestDeleteFile()
        {
            //Create source directory  
            string sourceDirectory = TaskTestUtilities.CreateTempFolder();

            //Create a file in the source directory
            Guid guid = Guid.NewGuid();
            string guidString = guid.ToString();

            string sourceFilename = guidString + ".temp";
            string sourceFullPath = sourceDirectory + "\\" + sourceFilename;

            //Create a new file
            System.IO.FileStream sourceFile = System.IO.File.Create(sourceFullPath);

            // Add some information to the file.
            Byte[] info = new UTF8Encoding(true).GetBytes("This is some text in the file to be copied.");
            sourceFile.Write(info, 0, info.Length);

            sourceFile.Close();

            //Ensure the file to be deleted is there
            if (!(System.IO.File.Exists(sourceFullPath)))
            {
                Assert.Fail("File to be deleted does not exist");
            }


            // Run the delete file task
            Tasks.File.DeleteFiles task = new Tasks.File.DeleteFiles();
           
            task.Files = new ITaskItem[] { new TaskItem(sourceFullPath) };
            task.Force = true;
            
            bool taskReturnValue = task.Execute();

            Assert.IsTrue(taskReturnValue, "DeleteFileSucceeded");
            Assert.IsTrue(task.Files[0].ItemSpec == sourceFullPath, "DeleteFileProperties");
            Assert.IsTrue(task.Force, "DeleteFileProperties");
            
            //Check that the file has been deleted
            if (System.IO.File.Exists(sourceFullPath))
            {
                Assert.Fail("Deleted file still exists");
            }
        }

        /// <summary>
        /// Creates a temporary folder with spaces and a file within it, runs the File.Delete task, and
        /// independently checks that the file was deleted.
        /// </summary>
        [TestMethod]
        public void TestDeleteFileWithPathSpaces()
        {
            //Create source directory  
            string sourceDirectory = TaskTestUtilities.CreateTempFolderWithSpaces();

            //Create a file in the source directory
            Guid guid = Guid.NewGuid();
            string guidString = guid.ToString();

            string sourceFilename = guidString + ".temp";
            string sourceFullPath = sourceDirectory + "\\" + sourceFilename;

            //Create a new file
            System.IO.FileStream sourceFile = System.IO.File.Create(sourceFullPath);

            // Add some information to the file.
            Byte[] info = new UTF8Encoding(true).GetBytes("This is some text in the file to be copied.");
            sourceFile.Write(info, 0, info.Length);

            sourceFile.Close();

            //Ensure the file to be deleted is there
            if (!(System.IO.File.Exists(sourceFullPath)))
            {
                Assert.Fail("File to be deleted does not exist");
            }


            // Run the delete file task
            Tasks.File.DeleteFiles task = new Tasks.File.DeleteFiles();
           
            task.Files = new ITaskItem[] { new TaskItem(sourceFullPath) };
            task.Force = true;

            bool taskReturnValue = task.Execute();

            Assert.IsTrue(taskReturnValue, "DeleteFileSucceeded");
            Assert.IsTrue(task.Files[0].ItemSpec == sourceFullPath, "DeleteFileProperties");
            Assert.IsTrue(task.Force, "DeleteFileProperties");
            
            //Check that the file has been deleted
            if (System.IO.File.Exists(sourceFullPath))
            {
                Assert.Fail("Deleted file still exists");
            }
        }
    }
}


