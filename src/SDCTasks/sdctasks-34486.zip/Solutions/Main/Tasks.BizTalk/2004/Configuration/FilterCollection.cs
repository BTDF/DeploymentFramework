//-------------------------------------------------------------------------------------
// <copyright file="FilterCollection.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      A collection of BizTalk 2004 objects.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using directives

    using System;
    using System.Collections;

	#endregion

    /// <summary>
    /// A collection of <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Filter"/> objects.
	/// </summary>
	[Serializable]
    public class FilterCollection : CollectionBase
    {
		#region Constructors

        /// <summary>
        /// Creates a new collection of <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Filter"/> objects.
        /// </summary>
        public FilterCollection()
        {
        }

		#endregion

		#region Indexers

        /// <summary>
        /// Gets or sets the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Filter"/> at a specified 
        /// position within the collection.
        /// </summary>
        /// <param name="index">
        /// The zero based index in the collection.
        /// </param>
        /// <value>
        /// A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Filter"/>.
        /// </value>
        public Filter this[int index]
        {
            get 
			{ 
				return (Filter)this.List[index]; 
			}
            set 
			{ 
				this.List[index] = value; 
			}
        }

		#endregion

		#region Methods

        /// <summary>
        /// Adds a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Filter"/> to the collection.
        /// </summary>
        /// <param name="filter">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Filter"/> to add.
        /// </param>
        public void Add(Filter filter) 
        {
            this.List.Add(filter);
        }

		/// <summary>
		/// Gets whether a particular <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Filter"/>
		/// is contained in the collection.
		/// </summary>
		/// <param name="filter">
		/// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Filter"/> to check for.
		/// </param>
		/// <returns>
		/// <b>true</b> if <paramref name="filter"/> is contained in the collection, or <b>false</b> otherwise.
		/// </returns>
		public bool Contains(Filter filter) 
		{
			return this.List.Contains(filter);
		}

		/// <summary>
		/// Copies the collection into an <see cref="System.Array"/>.
		/// </summary>
		/// <param name="objects">
		/// The <see cref="System.Array"/> to copy the collection int.
		/// </param>
		/// <param name="index">
		/// The zero based index in the array at which to begin copying.
		/// </param>
		public void CopyTo(Filter[] objects, int index) 
		{
			this.List.CopyTo(objects, index);
		}

		/// <summary>
		/// Gets the index of a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Filter"/>.
		/// </summary>
		/// <param name="filter">
		/// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Filter"/> to get the index of.
		/// </param>
		/// <returns>
		/// The index of <paramref name="filter"/> if it is contained in the collection, or -1 otherwise.
		/// </returns>
		public int IndexOf(Filter filter) 
		{
			return this.List.IndexOf(filter);
		}

        /// <summary>
        /// Inserts a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Filter"/> into the collection.
        /// </summary>
        /// <param name="index">
        /// The zero based index at which to insert <paramref name="filter"/>.
        /// </param>
        /// <param name="filter">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Filter"/> to insert.
        /// </param>
        public void Insert(int index, Filter filter) 
        {
            this.List.Insert(index, filter);
        }

        /// <summary>
        /// Removes a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Filter"/> from the collection.
        /// </summary>
        /// <param name="filter">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Filter"/> to remove.
        /// </param>
        public void Remove(Filter filter) 
        {
            this.List.Remove(filter); 
        }

		#endregion
    }
}

