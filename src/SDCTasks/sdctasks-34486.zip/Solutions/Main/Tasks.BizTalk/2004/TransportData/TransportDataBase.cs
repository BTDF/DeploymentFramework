namespace Microsoft.Sdc.Tasks.BizTalk2004.TransportData
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;


    #endregion



    public abstract class TransportDataBase : BizTalk2004TaskBase
    {
        #region Member variables

        private string parentType;
        private string transportDataXml;

        #endregion

        #region properties 

        [Required]
        public string ParentType
        {
            get { return this.parentType; }
            set { this.parentType = value; }
        }

        [Output]
        public string TransportDataXml
        {
            get { return this.transportDataXml; }
            set { this.transportDataXml = value; }
        }

        #endregion 

    }
}

