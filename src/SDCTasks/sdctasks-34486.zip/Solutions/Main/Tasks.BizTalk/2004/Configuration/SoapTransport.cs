//-------------------------------------------------------------------------------------
// <copyright file="ReceiveLocation.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Represents a combination of a specific address where the inbound message arrives and the pipeline processes the message.
// </summary>  
//-------------------------------------------------------------------------------------


namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using Directives

	using System;

	#endregion 

	/// <summary>
	/// SoapTransport Wrapper class.
	/// </summary>
	internal class SoapTransport : TransportData
	{
		/// <summary>
		/// Name of the Transport Type
		/// </summary>
		public const string Name = "SOAP";

		#region Constructor

		/// <summary>
		/// Creates a new instance of the Soap Transport Object
		/// </summary>
		/// <param name="parentType"> A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.TransportDataParentType"/> specifying the parent type.</param>
		public SoapTransport(TransportDataParentType parentType)
		{
			this.ParentType = parentType;
		}

		/// <summary>
		/// Creates a new instance of the Soap Transport Object
		/// </summary>
		/// <param name="parentType"> A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.TransportDataParentType"/> specifying the parent type.</param>
		/// <param name="transportDataXml">A string containing the TransportData Xml.</param>
		public SoapTransport(TransportDataParentType parentType, string transportDataXml)
		{
			this.ParentType = parentType;
			this.InitializeFromXml(transportDataXml);
		}
		
		#endregion

		#region common properties

		/// <summary>
		/// Virtual directory containing the Web service on the deployment server.
		/// </summary>
		public string URI
		{
			get
			{
				return this.Items["URI"].Value.ToString();
			}
			set
			{
				if(!this.Items.Contains("URI"))
					this.Items.Add(new TransportDataItem("URI", typeof(string), value));
				else
					this.Items["URI"].Value = value;
			}
		}



		#endregion

		#region receive location properties

		/// <summary>
		/// Public address field containing the entire, callable URL. 
		/// </summary>
		public string AddressableURI
		{
			get
			{
				return this.Items["AddressableURI"].Value.ToString();
			}
			set
			{
				if (this.ParentType == TransportDataParentType.ReceiveLocation)
				{
					if(!this.Items.Contains("AddressableURI"))
						this.Items.Add(new TransportDataItem("AddressableURI", typeof(string), value));
					else
						this.Items["AddressableURI"].Value = value;
				}
				else
					throw new InvalidOperationException("The AddressableURI property can only be set for a receive location.");
			}
		}


		/// <summary>
		/// Specifies whether the Soap adapter will issue the SSO ticket to messages that arrive.
		/// </summary>
		public bool UseSSO
		{
			get
			{
				return (bool) this.Items["UseSSO"].Value;
			}
			set
			{
				if (this.ParentType == TransportDataParentType.ReceiveLocation)
				{

					if(!this.Items.Contains("UseSSO"))
						this.Items.Add(new TransportDataItem("UseSSO", typeof(bool), value));
					else
						this.Items["UseSSO"].Value = value;
				}
				else
					throw new InvalidOperationException("The UseSSO property can only be set for a receive location.");


			}
		}


		#endregion

		#region send port properties

		/// <summary>
		/// User name to specify for accessing the target Web service. 
		/// </summary>
		public string Username
		{
			get
			{
				return this.Items["Username"].Value.ToString();
			}
			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("Username"))
						this.Items.Add(new TransportDataItem("Username", typeof(string), value));
					else
						this.Items["Username"].Value = value;
				}
				else
					throw new InvalidOperationException("The Username property can only be set for send port.");
			}
		}


		/// <summary>
		/// User password to use for authentication with the server.  
		/// </summary>
		public string Password
		{
			get
			{
				return this.Items["Password"].Value.ToString();
			}
			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("Password"))
						this.Items.Add(new TransportDataItem("Password", typeof(string), value));
					else
						this.Items["Password"].Value = value;
				}
				else
					throw new InvalidOperationException("The Password property can only be set for send port.");
			}
		}


		/// <summary>
		/// Thumbprint of client SSL certificate. 
		/// </summary>
		public string ClientCertificate
		{
			get
			{
				return this.Items["ClientCertificate"].Value.ToString();
			}
			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("ClientCertificate"))
						this.Items.Add(new TransportDataItem("ClientCertificate", typeof(string), value));
					else
						this.Items["ClientCertificate"].Value = value;
				}
				else
					throw new InvalidOperationException("The ClientCertificate property can only be set for send port.");
			}
		}
		
		/// <summary>
		/// The name of the SSO application to use to redeem the ticket for client credentials. 
		/// The <b>AffiliateApplicationName</b> is mutually exclusive to a <b>Username></b> and <b>Password</b> pair.
		/// </summary>
		public string AffiliateApplicationName
		{
			get
			{
				return this.Items["AffiliateApplicationName"].Value.ToString();
			}

			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("AffiliateApplicationName"))
						this.Items.Add(new TransportDataItem("AffiliateApplicationName", typeof(string), value));
					else
						this.Items["AffiliateApplicationName"].Value = value;
				}
				else
					throw new InvalidOperationException("The AffiliateApplicationName property can only be set for send port.");
			}
		}

		/// <summary>
		/// Indicates whether the SOAP send port uses a proxy server to access the target Web service. 
		/// </summary>
		public bool UseProxy
		{
			get
			{
				return (bool) this.Items["UseProxy"].Value;
			}

			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{

					if(!this.Items.Contains("UseProxy"))
						this.Items.Add(new TransportDataItem("UseProxy", typeof(bool), value));
					else
						this.Items["UseProxy"].Value = value;
				}
				else
					throw new InvalidOperationException("The UseProxy property can only be set for a send port.");
            }
		}


		/// <summary>
		/// Address of the HTTP proxy to use for the Web service call. 
		/// </summary>
		public string ProxyAddress
		{
			get
			{
				return this.Items["ProxyAddress"].Value.ToString();
			}

			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("ProxyAddress"))
						this.Items.Add(new TransportDataItem("ProxyAddress", typeof(string), value));
					else
						this.Items["ProxyAddress"].Value = value;
				}
				else
					throw new InvalidOperationException("The ProxyAddress property can only be set for send port.");
			}
		}
		
		/// <summary>
		/// Port of the HTTP proxy to use for the Web service call. 
		/// </summary>
		public int ProxyPort
		{
			get
			{
				return Convert.ToInt32(this.Items["ProxyPort"].Value);
			}

			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("ProxyPort"))
						this.Items.Add(new TransportDataItem("ProxyPort", typeof(int), value));
					else
						this.Items["ProxyPort"].Value = value;
				}
				else
					throw new InvalidOperationException("The ProxyPort property can only be set for send port.");
			}
		}

		/// <summary>
		/// User name to use for the proxy. 
		/// </summary>
		public string ProxyUsername
		{
			get
			{
				return this.Items["ProxyUsername"].Value.ToString();
			}

			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("ProxyUsername"))
						this.Items.Add(new TransportDataItem("ProxyUsername", typeof(string), value));
					else
						this.Items["ProxyUsername"].Value = value;
				}
				else
					throw new InvalidOperationException("The ProxyUsername property can only be set for send port.");
			}
		}
		
		/// <summary>
		/// Password to use for the proxy.
		/// </summary>
		public string ProxyPassword
		{
			get
			{
				return this.Items["ProxyPassword"].Value.ToString();
			}

			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("ProxyPassword"))
						this.Items.Add(new TransportDataItem("ProxyPassword", typeof(string), value));
					else
						this.Items["ProxyPassword"].Value = value;
				}
				else
					throw new InvalidOperationException("The ProxyPassword property can only be set for send port.");
			}
		}
		#endregion 
	}
}
