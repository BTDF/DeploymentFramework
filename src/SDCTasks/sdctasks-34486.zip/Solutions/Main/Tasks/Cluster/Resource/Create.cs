//-----------------------------------------------------------------------
// <copyright file="Create.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Mark Phillips</author>
// <email>v-mphill@microsoft.com</email>
// <date>2004-05-24</date>
// <summary>Creates a Cluster Resource.</summary>
//-----------------------------------------------------------------------
#if CLUSTER
namespace Microsoft.Sdc.Tasks.Cluster.Resource
{
    #region Using directives

    using System;
    using System.Globalization;
    using System.Reflection;
    using System.Collections;
    using System.Runtime.InteropServices;
    using Microsoft.Cluster.Interop;
    using Microsoft.Build.Framework;

    #endregion

    /// <summary>
    /// Creates a Cluster Resource
    /// </summary>          
    /// <remarks>
    /// <code><![CDATA[
    /// <Cluster.Resource.Create
    ///             Group="group" 
    ///             Resource="resource"
    ///             Type="type"
    ///             Monitor="monitor"
    ///             Cluster="cluster" >
    /// </Cluster.Resource.Property>
    /// ]]></code>
    /// <para>where:</para>
    /// <para><i>group (Required)</i></para>
    /// <para>TODO</para>
    /// <para><i>resource (Required)</i></para>
    /// <para>TODO</para>
    /// <para><i>type (Required)</i></para>
    /// <para></para>
    /// <para><i>monitor</i></para>
    /// <para>TODO</para>
    /// <para><i>cluster</i></para>
    /// <para>TODO</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <Cluster.Resource.Create
    ///             Resource="TODO"
    ///             Group="TODO"
    ///             Type="TODO"
    ///         </Cluster.Resource.Create> 
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Create : TaskBase
    {
        private string clusterName = String.Empty;
        private string resourceName = String.Empty;
        private string resourceType = String.Empty;
        private string groupName = String.Empty;
        private string monitorType = "Default";
        private Microsoft.Cluster.Interop.Cluster cluster = null;

        /// <summary>
        /// Initializes a new instance of the Create class.
        /// </summary>
        public Create()
        {
        }

        public string Cluster
        {
            get
            {
                return (this.clusterName == null ? String.Empty : this.clusterName);
            }

            set
            {
                this.clusterName = value;
            }
        }

        [Required]
        public string Resource
        {
            get
            {
                return (this.resourceName == null ? String.Empty : this.resourceName);
            }

            set
            {
                this.resourceName = value;
            }
        }

        [Required]
        public string Type
        {
            get
            {
                return (this.resourceType == null ? String.Empty : this.resourceType);
            }

            set
            {
                this.resourceType = value;
            }
        }

        [Required]
        public string Group
        {
            get
            {
                return (this.groupName == null ? String.Empty : this.groupName);
            }

            set
            {
                this.groupName = value;
            }
        }

        public string Monitor
        {
            get
            {
                return (this.monitorType == null ? String.Empty : this.monitorType);
            }

            set
            {
                this.monitorType = value;
            }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            if (this.monitorType != "Default" && this.monitorType != "Separate")
            {
                throw new TaskException("ClusterServer.InvalidMonitor");
            }

            if (this.resourceName == null || this.resourceName.Length == 0)
            {
                throw new TaskException("ClusterServer.InvalidResource");
            }

            if (this.resourceType == null || this.resourceType.Length == 0)
            {
                throw new TaskException("ClusterServer.InvalidResourceType");
            }

            try
            {
                this.cluster = new Microsoft.Cluster.Interop.Cluster();
                if (this.clusterName == null || this.clusterName.Length == 0)
                {
                    this.cluster.Open("");
                }
                else
                {
                    this.cluster.Open(this.clusterName);
                }
            }
            catch (Exception)
            {
                throw new TaskException("ClusterServer.FailConnect", ((this.clusterName == null || this.clusterName.Length == 0) ? "localhost" : this.clusterName));
            }

            Microsoft.Cluster.Interop.ClusResources resources = this.cluster.Resources;

            try
            {
                Microsoft.Cluster.Interop.ClusResource resource = resources.CreateItem(this.resourceName, this.resourceType, this.groupName, (this.monitorType == "Default" ? CLUSTER_RESOURCE_CREATE_FLAGS.CLUSTER_RESOURCE_DEFAULT_MONITOR : CLUSTER_RESOURCE_CREATE_FLAGS.CLUSTER_RESOURCE_SEPARATE_MONITOR));
            }
            catch (Exception)
            {
                throw new TaskException("ClusterServer.Create", new string[] { this.resourceName, this.groupName });
            }

            Console.WriteLine(String.Format(CultureInfo.InvariantCulture, "Resource {0} has been created.", this.resourceName));
        }
    }
}
#endif