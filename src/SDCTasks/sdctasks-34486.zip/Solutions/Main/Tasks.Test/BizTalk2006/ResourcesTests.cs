using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Globalization;

namespace Microsoft.Sdc.Tasks.Test.BizTalk2006
{
    /// <summary>
    /// Summary description for ResourcesTests
    /// </summary>
    [TestClass]
    public class ResourcesTests
    {
        private static readonly string APPNAME= "BAMApp";

        public ResourcesTests()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        #region Additional test attributes

        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext) 
        {
            Microsoft.Sdc.Tasks.BizTalk2006.Application.Create createApp = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Create();
            createApp.Application = ResourcesTests.APPNAME;
            createApp.Execute();
        }
        
        // Use ClassCleanup to run code after all tests in a class have run
        [ClassCleanup()]
        public static void MyClassCleanup() 
        {
            Microsoft.Sdc.Tasks.BizTalk2006.Application.Delete deleteAppTask = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Delete();
            deleteAppTask.Application = ResourcesTests.APPNAME;
            deleteAppTask.Execute();
        }
        
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        //public void MyTestInitialize() 
        //{ 
        //}
        
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        //public void MyTestCleanup() 
        //{
        //}
        
        #endregion

        [TestMethod]
        public void TestResourcesActions()
        {
            // Testing in adding resources, including BizTalk.
            // Add a .NET Assembly
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.DeployResource resource1 = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.DeployResource();
            resource1.Application = ResourcesTests.APPNAME;
            resource1.ResourceType = "System.BizTalk:Assembly";
            resource1.AssemblyPath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\Microsoft.Samples.BizTalk.BamEndToEnd.Components.dll";
            resource1.Overwrite= true;
            resource1.Options = "GacOnAdd,GacOnInstall";
            resource1.Execute();

            // Add a BizTalk Assembly
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.DeployResource resource2 = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.DeployResource();
            resource2.Application = ResourcesTests.APPNAME;
            resource2.ResourceType = "System.BizTalk:BizTalkAssembly";
            resource2.AssemblyPath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\Microsoft.Samples.BizTalk.BamEndToEnd.Services.dll";
            resource2.Overwrite = true;
            resource2.Options = "GacOnAdd,GacOnInstall";
            resource2.Execute();

            // Add a Xml Binding file, as Development
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.DeployResource resource3 = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.DeployResource();
            resource3.Application = ResourcesTests.APPNAME;
            resource3.ResourceType = "System.BizTalk:BizTalkBinding";
            resource3.AssemblyPath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\BAMEndToEndBinding.xml";
            resource3.Overwrite = true;
            resource3.Properties = "TargetEnvironment=Deployment";
            resource3.Execute();

            // Add a Xml BAM file
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.DeployResource resource4 = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.DeployResource();
            resource4.Application = ResourcesTests.APPNAME;
            resource4.ResourceType = "System.BizTalk:Bam";
            resource4.AssemblyPath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\BAMEndToEnd.xml";
            resource4.Overwrite = true;
            resource4.Execute();

            // Check if the resources are added
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.ExistsResource exists1 = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.ExistsResource();
            exists1.Application = ResourcesTests.APPNAME;
            exists1.ResourceType = "System.BizTalk:Assembly";
            exists1.ResourcePath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\Microsoft.Samples.BizTalk.BamEndToEnd.Components.dll";
            exists1.Execute();

            if (!exists1.DoesExist)
            {
                Assert.Fail(string.Format(CultureInfo.InvariantCulture, "Assembly {0} was expected to exist", exists1.ResourcePath));
            }

            // Check if the resources are added
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.ExistsResource exists2 = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.ExistsResource();
            exists2.Application = ResourcesTests.APPNAME;
            exists2.ResourceType = "System.BizTalk:BizTalkAssembly";
            exists2.ResourcePath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\Microsoft.Samples.BizTalk.BamEndToEnd.Services.dll"; 
            exists2.Execute();

            if (!exists2.DoesExist)
            {
                Assert.Fail(string.Format(CultureInfo.InvariantCulture, "Assembly {0} was expected to exist", exists2.ResourcePath));
            }

            // Check if the resources are added
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.ExistsResource exists3 = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.ExistsResource();
            exists3.Application = ResourcesTests.APPNAME;
            exists3.ResourceType = "System.BizTalk:BizTalkBinding";
            exists3.ResourcePath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\BAMEndToEndBinding.xml";
            exists3.Execute();

            if (!exists3.DoesExist)
            {
                Assert.Fail(string.Format(CultureInfo.InvariantCulture, "Assembly {0} was expected to exist", exists3.ResourcePath));
            }

            // Check if the resources are added
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.ExistsResource exists4 = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.ExistsResource();
            exists4.Application = ResourcesTests.APPNAME;
            exists4.ResourceType = "System.BizTalk:Bam";
            exists4.ResourcePath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\BAMEndToEnd.xml";
            exists4.Execute();

            if (!exists4.DoesExist)
            {
                Assert.Fail(string.Format(CultureInfo.InvariantCulture, "Assembly {0} was expected to exist", exists4.ResourcePath));
            }

            // Remove .NET assemblie
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.UndeployResource undeploy1Task = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.UndeployResource();
            undeploy1Task.Application = ResourcesTests.APPNAME;
            undeploy1Task.ResourceType = "System.BizTalk:Assembly";
            undeploy1Task.AssemblyPath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\Microsoft.Samples.BizTalk.BamEndToEnd.Components.dll";
            undeploy1Task.Execute();

            // Remove BizTalk assemblie
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.UndeployResource undeploy2Task = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.UndeployResource();
            undeploy2Task.Application = ResourcesTests.APPNAME;
            undeploy2Task.ResourceType = "System.BizTalk:BizTalkAssembly";
            undeploy2Task.AssemblyPath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\Microsoft.Samples.BizTalk.BamEndToEnd.Services.dll";
            undeploy2Task.Execute();

            // Remove Xml Binding
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.UndeployResource undeploy3Task = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.UndeployResource();
            undeploy3Task.Application = ResourcesTests.APPNAME;
            undeploy3Task.ResourceType = "System.BizTalk:BizTalkBinding";
            undeploy3Task.AssemblyPath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\BAMEndToEndBinding.xml";
            undeploy3Task.Execute();

            // Remove Bam file
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.UndeployResource undeploy4Task = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.UndeployResource();
            undeploy4Task.Application = ResourcesTests.APPNAME;
            undeploy4Task.ResourceType = "System.BizTalk:Bam";
            undeploy4Task.AssemblyPath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\BAMEndToEnd.xml";
            undeploy4Task.Execute();
        }
    }
}
