using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Sdc.Tasks.Network;
//-----------------------------------------------------------------------
// <Deleteright file="GetIPByHostNameTest.cs" company="Microsoft">
// Deleteright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </Deleteright>
// <author>Martin peck</author>
// <email>mpeck</email>
// <date>2006-02-21</date>
// <summary>Tests GetIPByName task</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using System.Text;
    using System.Configuration;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Network;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;
    using Microsoft.Build.Utilities;

    /// <summary>
    /// 
    /// </summary>
    [TestClass]
    public class GetIPByHostNameTest
    {
        public GetIPByHostNameTest()
        {
        }

        /// <summary>
        /// Performs a GetIPByName
        /// </summary>
        [TestMethod]
        public void TestGetIPByHostName()
        {
            string hostname = ConfigurationManager.AppSettings["TestGetIPByNameHost"];

            GetIPByHostName task = new GetIPByHostName();
            task.HostName = hostname;
            task.Execute();

            Assert.IsNotNull(task.IPAddress, "IPAddress property should not be null");
            Assert.IsFalse(task.IPAddress.Length == 0, "IPAddress.Length should be length greater than 0");
            Assert.IsNotNull(task.AllIPAddresses, "AllIPAddresses array should not be null");
            Assert.IsFalse(task.AllIPAddresses.Length == 0, "AllIPAddresses.Length should be greater than 0");
            Assert.IsTrue(task.HostExists, "HostExists should return true for {0}", hostname);
            
            foreach (string address in task.AllIPAddresses)
            {
                Console.WriteLine("IP Address for {1}: {0}", address, hostname);
            }
        }

        /// <summary>
        /// Performs a GetIPByName with a bad hostname
        /// </summary>
        [TestMethod]     
        [ExpectedException(typeof(ApplicationException))]
        public void TestGetIPByHostNameBad()
        {
            string hostname = ConfigurationManager.AppSettings["TestGetIPByNameHostBad"];

            GetIPByHostName task = new GetIPByHostName();
            task.HostName = hostname;            
            task.Execute();
        }
    }
}


