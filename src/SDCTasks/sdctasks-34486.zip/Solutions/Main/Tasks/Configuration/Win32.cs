/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/

namespace Microsoft.Sdc.Tasks.Configuration 
{
	using System;
	using System.Runtime.InteropServices;
	using BOOL = System.Int32;
	using PACL = System.IntPtr;
	using DWORD = System.UInt32;
	using LPVOID = System.IntPtr;
	using LPCTSTR = System.String;
	using PSECURITY_DESCRIPTOR = System.IntPtr;
	using PSID = System.IntPtr;
	using HLOCAL = System.IntPtr;
	using PUCHAR = System.IntPtr;
	using PDWORD = System.IntPtr;
	using PSID_IDENTIFIER_AUTHORITY = System.IntPtr;
	using UCHAR = System.Byte;
	/// <summary>
	/// Provides wrappers for Win32 functions
	/// </summary>
	internal sealed class Win32 
	{		
		internal const BOOL FALSE = 0;		
		internal const BOOL TRUE = 1;
		internal const int SUCCESS = 0;
		internal const int ERROR_INSUFFICIENT_BUFFER = 122;
		internal const int ERROR_NONE_MAPPED = 1332;
		
		private Win32() 
		{
		}

		internal static IntPtr AllocGlobal(uint size) 
		{
			return AllocGlobal((int)size);
		}
		
		internal static IntPtr AllocGlobal(int size) 
		{
			return Marshal.AllocHGlobal(size);
		}
		internal static void FreeGlobal(IntPtr ptr) 
		{
			if (ptr == IntPtr.Zero)	return;
			Marshal.FreeHGlobal(ptr);
		}
		
		internal static DWORD GetLastError() 
		{
			return (DWORD)Marshal.GetLastWin32Error();
		}
		
		internal static void ThrowLastError() 
		{
			Marshal.ThrowExceptionForHR(Marshal.GetHRForLastWin32Error());
		}
		
		internal static void CheckCall(bool funcResult) 
		{
			if (!funcResult) ThrowLastError();
		}
		
		internal static void CheckCall(BOOL funcResult) 
		{
			CheckCall(funcResult != 0);
		}
	}
}
