﻿using System;

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	/// <summary>
	/// Denotes the type modifier of the orchestration port.
	/// </summary>
	public enum PortModifier: int
	{
		/// <summary>
		/// Inbound port of the orchestration.
		/// </summary>
		Export = 2,

		/// <summary>
		/// Outbound port of the orchestration. 
		/// </summary>
		Import = 1

	}
}

