//-------------------------------------------------------------------------------------
// <copyright file="Create.cs" company="Microsoft">
//      Copyright (c) Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <author>Greg Beech</author>
// <email>gregbee@microsoft.com</email>
// <date>2004-04-20</date>
// <summary>
//      Creates a share on either the local or a remote machine.
// </summary>
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Folder.Share
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Management;
    using System.Text;

    using Microsoft.Build.Framework;
    using Microsoft.Build.Utilities;

    #endregion

    #region Class Comments
    /// <summary>
    /// Checks whether a share exists on either the local or a remote machine.
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<Share.Exists ShareName="shareName" Machine="machine" UserName="userName" Password="password" />]]></code>
    /// <para>where:</para>
    /// <para><i>shareName (Required)</i></para>
    /// <para>
    /// The name of the share to check for.
    /// </para>
    /// <para><i>machine</i></para>
    /// <para>
    /// The name or IP address of the machine to check for the share on. The default is the local machine.
    /// </para>
    /// <para><i>userName</i></para>
    /// <para>
    /// If different credentials are needed to connect to a remote machine, this is the user name in the form 
    /// DOMAIN\Username. This must not be supplied for the local machine. The default is to use the same
    /// credentials as the user the task is running as.
    /// </para>
    /// <para><i>password</i></para>
    /// <para>
    /// The password for the user account specified by <i>userName</i>. The default is no password.
    /// </para>
    /// <para><i>DoesExist (Output)</i></para>
    /// <para>
    /// <b>true</b> if the share does exist, or <b>false</b> otherwise.
    /// </para>
    /// <seealso cref="Microsoft.Sdc.Tasks.Folder.Share.Create"/>
    /// <seealso cref="Microsoft.Sdc.Tasks.Folder.Share.DeleteShare"/>
    /// <seealso cref="Microsoft.Sdc.Tasks.Folder.Share.Connect"/>
    /// <seealso cref="Microsoft.Sdc.Tasks.Folder.Share.Disconnect"/>
    /// </remarks>
    /// <example>
    /// The following example shows how this task may be used with the Share.Delete task to
    /// conditionally delete a share.
    /// <code><![CDATA[
    /// <Project>
    ///     <PropertyGroup>
    ///         <SoftwareShareExists />
    ///     </PropertyGroup>
    ///     <Target Name="Test">
    ///         <Share.Exists
    ///             ShareName="Software" 
    ///             Machine="MyMachine" 
    ///             UserName="domain\username" 
    ///             Password="password1">
    ///             <Output TaskParameter="DoesExist" PropertyName="SoftwareShareExists" />
    ///         </Share.Exists>
    ///         <Share.Delete
    ///             Condition="'$(SoftwareShareExists)'=='true'"
    ///             ShareName="Software" 
    ///             Machine="MyMachine" 
    ///             UserName="domain\username" 
    ///             Password="password1" />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    #endregion
    public class Exists : ShareTaskBase
    {
        #region Member Variables

        private bool doesExist;

        #endregion

        #region Constructors

        /// <summary>
        /// Creates a new task to check whether a share exists.
        /// </summary>
        public Exists()
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets whether the share does exist.
        /// </summary>
        /// <value>
        /// <b>true</b> if the share does exist, or <b>false</b> otherwise.
        /// </value>
        [Output]
        public bool DoesExist
        {
            get
            {
                return this.doesExist;
            }
        }

        #endregion

        #region Protected Methods

        /// <summary>
        /// Executes the task
        /// </summary>
        protected override void InternalExecute()
        {
            //connect to the machine and get the share
            ManagementScope scope = this.GetManagementScope();
            string sharePathString = string.Concat("Win32_Share.Name='", this.ShareName, "'");
            ManagementPath sharePath = new ManagementPath(sharePathString);
            ManagementObject shareObject = new ManagementObject(scope, sharePath, null);

            //bind to the share to see if it exists
            try
            {
                shareObject.Get();
                this.doesExist = true;
            }
            catch (ManagementException)
            {
                this.doesExist = false;
            }
        }

        #endregion
    }
}