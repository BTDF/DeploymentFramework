//-----------------------------------------------------------------------
// <copyright file="AddFileToZipTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>andyr</email>
// <date>2004-05-25</date>
// <summary>Tests zip file creation</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.Globalization;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the Create Guid Task
    /// </summary>
    [TestClass]
    public class AddFileToZipTest
    {
        

        public AddFileToZipTest()
        {
        }

        [TestMethod]
        //[Ignore("Breaking the build...")]
        public void TestAddAndExtractFileToZip()
        {
            //Create a temp directory
            string pathToZipFolder = TaskTestUtilities.CreateTempFolder();
            string pathToFileFolder = TaskTestUtilities.CreateTempFolder();
            string pathToExtractFolder = TaskTestUtilities.CreateTempFolder();

            try
            {
                //Set the zip file name
                string pathToZipFile = pathToZipFolder + ("\\testZip.zip");

                //Create the zip file
                Tasks.Zip.Create createZipTask = new Tasks.Zip.Create();
                
                createZipTask.PathToZipFile = pathToZipFile;
                bool taskReturnValue = createZipTask.Execute();

                Assert.IsTrue(taskReturnValue);
                Assert.IsTrue(System.IO.File.Exists(pathToZipFile));

                //Check properties
                Assert.IsTrue( createZipTask.PathToZipFile == pathToZipFile);

                //Create the files to be added
                int NUM_ADD_FILES = 2;
                string[] addToZipFiles = new string[NUM_ADD_FILES];
                taskReturnValue = false;

                Tasks.Zip.AddFile addFileTask = new Tasks.Zip.AddFile();
                addFileTask.PathToZipFile = pathToZipFile;

                
                for (int i = 0; i < NUM_ADD_FILES; i++)
                {
                    addToZipFiles[i] = TaskTestUtilities.CreateTempFileInFolder("addFile" + i.ToString(CultureInfo.InvariantCulture), pathToFileFolder);

                    addFileTask.PathToFile = pathToFileFolder + "\\" + addToZipFiles[i];
                    taskReturnValue = addFileTask.Execute();

                    //Test the file was added
                    Assert.IsTrue(taskReturnValue);
                    Assert.IsTrue(addFileTask.PathToFile == pathToFileFolder + "\\" + addToZipFiles[i]);
                }

                Assert.IsTrue(addFileTask.PathToZipFile == pathToZipFile);

                //Ensure that these files can be extracted

                Tasks.Zip.ExtractFile extractTask = new Tasks.Zip.ExtractFile();
                extractTask.PathToZipFile = pathToZipFile;
                extractTask.PathToFile = pathToExtractFolder;

                
                for (int i = 0; i < NUM_ADD_FILES; i++)
                {
                    string fileToExtract = Path.Combine(pathToFileFolder, addToZipFiles[i]).Substring(3);
                    extractTask.FileToExtract = fileToExtract;
                    taskReturnValue = extractTask.Execute();

                    Assert.IsTrue(taskReturnValue);
                    Assert.IsTrue(extractTask.FileToExtract == fileToExtract);

                    Assert.IsTrue(System.IO.File.Exists(Path.Combine(pathToExtractFolder, fileToExtract)));
                }

                Assert.IsTrue(extractTask.PathToZipFile == pathToZipFile);
                Assert.IsTrue(extractTask.PathToFile == pathToExtractFolder);

            }
            finally
            {
                Directory.Delete(pathToZipFolder, true);
                Directory.Delete(pathToFileFolder, true);
                Directory.Delete(pathToExtractFolder, true);
            }
        }

        [TestMethod]
        public void TestUninitializedCreateTaskFails()
        {
            Tasks.Zip.Create task = new Tasks.Zip.Create();
           
            try
            {
                bool taskReturnValue = task.Execute();
                Assert.Fail("Uninitialised tasks should not succeed.");
            }
            catch (ApplicationException)
            {
                Console.WriteLine("Correctly threw exception");
                Console.WriteLine(((PseudoBuildEngine) task.BuildEngine).PreviousMessage);
            }
        }

        [TestMethod]
        //[Ignore("Please complete with bug #")]
        public void TestUninitializedAddFileTaskFails()
        {
            Tasks.Zip.AddFile task = new Tasks.Zip.AddFile();
           
            try
            {
                bool taskReturnValue = task.Execute();
                Assert.Fail("Uninitialised tasks should not succeed.");
            }
            catch (ApplicationException)
            {
                Console.WriteLine("Correctly threw exception");
                Console.WriteLine(((PseudoBuildEngine) task.BuildEngine).PreviousMessage);
            }
        }

        [TestMethod]
        //[Ignore("Please complete with bug #")]
        public void TestUninitializedExtractFileTaskFails()
        {
            Tasks.Zip.ExtractFile task = new Tasks.Zip.ExtractFile();
           
            try
            {
                bool taskReturnValue = task.Execute();
                Assert.Fail("Uninitialised tasks should not succeed.");
            }
            catch (ApplicationException)
            {
                Console.WriteLine("Correctly threw exception");
                Console.WriteLine(((PseudoBuildEngine) task.BuildEngine).PreviousMessage);
            }
        }
    }
}


