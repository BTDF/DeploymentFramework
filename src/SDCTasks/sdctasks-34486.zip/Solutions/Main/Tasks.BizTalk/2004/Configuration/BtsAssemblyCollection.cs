﻿//-----------------------------------------------------------------------
// <copyright file="BtsAssemblyCollection.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <summary>BtsAssemblyCollection</summary>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;

    #endregion

    internal class BtsAssemblyCollection : System.Collections.ReadOnlyCollectionBase
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public BtsAssemblyCollection() 
        { 
        }

        /// <summary>
        /// Indexer
        /// </summary>
        /// <param name="displayName">displayName</param>
        /// <returns></returns>
        public BtsAssembly this[string displayName]
        {
            get
            {
                BtsAssembly item = null;
                foreach (BtsAssembly currentitem in this.InnerList)
                {
                    if (currentitem.DisplayName == displayName)
                    {
                        item = currentitem;
                        break;
                    }
                }
                return item;
            }
        }

        /// <summary>
        /// Indexer
        /// </summary>
        /// <param name="index">index</param>
        /// <returns></returns>
        public BtsAssembly this[int index]
        {
            get
            {
                return (BtsAssembly)this.InnerList[index];
            }
        }

        internal void Add(BtsAssembly item)
        {
            this.InnerList.Add(item);
        }
    }
}
