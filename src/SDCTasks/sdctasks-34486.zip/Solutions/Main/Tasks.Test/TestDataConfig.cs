//-----------------------------------------------------------------------
// <copyright file="TestDataConfig.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>andyr</email>
// <date>2004-05-25</date>
// <summary>Tests sending an email</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{


    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Configuration;
    using System.Web.Configuration;


    class Config
    {
        private Config()
        { }

        private static string _testDataPathName = WebConfigurationManager.AppSettings["TestDataPathName"];
        private static string _testDataAssemblyName = WebConfigurationManager.AppSettings["TestDataAssemblyName"];
        private static string _testDataPrivateKey = WebConfigurationManager.AppSettings["TestDataPrivateKey"];
        private static string _runtime = WebConfigurationManager.AppSettings["Runtime"];

        static public string TestDataPathName
        {
            get
            {
                return _testDataPathName;
            }
        }

        static public string TestDataAssemblyName
        {
            get
            {
                return _testDataAssemblyName;
            }
        }
        static public string TestDataPrivateKey
        {
            get
            {
                return _testDataPrivateKey;
            }
        }
        static public string Runtime
        {
            get
            {
                return _runtime;
            }
        }
    }
}