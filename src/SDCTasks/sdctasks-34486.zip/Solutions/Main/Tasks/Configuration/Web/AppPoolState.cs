/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
using System;

namespace Microsoft.Sdc.Tasks.Configuration.Web {
	/// <summary>
	/// Summary description for AppPoolStatee.
	/// </summary>
	
	public enum AppPoolState {
		Unknown = 0,
		Starting = 1,
		Started = 2,
		Stopping = 3,
		Stopped = 4,		
	}	
}
