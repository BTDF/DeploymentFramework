//-----------------------------------------------------------------------
// <copyright file="CheckExists.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.ComponentServices.Application
{
    using Microsoft.Sdc.Tasks.Configuration.ComponentServices;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Checks if the specified ComponentServices Application exists
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<ComponentServices.Application.CheckExists ApplicationName="applicationName"/>]]></code>
    /// <para>where:</para>
    /// <para><i>applicationName (Required)</i></para>
    /// <para>The name of the COM+ application to be shutdown. If the application name exists multiple times then all matches will all be deleted.</para>
    /// <para><i>Exists (output)</i></para>
    /// <para>Boolean indicating whether the Application exists</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <ComponentServices.Application.Shutdown ApplicationName="MyApplicationName" />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class CheckExists : TaskBase
    {
        private string applicationName;
        private bool exists;

        /// <summary>
        /// Gets or sets the name of the COM+ application to be shutdown
        /// </summary>
        /// <value>The name of the application that will be shutdown</value>
        [Required]
        public string ApplicationName
        {
            get { return this.applicationName; }
            set { this.applicationName = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="CheckExists"/> is exists.
        /// </summary>
        /// <value><c>true</c> if exists; otherwise, <c>false</c>.</value>
        [Output]
        public bool Exists
        {
            get { return this.exists; }
            set { this.exists = value; }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            Log.LogMessage(string.Format("Checking if Application Exists: {0}", this.ApplicationName));
            this.Exists = Application.Exists(this.ApplicationName);
        }
    }
}