//-------------------------------------------------------------------------------------
// <copyright file="Undeploy.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Undeploy an assembly from BizTalk.
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.Assembly
{
    #region Using directives

    using System;
    using System.Globalization;
    using BizTalk.ApplicationDeployment;

    #endregion

    /// <summary>
    /// Undeploy an assembly from BizTalk.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2004.Assembly.Undeploy AssemblyPath="assemblyPath" SimpleName="simpleName" Version="version" PublicKeyToken="publicKeyToken" Culture="culture" UninstallFromGac="uninstallFromGac" LogPath="logPath" Server="server" Database="database" />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>assemblyPath</i></para>
    /// <para>
    /// The path to the assembly to be undeployed. This is used if supplied, but is not required if 
    /// <i>simpleName</i>, <i>version</i>, <i>publicKeyToken</i> and <i>culture</i> are all supplied.
    /// </para>
    /// <para><i>simpleName</i></para>
    /// <para>
    /// The simple name of the assembly to be undeployed. This is not used if <i>assemblyPath</i> is supplied.
    /// </para>
    /// <para><i>version</i></para>
    /// <para>
    /// The version of the assembly to be undeployed. This is not used if <i>assemblyPath</i> is supplied.
    /// </para>
    /// <para><i>publicKeyToken</i></para>
    /// <para>
    /// The public key token of the assembly to be undeployed. This is not used if <i>assemblyPath</i> is supplied.
    /// </para>
    /// <para><i>culture</i></para>
    /// <para>
    /// The culture of the assembly to be undeployed. This is not used if <i>assemblyPath</i> is supplied.
    /// </para>
    /// <para><i>logPath</i></para>
    /// <para>
    /// The path to the log file for the uninstallation. The default is no log file.
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// <para><i>username</i></para>
    /// <para>
    /// The username to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// <para><i>password</i></para>
    /// <para>
    /// The password to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <!-- Undeploy using the assembly file -->
    ///         <BizTalk2004.Assembly.Undeploy 
    ///             AssemblyPath="C:\Build\Output\MyAssembly.dll" 
    ///             UninstallFromGac="true"
    ///             LogPath="C:\Build\Logs\MyAssemblyUndeploy.log" 
    ///             Server="." 
    ///             Database="BizTalkMgmtDb" 
    ///              
    ///              />
    ///         <!-- Undeploy using the assembly details -->
    ///         <BizTalk2004.Assembly.Undeploy 
    ///             SimpleName="MyAssembly"
    ///             Version="2.0.0.0"
    ///             PublicKeyToken="128bd009fce13573"
    ///             Culture="neutral"
    ///             UninstallFromGac="true"
    ///             LogPath="C:\Build\Logs\MyAssemblyUndeploy.log" 
    ///             Server="." 
    ///             Database="BizTalkMgmtDb" 
    ///              
    ///              />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Undeploy : BizTalk2004.Assembly.Undeploy
    {
        #region Member Variables

        private string application;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the application.
        /// </summary>
        /// <value>The application.</value>
        public string Application
        {
            get { return this.application; }
            set { this.application = value; }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {
            if (string.IsNullOrEmpty(this.Application))
            {
                base.InternalExecute();
            }
            else
            {
                BizTalk2004.Configuration.BizTalkInstallation installation = this.GetInstallation();
                string resourceType = "System.BizTalk:BizTalkAssembly";
                resourceType = SdmParser.GetInstance().TransformResourceType(resourceType);

                using (Group group = new Group())
                {
                    group.DBServer = installation.Server;
                    group.DBName = installation.Database;

                    try
                    {
                        Application app = group.Applications[this.Application];
                        if (app != null)
                        {
                            app.UILevel = 2;

                            string name;
                            if (string.IsNullOrEmpty(this.AssemblyPath))
                            {
                                name = string.Format("{0}, Version={1}, Culture={2}, PublicKeyToken={3}", this.SimpleName, this.Version, this.Culture, this.PublicKeyToken);
                            }
                            else
                            {
                                System.Reflection.Assembly ass = System.Reflection.Assembly.ReflectionOnlyLoadFrom(this.AssemblyPath);
                                name = ass.FullName;
                            }

                            Log.LogMessage(string.Format(CultureInfo.InvariantCulture, "Removing Assembly: {0} from Application: {1}", name, this.Application));
                            app.ResourceCollection.Remove(resourceType, name);
                        }
                        else
                        {
                            Log.LogError(string.Format(CultureInfo.InvariantCulture, "Application not found: {0}", this.Application));
                            return;
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.LogError(string.Format(CultureInfo.InvariantCulture, "Undeploy Assembly failure: {0}", ex));
                        group.Abort();
                        throw;
                    }
                }
            }
        }

        #endregion
    }
}

