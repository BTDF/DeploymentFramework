//-----------------------------------------------------------------------
// <copyright file="Privilege.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <summary>Privilege</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Configuration.ActiveDirectory
{
    using System;
    
    internal enum Privilege
    {
        /// <summary>
        /// 
        /// </summary>
        SeInteractiveLogonRight,
        
        /// <summary>
        /// 
        /// </summary>
        SeNetworkLogonRight,
        
        /// <summary>
        /// Privilege to logon as a batch job
        /// </summary>
        SeBatchLogonRight,
        
        /// <summary>
        /// Privilege to logon as a service
        /// </summary>
        SeServiceLogonRight,
        
        /// <summary>
        /// 
        /// </summary>
        SeDenyInteractiveLogonRight,
        
        /// <summary>
        /// 
        /// </summary>
        SeDenyNetworkLogonRight,
        
        /// <summary>
        /// 
        /// </summary>
        SeDenyBatchLogonRight,
        
        /// <summary>
        /// 
        /// </summary>
        SeDenyServiceLogonRight,
        
        /// <summary>
        /// 
        /// </summary>
        SeRemoteInteractiveLogonRight,
        
        /// <summary>
        /// 
        /// </summary>
        SeDenyRemoteInteractiveLogonRight,
        
        /// <summary>
        /// 
        /// </summary>
        SeIncreaseQuotaPrivilege,
        
        /// <summary>
        /// 
        /// </summary>
        SeAuditPrivilege,
        
        /// <summary>
        /// 
        /// </summary>
        SeAssignPrimaryTokenPrivilege
    }
}
