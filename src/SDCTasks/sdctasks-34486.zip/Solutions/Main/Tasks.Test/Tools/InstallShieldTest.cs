//-----------------------------------------------------------------------
// <copyright file="InstallShieldTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-06-04</date>
// <summary>Unit test for the InstallShield Tools Tasks.</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the InstallShield Test Task
    /// </summary>
    [TestClass]
    public class InstallShieldTest
    {
        

        public InstallShieldTest()
        {
        }

        [TestMethod]
        [Ignore]//("Please complete with bug #")]
        public void TestInstallShieldTask()
        {
            Tools.Installshield installShieldTask = new Tools.Installshield();
            
            string buildPath = "";
            string projectFilePath = "";
            string releaseConfiguration = "";
            string releaseName = "";
            string[] writeableDirectories = new string[2];

            installShieldTask.BuildPath = buildPath;
            installShieldTask.ProjectFilepath = projectFilePath;
            installShieldTask.ReleaseConfiguration = releaseConfiguration;
            installShieldTask.ReleaseName = releaseName;
            installShieldTask.WriteableDirectories = writeableDirectories;

            try
            {
                bool installShieldSuccess = installShieldTask.Execute();

                //Ensure the task was successful
                Assert.IsTrue( installShieldSuccess);

                //Check the properties of the task
                Assert.IsTrue( installShieldTask.BuildPath == buildPath);
                Assert.IsTrue(installShieldTask.ProjectFilepath == projectFilePath);
                Assert.IsTrue( installShieldTask.ReleaseConfiguration == releaseConfiguration);
                Assert.IsTrue( installShieldTask.ReleaseName == releaseName);
                Assert.IsTrue( installShieldTask.WriteableDirectories == writeableDirectories);

            }
            finally
            {

            }
        }

        [TestMethod]
        public void TestUninitialisedTaskFails()
        {
            Tools.Installshield task = new Tools.Installshield();
           

            try
            {
                bool taskReturnValue = task.Execute();
                Assert.Fail("Uninitialised tasks should not succeed.");
            }
            catch (ApplicationException)
            {
                Console.WriteLine("Correctly threw exception");
                Console.WriteLine(((PseudoBuildEngine) task.BuildEngine).PreviousMessage);
            }

        }

    }
}