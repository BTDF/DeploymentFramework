﻿//-------------------------------------------------------------------------------------
// <copyright file="BtsPartyAliasCollection.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      BtsPartyAliasCollection
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;

    #endregion

    internal class BtsPartyAliasCollection : System.Collections.ReadOnlyCollectionBase
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public BtsPartyAliasCollection()
        {
        }

        /// <summary>
        /// Indexer
        /// </summary>
        /// <param name="qualifier">qualiifier</param>
        /// <param name="value">value</param>
        /// <returns></returns>
        public BtsPartyAlias this[string qualifier, string value]
        {
            get
            {
                BtsPartyAlias item = null;
                foreach (BtsPartyAlias currentitem in this.InnerList)
                {
                    if (currentitem.Qualifier == qualifier && currentitem.Value == value)
                    {
                        item = currentitem;
                        break;
                    }
                }
                return item;
            }
        }

        /// <summary>
        /// Indexer
        /// </summary>
        /// <param name="index">index</param>
        /// <returns></returns>
        public BtsPartyAlias this[int index]
        {
            get
            {
                return (BtsPartyAlias)this.InnerList[index];
            }
        }

        internal void Add(BtsPartyAlias item)
        {
            this.InnerList.Add(item);
        }
    }
}