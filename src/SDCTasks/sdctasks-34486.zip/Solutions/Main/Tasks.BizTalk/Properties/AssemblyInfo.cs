﻿//-----------------------------------------------------------------------
// <copyright file="AssemblyInfo.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-03-23</date>
// <summary>All the Assembly level attributes</summary>
//-----------------------------------------------------------------------

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: InternalsVisibleTo("Microsoft.Sdc.Tasks.Test, PublicKey=0024000004800000940000000602000000240000525341310004000001000100458c5dc664132b6f8df40ef03b8c3bdeb48a96ff9e5e1ef0d048d9949b947eac86d80773433ed06cec5111c327e669b33e348f69426a41d59f32c339919a01716843633004cb382f0635a438a23d287386af3947f5473de3100366f6919c133780aa6b55272dcc7927c2573dfaef54fc9216afc553bec934e52c41f811da77ba")]
[assembly: InternalsVisibleTo("Microsoft.Sdc.Tasks.Test2, PublicKey=0024000004800000940000000602000000240000525341310004000001000100458c5dc664132b6f8df40ef03b8c3bdeb48a96ff9e5e1ef0d048d9949b947eac86d80773433ed06cec5111c327e669b33e348f69426a41d59f32c339919a01716843633004cb382f0635a438a23d287386af3947f5473de3100366f6919c133780aa6b55272dcc7927c2573dfaef54fc9216afc553bec934e52c41f811da77ba")]