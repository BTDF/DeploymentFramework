﻿//-----------------------------------------------------------------------
// <copyright file="DriveInfo.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Giles Knap</author>
// <email>gilesk</email>
// <date>2006-03-08</date>
// <summary>
// gets information about system drives
// </summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks
{
    #region Using directives
    using System;
    using System.Text;
    using System.IO;
    using Microsoft.Build.BuildEngine;
    using Microsoft.Build.Framework;
    using Microsoft.Build.Utilities;
    using Microsoft.Build.Shared;
    #endregion


    /// <summary>
    /// Retrieves information about a system drive
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<DriveInfo DriveName="DriveName">
    ///                 <Output TaskParameter="AvailableFreeSpace" PropertyName="out1" />
    ///                 <Output TaskParameter="VolumeLabel" PropertyName="out2" />
    ///                 <Output TaskParameter="TotalSize" PropertyName="out3" />
    ///                 <Output TaskParameter="DriveFormat" PropertyName="out4" />
    ///                </DriveInfo>]]></code>
    /// <para>where:</para>
    /// <para><i>DriveName</i></para>
    /// <para>The name of the drive for which to retreive information</para>
    /// <para><i>AvailableFreeSpace</i></para>
    /// <para>Free space on the disk</para>
    /// <para><i>VolumeLabel</i></para>
    /// <para>the volume label</para>
    /// <para><i>TotalSize</i></para>
    /// <para>total disk space</para>
    /// <para><i>DriveFormat</i></para>
    /// <para>eg. NTFS or FAT32</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <DriveInfo t DriveName="DriveName">
    ///                 <Output TaskParameter="DriveName" PropertyName="out6" />
    ///                 <Output TaskParameter="AvailableFreeSpace" PropertyName="out1" />
    ///                 <Output TaskParameter="VolumeLabel" PropertyName="out2" />
    ///                 <Output TaskParameter="TotalSize" PropertyName="out3" />
    ///                 <Output TaskParameter="DriveFormat" PropertyName="out4" />
    ///         </DriveInfo>
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class DriveInfo : TaskBase
    {
        private long         availableFreeSpace;
        private string      volumeLabel;
        private long         totalSize;
        private string      driveFormat;
        private string      driveName;

        [Output]
        public long AvailableFreeSpace
        {
            get { return availableFreeSpace; }
            set { availableFreeSpace = value; }
        }

        [Output]
        public string VolumeLabel
        {
            get { return volumeLabel; }
            set { volumeLabel = value; }
        }

        [Output]
        public long TotalSize
        {
            get { return totalSize; }
            set { totalSize = value; }
        }

        [Output]
        public string DriveFormat
        {
            get { return driveFormat; }
            set { driveFormat = value; }
        }

        [Required]
        public string DriveName
        {
            get { return driveName; }
            set { driveName = value; }
        }

        public DriveInfo()
        {
        }

        protected override void InternalExecute()
        {
            System.IO.DriveInfo info = new System.IO.DriveInfo(driveName);
            availableFreeSpace = info.AvailableFreeSpace;
            volumeLabel = info.VolumeLabel.ToString();
            totalSize = info.TotalSize;
            driveFormat = info.DriveFormat;
        }
    }
}
