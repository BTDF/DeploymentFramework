﻿namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;

    #endregion

    internal class BtsReceivePortCollection : System.Collections.ReadOnlyCollectionBase
    {
        public BtsReceivePortCollection() { }

        public BtsReceivePort this[string name]
        {
            get
            {
                BtsReceivePort item = null;
                foreach (BtsReceivePort currentitem in this.InnerList)
                {
                    if (currentitem.Name == name)
                    {
                        item = currentitem;
                        break;
                    }
                }
                return item;

            }
        }
        public BtsReceivePort this[int index]
        {
            get
            {
                return (BtsReceivePort)this.InnerList[index];
            }
        }

        internal void Add(BtsReceivePort item)
        {
            this.InnerList.Add(item);
        }


    }

}
