//-----------------------------------------------------------------------
// <copyright file="Update.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation. All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-03-23</date>
// <summary>Updates the specified ComponentServices Component.</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.ComponentServices.Component
{
    using System;
    using Microsoft.Sdc.Tasks.Configuration.ComponentServices;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Updates the specified ComponentServices Component.
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[
    /// <ComponentServices.Component.Update
    ///         ApplicationName="applicationName" 
    ///         ComponentName="componentName" 
    ///         ConstructorString="componentName" />
    /// ]]></code>
    /// <para>where:</para>
    /// <para><i>applicationName (Required)</i></para>
    /// <para>The name of the COM+ application. This application will be created if it does not exist.</para>
    /// <para><i>componentName (Required)</i></para>
    /// <para>The name of the COM+ component to update.</para>
    /// <para><i>constructorString</i></para>
    /// <para>The constructor string for the specified COM+ component.</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <ComponentServices.Component.Update
    ///             ApplicationName="IIS Out-Of-Process Pooled Applications"
    ///             ComponentName="IISWAM.OutofProcessPool"
    ///             ConstructorString="bob" />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Update : TaskBase
    {
        private string applicationName;
        private string componentName;
        private string constructorString = String.Empty;

        #region Public Properties

        /// <summary>
        /// Gets or sets the name of the COM+ application.
        /// </summary>
        /// <value>The name of the COM+ application. This application will be created if it does not exist.</value>
        [Required]
        public string ApplicationName
        {
            get { return this.applicationName; }
            set { this.applicationName = value; }
        }

        /// <summary>
        /// Gets or sets the name of the COM+ component to update.
        /// </summary>
        /// <value>The name of the COM+ component to update.</value>
        [Required]
        public string ComponentName
        {
            get { return this.componentName; }
            set { this.componentName = value; }
        }

        /// <summary>
        /// Gets or sets the constructor string for the specified COM+ component.
        /// </summary>
        /// <value>The constructor string for the specified COM+ component.</value>
        public string ConstructorString
        {
            get { return this.constructorString; }
            set { this.constructorString = value; }
        }

        #endregion

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            #region Execute code

            Log.LogMessageFromResources("ComponentServices.UpdatingComponent", this.componentName);
            Application app = Application.Load(this.applicationName);
            Component comp = app.Components[this.componentName];
            if (comp != null)
            {
                comp.Constructor = this.constructorString;
                comp.ConstructionEnabled = (this.constructorString.Length > 0);
                comp.Save();
            }

            #endregion
        }
    }
}