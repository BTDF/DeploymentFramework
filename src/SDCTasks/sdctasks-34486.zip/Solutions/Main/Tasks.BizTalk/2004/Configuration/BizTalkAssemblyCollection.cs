//-------------------------------------------------------------------------------------
// <copyright file="BizTalkAssemblyCollection.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      A collection of BizTalk 2004 objects.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;

    #endregion

    /// <summary>
    /// A collection of <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> objects.
    /// </summary>
    internal class BizTalkAssemblyCollection : CollectionBase
    {
        #region Constructors

        /// <summary>
        /// Creates a new collection of <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> objects.
        /// </summary>
        public BizTalkAssemblyCollection()
        {
        }

        #endregion

        #region Indexers

        /// <summary>
        /// Gets or sets the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> at a specified 
        /// position within the collection.
        /// </summary>
        /// <param name="index">
        /// The zero based index in the collection.
        /// </param>
        /// <value>
        /// A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/>.
        /// </value>
        public BizTalkAssembly this[int index]
        {
            get { return (BizTalkAssembly)this.List[index]; }
            set { this.List[index] = value; }
        }

        /// <summary>
        /// Gets or sets the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> with
        /// a particular name.
        /// </summary>
        /// <param name="name">
        /// The name of the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/>.
        /// </param>
        /// <value>
        /// A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/>.
        /// </value>
        /// <exception cref="System.ArgumentNullException">
        /// Thrown when <paramref name="name"/> is <b>null</b> or zero length.
        /// </exception>
        /// <exception cref="System.ArgumentOutOfRangeException">
        /// Thrown when no assembly matching <paramref name="name"/> is found in the collection.
        /// </exception>
        public BizTalkAssembly this[string name]
        {
            get
            {
                int index = this.IndexOf(name);
                if (index >= 0)
                {
                    return this[index];
                }
                else
                {
                    throw new ArgumentOutOfRangeException("No assembly with the specified name was found.", name, "name");
                }
            }

            set
            {
                int index = this.IndexOf(name);
                if (index >= 0)
                {
                    this[index] = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException("No assembly with the specified name was found.", name, "name");
                }
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Adds a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> to the collection.
        /// </summary>
        /// <param name="assembly">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> to add.
        /// </param>
        public void Add(BizTalkAssembly assembly)
        {
            this.List.Add(assembly);
        }

        /// <summary>
        /// Gets whether a particular <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/>
        /// is contained in the collection.
        /// </summary>
        /// <param name="assembly">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> to check for.
        /// </param>
        /// <returns>
        /// <b>true</b> if <paramref name="assembly"/> is contained in the collection, or <b>false</b> otherwise.
        /// </returns>
        public bool Contains(BizTalkAssembly assembly)
        {
            return this.List.Contains(assembly);
        }

        /// <summary>
        /// Gets whether a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> with the
        /// specified name is contained in the collection.
        /// </summary>
        /// <param name="name">
        /// The name of the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/>.
        /// </param>
        /// <returns>
        /// <b>true</b> if an assembly with the name is contained in the collection, or <b>false</b> otherwise.
        /// </returns>
        public bool Contains(string name)
        {
            int index = this.IndexOf(name);
            return (index != -1);
        }

        /// <summary>
        /// Copies the collection into an <see cref="System.Array"/>.
        /// </summary>
        /// <param name="objects">
        /// The <see cref="System.Array"/> to copy the collection int.
        /// </param>
        /// <param name="index">
        /// The zero based index in the array at which to begin copying.
        /// </param>
        public void CopyTo(BizTalkAssembly[] objects, int index)
        {
            this.List.CopyTo(objects, index);
        }

        /// <summary>
        /// Gets the index of a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/>.
        /// </summary>
        /// <param name="assembly">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> to get the index of.
        /// </param>
        /// <returns>
        /// The index of <paramref name="assembly"/> if it is contained in the collection, or -1 otherwise.
        /// </returns>
        public int IndexOf(BizTalkAssembly assembly)
        {
            return this.List.IndexOf(assembly);
        }

        /// <summary>
        /// Retrieves the index of a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> from 
        /// the collection with the specified name.
        /// </summary>
        /// <param name="name">
        /// The name of the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/>.
        /// </param>
        /// <returns>
        /// The index of the item if found, or -1 otherwise.
        /// </returns>
        public int IndexOf(string name)
        {
            if (name == null)
            {
                throw new ArgumentNullException("name");
            }
            name = name.Replace(" ", "");
            for (int index = 0; index < this.List.Count; index++)
            {
                if (((BizTalkAssembly)this.List[index]).Name.Replace(" ", "") == name)
                {
                    return index;
                }
            }
            return -1;
        }

        /// <summary>
        /// Inserts a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> into the collection.
        /// </summary>
        /// <param name="index">
        /// The zero based index at which to insert <paramref name="assembly"/>.
        /// </param>
        /// <param name="assembly">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> to insert.
        /// </param>
        public void Insert(int index, BizTalkAssembly assembly)
        {
            this.List.Insert(index, assembly);
        }

        /// <summary>
        /// Removes a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> from the collection.
        /// </summary>
        /// <param name="assembly">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> to remove.
        /// </param>
        public void Remove(BizTalkAssembly assembly)
        {
            this.List.Remove(assembly);
        }

        #endregion
    }
}

