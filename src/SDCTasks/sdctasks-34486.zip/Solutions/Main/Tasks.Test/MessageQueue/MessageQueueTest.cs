//-----------------------------------------------------------------------
// <copyright file="MessageQueueTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-05-28</date>
// <summary>Tests message queue tasks</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    using System.Messaging;

    /// <summary>
    /// Unit test for the testing of the message queue tasks
    /// </summary>
    [TestClass]
    public class MessageQueueTest
    {
        

        private const string QUEUE_PATH = ".\\queueUnitTest";

        public MessageQueueTest()
        {
        }

        

        [TestMethod]
        [Ignore]//("Can't send message on newly created queue. Could it be due to http://support.microsoft.com/default.aspx?scid=kb;en-us;834467&Product=WinXP?")]
        public void TestMessageQueue()
        {
            //Make sure the queue doesn't exist...
            if (System.Messaging.MessageQueue.Exists(QUEUE_PATH))
            {
               System.Messaging.MessageQueue.Delete(QUEUE_PATH);
            }

           Console.WriteLine("ClearedQueue");

           //Create the queue without transactions
            CreateQueue(false);
            Console.WriteLine("CreatedQueue");

            //Use System.Messaging to ensure this queue exists
            SendAndReceiveMessage(true);
            Console.WriteLine("SentMessage");

            //Delete the queue
            DeleteQueue();
            Console.WriteLine("DeletedQueue");

            //Use System.Messaging to ensure this queue no longer exists
            SendAndReceiveMessage(false);
            Console.WriteLine("NotSentMessage");

        }

        private void CreateQueue(bool transactionsEnabled)
        {
            //Create the queue
            Tasks.MessageQueue.Create createQueueTask = new Tasks.MessageQueue.Create();
            createQueueTask.QueuePath = QUEUE_PATH;
            string queueLabel = TaskTestUtilities.GenerateNewGuid();
            createQueueTask.QueueLabel = queueLabel;
            createQueueTask.TransactionsEnabled = transactionsEnabled;

            bool createQueueTaskReturnValue = createQueueTask.Execute();

            //Test the new queue was created successfully
            Assert.IsTrue(createQueueTaskReturnValue, "CreateMSMQSucceeded");
            Assert.AreEqual(createQueueTask.QueuePath, QUEUE_PATH);
            Assert.AreEqual(createQueueTask.QueueLabel, queueLabel);
            Assert.AreEqual(createQueueTask.TransactionsEnabled, transactionsEnabled);
        }

        private void DeleteQueue()
        {
            Tasks.MessageQueue.DeleteQueue deleteQueueTask = new Tasks.MessageQueue.DeleteQueue();
            deleteQueueTask.QueuePath = QUEUE_PATH;

            bool deleteQueueTaskReturnValue = deleteQueueTask.Execute();

            //Test the new queue was created successfully
            Assert.IsTrue(deleteQueueTaskReturnValue, "DeleteMSMQSucceeded");
            Assert.IsTrue(deleteQueueTask.QueuePath == QUEUE_PATH, "DeleteMSMQProperties");
        }

        /// <summary>
        /// Attempts to send and receive a message on the created queue
        /// </summary>
        /// <param name="successExpected">True if this test is expected to pass, otherwise false</param>
        private void SendAndReceiveMessage(bool successExpected)
        {
            try
            {
                System.Messaging.MessageQueue testQueueCreation = new System.Messaging.MessageQueue(QUEUE_PATH);
                Console.WriteLine("Got queue");
                System.Messaging.Message testSendMessage = new System.Messaging.Message();
                testSendMessage.Body = "Send Message Unit Test";
                testQueueCreation.Send(testSendMessage);
                Console.WriteLine("Sent message");

                testQueueCreation.MessageReadPropertyFilter.Priority = true;
                testQueueCreation.Formatter = new XmlMessageFormatter(new Type[] { typeof(string) });
                System.Messaging.Message testReceiveMessage = testQueueCreation.Receive();
                Console.WriteLine("Received message");
                Assert.AreEqual( testSendMessage.Body, testReceiveMessage.Body);

            }
            catch (MessageQueueException msmqEx)
            {
                if (successExpected)
                {
                    Assert.Fail(msmqEx.ToString());
                }
                else
                {
                    return;
                }
            }

            if (!successExpected)
            {
                Assert.Fail("Message sent and received successfully when failure expected");
            }

        }
    }
}


