﻿//-----------------------------------------------------------------------
// <copyright file="MessageDialog.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Giles Knap</author>
// <email>gilesk</email>
// <date>2005-10-05</date>
// <summary>
// shortens a file path.
// </summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks
{
    #region Using directives
    using System;
    using System.Text;
    using System.IO;
    using Microsoft.Build.BuildEngine;
    using Microsoft.Build.Framework;
    using Microsoft.Build.Utilities;
    using Microsoft.Build.Shared;
    using System.Windows.Forms; 
    #endregion

    /// <summary>
    /// Pops up a modal dialog
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<MessageDialog DialogTitle="DialogTitle" Dialogtext="Text" Buttons="ButtonList">
    ///                 <Output TaskParameter="ButtonPressed" PropertyName="buttonPressed" />
    ///                </MessageDialog>]]></code>
    /// <para>where:</para>
    /// <para><i>dialogTitle (Required)</i></para>
    /// <para>The title</para>
    /// <para><i>Text (Required)</i></para>
    /// <para>the text so show</para>
    /// <para><i>ButtonList</i></para>
    /// <para>list of the buttons to display on the dialog (defaults to 'OK')</para>
    /// <para><i>ButtonPressed (Output)</i></para>
    /// <para>an integer value representing the button pressed (zero based)</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <MessageDialog
    ///             DialogTitle="Abort" DialogText="Do you want to abort this build?" Buttons="Abort;Continue">
    ///                 <Output TaskParameter="ButtonPressed" PropertyName="ButtonPressed" />
    ///         </MessageDialog>
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class MessageDialog : TaskBase
    {
        private string dialogTitle;
        private string dialogText;
        private string[] buttons = { "OK" };
        private string buttonPressed = "None";

        public MessageDialog()
        {
        }

        /// <summary>
        /// returns the text of the button that was pressed
        /// </summary>
        /// <value>
        ///  </value>
        [Output]          
        public string ButtonPressed
        {
            get { return this.buttonPressed; }
            set { this.buttonPressed = value; }
        }

        /// <summary>
        /// A list of captions for 1 to 4 buttons
        /// </summary>
        ///  <value>
        ///  </value>
        public string[] Buttons
        {
            get { return this.buttons; }
            set { this.buttons = value; }
        }

        [Required]
        public string DialogTitle
        {
            get { return this.dialogTitle; }
            set { this.dialogTitle = value; }
        }

        [Required]
        public string DialogText
        {
            get { return this.dialogText; }
            set { this.dialogText = value; }
        }

        protected override void InternalExecute()
        {
            MessageForm form = new MessageForm(this.dialogTitle, this.dialogText, this.buttons);
            form.ShowDialog();
            buttonPressed = form.ButtonPressedText;
        }
    }
}
