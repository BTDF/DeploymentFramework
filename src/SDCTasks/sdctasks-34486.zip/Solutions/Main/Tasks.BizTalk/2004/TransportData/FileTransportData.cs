
namespace Microsoft.Sdc.Tasks.BizTalk2004.TransportData
{
    #region Using directives
    using System;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    #endregion

    public class FileTransportData : TransportDataBase
    {
        #region Send Port properties
        private string fileName;
        private bool allowCacheOnWrite;
        private string copyMode;


        /// <summary>
        /// Gets or sets the name of the file.
        /// </summary>
        /// <value>The name of the file.</value>
        public string FileName
        {
            get { return this.fileName; }
            set { this.fileName = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [allow cache on write].
        /// </summary>
        /// <value><c>true</c> if [allow cache on write]; otherwise, <c>false</c>.</value>
        public bool AllowCacheOnWrite
        {
            get { return this.allowCacheOnWrite; }
            set { this.allowCacheOnWrite = value; }
        }

        /// <summary>
        /// Gets or sets the copy mode.
        /// </summary>
        /// <value>The copy mode.</value>
        public string CopyMode
        {
            get { return this.copyMode; }
            set { this.copyMode = value; }
        }
        #endregion

        #region Receive Location properties


        private string fileMask;
        private long batchSize;
        private long retryCount;
        private long retryInterval;


        /// <summary>
        /// Gets or sets the file mask.
        /// </summary>
        /// <value>The file mask.</value>
        public string FileMask
        {
            get { return this.fileMask; }
            set { this.fileMask = value; }
        }

        /// <summary>
        /// Gets or sets the size of the batch.
        /// </summary>
        /// <value>The size of the batch.</value>
        public long BatchSize
        {
            get { return this.batchSize; }
            set { this.batchSize = value;}
        }

        /// <summary>
        /// Gets or sets the retry count.
        /// </summary>
        /// <value>The retry count.</value>
        public long RetryCount
        {
            get { return this.retryCount; }
            set { this.retryCount = value; }

        }

        /// <summary>
        /// Gets or sets the retry interval.
        /// </summary>
        /// <value>The retry interval.</value>
        public long RetryInterval
        {
            get { return this.retryInterval; }
            set { this.retryInterval = value; }

        }

        #endregion 

        #region methods

        protected override void InternalExecute()
        {
            Configuration.BizTalkInstallation installation = this.GetInstallation();
            Configuration.TransportDataParentType _parentType = (TransportDataParentType)Enum.Parse(typeof(TransportDataParentType), this.ParentType);

            Configuration.FileTransport fileTransport = new Microsoft.Sdc.Tasks.BizTalk2004.Configuration.FileTransport(_parentType);

            switch(_parentType)
            {
                case TransportDataParentType.ReceiveLocation:
                    fileTransport.FileMask = this.fileMask;
                    fileTransport.BatchSize = this.batchSize;
                    fileTransport.RetryCount = this.retryCount;
                    fileTransport.RetryInterval = this.retryInterval;
                    break;
                case TransportDataParentType.SendPort:
                    fileTransport.FileName = this.fileName;
                    fileTransport.CopyMode = (FileTransportCopyMode)Enum.Parse(typeof(FileTransportCopyMode), this.copyMode);
                    fileTransport.AllowCacheOnWrite = this.allowCacheOnWrite;
                    break;

            }

            this.TransportDataXml = fileTransport.GetTransportXml();

        }
        #endregion
    }
}

