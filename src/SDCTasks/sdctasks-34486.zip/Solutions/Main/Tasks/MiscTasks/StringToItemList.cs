﻿//-----------------------------------------------------------------------
// <copyright file="StringToItemList.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Giles Knap</author>
// <email>gilesk</email>
// <date>2005-08-22</date>
// <summary>
// splits a string into an item list
// </summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks
{
    #region Using directives
    using System;
    using System.Text;
    using Microsoft.Build.BuildEngine;
    using Microsoft.Build.Framework;
    using Microsoft.Build.Utilities;
    using Microsoft.Build.Shared;
    #endregion

    /// <summary>
    /// Splits a string into an item list. Useful where parameters that are passed on the command line (or in an MSI property etc.)
    /// are required to have multiple values. 
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<StringToItemList InputString="inputString" Separator="separator">
    ///                 <Output TaskParameter="OutputList" ItemName="outputList" />
    ///                </StringToItemList>]]></code>
    /// <para>where:</para>
    /// <para><i>inputString (Required)</i></para>
    /// <para>The the string containing multiple values.</para>
    /// <para><i>separator (Optional)</i></para>
    /// <para>separtor that the string uses to distinguish values, default to " ", can also be an item list in order to specify multiple separators</para>
    /// <para><i>outputList (Required)</i></para>
    /// <para>the resulting item list</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <StringToItemList
    ///             InputString="one,two,three"
    ///             Separator="," >
    ///                 <Output TaskParameter="OutputList" ItemName="MyList" />
    ///         </StringToItemList>
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class StringToItemList : TaskBase
    {
        private string inputString;
        private string[] separator = { " " };
        private string[] result;

        public StringToItemList()
        {
        }

        [Output]
        public string[] OutputList
        {
            get { return this.result; }
            set { this.result = value; }
        }

        public string[] Separator
        {
            get { return this.separator; }
            set { this.separator = value; }
        }

        [Required]
        public string InputString
        {
            get { return this.inputString; }
            set { this.inputString = value; }
        }

        protected override void InternalExecute()
        {
            this.result = inputString.Split(this.separator, StringSplitOptions.None);
        }
    }
}
