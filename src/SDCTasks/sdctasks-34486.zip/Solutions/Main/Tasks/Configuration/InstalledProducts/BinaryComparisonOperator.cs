using System;

namespace Microsoft.Sdc.Tasks.Configuration.InstalledProducts
{
	/// <summary>
	/// Type of comparison to perform
	/// </summary>
	public enum BinaryComparisonOperator
	{
		Equals,
		Contains,
		LessThan,
		GreaterThan,
		LessThanOrEquals,
		GreaterThanOrEquals,
        StartsWith,
        EndsWith
	}
}
