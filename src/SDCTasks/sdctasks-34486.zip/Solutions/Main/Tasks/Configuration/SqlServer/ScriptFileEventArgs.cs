/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Erwin Wendland</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace Microsoft.Sdc.Tasks.Configuration.SqlServer
{

    /// <summary>
    /// Provides data for the ScriptFileExecuted event.
    /// </summary>
    /// <remarks>
    /// A ScriptFileEventArgs, which specifies information about the SQL 
    /// script file that was executed, is passed with each ScriptFileExecuted event.
    /// </remarks>
    internal class ScriptFileEventArgs : EventArgs
    {

        #region Private members

        private FileInfo scriptFileInfo;
        private bool succeeded;
        private Exception executionException;
        private SqlErrorCollection sqlInfo;

        #endregion

        /// <summary>
        /// Initializes a new instance of the ScriptFileEventArgs class.
        /// </summary>
        /// <param name="scriptFileInfo">
        /// A FileInfo value that represents information about the script 
        /// file that was executed.
        /// </param>
        public ScriptFileEventArgs(FileInfo scriptFileInfo)
        {
            this.scriptFileInfo = scriptFileInfo;
            this.succeeded = true;
            this.executionException = null;
        }

        /// <summary>
        /// Initializes a new instance of the ScriptFileEventArgs class.
        /// </summary>
        /// <param name="sqlInfo">
        /// A SqlErrorCollection that contains errors or trace information obtained from
        /// the connection used to execute a script.
        /// </param>
        public ScriptFileEventArgs(SqlErrorCollection sqlInfo)
        {
            this.scriptFileInfo = null;
            this.succeeded = true;
            this.executionException = null;
            this.sqlInfo = sqlInfo;
        }

        /// <summary>
        /// Initializes a new instance of the ScriptFileEventArgs class.
        /// </summary>
        /// <param name="scriptFileInfo">
        /// A FileInfo value that represents information about the script 
        /// file that was executed.
        /// </param>
        /// <param name="reasonForFailure">
        /// The exception that was caught when a script execution failed.
        /// </param>
        public ScriptFileEventArgs(
            FileInfo scriptFileInfo,
            Exception reasonForFailure)
        {
            this.scriptFileInfo = scriptFileInfo;
            succeeded = false;
            executionException = reasonForFailure;
        }

        /// <summary>
        /// A collection of SqlErrors.
        /// </summary>
        public SqlErrorCollection SqlInfo
        {
            get { return this.sqlInfo; }
        }

        /// <summary>
        /// Gets the information about a script file that has been executed.
        /// </summary>
        public System.IO.FileInfo ScriptFileInfo
        {
            get
            {
                return scriptFileInfo;
            }
        }

        /// <summary>
        /// Is true if the script executed successfully, otherwise false.
        /// </summary>
        public bool Succeeded
        {
            get
            {
                return succeeded;
            }
        }

        /// <summary>
        /// The exception that was caught when a script execution failed.
        /// </summary>
        public Exception ExecutionException
        {
            get
            {
                return executionException;
            }
        }

    }
}