using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Microsoft.Sdc.Tasks.Test.BizTalk2006
{
    /// <summary>
    /// Summary description for BizTalkExportTest
    /// </summary>
    [TestClass]
    public class BizTalkExportTest
    {
        public BizTalkExportTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void TestBizTalkExport()
        {
            Microsoft.Sdc.Tasks.BizTalk2006.Export exportTask = new Microsoft.Sdc.Tasks.BizTalk2006.Export();
            exportTask.OutputFile = "DeployBizTalk.proj";
            exportTask.Assemblies = new Microsoft.Build.Framework.ITaskItem[] { 
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.CableOrderActions.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.CableOrderStage1.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.CableOrderStage2.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.CableProvisioningSystemClient.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.IOperationsSystem.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.IOrderHandler.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.Maps.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.MessagingSchemas.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.OperationsClient.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.OperationsHandler.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.OpsAdapterMgmt.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.OpsAdater.IOpsAIC.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.OpsTxAdapter.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.OrderBroker.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.OrderBrokerMaps.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.OrderBrokerSchemas.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.OrderHandler.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.OrderManager.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.SchemaClasses.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.Schemas.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.ServiceLevelTracking.dll"),
                new Microsoft.Build.Utilities.TaskItem("Microsoft.Samples.BizTalk.SouthridgeVideo.Utilities.dll")
            };
            exportTask.SourceFolder = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Scenarios\BPM\MainAssemblies";
            exportTask.Execute();
        }
    }
}
