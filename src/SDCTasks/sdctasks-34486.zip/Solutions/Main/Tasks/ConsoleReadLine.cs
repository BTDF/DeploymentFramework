//-----------------------------------------------------------------------
// <copyright file="ConsoleReadLine.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-03-23</date>
// <summary>Forces the command line to read a newline</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks
{
    using System;
    using System.Xml;
    using System.Globalization;
    using System.IO;
    using System.Collections;
    using System.Text;

    using Microsoft.Build.Framework;

    /// <summary>
    /// Forces the command line to read a newline.
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<ConsoleReadLine Message="message">
    ///                    <Output TaskParameter="Response" ItemName="response" />
    ///                </ConsoleReadLine>
    /// ]]></code>
    /// <para>where:</para>
    /// <para><i>message (Optional)</i></para>
    /// <para>The optional message to explain the response required from the user.</para>
    /// <para><i>response (Output)</i></para>
    /// <para>The response from the user.</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test">
    ///         <ConsoleReadLine Message="Press Enter to continue or Ctrl-C to abort.">
    ///             <Output TaskParameter="Response" ItemName="UserResponse" />
    ///         </ConsoleReadLine>
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class ConsoleReadLine : TaskBase
    {
        /// <summary>
        /// The optional message to explain the response required from the user.
        /// </summary>
        private string message;

        /// <summary>
        /// The response from the user.
        /// </summary>
        private string response;

        /// <summary>
        /// Initializes a new instance of the ConsoleReadLine class.
        /// </summary>
        public ConsoleReadLine()
        {
        }

        /// <summary>
        /// Gets or sets the optional message to explain the response required from the user.
        /// </summary>
        public string Message
        {
            get
            {
                return (this.message == null ? String.Empty : this.message);
            }

            set
            {
                this.message = value;
            }
        }

        /// <summary>
        /// The response from the user.
        /// </summary>
        [Output]
        public string Response
        {
            get
            {
                return (this.response == null ? String.Empty : this.response);
            }

            set
            {
                this.response = value;
            }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            // Show the optional message to explain the response required from the user
            if (String.IsNullOrEmpty(this.Message) == false)
            {
                this.Log.LogMessage(MessageImportance.High, this.Message);
            }

            // Read a line from the console
            this.Response = Console.ReadLine();

            // Show the response from the user
            this.Log.LogMessageFromResources(MessageImportance.Low, "Console.ReadLine.Response", this.Response);
        }
    }
}