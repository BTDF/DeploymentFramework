//-----------------------------------------------------------------------
// <copyright file="Create.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.Application
{
    using BizTalk2004;
    using BizTalk.ExplorerOM;
    using Build.Framework;
    using System.Globalization;

    /// <summary>
    /// Creates an application
    /// </summary>
    public class Create : BizTalk2004TaskBase
    {
        private string application;
        private string description;
        private bool isdefault;
        private ITaskItem[] referencedApplications;

        /// <summary>
        /// Gets or sets the application.
        /// </summary>
        /// <value>The application.</value>
        [Required]
        public string Application
        {
            get { return this.application; }
            set { this.application = value; }
        }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>The description.</value>
        public string Description
        {
            get { return this.description; }
            set { this.description = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is default.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is default; otherwise, <c>false</c>.
        /// </value>
        public bool IsDefault
        {
            get { return this.isdefault; }
            set { this.isdefault = value; }
        }

        /// <summary>
        /// Gets or sets the referenced applications.
        /// </summary>
        /// <value>The referenced applications.</value>
        public ITaskItem[] ReferencedApplications
        {
            get { return this.referencedApplications; }
            set { this.referencedApplications = value; }
        }

        /// <summary>
        /// This is the main execute method that all tasks should implement
        /// </summary>
        /// <remarks>
        /// TaskException should be thrown in the event of errors
        /// </remarks>
        protected override void InternalExecute()
        {
            BtsCatalogExplorer explorer = this.GetBtsCatalogExplorer(this.Server, this.Database);

            Application appl = explorer.AddNewApplication();
            appl.Name = this.Application;
            appl.Description = this.Description;
            if (this.IsDefault)
            {
                explorer.DefaultApplication = appl;
            }

            if (this.ReferencedApplications != null)
            {
                foreach (ITaskItem item in this.ReferencedApplications)
                {
                    string refName = item.ItemSpec;
                    Application refApp = explorer.Applications[refName];
                    Log.LogMessage(string.Format(CultureInfo.InvariantCulture, "Adding Reference Application: {0} to Application: {1}", refName, this.Application));
                    appl.AddReference(refApp);
                }
            }

            explorer.SaveChanges();
        } 
    }
}
