/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/


namespace Microsoft.Sdc.Tasks.Configuration.Web {
    using System.Globalization;
    using System;
    using System.DirectoryServices;
    using System.Security.Principal;
    using System.Collections;
    using System.Runtime.InteropServices;
    using Microsoft.Sdc.Tasks.Configuration.Framework;

    internal class VirtualDirectory {

        string             path;
        AuthFlags          authFlags;
        string             name;
        WebSite            parent;
        string             webAppName = "";
        DirectoryEntry     de;
        AccessFlags        accessFlags;
        string             appPoolId = "DefaultAppPool";
        string             anonymousUserName;
        string             anonymousUserPassword;
        string             uncUserName;
        string             uncPassword;
        int                aspScriptTimeout=90;
        HttpErrorCollection httpErrors;

        public VirtualDirectory(string name) {
            this.name = name;
        }

        public VirtualDirectory(string name, string webappname)
        {
            this.name = name;
            this.WebAppName = webappname;
        }

        public VirtualDirectory(string name, WebSite parent) {
            this.name = name;
            this.parent = parent;
            if (name.ToLower(CultureInfo.InvariantCulture) == "root") {
                DirectoryEntry p = parent.GetDirectoryEntry();
                if (p != null) {
                    de = p.Children.Find("ROOT", "IIsWebVirtualDir");
                    Initialize(de,parent);
                }
            }
        }

        internal VirtualDirectory(DirectoryEntry vdir, WebSite parent) {
            Initialize(vdir, parent);
        }

        void Initialize(DirectoryEntry vdir, WebSite parent) {
            name = vdir.Name;
            this.parent = parent;
            path = (string)vdir.Properties["Path"][0];
            authFlags = (AuthFlags)vdir.Properties["AuthFlags"][0];
            accessFlags = (AccessFlags)vdir.Properties["AccessFlags"][0];
            anonymousUserName = (string)vdir.Properties["AnonymousUserName"][0];
            anonymousUserPassword = (string)vdir.Properties["AnonymousUserPass"][0];
            if (vdir.Properties["UNCUserName"] != null && vdir.Properties["UNCUserName"][0] != null)
            {
                uncUserName = (string)vdir.Properties["UNCUserName"][0];
            }
            else
            {
                uncUserName= String.Empty;
            }

            if (vdir.Properties["UNCPassword"] != null && vdir.Properties["UNCPassword"][0] != null)
            {
                uncPassword = (string)vdir.Properties["UNCPassword"][0];
            }
            else
            {
                uncPassword= String.Empty;
            }

            aspScriptTimeout = (int)vdir.Properties["AspScriptTimeout"][0];
            de = vdir;
            try {
                appPoolId = (string)vdir.Properties["AppPoolId"][0];
            }
            catch(COMException) {
                //it will come in here if we don't have app pools like Win2k
            }    
       
            try
            {
                PropertyValueCollection httpErrorsCollection = vdir.Properties["HttpErrors"];

                httpErrors = new HttpErrorCollection(this.DirectoryEntry);
                
            }
            catch(COMException)
            {
                //it will come here if this webdirectory has no configured HttpErrors
            }
        }

        DirectoryEntry EnsureVirtualDirectory() {

            DirectoryEntry de = null;
            
            if (name.ToLower(CultureInfo.InvariantCulture) == "root" ) {
                de = parent.Root.DirectoryEntry;
                if (de == null) {
                    de = parent.GetDirectoryEntry().Children.Find("root", "IIsWebVirtualDir");
                }
            } else {
                if (parent.VirtualDirectories[name] != null) {
                    de = parent.VirtualDirectories[name].DirectoryEntry;
                    if (de == null) {
                        try {
                            de = parent.Root.DirectoryEntry.Children.Find(name, "IIsWebVirtualDir");
                        }
                        catch {
                            de = parent.Root.DirectoryEntry.Children.Add(name, "IIsWebVirtualDir");
                        }
                    }
                } else {
                    de = parent.Root.DirectoryEntry.Children.Add(name, "IIsWebVirtualDir");
                    de.CommitChanges();
                }
            }
            
            return de;
        }

        public void Save() {
            //TODO need to check that all the properties we need have been provided
            // path
            // 
            // if we don't have a directory entry
            // and if the identifier is zero
            // then try and create a new site
            // otherwise if no dir entry but identifier is set check to see if the site exists
            // if it does throw an exception (as you should have called load)
            //otherwise try to create it with the identifier provided
            
            
            if (parent == null) {
                throw new ApplicationException("Parent must be provided before saving.");
            }
                
            if (de == null) {
                de = EnsureVirtualDirectory();
            }

            ComWrapper app = new ComWrapper(de.NativeObject);
            app.CallMethod("Put", new Object[] {"AuthFlags", authFlags});
            app.CallMethod("Put", new Object[] {"Path", path});
            app.CallMethod("Put", new Object[] {"AccessFlags", accessFlags});
            
            try 
            {
                app.CallMethod("Put", new Object[] {"AppPoolId", appPoolId});
            }
            catch(System.Reflection.TargetInvocationException) 
            {
                //catches here if we have trouble saving apppool id's on Win2k
            }
            
            app.CallMethod("Put", new Object[] {"AspScriptTimeout", aspScriptTimeout});
            
            if (anonymousUserName != null) 
            {
                app.CallMethod("Put", new Object[] {"AnonymousUserName", anonymousUserName});
                app.CallMethod("Put", new Object[] {"AnonymousUserPass", anonymousUserPassword});
            }
            if (uncUserName != null)
            {
                app.CallMethod("Put", new object[] {"UNCUserName", uncUserName});
            }
            if (uncPassword != null)
            {
                app.CallMethod("Put", new object[] {"UNCPassword", uncPassword});
            }

            if( httpErrors != null)
            {
                httpErrors.Save(de);
            }

            de.CommitChanges();
        }
            
        //de.Dispose();    

        public AuthFlags AuthFlags {
            get {
                return authFlags ;
            }
            set {
                authFlags = value;
            }
        }

        public string Path {
            get {
                return (path == null ? String.Empty : path);
            }
            set {
                path = value;
            }
        }

        public WebSite Parent {
            get {
                return parent ;
            }
            set { 
                parent = value;
            }
        }   

        public DirectoryEntry DirectoryEntry {
            get {
                return de;
            }
        }

        public string Name {
            get {
                return (name == null ? String.Empty : name);
            }
            set {
                name = value;
            }
        }

        public HttpErrorCollection HttpErrors
        {
            get
            {
                return httpErrors;
            }
        }

        public static bool Exists(string name, int webSiteIdentifier, string machineName) {
            
            try {
                if (DirectoryEntry.Exists("IIS://" + machineName + "/W3SVC/" + Convert.ToString(webSiteIdentifier) + "/root/" + name)) {
                    return true;
                }
            }
            catch {
                return false;
            }
            return false;
        }

        public static void Delete(string name, int webSiteIdentifier, string machineName) {
            if (name.ToLower(CultureInfo.InvariantCulture) == "root") {
                throw new ApplicationException("You cannot delete the root virtual directory. Delete the Website instead.");
            }
            DirectoryEntry web = new DirectoryEntry("IIS://" + machineName + "/W3SVC/" + Convert.ToString(webSiteIdentifier) + "/root");
            object[] args = {"IISWebVirtualDir", name};
            web.Invoke("Delete", args);
            web.Dispose();                      
        }

        public void Delete() {
            if (this.name.ToLower(CultureInfo.InvariantCulture) == "root") {
                throw new ApplicationException("You cannot delete the root virtual directory. Delete the Website instead.");
            }
            
            object[] args = {"IISWebVirtualDir", name};
            parent.Root.DirectoryEntry.Invoke("Delete", args);
        }

        public AccessFlags AccessFlags {
            get {
                return accessFlags ;
            }
            set {
                accessFlags = value;
            }
        }   

        public string AppPoolId {
            get {
                return (appPoolId == null ? String.Empty : appPoolId);
            }
            set {
                appPoolId = value;
            }
        }

        public void AppCreate() {
            ComWrapper app = new ComWrapper(de.NativeObject);
            app.CallMethod("AppCreate",new object[] {false});
        }   

        public void AppCreate3() {          

            object[] args;
            
            {
                args = new object[] { 2, appPoolId, false };

                if (WebAppName != String.Empty)
                {
                    de.Properties["AppFriendlyName"][0] = WebAppName;
                }

                de.Invoke("AppCreate3", args);
                de.CommitChanges();
            }
        }

        public void AppUnLoad() {
            ComWrapper app = new ComWrapper(de.NativeObject);
            app.CallMethod("AppUnLoad");            
        }

        public void AppDelete() {
            ComWrapper app = new ComWrapper(de.NativeObject);
            app.CallMethod("AppDelete");
        }

        public string AnonymousUserName {
            get {
                return (anonymousUserName == null ? String.Empty : anonymousUserName);
            }
            set {
                anonymousUserName = value;
            }
        }

        public string AnonymousUserPassword {
            get {
                return (anonymousUserPassword == null ? String.Empty : anonymousUserPassword);
            }
            set {
                anonymousUserPassword = value;
            }
        }       

        public string UncUserName 
        {
            get 
            {
                return (uncUserName == null ? String.Empty : uncUserName);
            }
            set 
            {
                uncUserName = value;
            }
        }

        public string UncPassword 
        {
            get 
            {
                return (uncPassword == null ? String.Empty : uncPassword);
            }
            set 
            {
                uncPassword = value;
            }
        }       

        public int AspScriptTimeout 
        {
            get {
                return aspScriptTimeout ;
            }
            set {
                aspScriptTimeout = value;
            }
        }

        public string WebAppName
        {
            get
            {
                return (this.webAppName == null ? String.Empty : this.webAppName);
            }
            set
            {
                this.webAppName = value;
            }
        }
    }
}

