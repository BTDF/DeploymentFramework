/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/


namespace Microsoft.Sdc.Tasks.Configuration.Web 
{
    using System.Globalization;
    using System;
    using System.DirectoryServices;
    using System.Security.Principal;
    using System.Collections;
    using System.Runtime.InteropServices;
    using Microsoft.Sdc.Tasks.Configuration.Framework;

    internal class FtpVirtualDirectory 
    {

        string             path;
        string             name;
        FtpSite            parent;
        DirectoryEntry     de;
        AccessFlags        accessFlags;

        public FtpVirtualDirectory(string name) 
        {
            this.name = name;
        }

        public FtpVirtualDirectory(string name, FtpSite parent) 
        {
            this.name = name;
            this.parent = parent;
            if (name.ToLower(CultureInfo.InvariantCulture) == "root") 
            {
                DirectoryEntry p = parent.GetDirectoryEntry();
                if (p != null) 
                {
                    de = p.Children.Find("ROOT", "IIsFtpVirtualDir");
                    Initialize(de,parent);
                }
            }
        }

        internal FtpVirtualDirectory(DirectoryEntry vdir, FtpSite parent) 
        {
            Initialize(vdir, parent);
        }

        void Initialize(DirectoryEntry vdir, FtpSite parent) 
        {
            name = vdir.Name;
            this.parent = parent;
            path = (string)vdir.Properties["Path"][0];
            accessFlags = (AccessFlags)vdir.Properties["AccessFlags"][0];
            de = vdir;
        }

        DirectoryEntry EnsureFtpVirtualDirectory() 
        {

            DirectoryEntry de = null;
            
            if (name.ToLower(CultureInfo.InvariantCulture) == "root" ) 
            {
                de = parent.Root.DirectoryEntry;
                if (de == null) 
                {
                    de = parent.GetDirectoryEntry().Children.Find("root", "IIsFtpVirtualDir");
                }
            } 
            else 
            {
                if (parent.VirtualDirectories[name] != null) 
                {
                    de = parent.VirtualDirectories[name].DirectoryEntry;
                    if (de == null) 
                    {
                        try 
                        {
                            de = parent.Root.DirectoryEntry.Children.Find(name, "IIsFtpVirtualDir");
                        }
                        catch 
                        {
                            de = parent.Root.DirectoryEntry.Children.Add(name, "IIsFtpVirtualDir");
                        }
                    }
                } 
                else 
                {
                    de = parent.Root.DirectoryEntry.Children.Add(name, "IIsFtpVirtualDir");
                    de.CommitChanges();
                }
            }
            
            return de;
        }

        public void Save() 
        {
            //TODO need to check that all the properties we need have been provided
            // path
            // 
            // if we don't have a directory entry
            // and if the identifier is zero
            // then try and create a new site
            // otherwise if no dir entry but identifier is set check to see if the site exists
            // if it does throw an exception (as you should have called load)
            //otherwise try to create it with the identifier provided
            
            
            if (parent == null) 
            {
                throw new ApplicationException("Parent must be provided before saving.");
            }
                
            if (de == null) 
            {
                de = EnsureFtpVirtualDirectory();
            }

            ComWrapper app = new ComWrapper(de.NativeObject);
            app.CallMethod("Put", new Object[] {"Path", path});
            app.CallMethod("Put", new Object[] {"AccessFlags", accessFlags});
            
            de.CommitChanges();
        }
            
        public string Path 
        {
            get 
            {
                return (path == null ? String.Empty : path);
            }
            set 
            {
                path = value;
            }
        }

        public FtpSite Parent 
        {
            get 
            {
                return parent ;
            }
            set 
            { 
                parent = value;
            }
        }   

        public DirectoryEntry DirectoryEntry 
        {
            get 
            {
                return de;
            }
        }

        public string Name 
        {
            get 
            {
                return (name == null ? String.Empty : name);
            }
            set 
            {
                name = value;
            }
        }

        public static bool Exists(string name, int ftpSiteIdentifier, string machineName) 
        {
            
            try 
            {
                if (DirectoryEntry.Exists("IIS://" + machineName + "/MSFTPSVC/" + Convert.ToString(ftpSiteIdentifier) + "/root/" + name)) 
                {
                    return true;
                }
            }
            catch 
            {
                return false;
            }
            return false;
        }

        public static void Delete(string name, int ftpSiteIdentifier, string machineName) 
        {
            if (name.ToLower(CultureInfo.InvariantCulture) == "root") 
            {
                throw new ApplicationException("You cannot delete the root virtual directory. Delete the FtpSite instead.");
            }
            DirectoryEntry ftp = new DirectoryEntry("IIS://" + machineName + "/MSFTPSVC/" + Convert.ToString(ftpSiteIdentifier) + "/root");
            object[] args = {"IISFtpVirtualDir", name};
            ftp.Invoke("Delete", args);
            ftp.Dispose();                      
        }

        public void Delete() 
        {
            if (this.name.ToLower(CultureInfo.InvariantCulture) == "root") 
            {
                throw new ApplicationException("You cannot delete the root virtual directory. Delete the FtpSite instead.");
            }
            
            object[] args = {"IISFtpVirtualDir", name};
            parent.Root.DirectoryEntry.Invoke("Delete", args);
        }

        public AccessFlags AccessFlags 
        {
            get 
            {
                return accessFlags ;
            }
            set 
            {
                accessFlags = value;
            }
        }   
    }
}

