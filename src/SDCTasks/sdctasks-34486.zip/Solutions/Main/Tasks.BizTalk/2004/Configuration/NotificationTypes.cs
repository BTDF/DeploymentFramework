using System;

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	/// <summary>
	/// Delivery notification types, which may be combined.
	/// </summary>
	[Flags]
	public enum NotificationTypes
	{
		/// <summary>
		/// No notification.
		/// </summary>
		None = 1,
		/// <summary>
		/// Notification when the transmission has been successful.
		/// </summary>
		Transmitted = 2
	}
}

