//-----------------------------------------------------------------------
// <copyright file="RemoveAssembly.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Jason Birth [4 Feb 08: Mike Fourie - Updated]</author>
// <email>jasonbi</email>
// <date>2004-06-18</date>
// <summary>Removes an assembly from the GAC.</summary>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.GlobalAssemblyCache
{
    using Microsoft.Build.Framework;

    /// <summary>
    /// Removes an assembly from the GAC
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<GlobalAssemblyCache.RemoveAssembly AssemblyName="assemblyName" />]]></code>
    /// <para>where:</para>
    /// <para><i>assemblyName (Required)</i></para>
    /// <para>
    /// The fully qualified name of the assembly to remove from the GAC
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test">
    ///         <GlobalAssemblyCache.RemoveAssembly
    ///             AssemblyName="sampleAssembly, Version=1.0.1630.33126, Culture=neutral, PublicKeyToken=74b9cb296faeeb25, Custom=null" />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class RemoveAssembly : TaskBase
    {
        private string assemblyName;

        /// <summary>
        /// The fully qualified name of the assembly to remove from the GAC
        /// </summary>
        /// <value>The fully qualified name of the assembly to remove from the GAC</value>
        [Required]
        public string AssemblyName
        {
            get { return this.assemblyName; }
            set { this.assemblyName = value; }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            GacHelper.Uninstall(this.AssemblyName);
        }
    }
}