//-----------------------------------------------------------------------
// <copyright file="Enlist.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.Orchestration
{
    using System.Globalization;
    using BizTalk.ExplorerOM;

    /// <summary>
    /// Enlists the given instance of the BizTalk Orchestration.
    /// </summary>
    /// <remarks>
    /// 	<code>
    /// 		<![CDATA[<BizTalk2004.Orchestration.Enlist Application="applicationName" AssemblyName = "assemblyname" Name="name" Server="server" Database="database" />]]>
    /// 	</code>
    /// 	<para>where:</para>
    /// 	<para><i>Application (Optional)</i></para>
    /// 	<para>
    /// The name of the application
    /// </para>
    /// 	<para><i>assemblyName (Required)</i></para>
    /// 	<para>
    /// The name of the assembly that contains the orchestration.
    /// </para>
    /// 	<para><i>name (Required)</i></para>
    /// 	<para>
    /// The name of the orchestration to enlist.
    /// </para>
    /// 	<para><i>server</i></para>
    /// 	<para>
    /// The logical name of the server Orchestrationing the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// 	<para><i>database</i></para>
    /// 	<para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified
    /// then the installation will default to the local installation.
    /// </para>
    /// 	<para><i>username</i></para>
    /// 	<para>
    /// The username to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// 	<para><i>password</i></para>
    /// 	<para>
    /// The password to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// </remarks>
    /// <example>
    /// 	<code><![CDATA[
    /// <Project>
    /// <Target Name="Test" >
    /// <BizTalk2004.Orchestration.Enlist
    /// Application="EAIApplication"
    /// AssemblyName="EAIOrchestrations, Version=1.0.0.0, Culture=neutral, PublicKeyToken=a0cf43ab166707e8"
    /// Name="EAIOrchestrations.EAIProcess" />
    /// </Target>
    /// </Project>
    /// ]]></code>
    /// </example>
    public class Enlist : BizTalk2004.Orchestration.Enlist
    {
        private string application;

        /// <summary>
        /// Gets or sets the application.
        /// </summary>
        /// <value>The application.</value>
        public string Application
        {
            get { return this.application; }
            set { this.application = value; }
        }

        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {
            if (string.IsNullOrEmpty(this.Application))
            {
                base.InternalExecute();
            }
            else
            {
                BtsCatalogExplorer explorer = this.GetBtsCatalogExplorer(this.Server, this.Database);

                Application app = explorer.Applications[this.Application];
                if (app != null)
                {
                    BtsOrchestration orchestration = app.Orchestrations[this.Name];
                    if (orchestration != null)
                    {
                        Log.LogMessage(string.Format(CultureInfo.InvariantCulture, "Enlisting Orchestration: {0} in Application {1}", this.Name, this.Application));
                        orchestration.Status = OrchestrationStatus.Enlisted;
                        explorer.SaveChanges();
                    }
                    else
                    {
                        Log.LogError(string.Format(CultureInfo.InvariantCulture, "Orchestration not found: {0} for Application {1}", this.Name, this.Application));
                        return;
                    }
                }
                else
                {
                    Log.LogError(string.Format(CultureInfo.InvariantCulture, "Application not found: {0}", this.Application));
                    return;
                }
            }
        }
    }
}
