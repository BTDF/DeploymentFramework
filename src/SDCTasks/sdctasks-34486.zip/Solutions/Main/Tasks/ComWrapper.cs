//-----------------------------------------------------------------------
// <copyright file="ComWrapper.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-03-23</date>
// <summary>Provides Ua wrapper arounmd a com object</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks
{
    using System;
    using System.Reflection;
    using System.Runtime.InteropServices;

    internal class ComWrapper
    {
        private Type comObjectType;
        private object comObject;

        public object ComObject
        {
            get
            {
                return comObject;
            }

            set
            {
                comObject = value;
            }
        }




        public ComWrapper(object o): this (o, false)
        {           
        }
        
        public ComWrapper(object o, bool secureIDispatch)
        {
            Initialize(o, secureIDispatch);
        }

        public ComWrapper(string progID) : this (progID, null, false)
        {           
        }

        public ComWrapper(string progID, string server) : this (progID, server, false)
        {
        }

        public ComWrapper(string progID, string server, bool secureIDispatch)
        {
            if (server != null && server.Length == 0)
            {
                server = null;
            }
            Initialize(Activator.CreateInstance(Type.GetTypeFromProgID(progID, server, true)), secureIDispatch);
        }

        private void Initialize(object o,  bool secureIDispatch) 
        {
            this.comObject = o;
            this.comObjectType = this.comObject.GetType();
            if (secureIDispatch)
            {
                this.SecureIDispatch(o);
            }
        }

        public object CallMethod(string methodName)
        {
            return this.CallMethod(methodName, new object[] {});
        }

        public object CallMethod(string methodName, object [] args)
        {
            return this.comObjectType.InvokeMember(methodName, BindingFlags.Default | BindingFlags.InvokeMethod, null, this.comObject, args);
        }

        public object GetProperty(string propertyName)
        {
            return this.comObjectType.InvokeMember(propertyName, BindingFlags.InvokeMethod|BindingFlags.GetProperty, null, this.comObject, new object[] {});
        }

        public object GetProperty(string propertyName, string args)
        {
            return this.comObjectType.InvokeMember(propertyName, BindingFlags.InvokeMethod | BindingFlags.GetProperty, null, this.comObject, new object[] {args});
        }

        public object GetProperty(string propertyName, int args)
        {
            return this.comObjectType.InvokeMember(propertyName, BindingFlags.InvokeMethod | BindingFlags.GetProperty, null, this.comObject, new object[] {args});
        }

        public void SetProperty(string propertyName, object [] args)
        {
            this.comObjectType.InvokeMember(propertyName, BindingFlags.Default | BindingFlags.SetProperty, null, this.comObject, args);
        }

        private void SecureIDispatch(object objectToSecure)
        {
            IntPtr iDispatchForObject = Marshal.GetIDispatchForObject(objectToSecure);
            uint hr = NativeMethods.CoSetProxyBlanket(iDispatchForObject,
                                        NativeMethods.RPC_C_AUTHN_DEFAULT,
                                        NativeMethods.RPC_C_AUTHZ_DEFAULT,
                                        IntPtr.Zero,
                                        NativeMethods.RPC_C_AUTHN_LEVEL_PKT_PRIVACY,
                                 (uint)NativeMethods.RpcImpLevel.Impersonate,
                                        IntPtr.Zero,
                                        NativeMethods.EOAC_DEFAULT);
/*
            Guid iidInterface = new Guid("{00020400-0000-0000-C000-000000000046}");
            IntPtr pInterface;
            IntPtr pIUnk = Marshal.GetIUnknownForObject(objectToSecure);
            Marshal.QueryInterface(pIUnk, ref iidInterface, out pInterface);

            
            uint hr = NativeMethods.CoSetProxyBlanket(pInterface,
                                        NativeMethods.RPC_C_AUTHN_DEFAULT,
                                        NativeMethods.RPC_C_AUTHZ_DEFAULT,
                                        IntPtr.Zero,
                                        NativeMethods.RPC_C_AUTHN_LEVEL_PKT_PRIVACY,
                                 (uint)NativeMethods.RpcImpLevel.Impersonate,
                                        IntPtr.Zero,
                                        NativeMethods.EOAC_DEFAULT);
  
            */
        }
    }
}
