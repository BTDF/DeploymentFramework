//-------------------------------------------------------------------------------------
// <copyright file="BizTalk2004TaskBase.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Base class for all BizTalk 2004 tasks.
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2004
{
    #region Using directives
    using Microsoft.Sdc.Tasks;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    #endregion

    /// <summary>
    /// Base class for all BizTalk 2004 tasks.
    /// </summary>
    public abstract class BizTalk2004TaskBase : TaskBase
    {
        private string database;
        private string server;

        #region Properties

        /// <summary>
        /// Gets or sets the name of the BizTalk management database.
        /// </summary>
        /// <value>
        /// The name of the BizTalk management database.
        /// </value>
        public string Database
        {
            get { return this.database; }
            set { this.database = value; }
        }

        /// <summary>
        /// Gets or sets the logical name of the server hosting the BizTalk management database.
        /// </summary>
        /// <value>
        /// The logical name of the server hosting the BizTalk management database.
        /// </value>
        public string Server
        {
            get { return this.server; }
            set { this.server = value; }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation"/> for this task.
        /// </summary>
        /// <returns>
        /// A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation"/>.
        /// </returns>
        internal BizTalkInstallation GetInstallation()
        {
            // Check if we need the local or remote configuration
            if (string.IsNullOrEmpty(this.Server) || string.IsNullOrEmpty(this.Database))
            {
                return BizTalkInstallation.Load();
            }

            return BizTalkInstallation.Load(this.Server, this.Database);
        }

        /// <summary>
        /// Gets the BTS catalog explorer.
        /// </summary>
        /// <returns>An instance of the BTSCatalogExplorer</returns>
        internal Microsoft.BizTalk.ExplorerOM.BtsCatalogExplorer GetBtsCatalogExplorer()
        {
            Microsoft.BizTalk.ExplorerOM.BtsCatalogExplorer explorer = new Microsoft.BizTalk.ExplorerOM.BtsCatalogExplorer();
            BizTalkInstallation installation = BizTalkInstallation.Load();
            explorer.ConnectionString = installation.CatalogExplorer.ConnectionString;
            return explorer;
        }

        /// <summary>
        /// Gets the BTS catalog explorer.
        /// </summary>
        /// <param name="server">The server.</param>
        /// <param name="database">The database.</param>
        /// <returns>An instance of the BTSCatalogExplorer</returns>
        internal Microsoft.BizTalk.ExplorerOM.BtsCatalogExplorer GetBtsCatalogExplorer(string server, string database)
        {
            Microsoft.BizTalk.ExplorerOM.BtsCatalogExplorer explorer = new Microsoft.BizTalk.ExplorerOM.BtsCatalogExplorer();
            BizTalkInstallation installation;

            // Added the Else statement. When the server & database aren't empty, the old version try to initialize the connectionstring,
            // however the variable 'installation' used to read the connection string wasn't initialized.
            // With the else statement it will be, resolving the error
            if (string.IsNullOrEmpty(server) || string.IsNullOrEmpty(database))
            {
                installation = BizTalkInstallation.Load();
            }
            else
            {
                installation = BizTalkInstallation.Load(server, database);
            }

            this.Server = installation.Server;
            this.Database = installation.Database;
            explorer.ConnectionString = installation.CatalogExplorer.ConnectionString;
            return explorer;
        }

        /// <summary>
        /// Splits an assembly qualified type name into the unqualified type name and the assembly name.
        /// </summary>
        /// <param name="qualifiedName">
        /// An assembly qualified type name.
        /// </param>
        /// <param name="typeName">
        /// The unqualified name of the type.
        /// </param>
        /// <param name="assemblyName">
        /// The display name of the assembly.
        /// </param>
        protected static void SplitQualifiedTypeName(string qualifiedName, out string typeName, out string assemblyName)
        {
            int splitPosition = qualifiedName.IndexOf(',', 0);
            typeName = qualifiedName.Substring(0, splitPosition).Trim();
            assemblyName = qualifiedName.Substring(splitPosition + 1).Trim();
        }

        #endregion
    }
}