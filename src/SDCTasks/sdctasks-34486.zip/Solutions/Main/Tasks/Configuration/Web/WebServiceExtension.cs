/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.Web
{
    using System;
    using System.DirectoryServices;
    using System.Runtime.InteropServices;
    using System.Globalization;

    /// <summary>
    /// Summary description for WebServiceExtension.
    /// </summary>
    internal sealed class WebServiceExtension
    {
        private WebServiceExtension()
        {
        }

        public static void AddFile(string path, string description)
        {
            AddFile(path, description, ExtensionPermission.Allowed, true, Guid.NewGuid().ToString(null, CultureInfo.InvariantCulture), "localhost");
        }

        public static void AddFile(string path, string description, ExtensionPermission permission)
        {
            AddFile(path, description, permission, true, Guid.NewGuid().ToString(null, CultureInfo.InvariantCulture), "localhost");
        }

        public static void AddFile(string path, string description, ExtensionPermission permission, bool deleteable)
        {
            AddFile(path, description, permission, deleteable, Guid.NewGuid().ToString(null, CultureInfo.InvariantCulture), "localhost");
        }

        public static void AddFile(string path, string description, ExtensionPermission permission, bool deleteable, string groupID)
        {
            AddFile(path, description, permission, deleteable, groupID, "localhost");
        }

        public static void AddFile(string path, string description, ExtensionPermission permission, bool deleteable, string groupID, string machineName)
        {
            bool access = false;
            if (permission == ExtensionPermission.Allowed)
            {
                access = true;
            }

            DirectoryEntry web = new DirectoryEntry("IIS://" + machineName + "/W3SVC");
            ComWrapper ws = new ComWrapper(web.NativeObject);
            try
            {
                ws.CallMethod("AddExtensionFile", new object[] { path, access, groupID, deleteable, description });
            }
            catch (Exception e)
            {
                throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to create the web service extension of '{0}'. It may exist already.", path), e);
            }

            web.Dispose();
        }

        public static bool FileExists(string path, string machineName)
        {
            bool result = false;
            path = path.Trim().ToLower(CultureInfo.InvariantCulture);

            DirectoryEntry web = new DirectoryEntry("IIS://" + machineName + "/W3SVC");
            ComWrapper ws = new ComWrapper(web.NativeObject);

            try
            {
                Array extensionFiles = (Array) ws.CallMethod("ListExtensionFiles");

                foreach (string extension in extensionFiles)
                {
                    if (extension.Trim().ToLower(CultureInfo.InvariantCulture) == path)
                    {
                        result = true;
                        break;
                    }
                }
            }
            finally
            {
                web.Dispose();
            }

            return result;
        }

        public static void DeleteFile(string path, string machineName)
        {
            DirectoryEntry web = new DirectoryEntry("IIS://" + machineName + "/W3SVC");
            ComWrapper ws = new ComWrapper(web.NativeObject);

            try
            {
                ws.CallMethod("DeleteExtensionFileRecord", new object[] { path });
            }
            catch (COMException e)
            {
                throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to delete web service extension of '{0}'", path), e);
            }
            finally
            {
                web.Dispose();
            }
        }
    }
}