﻿//-----------------------------------------------------------------------
// <copyright file="InsertParent.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-07-01</date>
// <summary>Inserts a node into a hhc file</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Help
{
    #region Using directives
    using System;
    using System.Xml;
    using System.Globalization;
    using System.IO;
    using System.Text.RegularExpressions;
    using Microsoft.Win32;
    using Microsoft.Build.Framework;
    using Microsoft.Build.Tasks;
    #endregion
    /// <summary>
    /// Inserts a node inot a hhc project.
    /// </summary>          
    /// <remarks>
    /// <code><![CDATA[
    /// <Help.CreateProject SourceFolder="folder" />
    /// ]]></code>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class InsertParent : Microsoft.Sdc.Tasks.Help.InsertBase
    {
        private string endNodeName;
        private string endNodeLocal;

        /// <summary>
        /// Initializes a new instance of the InsertParent class.
        /// </summary>
        public InsertParent()
        {
        }

        /// <summary>
        /// The Name of the Node to insert the parent around
        /// </summary>
        /// <value>Must be a valid Node Name. Use -1 to specify the last node name</value>
        [Required]
        public string EndNodeName
        {
            get { return this.endNodeName; }
            set { this.endNodeName = value; }
        }

        /// <summary>
        /// The Name of the Node to insert the parent around
        /// </summary>
        /// <value>Must be a valid Node Local value.</value>
        [Required]
        public string EndNodeLocal
        {
            get { return this.endNodeLocal; }
            set { this.endNodeLocal = value; }
        }

        private string InsertEnd(string contents)
        {
            string returnString = null;

            if (this.EndNodeName == "-1")
            {
                //this is a special value to indicate add the End at the very end of the file
                returnString = contents + "</UL>";
            }
            else
            {
                string searchString = BuildSearchString(this.EndNodeName, this.EndNodeLocal);
                int location = contents.IndexOf(searchString);
                returnString = contents.Insert(location + searchString.Length, "</UL>");

            }
            return returnString;
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            //insert a node like this
            //note that it inserts a <LI> tag and then at end end of this inserted tag is a <UL> tag
            /*
            <LI>
              <OBJECT type="text/sitemap">
                <param name="Name" value="API Reference">
                <param name="Local" value="(global).html">
              </OBJECT>
            </LI>
            <UL>
            */

            /*
            Then after the end tag's </OBJECT> tag it will need to insert </UL>
            */
            
            string contents = System.IO.File.ReadAllText(this.ContentsFilePath);
            contents = this.InsertStart(contents, true, false);
            contents = this.InsertEnd(contents);
            System.IO.File.WriteAllText(this.ContentsFilePath, contents);
        }
    }
}
