//-----------------------------------------------------------------------
// <copyright file="Create.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>James Hartill</author>
// <email></email>
// <date>2004-03-25</date>
// <summary>Creates a new Event Source for Event logging.</summary>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.EventSource
{
    using System;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Creates a new Event Source for Event logging. A TaskException will be thrown if the source already exists.
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<EventSource.Create Source="source" LogName="logName" />]]></code>
    /// <para>where:</para>
    /// <para><i>source (Required)</i></para>
    /// <para>The source name by which the application is registered on the local computer.</para>
    /// <para><i>logName (Required)</i></para>
    /// <para>The name of the log the source's entries are written to. Possible values include: Application, Security, System, or a custom event log.</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <EventSource.Create
    ///             Source="MyEventSource"
    ///             LogName="Application" />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Create : TaskBase
    {
        private string source = String.Empty;
        private string logName = String.Empty;

        /// <summary>
        /// The source name by which the application is registered on the local computer
        /// </summary>
        /// <value>The source parameter can be any string, although often it will be the name of your application or a component of your application. The source must be unique on the local computer.</value>
        [Required]
        public string Source
        {
            get
            {
                return (this.source ?? String.Empty);
            }

            set
            {
                this.source = value;
            }
        }

        /// <summary>
        /// The name of the log the source's entries are written to.
        /// </summary>
        /// <value>Possible values include: Application, Security, System, or a custom event log.</value>
        [Required]
        public string LogName
        {
            get
            {
                return (this.logName ?? String.Empty);
            }

            set
            {
                this.logName = value;
            }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            Log.LogMessageFromResources("EventSource.Create", this.source, this.logName);
            if (!System.Diagnostics.EventLog.SourceExists(this.source))
            {
                System.Diagnostics.EventLog.CreateEventSource(this.source, this.logName);
            }
            else
            {
                throw new TaskException("EventSource.Exists", this.source);
            }
        }
    }
}
