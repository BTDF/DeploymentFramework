//-------------------------------------------------------------------------------------
// <copyright file="Filter.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      A filter condition.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using directives

    using System;
	using System.ComponentModel;
    using System.Xml.Serialization;

	#endregion

	/// <summary>
	/// A filter condition.
	/// </summary>
	[Serializable]
	public class Filter
	{
		#region Member Variables

        private string property;
        private string value;
        private FilterOperator filterOperator;

		#endregion

		#region Constructors

		/// <summary>
		/// Creates a new filter condition.
		/// </summary>
		public Filter()
		{
        }

		/// <summary>
		/// Creates a new filter condition.
		/// </summary>
		/// <param name="property">
		/// The name of the property to filter on.
		/// </param>
		/// <param name="filterOperator">
		/// The operator to use to compare the filter value with the actual value.
		/// </param>
		/// <param name="value">
		/// The value of the filter.
		/// </param>
		public Filter(string property, FilterOperator filterOperator, string value)
		{
			this.property = property;
			this.filterOperator = filterOperator;
			this.value = value;
		}

		#endregion

		#region Properties

		/// <summary>
		/// Gets or sets the name of the property to filter on.
		/// </summary>
		/// <value>
		/// The name of the property to filter on.
		/// </value>
		[XmlAttribute]
        public string Property
        {
            get 
			{ 
				return this.property; 
			}
            set 
			{ 
				this.property = value; 
			}
        }

		/// <summary>
		/// Gets or sets the type of operator used to compare the actual value with the filter value.
		/// </summary>
		/// <value>
		/// One of the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.FilterOperator"/> values.
		/// </value>
		[XmlIgnore]
        public FilterOperator Operator
        {
            get 
			{ 
				return this.filterOperator; 
			}
            set 
			{ 
				this.filterOperator = value; 
			}
        }

		/// <summary>
		/// Gets or sets the BizTalk operator code for type of operator used to compare the actual value with the filter value.
		/// </summary>
		/// <value>
		/// An integer representing one of the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.FilterOperator"/> values.
		/// </value>
		[XmlAttribute("Operator")]
		[Browsable(false)]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public int OperatorCode
		{
			get 
			{ 
				return (int)this.filterOperator; 
			}
			set 
			{ 
				this.filterOperator = (FilterOperator)value; 
			}
		}

		/// <summary>
		/// Gets or sets the value of the filter.
		/// </summary>
		/// <value>
		/// The value of the filter.
		/// </value>
		[XmlAttribute]
        public string Value
        {
            get 
			{ 
				return this.value; 
			}
            set 
			{ 
				this.value = value; 
			}
        }

		#endregion
	}
}

