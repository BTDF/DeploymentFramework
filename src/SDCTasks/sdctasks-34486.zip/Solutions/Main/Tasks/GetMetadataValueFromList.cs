﻿//-----------------------------------------------------------------------
// <copyright file="GetMetadataValueFromList.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author></author>
// <email></email>
// <date>2004-03-23</date>
// <summary></summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks
{
    using System;
    using System.Threading;
    using System.Globalization;
    using Microsoft.Build.Framework;
    using System.Collections;

    public class GetMetadataValueFromList : TaskBase
    {
        
        /// <summary>
        /// Initializes a new instance of the GetMetadataValueFromList class.
        /// </summary>
        public GetMetadataValueFromList()
        {
        }


        private ITaskItem[] list;
        private string attributeToMatch;
        private string valueToMatch;
        private string attributeToExtract;
        private string[] returnValue;

        [Required]
        public string MetadataNameToMatch
        {
            get { return attributeToMatch; }
            set { attributeToMatch = value; }
        }

        [Required]
        public string MetadataValueToMatch
        {
            get { return valueToMatch; }
            set { valueToMatch = value; }
        }

        [Required]
        public string MetadataNameToExtract
        {
            get { return attributeToExtract; }
            set { attributeToExtract = value; }
        }

        public ITaskItem[] List
        {
            get { return this.list; }
            set { this.list = value; }
        }

        [Output]
        public string[] Value
        {
            get { return this.returnValue; }
            set { this.returnValue = value; }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            /*
            <GetMetadataValueFromList
                List="@(Solutions)"
                MetadataNameToMatch="Identity"
                MetadataValueToMatch="%(FxCopAssemblies.SolutionName)"
                MetadataNameToExtract="FxCopVersion">
            
                <Output TaskParameter="Value" PropertyName="FxCopVersion"/>
            </GetAttributeValueFromList>
            */

            ArrayList bob = new ArrayList();
            foreach (ITaskItem item in list)
            {
                if (item.GetMetadata(this.MetadataNameToMatch) == this.MetadataValueToMatch)
                {
                    bob.Add(item.GetMetadata(this.MetadataNameToExtract));
                }
            }
    
            string[] argsArray = new string[bob.Count];
            bob.CopyTo(argsArray);
    
            this.returnValue = argsArray;
        }
    }
}

