//-------------------------------------------------------------------------------------
// <copyright file="DeleteAlias.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Deletes an Alias for a Party in Biztalk
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2004.Party
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion

    public class DeleteAlias : BizTalk2004TaskBase
    {
        #region member variables

        private string partyname;
        private string qualifier;
        private string value;

        #endregion


        #region properties



        [Required]
        public string Qualifier
        {
            get { return this.qualifier; }
            set { this.qualifier = value; }
        }

        [Required] 
        public string Value
        {
            get { return this.value; }
            set { this.value = value; }
        }

        [Required] 
        public string PartyName
        {
            get { return this.partyname; }
            set { this.partyname = value; }
        }

        #endregion

        public DeleteAlias()
        {
        }

        protected override void InternalExecute()
        {

            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation installation = this.GetInstallation();
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party party = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party.Load(installation, this.partyname);

            if (party != null)
                party.DeleteAlias(this.qualifier, this.value);
            else
                throw new InvalidOperationException("Party does not exist.");

        }
    }
}

