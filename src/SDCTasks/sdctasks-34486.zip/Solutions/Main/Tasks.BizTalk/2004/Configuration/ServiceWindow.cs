//-------------------------------------------------------------------------------------
// <copyright file="ServiceWindow.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      A service window defining start and end times for a service.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    using System;

	/// <summary>
	/// A service window defining start and end times for a service.
	/// </summary>
	internal class ServiceWindow
    {
		#region Member Variables

        private bool enabled;
        private DateTime endTime;
        private DateTime startTime;

		#endregion

		#region Constructors

		/// <summary>
		/// Creates a new service window.
		/// </summary>
		public ServiceWindow()
			: this(false)
		{
		}

		/// <summary>
		/// Creates a new service window.
		/// </summary>
		/// <param name="enabled">
		/// <b>true</b> to enable the service window, or <b>false</b> otherwise.
		/// </param>
		public ServiceWindow(bool enabled)
			: this(enabled, DateTime.MinValue, DateTime.MinValue)
		{
		}

		/// <summary>
		/// Creates a new service window with specified start and end times.
		/// </summary>
		/// <param name="enabled">
		/// <b>true</b> to enable the service window, or <b>false</b> otherwise.
		/// </param>
		/// <param name="startTime">
		/// The start time of the service window.
		/// </param>
		/// <param name="endTime">
		/// The end time of the service window.
		/// </param>
		public ServiceWindow(bool enabled, DateTime startTime, DateTime endTime)
		{
			this.enabled = enabled;
			this.startTime = startTime;
			this.endTime = endTime;
        }

		#endregion

		#region Properties

        /// <summary>
        /// Gets or sets the time at which the service window ends. The date part is ignored.
        /// </summary>
        /// <value>
        /// A <see cref="System.DateTime"/>.
        /// </value>
        public DateTime EndTime
        {
            get 
			{ 
				return this.endTime; 
			}
            set 
			{ 
				this.endTime = value; 
			}
        }

		/// <summary>
		/// Gets or sets the time at which the service window starts. The date part is ignored.
		/// </summary>
		/// <value>
		/// A <see cref="System.DateTime"/>.
		/// </value>
        public DateTime StartTime
        {
            get 
			{ 
				return this.startTime; 
			}
            set 
			{ 
				this.startTime = value; 
			}
        }

        /// <summary>
        /// Gets or sets whether the service window is available.
        /// </summary>
        /// <value>
        /// <b>true</b> if the service window is enabled, or <b>false</b> otherwise.
        /// </value>
        public bool Enabled
        {
            get 
			{ 
				return this.enabled; 
			}
            set 
			{ 
				this.enabled = value; 
			}
        }

		#endregion
	}
}

