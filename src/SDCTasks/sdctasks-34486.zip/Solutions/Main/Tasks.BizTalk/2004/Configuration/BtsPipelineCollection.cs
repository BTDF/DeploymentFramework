﻿//-------------------------------------------------------------------------------------
// <copyright file="BtsPipelineCollection.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      BtsPipelineCollection
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;

    #endregion

    internal class BtsPipelineCollection : System.Collections.ReadOnlyCollectionBase
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public BtsPipelineCollection()
        {
        }

        /// <summary>
        /// Indexer
        /// </summary>
        /// <param name="fullName">string</param>
        /// <returns>BtsPipeline</returns>
        public BtsPipeline this[string fullName]
        {
            get
            {
                BtsPipeline item = null;
                foreach (BtsPipeline currentitem in this.InnerList)
                {
                    if (currentitem.FullName == fullName)
                    {
                        item = currentitem;
                        break;
                    }
                }
                return item;
            }
        }

        /// <summary>
        /// Indexer
        /// </summary>
        /// <param name="fullName">string</param>
        /// <param name="assemblyName">string</param>
        /// <returns>BtsPipeline</returns>
        public BtsPipeline this[string fullName, string assemblyName]
        {
            get
            {
                BtsPipeline item = null;
                foreach (BtsPipeline currentitem in this.InnerList)
                {
                    if (currentitem.FullName == fullName && currentitem.BtsAssembly.DisplayName == assemblyName)
                    {
                        item = currentitem;
                        break;
                    }
                }
                return item;
            }
        }

        /// <summary>
        /// Indexer
        /// </summary>
        /// <param name="index">int</param>
        /// <returns>BtsPipeline</returns>
        public BtsPipeline this[int index]
        {
            get
            {
                return (BtsPipeline)this.InnerList[index];
            }
        }

        internal void Add(BtsPipeline item)
        {
            this.InnerList.Add(item);
        }
    }
}
