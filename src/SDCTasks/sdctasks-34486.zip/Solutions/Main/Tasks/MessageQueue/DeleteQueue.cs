//-----------------------------------------------------------------------
// <copyright file="DeleteQueue.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-03-23</date>
// <summary>Deletes the specified MessageQueue.</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.MessageQueue
{
    using System;
    using System.Xml;
    using System.Globalization;
    using System.Messaging;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Deletes the specified Message Queue.
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<MessageQueue.DeleteQueue QueuePath="queuePath" />]]></code>
    /// <para>where:</para>
    /// <para><i>queuePath (Required)</i></para>
    /// <para>
    /// The location of the queue to be deleted. The path must be prefixed by the machine name (or "." to represent the local computer). 
    /// See <see cref="System.Messaging.MessageQueue.Path"/> for more details.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test">
    ///         <MessageQueue.DeleteQueue
    ///             QueuePath=".\\TempQueue" />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class DeleteQueue : TaskBase
    {
        private string queuePath;

        /// <summary>
        /// The path of the queue to delete.
        /// </summary>
        /// <value>See <see cref="System.Messaging.MessageQueue.Path"/> for more details on correct formats for this property</value>
        [Required]
        public string QueuePath
        {
            get
            {
                return (this.queuePath == null ? String.Empty : this.queuePath);
            }

            set
            {
                this.queuePath = value;
            }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            Log.LogMessageFromResources("Msmq.Delete", this.queuePath);
            MessageQueue.Delete(this.queuePath);
        }
    }
}