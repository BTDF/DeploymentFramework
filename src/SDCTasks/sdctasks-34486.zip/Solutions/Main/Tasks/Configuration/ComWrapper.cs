/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author></Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/

namespace Microsoft.Sdc.Tasks.Configuration
{
    using System;
    using System.Reflection;

    internal class ComWrapper
    {
        private Type   comObjectType;
        public object  comObject;

        public object ComObject
        {
            get
            {
                return comObject;
            }
        }

        public ComWrapper(object o)
        {
            Initialize(o);
        }

        public ComWrapper(string progID)
        {
            Initialize(Activator.CreateInstance(Type.GetTypeFromProgID(progID)));
        }

        public ComWrapper(System.Guid guid)
        {
            Initialize(Activator.CreateInstance(Type.GetTypeFromCLSID(guid)));
        }

        private void Initialize(object o) 
        {
            this.comObject = o;
            this.comObjectType = this.comObject.GetType();
        }

        public object CallMethod(string methodName)
        {
            return this.CallMethod(methodName, new object[] {});
        }

        public object CallMethod(string methodName, object [] args)
        {
            return this.comObjectType.InvokeMember(methodName, BindingFlags.Default | BindingFlags.InvokeMethod, null, this.comObject, args);
        }

        public object GetProperty(string propertyName)
        {
            return this.comObjectType.InvokeMember(propertyName, BindingFlags.InvokeMethod|BindingFlags.GetProperty, null, this.comObject, new object[] {});
        }

        public object GetProperty(string propertyName, string args)
        {
            return this.comObjectType.InvokeMember(propertyName, BindingFlags.InvokeMethod | BindingFlags.GetProperty, null, this.comObject, new object[] {args});
        }

        public object GetProperty(string propertyName, int args)
        {
            return this.comObjectType.InvokeMember(propertyName, BindingFlags.InvokeMethod | BindingFlags.GetProperty, null, this.comObject, new object[] {args});
        }

        public void SetProperty(string propertyName, object [] args)
        {
            this.comObjectType.InvokeMember(propertyName, BindingFlags.Default | BindingFlags.SetProperty, null, this.comObject, args);
        }  

        public void SetProperty(string propertyName, object arg)
        {
            object[] args = {arg};
            this.comObjectType.InvokeMember(propertyName, BindingFlags.Default | BindingFlags.SetProperty, null, this.comObject, args);
        }       


    }
}
