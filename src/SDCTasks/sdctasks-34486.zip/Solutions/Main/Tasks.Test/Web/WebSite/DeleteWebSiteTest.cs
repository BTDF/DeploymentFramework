//-----------------------------------------------------------------------
// <copyright file="DeleteWebSiteTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-03-23</date>
// <summary>Tests deleting a website</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration.Web;

    /// <summary>
    /// Unit test for the DeleteWebSiteTest Task
    /// </summary>
    [TestClass]
    public class DeleteWebSiteTest
    {
        [TestMethod]
        public void TestDeleteWebSite()
        {
            Tasks.Web.WebSite.Create task = new Tasks.Web.WebSite.Create();

            //Generate a new random webname
            Guid guid = Guid.NewGuid();
            string webname = guid.ToString();
            webname = webname.Replace("-", "").Substring(0, 11);
            string newFolder = webname;

            if (WebSite.Exists("localhost", webname))
            {
                Assert.Fail("WebSite already existed");
            }

            task.Description = webname;
            task.Path = Environment.ExpandEnvironmentVariables(@"%TEMP%\" + newFolder);
            task.HostName = "test";
            task.Port = "90";
            bool taskReturnValue = task.Execute();
            Assert.IsTrue(taskReturnValue, "TestCreateWebSite");

            //Check the web now exists
            bool exists = WebSite.Exists("localhost", webname);
            Assert.IsTrue(exists, "TestCreateWebSite");

            //Now delete the web
            WebSite.Delete(webname, "localhost");

            Tasks.Web.WebSite.DeleteWebsite task2 = new Tasks.Web.WebSite.DeleteWebsite();
            task2.Description = webname;

            taskReturnValue = task2.Execute();    
            Assert.IsTrue(taskReturnValue, "DeleteWebSite task executed");
        
            exists = WebSite.Exists("localhost", webname);
            Assert.IsFalse(exists, "TestCreateWebSite");
        }
    }
}


