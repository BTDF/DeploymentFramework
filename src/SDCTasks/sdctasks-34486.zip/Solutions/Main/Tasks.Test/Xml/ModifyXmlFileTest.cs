//-----------------------------------------------------------------------
// <copyright file="ModifyXmlFileTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-06-02</date>
// <summary>Tests xml file modification tasks</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    using System.Xml;

    /// <summary>
    /// Unit test for the modifying an xml file test
    /// </summary>
    [TestClass]
    public class ModifyXmlFileTest
    {
        private const string XML_FILE = @"TestData\TestModifyXmlTask.xml";

        public ModifyXmlFileTest()
        {
        }
        
        /// <summary>
        /// Unit test for the Xml.ModifyFile unit test. To keep it atomic, the test file
        /// specified by XML_FILE is backed up. The Xml file is then modified and saved. 
        /// An independent test to assert the modification has been persisted is made, before the
        /// backed up file is restored.
        /// </summary>
        [TestMethod]
        [Ignore]
        public void TestModifyXmlFile()
        {
            //Backup the Xml file before the tests start.
            BackupTestData();

            try
            {
                Tasks.Xml.ModifyFile modifyXmlTask = new Tasks.Xml.ModifyFile();
               
                modifyXmlTask.Path = XML_FILE;

                string attributeName = "NodeID";
                bool force = true;
                string newValue = "MODIFIED";
                string regularExpression = String.Empty;
                string xPath = "/UnitTestNodes/UnitTestNode";

                modifyXmlTask.AttributeName = attributeName;
                modifyXmlTask.Force = force;
                modifyXmlTask.NewValue = newValue;
                modifyXmlTask.RegularExpression = regularExpression;
                modifyXmlTask.XPath = xPath;

                bool modifyXmlTaskReturnValue = modifyXmlTask.Execute();

                //Test the task was executed successfully
                Assert.IsTrue(modifyXmlTaskReturnValue, "XmlModificationSucceeded");

                //Test the properties are persisted correctly
                Assert.IsTrue(modifyXmlTask.Path == XML_FILE, "XmlModify - Path");
                Assert.IsTrue(modifyXmlTask.AttributeName == attributeName, "XmlModify - Attribute");
                Assert.IsTrue(modifyXmlTask.Force == force, "XmlModify - Force");
                Assert.IsTrue(modifyXmlTask.NewValue == newValue, "XmlModify - NewValue");
                Assert.IsTrue(modifyXmlTask.RegularExpression.Length == 0, "XmlModify - RegularExpression");
                Assert.IsTrue(modifyXmlTask.XPath == xPath, "XmlModify - XPath");

                //Check that the newValue is in the file
                XmlDataDocument doc = new XmlDataDocument();
                doc.Load(XML_FILE);
                XmlNode node = doc.SelectSingleNode(xPath);
                Assert.IsTrue(node.Attributes[0].Value == modifyXmlTask.NewValue, "XmlModify - Checked");
            }
            finally
            {
                RestoreTestData();
            }
        }

        /// <summary>
        /// Makes a backup of the ModifyXml test file.
        /// </summary>
        private void BackupTestData()
        {
            if (!(System.IO.File.Exists(XML_FILE + ".bak")))
            {
                System.IO.File.Copy(XML_FILE, XML_FILE + ".bak");
            }
        }

        /// <summary>
        /// Restores the backed up ModifyXml test data.
        /// </summary>
        private void RestoreTestData()
        {
            if (System.IO.File.Exists(XML_FILE))
            {
                System.IO.File.Delete(XML_FILE);
                System.IO.File.Copy(XML_FILE + ".bak", XML_FILE);
                System.IO.File.Delete(XML_FILE + ".bak");
            }
        }
    }
}


