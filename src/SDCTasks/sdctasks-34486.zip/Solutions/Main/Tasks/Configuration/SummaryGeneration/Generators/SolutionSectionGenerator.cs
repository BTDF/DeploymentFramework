/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Simon Ransom</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.SummaryGeneration.Generators
{
	using System;
	using System.IO;
	using System.Xml;
	using System.Text.RegularExpressions;

	/// <summary>
	/// Summary description for SolutionSectionGenerator.
	/// </summary>
	internal class SolutionSectionGenerator: ISectionGenerator
	{
		public Section GenerateSection(string sourceFolder, string fileSpec, string name)
		{
			XmlDocument section = new XmlDocument();
			section.AppendChild(section.CreateElement("Section"));
			section.DocumentElement.SetAttribute("Type","Solution");
			if (name != null)
			{
				section.DocumentElement.SetAttribute("Name",name);
			}
			string [] reportFiles = Directory.GetFiles(sourceFolder,fileSpec);
			
			Regex regExHeader=new Regex(@"Rebuild All started: Project: (?<project>[^ ,]+), Configuration: (?<configuration>[A-Za-z]+)");
			Regex regExFooter=new Regex(@"Build complete -- (?<errors>[0-9]+) errors, (?<warnings>[0-9]+) warnings");
			
			string projectName=null;
			string configurationName=null;
			
			foreach (string reportFile in reportFiles)
			{
				// Open the solution build output file
				using (StreamReader reader = File.OpenText(reportFile))
				{
					string line=null;
					while ((line = reader.ReadLine()) != null)
					{
						if (regExHeader.IsMatch(line)) 
						{
							Match match = regExHeader.Match(line);
							GroupCollection group =match.Groups;
							projectName = group["project"].Value;
							configurationName = group["configuration"].Value;
						}
						else if (regExFooter.IsMatch(line))
						{
							Match match = regExFooter.Match(line);
							GroupCollection group =match.Groups;
							string errors = group["errors"].Value;
							string warnings = group["warnings"].Value;

							XmlElement projectElement = section.CreateElement("Project");
							projectElement.SetAttribute("Name",projectName);
							projectElement.SetAttribute("Configuration",configurationName);
							projectElement.SetAttribute("Errors",errors);
							projectElement.SetAttribute("Warnings",warnings);
							section.DocumentElement.AppendChild(projectElement);
						}
					}
					reader.Close();
				}			
			}
			return new Section(section);
		}

		public SolutionSectionGenerator()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
