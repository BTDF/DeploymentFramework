﻿
namespace Microsoft.Sdc.Tasks.BizTalk2004.ReceiveLocation
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion


    public class RemoveReceiveLocation : BizTalk2004TaskBase
    {

        #region member variables

        private string name;
        private string receivePort;

        #endregion


        #region properties

        /// <summary>
        /// Gets or sets the name of the receive location.
        /// </summary>
        /// <value>A string representing the name of this receive location.</value>
        [Required]
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        /// <summary>
        /// The receive port that this receive location belongs to.
        /// </summary>
        [Required]
        public string ReceivePort
        {
            get { return this.receivePort; }
            set { this.receivePort = value; }
        }

        #endregion


        public RemoveReceiveLocation() { }


        protected override void InternalExecute()
        {
            //loading
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation installation = this.GetInstallation();
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.ReceivePort rxPort = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.ReceivePort.Load(installation, this.receivePort);

            if (rxPort == null)
                throw new InvalidOperationException("Receive Port does not exist.");

            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.ReceiveLocation rxLocation = rxPort.ReceiveLocations[this.name];

            if (rxLocation == null)
                throw new InvalidOperationException("The Receive Location does not exist.");

            //deleting the receive location
            rxPort.RemoveReceiveLocation(rxLocation);
        }
    }
}

