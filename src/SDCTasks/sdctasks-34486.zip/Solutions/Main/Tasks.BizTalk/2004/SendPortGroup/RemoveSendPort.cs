namespace Microsoft.Sdc.Tasks.BizTalk2004.SendPortGroup
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;

    #endregion

    public class RemoveSendPort : BizTalk2004TaskBase
    {
        private string name;
        private string sendport;

        [Required]
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        [Required]
        public string SendPort
        {
            get { return this.sendport; }
            set { this.sendport = value; }

        }

        public RemoveSendPort()
        {

        }

        protected override void InternalExecute()
        {
            BizTalkInstallation installation = this.GetInstallation();
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SendPortGroup sendportGroup = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SendPortGroup.Load(installation, this.name);

            if (sendportGroup.SendPorts.Contains(this.sendport))
                sendportGroup.SendPorts.Remove(installation.SendPorts[this.sendport]);
            else
                throw new InvalidOperationException(string.Format("SendPortGroup {0} does not contain SendPort {1}.", this.name, this.sendport));

        }

    }
}

