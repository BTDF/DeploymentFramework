//-----------------------------------------------------------------------
// <copyright file="Create.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-03-25</date>
// <summary>Creates an Active Directory group either locally or on a domain.</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.ActiveDirectory.Group
{
    using System;
    using Microsoft.Build.Framework;
    using Microsoft.Build.Utilities;
    using System.Resources;
    using System.Reflection;
    using System.Xml;
    using System.Globalization;
    using AD = Microsoft.Sdc.Tasks.Configuration.ActiveDirectory;

    /// <summary>
    /// Creates an Active Directory group either locally or on a domain.
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<ActiveDirectory.Group.Create GroupName="groupName" DomainName="domainName" EnsureGroup="ensureGroup" />]]></code>
    /// <para>where:</para>
    /// <para><i>groupName (Required)</i></para>
    /// <para>The groupname to create.</para>
    /// <para><i>domainName</i></para>
    /// <para>The domain the group is to be added to. If not specified it defaults to the local machine.</para>
    /// <para><i>Description</i></para>
    /// <para>A description of the group.</para>
    /// <para><i>ensureGroup</i></para>
    /// <para>If TRUE and the group already exists then no error is thrown.</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <ActiveDirectory.Group.Create
    ///             GroupName="newGroup"
    ///             DomainName="mydomain"
    ///             Description="Group Description"
    ///             EnsureGroup="true" />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Create : TaskBase
    {
        private string groupName;
        private string domainName;
        private bool ensureGroup;
        /// <summary>Private variable</summary>
        private string description;

        /// <summary>
        /// Initializes a new instance of the Create class.
        /// </summary>
        public Create()
        {
        }        

        /// <summary>
        /// The name of the group to be created
        /// </summary>
        /// <value>The name of the group</value>
        [Required]
        public string GroupName
        {
            get
            {
                return (this.groupName == null ? String.Empty : this.groupName);
            }

            set
            {
                this.groupName = value;
            }
        }

        /// <summary>
        /// The domain to which the group is to be added
        /// </summary>
        /// <value>The name of the domain to which the group is to be added. If not specified it defaults to the local machine</value>
        public string DomainName
        {
            get
            {
                return (this.domainName == null ? String.Empty : this.domainName);
            }

            set
            {
                this.domainName = value;
            }
        }

        /// <summary>
        /// A description for the group being added.
        /// </summary>
        public string Description
        {
            get { return this.description; }
            set { this.description = value; }
        }


        /// <summary>
        /// If TRUE and the Group already exists then no error is thrown.
        /// </summary>
        /// <value>True to not throw an error if the group already exists within the domain</value>
        public bool EnsureGroup
        {
            get
            {
                return this.ensureGroup;
            }

            set
            {
                this.ensureGroup = value;
            }
        }       

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            #region Execute code

            if (this.ensureGroup)
            {
                Log.LogMessageFromResources("ActiveDirectory.EnsureGroup", this.groupName);
                this.EnsureGroupExists(this.groupName, this.domainName, this.description);
            }
            else
            {
                Log.LogMessageFromResources("ActiveDirectory.CreateGroup", this.groupName);
                AD.Group group = new AD.Group(this.groupName, this.domainName);
                if (!string.IsNullOrEmpty(this.description))
                {
                    group.Description = this.description; 
                }
                group.Save();
            }
            #endregion
        }

        private void EnsureGroupExists(string name, string domain, string description)
        {
            if (domain != null && domain.Length > 0)
            {
                if (!AD.Group.Exists(name, domain))
                {
                    Log.LogMessageFromResources("ActiveDirectory.CreateGroup", name);
                    AD.Group grp = new AD.Group(name, domain);
                    if (!string.IsNullOrEmpty(description))
                    {
                        grp.Description = description;
                    }
                    grp.Save();
                }
            }
            else
            {
                if (!AD.Group.Exists(name))
                {
                    Log.LogMessageFromResources("ActiveDirectory.CreateGroup", name);
                    AD.Group grp = new AD.Group(name);
                    if (!string.IsNullOrEmpty(description))
                    {
                        grp.Description = description;
                    }
                    grp.Save();
                }
            }
        }
    }
}