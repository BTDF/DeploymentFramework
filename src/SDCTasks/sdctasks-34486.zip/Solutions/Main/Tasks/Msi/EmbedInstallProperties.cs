//-------------------------------------------------------------------------------------
// <copyright file="EmbedInstallProperties.cs" company="Microsoft">
//      Copyright (c) Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <author>Shaun Wilde</author>
// <email>v-swilde@microsoft.com</email>
// <date>2006-02-15</date>
// <summary>
//      Embed install properties into an MSI File
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Msi
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Text;
    using System.Xml;
    using System.Runtime.InteropServices;

    #endregion

    #region Class Comments
    /// <summary>
    /// Installs an MSI package.
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<Msi.Install MsiPath="msiPath" ProductCode="productCode" LogFile="logFile" LogOptions="logOptions" UserInterfaceLevel="userInterfaceLevel" LoadUserProfile="loadUserProfile" PropertyFiles="propertyFiles" Properties="properties" Features="features" />]]></code>
    /// <para>where:</para>
    /// <para><i>msiPath (Required*)</i></para>
    /// <para>
    /// The path to the MSI to install.
    /// </para>
    /// <para><i>productCode (Required*)</i></para>
    /// <para>
    /// The GUID product code of the product to install.
    /// </para>
    /// <para><i>logFile (Required)</i></para>
    /// <para>
    /// The path to the log file for the installation. The recommended file name is the name of the MSI
    /// with the extension *.install.log.
    /// </para>
    /// <para><i>logOptions</i></para>
    /// <para>
    /// A delimited list of logging options. Possible values are: Default, StatusMessages, Warnings, Errors,
    /// ActionStart, ActionSpecificRequests, UserRequests, InitialParameters, OutOfMemory, TerminalProperties,
    /// Verbose, AppendLog, FlushEachLine, AllInformation. The default is Default. Please see the
    /// <see cref="Microsoft.Sdc.Tasks.Msi.MsiTaskBase.MsiLoggingOptions"/> documentation for
    /// further information.
    /// </para>
    /// <para><i>userInterfaceLevel</i></para>
    /// <para>
    /// The user interface level displayed by MsiExec during the installation. Possible values are: 
    /// None, Basic, ReducedWithModalDialog, FullWithModalDialog, NoneWithModalDialog, BasicWithModalDialog,
    /// BasicWithNoModalDialogs. The default is None. Please see the 
    /// <see cref="Microsoft.Sdc.Tasks.Msi.MsiTaskBase.MsiExecUILevel"/> documentation for
    /// further information.
    /// </para>
    /// <para><i>loadUserProfile</i></para>
    /// <para>
    /// <b>true</b> if the user's profile is loaded during the processing of the MSI, or <b>false</b> otherwise.
    /// This may be needed for some custom installation actions such as configuring ports and channels in 
    /// Microsoft BizTalk Server. The default is <b>false</b>.
    /// </para>
    /// <para><i>propertyFiles</i></para>
    /// <para>
    /// A delimited list of XML property files that provide installation properties for the MSI. 
    /// Multiple property files are allowed so that you can have a hierarchy - the first file provides a base set of properties
    /// (e.g. environmental properties for a particular rig) and subsequent files can override these to provide a more
    /// specific property or add new properties (e.g. properties for a machine, then properties for an individual MSI).
    /// </para>
    /// <para><i>properties</i></para>
    /// <para>
    /// A delimited list of installation properties in the format Name=Value. If any property files have been 
    /// specified, then the properties specified here are seen as the most significant and can overwrite 
    /// any of the property values specified in the files.
    /// </para>
    /// <para><i>features</i></para>
    /// <para>
    /// A delimited list of the names of features to be installed. This is not necessary if the MSI does not
    /// have features configured, or you wish all features to be installed.
    /// </para>
    /// <para>
    /// <b>*</b> - Either <i>msiPath</i> or <i>productCode</i> must be provided. If both are provided then 
    /// <i>msiPath</i> takes precedence and <i>productCode</i> is ignored. If neither are provided then the
    /// task will throw an exception when it executes.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test">
    ///         <Msi.EmbedInstallProperties 
    ///             MsiPath="C:\Build\Msi\Packages\MyPackage.msi" 
    ///             ProductCode="b6b6f41c-fd3e-4b5b-8a73-c59494974990" 
    ///             LogFile="C:\Build\Msi\Packages\MyPackage.install.log" 
    ///             LogOptions="Default;Verbose" 
    ///             UserInterfaceLevel="None" 
    ///             LoadUserProfile="true" 
    ///             PropertyFiles="C:\Build\Properties\Global.xml;C:\Build\Properties\Rig4.xml" 
    ///             Properties="INSTALLDIR=C:\Install;DOMAIN=rig4;MACHINE=r4app01" 
    ///             Features="MSMQ,BTS2004,WebServices" >
    ///             <Output TaskParameter="ExecArguments" PropertyName="ExecArguments" />
    ///         </Msi.EmbedInstallProperties>
    ///     </Target>
    /// </Project>
    /// ]]></code>  
    /// A sample property file is shown below. Note that you must include the namespace for the file to
    /// be parsed correctly.
    /// <code><![CDATA[
    /// <Properties xmlns="urn:sdc-microsoft-com:deployment:properties:v2.0">
    ///     <Property Name="MY_PROPERTY" Value="some value" />
    ///     <Property Name="ANOTHER_PROPERTY" Value="some other value" />
    ///     <Property Name="SOMETHING_ELSE" Value="hello world" />
    ///     ... etc ...
    /// </Properties>
    /// ]]></code>
    /// </example>
    #endregion
    public sealed class EmbedInstallProperties : MsiTaskBase
    {
        #region Member Variables

        /// <summary>
        /// internal variable
        /// </summary>
        private string[] features;

        /// <summary>
        /// internal variable
        /// </summary>
        private bool embedProperties = false;

        /// <summary>
        /// internal variable
        /// </summary>
        private string msiExecArguments;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the EmbedInstallProperties class.
        /// </summary>
        public EmbedInstallProperties()
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the features selected to be installed from the MSI. This may be <b>null</b>.
        /// </summary>
        /// <remarks>
        /// This property is not necessary if either the MSI does not have any features, or if you want all features in the
        /// MSI to be installed. If you do wish to select particular features then this is a list of the names.
        /// </remarks>
        /// <value>
        /// A list of features selected to be installed from the MSI.
        /// </value>
        public string[] Features
        {
            get
            {
                return (this.features == null) ? new string[0] : this.features;
            }

            set
            {
                this.features = value;
            }
        }

        /// <summary>
        /// Specifies if Properties should be embedded into the MSI before installation.
        /// </summary>
        /// <remarks>
        /// When this property is set to true all properties specified in a property file will 
        /// be embedded into the MSI unless they have an additional attribute <b>Embed</b> set to false.
        /// All properties with an Embed attribute set to false will be included on the command-line.
        /// </remarks>
        /// <value>
        /// True or False.
        /// </value>
        public bool EmbedProperties
        {
            get
            {
                return this.embedProperties;
            }

            set
            {
                this.embedProperties = value;
            }
        }

        /// <summary>
        /// The argument string to use with the MSI file
        /// </summary>
        [Microsoft.Build.Framework.Output]
        public string ExecArguments
        {
            get
            {
                return this.msiExecArguments;
            }

            set
            {
                this.msiExecArguments = value;
            }
        }

        #endregion

        #region Protected Methods

        /// <summary>
        /// Executes the task to embed the properties into the MSI.
        /// </summary>
        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            this.msiExecArguments = BuildInstallArgumentsAndEmbedProperties(this.embedProperties, this.ProductCode, this.features);
        }
        #endregion
    }
}