﻿//-----------------------------------------------------------------------
// <copyright file="BtsOrchestrationCollection.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <summary>BtsOrchestrationCollection</summary>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;
    using Microsoft.BizTalk.ExplorerOM;

    #endregion

    internal class BtsOrchestrationCollection : System.Collections.ReadOnlyCollectionBase
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public BtsOrchestrationCollection() 
        { 
        }

        /// <summary>
        /// Indexer
        /// </summary>
        /// <param name="fullName">fullName</param>
        /// <returns></returns>
        public BtsOrchestration this[string fullName]
        {
            get
            {
                BtsOrchestration item = null;
                foreach (BtsOrchestration currentitem in this.InnerList)
                {
                    if (currentitem.FullName == fullName)
                    {
                        item = currentitem;
                        break;
                    }
                }
                return item;
            }
        }

        /// <summary>
        /// Indexer
        /// </summary>
        /// <param name="index">index</param>
        /// <returns></returns>
        public BtsOrchestration this[int index]
        {
            get
            {
                return (BtsOrchestration)this.InnerList[index];
            }
        }

        internal void Add(BtsOrchestration item)
        {
            this.InnerList.Add(item);
        }
    }
}
