/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Giles Knap/Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2005 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/


namespace Microsoft.Sdc.Tasks.Configuration.Web 
{
    using System.Globalization;
    using System;
    using System.DirectoryServices;
    using System.Security.Principal;
    using System.Collections;
    using System.Runtime.InteropServices;
    using Microsoft.Sdc.Tasks.Configuration.Framework;
    using System.Text;

    internal class IsapiFilters 
    {
        private WebSite             site = null;
        private DirectoryEntry      filtersDe = null;
        private DirectoryEntry      siteDe = null;
        private ArrayList           filterLoadOrder = new ArrayList();
        private  static char[]      separators = {','};

        public IsapiFilters(WebSite site) 
        {
            this.site = site;
            siteDe = site.GetDirectoryEntry();

            try 
            {
                filtersDe = siteDe.Children.Find("Filters", "IIsFilters");
            }
            catch 
            {
                filtersDe = null;
            }   
     
            if(filtersDe != null)
            {
                string loadOrder = filtersDe.Properties["FilterLoadOrder"].Value.ToString();
                filterLoadOrder.AddRange(loadOrder.Split(separators));
            }
        }

        DirectoryEntry EnsureIsapiFilters() 
        {
            if (filtersDe == null) 
            {                
                filtersDe = siteDe.Children.Add("Filters", "IIsFilters");
            }
        
            return filtersDe;
        }

        public bool Exists(string name)
        {
            if (filtersDe == null)
            {
                return false;
            }
            else
            {
                try 
                {
                    DirectoryEntry de = filtersDe.Children.Find(name, "IIsFilter");
                    return true;
                }
                catch 
                {
                    return false;
                }           
            }
        }

        public void Add(string name, string filterPath)
        {
            DirectoryEntry de = EnsureIsapiFilters();
            
            DirectoryEntry newDe = de.Children.Add(name, "IIsFilter");
            
            ComWrapper app = new ComWrapper(newDe.NativeObject);
            app.CallMethod("Put", new Object[] {"FilterPath", filterPath});
            this.filterLoadOrder.Add(name);
            this.UpdateLoadOrder();

            newDe.CommitChanges();
        }

        public void Delete(string name)
        {
            // if not found then allow original exception to flow up to caller
            DirectoryEntry de = filtersDe.Children.Find(name, "IIsFilter");
            int loadPosition = filterLoadOrder.IndexOf(name);
            
            if (loadPosition != -1)
            {      
                this.filterLoadOrder.RemoveAt(loadPosition);
                this.UpdateLoadOrder();

                object[] args = {"IIsFilter", name};
                filtersDe.Invoke("Delete", args);
                filtersDe.CommitChanges();            
            }            
        }

        public void UpdateLoadOrder()
        {
            DirectoryEntry de = EnsureIsapiFilters();

            StringBuilder filterLoadOrderString = new StringBuilder();
            for (int i = 0; i < filterLoadOrder.Count; i++)
            {
                if ( i > 0 ) filterLoadOrderString.Append(separators[0]);
                filterLoadOrderString.Append(filterLoadOrder[i]);
            }

            ComWrapper app = new ComWrapper(de.NativeObject);                 
            app.CallMethod("Put", new Object[] {"FilterLoadOrder", filterLoadOrderString.ToString()});

            de.CommitChanges();
        }

        public string[] FilterLoadOrder 
        {
            get 
            {
                return (string[]) filterLoadOrder.ToArray();
            }
            set 
            {
                // Todo, need to validate this before allowing update
                filterLoadOrder.Clear();
                filterLoadOrder.AddRange(value);
            }
        }
    }
}

