//-------------------------------------------------------------------------------------
// <copyright file="BindingType.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Defines the type of binding for an orchestration port. 
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    /// <summary>
    /// Defines the type of binding for an orchestration port. 
    /// </summary>
    public enum BindingType
    {
        /// <summary>
        /// Logical (declarative) binding implies that the port will be bound later in BizTalk Explorer. 
        /// </summary>
        Logical = 1,
        
        /// <summary>
        /// Physical (declarative with shortcut) binding means that the endpoint (in BizTalk Explorer) port is 
        /// created in the orchestration and bound to this orchestration port.
        /// </summary>
        Physical = 2,
        
        /// <summary>
        /// Orchestration binding implies that the port does not connect to a fixed endpoint, but instead 
        /// connects to the MessageBox database directly.
        /// </summary>
        Direct = 3,
        
        /// <summary>
        /// Dynamic binding implies that the endpoint will be made available at runtime.
        /// </summary>
        Dynamic = 4,
        
        /// <summary>
        /// Role binding implies that the port gets bound to a party indirectly by virtue of that party being 
        /// enlisted under a role. 
        /// </summary>
        Role = 5
    }
}

