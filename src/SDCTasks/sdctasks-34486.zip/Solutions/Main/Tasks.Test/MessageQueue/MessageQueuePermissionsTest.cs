//-----------------------------------------------------------------------
// <copyright file="MessageQueuePermissionsTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-05-28</date>
// <summary>Tests message queue permission tasks</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    using System.Messaging;

    /// <summary>
    /// Unit test for the testing of the message queue tasks
    /// </summary>
    [TestClass]
    public class MessageQueuePermissionsTest
    {
        

        private const string QUEUE_PATH = ".\\queueUnitTest";

        public MessageQueuePermissionsTest()
        {
        }

       

        [TestMethod]
        [Ignore]//("Can't send message on newly created queue. Could it be due to http://support.microsoft.com/default.aspx?scid=kb;en-us;834467&Product=WinXP?")]
        public void TestMessageQueue()
        {
            //Make sure the queue doesn't exist...
            if (System.Messaging.MessageQueue.Exists(QUEUE_PATH))
            {
                System.Messaging.MessageQueue.Delete(QUEUE_PATH);
            }

            //Create the queue without transactions
            CreateQueue(false);

            //Create a user
            Tasks.ActiveDirectory.User.Create newUser = new Microsoft.Sdc.Tasks.ActiveDirectory.User.Create();
            string userName = Guid.NewGuid().ToString("N").Substring(0, 11);
            newUser.UserName = userName;
            newUser.Password = "123$ABC";
            newUser.Execute();

            //Check the user now exists
            bool userExists = Configuration.ActiveDirectory.User.Exists(userName);
            Assert.IsTrue(userExists);

            Tasks.MessageQueue.SetPermissions permissionsTask = new Microsoft.Sdc.Tasks.MessageQueue.SetPermissions();
            
            string accessRight = "GenericRead";
            bool denyPermission = true;
            string username = newUser.UserName;

            permissionsTask.AccessRight = accessRight;
            permissionsTask.DenyPermission = denyPermission;
            permissionsTask.QueuePath = QUEUE_PATH;
            permissionsTask.UserName = username;

            bool permissionsTaskReturnValue = permissionsTask.Execute();
            Assert.IsTrue(permissionsTaskReturnValue);

            Assert.IsTrue(permissionsTask.AccessRight == accessRight, "MSMQPermissionsProperties");
            Assert.IsTrue(permissionsTask.DenyPermission == denyPermission, "MSMQPermissionsProperties");
            Assert.IsTrue(permissionsTask.QueuePath == QUEUE_PATH, "MSMQPermissionsProperties");
            Assert.IsTrue(permissionsTask.UserName == username, "MSMQPermissionsProperties");

            //Use System.Messaging to ensure this queue exists
            SendAndReceiveMessage(true);

            //Delete the queue
            DeleteQueue();

            //Use System.Messaging to ensure this queue no longer exists
            SendAndReceiveMessage(false);

            Configuration.ActiveDirectory.User deletedUser = Configuration.ActiveDirectory.User.Load(userName);
            bool userDeleted = deletedUser.Delete();
            Assert.IsTrue(userDeleted, "MSMQPermissions");

        }


       private void CreateQueue(bool transactionsEnabled)
        {
            //Create the queue
            Tasks.MessageQueue.Create createQueueTask = new Tasks.MessageQueue.Create();
            createQueueTask.QueuePath = QUEUE_PATH;
            string queueLabel = TaskTestUtilities.GenerateNewGuid();
            createQueueTask.QueueLabel = queueLabel;
            createQueueTask.TransactionsEnabled = transactionsEnabled;

            bool createQueueTaskReturnValue = createQueueTask.Execute();

            //Test the new queue was created successfully
            Assert.IsTrue(createQueueTaskReturnValue);
            Assert.AreEqual(createQueueTask.QueuePath, QUEUE_PATH);
            Assert.AreEqual( createQueueTask.QueueLabel, queueLabel);
            Assert.AreEqual(createQueueTask.TransactionsEnabled, transactionsEnabled);
        }

        private void DeleteQueue()
        {
            Tasks.MessageQueue.DeleteQueue deleteQueueTask = new Tasks.MessageQueue.DeleteQueue();
            deleteQueueTask.QueuePath = QUEUE_PATH;

            bool deleteQueueTaskReturnValue = deleteQueueTask.Execute();

            //Test the new queue was created successfully
            Assert.IsTrue(deleteQueueTaskReturnValue, "DeleteMSMQSucceeded");
        }

        /// <summary>
        /// Attempts to send and receive a message on the created queue
        /// </summary>
        /// <param name="successExpected">True if this test is expected to pass, otherwise false</param>
        private void SendAndReceiveMessage(bool successExpected)
        {
            try
            {
                System.Messaging.MessageQueue testQueueCreation = new System.Messaging.MessageQueue(QUEUE_PATH);
                System.Messaging.Message testSendMessage = new System.Messaging.Message();
                testSendMessage.Body = "Send Message Unit Test";
                testQueueCreation.Send(testSendMessage);

                testQueueCreation.MessageReadPropertyFilter.Priority = true;
                testQueueCreation.Formatter = new XmlMessageFormatter(new Type[] { typeof(string) });
                System.Messaging.Message testReceiveMessage = testQueueCreation.Receive();
                Assert.AreEqual( testSendMessage.Body, testReceiveMessage.Body);

            }
            catch (MessageQueueException msmqEx)
            {
                if (successExpected)
                {
                    Assert.Fail(msmqEx.ToString());
                }
                else
                {
                    return;
                }
            }

            if (!successExpected)
            {
                Assert.Fail("Message sent and received successfully when failure expected");
            }
        }
    }
}


