//-----------------------------------------------------------------------
// <copyright file="DeleteClusterResource.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Mark Phillips</author>
// <email>v-mphill@microsoft.com</email>
// <date>2004-05-24</date>
// <summary>Deletes a Cluster Resource.</summary>
//-----------------------------------------------------------------------
#if CLUSTER
namespace Microsoft.Sdc.Tasks.Cluster.Resource
{
    #region Using directives

    using System;
    using System.Reflection;
    using System.Collections;
    using System.Runtime.InteropServices;
    using Microsoft.Cluster.Interop;
    using Microsoft.Build.Framework;

    #endregion

    /// <summary>
    /// Deletes a Cluster Resource
    /// </summary>          
    /// <remarks>
    /// <code><![CDATA[
    /// <Cluster.Resource.DeleteClusterResource
    ///             Resource="resource"
    ///             Cluster="cluster" >
    /// </Cluster.Resource.DeleteClusterResource>
    /// ]]></code>
    /// <para>where:</para>
    /// <para><i>resource (Required)</i></para>
    /// <para>TODO</para>
    /// <para><i>cluster</i></para>
    /// <para>TODO</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <Cluster.Resource.DeleteClusterResource
    ///             Resource="TODO"
    ///         </Cluster.Resource.DeleteClusterResource> 
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class DeleteClusterResource : TaskBase
    {
        private string clusterName = String.Empty;
        private string resourceName = String.Empty;
        private Microsoft.Cluster.Interop.Cluster cluster = null;

        protected override void InternalExecute()
        {
            if (resourceName == null || resourceName == String.Empty)
            {
                throw new TaskException("ClusterServer.InvalidResource");
            }

            try
            {
                cluster = new Microsoft.Cluster.Interop.Cluster();
                if (clusterName == null || clusterName == String.Empty)
                {
                    cluster.Open("");
                }
                else
                {
                    cluster.Open(clusterName);
                }
            }
            catch (Exception)
            {
                throw new TaskException("ClusterServer.FailConnect", ((clusterName == null || clusterName == String.Empty) ? "localhost" : clusterName));
            }

            Microsoft.Cluster.Interop.ClusResources resources = cluster.Resources;

            try
            {
                resources.DeleteItem(resourceName);
            }
            catch (Exception)
            {
                throw new TaskException("ClusterServer.Delete", resourceName);
            }

            Console.WriteLine(String.Format("Resource {0} has been deleted.", resourceName));
        }

        public string Cluster
        {
            get
            {
                return (clusterName == null ? String.Empty : clusterName);
            }
            set
            {
                clusterName = value;
            }
        }

        [Required]
        public string Resource
        {
            get
            {
                return (resourceName == null ? String.Empty : resourceName);
            }
            set
            {
                resourceName = value;
            }
        }
    }
}
#endif