using System;

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	/// <summary>
	/// Defines the tracking types set for a logical endpoint.
	/// </summary>
	[Flags]
	public enum TrackingTypes : int
	{
		/// <summary>
		///  Tracks the entire message immediately after it is processed by the receive pipeline associated with this port.
		/// </summary>
		AfterReceivePipeline  = 2,  

		/// <summary>
		/// Tracks the entire message immediately after it is processed by the send pipeline associated with this port.
		/// This value is only allowed on two-way send ports.
		/// </summary>
	   AfterSendPipeline  = 8,  
 
		/// <summary>
		/// Tracks the entire message immediately before it is processed by the receive pipeline associated with this port. 
		/// </summary>
		BeforeReceivePipeline =  1, 
	
		/// <summary>
		/// Tracks the entire message immediately before it is processed by the send pipeline associated with this port.
		/// This value is only allowed on two-way send ports.
		/// </summary>
		BeforeSendPipeline  = 4

	}
}

