//-------------------------------------------------------------------------------------
// <copyright file="BizTalkInstallation.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Internal helper class which wraps the MSBTS_DeploymentService WMI class.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using directives

    using System;
	using System.Globalization;
    using System.Management;

	#endregion

    /// <summary>
    /// Internal helper class which wraps the MSBTS_DeploymentService WMI class.
    /// </summary>
    internal sealed class DeploymentService
    {
		#region Constructors

        /// <summary>
        /// Has only static members so cannot be instantiated.
        /// </summary>
        private DeploymentService() 
        {
        }

		#endregion

		#region Static Methods

		/// <summary>
		/// Deploys an assembly into BizTalk.
		/// </summary>
		/// <param name="installation">
		/// The BizTalk installation to deploy the assembly into.
		/// </param>
		/// <param name="assemblyPath">
		/// The path to the assembly.
		/// </param>
		/// <param name="installInGac">
		/// <b>true</b> to install the assembly into the GAC, or <b>false</b> otherwise.
		/// </param>
		/// <param name="bindingPath">
		/// Path to the assembly binding XML file; this may be <b>null</b>.
		/// </param>
		/// <param name="logPath">
		/// Path to the log file; this may be <b>null</b>.
		/// </param>
        /// <returns>
        /// The return code of the operation, zero indicates success.
        /// </returns>
        public static int Deploy(
            BizTalkInstallation installation,
			string assemblyPath, 
			bool installInGac, 
			string bindingPath, 
			string logPath)
        {
            //get the deployment service class
            ManagementClass deploymentService = ManagementHelper.GetDeploymentServiceClass(installation);
            //create the parameters for the deploy method
            ManagementBaseObject parameters = deploymentService.GetMethodParameters("Deploy");
            parameters["Server"] = installation.Server;
            parameters["Database"] = installation.Database;
            parameters["Assembly"] = assemblyPath;
            parameters["Install"] = installInGac;
            parameters["Binding"] = bindingPath;
            parameters["Log"] = logPath;
            //invoke the method and return the result
            ManagementBaseObject result = deploymentService.InvokeMethod("Deploy", parameters, null);
			return (result.Properties["ReturnValue"].Value != null) ? (int)result.Properties["ReturnValue"].Value : 0;
        }

		/// <summary>
		/// Exports the assembly bindings to an XML file.
		/// </summary>
		/// <param name="installation">
		/// The BizTalk installation to deploy the assembly into.
		/// </param>
		/// <param name="assemblyPath">
		/// The path to the assembly. This may be <b>null</b> if <paramref name="name"/>, <paramref name="version"/>,
		/// <paramref name="culture"/> and <paramref name="publicKeyToken"/> are supplied.
		/// </param>
		/// <param name="name">
		/// The name of the assembly. This may be <b>null</b> if <paramref name="assemblyPath"/> is supplied.
		/// </param>
		/// <param name="version">
		/// The version of the assembly. This may be <b>null</b> if <paramref name="assemblyPath"/> is supplied.
		/// </param>
		/// <param name="culture">
		/// The culture of the assembly. This may be <b>null</b> if <paramref name="assemblyPath"/> is supplied.
		/// </param>
		/// <param name="publicKeyToken">
		/// The pubkic key token of the assembly. This may be <b>null</b> if <paramref name="assemblyPath"/> is supplied.
		/// </param>
		/// <param name="bindingPath">
		/// Path to the output assembly binding XML file.
		/// </param>
		/// <param name="logPath">
		/// Path to the log file; this may be <b>null</b>.
		/// </param>
		/// <returns>
		/// The return code of the operation, zero indicates success.
		/// </returns>
		public static int ExportBindings(
			BizTalkInstallation installation,
			string assemblyPath,
			string name,
			Version version,
			string culture,
			string publicKeyToken,
			string bindingPath,
			string logPath)
		{
			//get the deployment service class
			ManagementClass deploymentService = ManagementHelper.GetDeploymentServiceClass(installation);
			//create the parameters for the remove method
			ManagementBaseObject parameters = deploymentService.GetMethodParameters("Export");
			parameters["Server"] = installation.Server;
			parameters["Database"] = installation.Database;
			parameters["Assembly"] = assemblyPath;
			parameters["Name"] = name;
			parameters["Version"] = version;
			parameters["Culture"] = culture;
			parameters["PublicKeyToken"] = publicKeyToken;
			parameters["Binding"] = bindingPath;
			parameters["Log"] = logPath;
			//invoke the method and return the result
			ManagementBaseObject result = deploymentService.InvokeMethod("Export", parameters, null);
			return (result.Properties["ReturnValue"].Value != null) ? (int)result.Properties["ReturnValue"].Value : 0;
		}

		/// <summary>
		/// Imports a binding file into the target database.
		/// </summary>
		/// <param name="installation">
		/// The BizTalk installation to deploy the assembly into.
		/// </param>
		/// <param name="bindingPath">
		/// Path to the assembly binding XML file.
		/// </param>
		/// <param name="logPath">
		/// Path to the log file; this may be <b>null</b>.
		/// </param>
		/// <returns>
		/// The return code of the operation, zero indicates success.
		/// </returns>
		public static int ImportBindings(
			BizTalkInstallation installation,
			string bindingPath,
			string logPath)
		{
			//get the deployment service class
			ManagementClass deploymentService = ManagementHelper.GetDeploymentServiceClass(installation);
			//create the parameters for the import method
			ManagementBaseObject parameters = deploymentService.GetMethodParameters("Import");
			parameters["Server"] = installation.Server;
			parameters["Database"] = installation.Database;
			parameters["Binding"] = bindingPath;
			parameters["Log"] = logPath;
			//invoke the method and return the result
			ManagementBaseObject result = deploymentService.InvokeMethod("Import", parameters, null);
			return (result.Properties["ReturnValue"].Value != null) ? (int)result.Properties["ReturnValue"].Value : 0;
		}

		/// <summary>
		/// Undeploys an assembly from BizTalk.
		/// </summary>
		/// <param name="installation">
		/// The BizTalk installation to deploy the assembly into.
		/// </param>
		/// <param name="assemblyPath">
		/// The path to the assembly. This may be <b>null</b> if <paramref name="name"/>, <paramref name="version"/>,
		/// <paramref name="culture"/> and <paramref name="publicKeyToken"/> are supplied.
		/// </param>
		/// <param name="name">
		/// The simple name of the assembly. This may be <b>null</b> if <paramref name="assemblyPath"/> is supplied.
		/// </param>
		/// <param name="version">
		/// The version of the assembly. This may be <b>null</b> if <paramref name="assemblyPath"/> is supplied.
		/// </param>
		/// <param name="culture">
		/// The culture of the assembly. This may be <b>null</b> if <paramref name="assemblyPath"/> is supplied.
		/// </param>
		/// <param name="publicKeyToken">
		/// The pubkic key token of the assembly. This may be <b>null</b> if <paramref name="assemblyPath"/> is supplied.
		/// </param>
		/// <param name="uninstallFromGac">
		/// <b>true</b> to uninstall the assembly from the GAC, or <b>false</b> otherwise.
		/// </param>
		/// <param name="logPath">
		/// Path to the log file; this may be <b>null</b>.
		/// </param>
		/// <returns>
		/// The return code of the operation, zero indicates success.
		/// </returns>
        public static int Undeploy(
            BizTalkInstallation installation,
            string assemblyPath,
			string name,
			Version version,
			string culture,
			string publicKeyToken,
            bool uninstallFromGac,
            string logPath)
        {
            //get the deployment service class
            ManagementClass deploymentService = ManagementHelper.GetDeploymentServiceClass(installation);
            //create the parameters for the remove method
            ManagementBaseObject parameters = deploymentService.GetMethodParameters("Remove");
            parameters["Server"] = installation.Server;
            parameters["Database"] = installation.Database;
            parameters["Assembly"] = assemblyPath;
			parameters["Name"] = name;
			parameters["Version"] = (version == null) ? null : version.ToString();
			parameters["Culture"] = culture;
			parameters["PublicKeyToken"] = publicKeyToken;
            parameters["UnInstall"] = uninstallFromGac;
            parameters["Log"] = logPath;
            //invoke the method and return the result
            ManagementBaseObject result = deploymentService.InvokeMethod("Remove", parameters, null);
			return (result.Properties["ReturnValue"].Value != null) ? (int)result.Properties["ReturnValue"].Value : 0;
		}

		#endregion
    }
}

