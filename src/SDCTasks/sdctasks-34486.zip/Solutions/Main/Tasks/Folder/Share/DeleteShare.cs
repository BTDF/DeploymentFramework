//-------------------------------------------------------------------------------------
// <copyright file="DeleteShare.cs" company="Microsoft">
//      Copyright (c) Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <author>Greg Beech [Updated: 22-2-08 Mike Fourie. Code Cleanup]</author>
// <email>gregbee@microsoft.com</email>
// <date>2004-04-20</date>
// <summary>
//      Deletes a share on either the local or a remote machine.
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.Folder.Share
{
    #region Using directives

    using System;
    using System.Globalization;
    using System.Management;

    #endregion

    #region Class Comments
    /// <summary>
    /// Deletes a share on either the local or a remote machine.
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<Share.DeleteShare ShareName="shareName" Machine="machine" UserName="userName" Password="password" />]]></code>
    /// <para>where:</para>
    /// <para><i>shareName (Required)</i></para>
    /// <para>
    /// The name of the share to delete.
    /// </para>
    /// <para><i>machine</i></para>
    /// <para>
    /// The name or IP address of the machine to delete the share from. The default is the local machine.
    /// </para>
    /// <para><i>userName</i></para>
    /// <para>
    /// If different credentials are needed to connect to a remote machine, this is the user name in the form 
    /// DOMAIN\Username. This must not be supplied for the local machine. The default is to use the same
    /// credentials as the user the task is running as.
    /// </para>
    /// <para><i>password</i></para>
    /// <para>
    /// The password for the user account specified by <i>userName</i>. The default is no password.
    /// </para>
    /// <seealso cref="Microsoft.Sdc.Tasks.Folder.Share.Create"/>
    /// <seealso cref="Microsoft.Sdc.Tasks.Folder.Share.Connect"/>
    /// <seealso cref="Microsoft.Sdc.Tasks.Folder.Share.Disconnect"/>
    /// <seealso cref="Microsoft.Sdc.Tasks.Folder.Share.Exists"/>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test">
    ///         <Share.DeleteShare
    ///             ShareName="Software"
    ///             Machine="MyMachine" 
    ///             UserName="domain\username" 
    ///             Password="password1" />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    #endregion
    public class DeleteShare : ShareTaskBase
    {
        #region Protected Methods

        /// <summary>
        /// Executes the task
        /// </summary>
        protected override void InternalExecute()
        {
            // connect to the machine and get the share
            ManagementScope scope = this.GetManagementScope();
            string sharePathString = string.Concat("Win32_Share.Name='", this.ShareName, "'");
            ManagementPath sharePath = new ManagementPath(sharePathString);
            ManagementObject shareObject = new ManagementObject(scope, sharePath, null);

            // bind to the share to see if it exists
            try
            {
                shareObject.Get();
            }
            catch (ManagementException)
            {
                this.Log.LogWarning("Share does not exist so cannot be deleted.");
                return;
            }

            // execute the method and check the return code
            ManagementBaseObject outputParams = shareObject.InvokeMethod("Delete", null, null);
            ShareReturnCode returnCode = (ShareReturnCode)Convert.ToUInt32(outputParams.Properties["ReturnValue"].Value, CultureInfo.InvariantCulture);
            if (returnCode != ShareReturnCode.Success)
            {
                throw new ApplicationException(string.Format(
                    CultureInfo.InvariantCulture,
                    "Failed to delete the share; detailed information is: {0} (Code {1}).",
                    returnCode,
                    (uint)returnCode));
            }
        }

        #endregion
    }
}