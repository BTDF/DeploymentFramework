//-----------------------------------------------------------------------
// <copyright file="CertTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Shaun Wilde (ICS)</author>
// <email>v-swilde</email>
// <date>2006-04-03</date>
// <summary>TODO</summary>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.Test.Web.WebSite
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration.Web;
    using System.Security.Cryptography.X509Certificates;

    /// <summary>
    /// Tests used for web site based certificate related actions
    /// </summary>
    [TestClass]
    public class CertTest
    {
        /// <summary>
        /// Test that it is possible to set the CertCheckMode property of a web-site
        /// </summary>
        [TestMethod]
        public void TestCertCheckMode()
        {
            Microsoft.Sdc.Tasks.Web.WebSite.CertCheckMode check = new Microsoft.Sdc.Tasks.Web.WebSite.CertCheckMode();
            check.Description = "Default Web Site";
            check.Enable = false;
            check.Execute();
            bool orignalValue = check.OriginalEnable;
            
            check.Enable = true;
            check.Execute();
            Assert.IsFalse(check.OriginalEnable);

            check.Enable = false;
            check.Execute();
            Assert.IsTrue(check.OriginalEnable);

            check.Enable = orignalValue;
            check.Execute();
        }

        [TestMethod]
        [Ignore]
        public void TestCertificateMapping()
        {
            Microsoft.Sdc.Tasks.Web.WebSite.CreateCertificateMapping create = new Microsoft.Sdc.Tasks.Web.WebSite.CreateCertificateMapping();
            create.Description = "Default Web Site";
            create.AccountFriendlyName = "My Friendly Name";
            create.AccountPassword = "*********";
            create.AccountUsername = @"ausername";
            create.CertificatePassword = "apassword";
            create.CertificatePath = @"PATHTOCERTIFICATE";
            create.Execute();

            Microsoft.Sdc.Tasks.Web.WebSite.DeleteCertificateMapping delete = new Microsoft.Sdc.Tasks.Web.WebSite.DeleteCertificateMapping();
            delete.AccountUsername = @"ausername";
            delete.Description = "Default Web Site";
            delete.Execute();

        }

        [TestMethod]
        [Ignore]
        public void TestUpdateSslFlags()
        {
            Microsoft.Sdc.Tasks.Web.WebSite.UpdateSslFlags update = new Microsoft.Sdc.Tasks.Web.WebSite.UpdateSslFlags();
            update.Description = "Default Web Site";
            //update.VirtualDirectory = "*******";
            update.SslAccessFlags = "RequireSsl MapClientCert RequireClientCert";
            update.Execute();
        }
    }
}
