
namespace Microsoft.Sdc.Tasks.BizTalk2004.TransportData
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion


    public class HttpTransportData : TransportDataBase
    {
        #region member variables

        private bool usesso;
        private string responsecontenttype;
        private bool loopback;
        private bool returncorrelationhandle;

        private int requesttimeout;
        private string contenttype;
        private int maxredirects;
        private bool usehandlerproxysettings;
        private bool useproxy;
        private string proxyname;
        private int proxyport;
        private string proxyusername;
        private string proxypassword;
        private string authenticationscheme;
        private string username;
        private string password;
        private string certificate;
        private string affliateapplicationname;

        #endregion


        #region common properties

        /// <summary>
        /// Specifies whether the HTTP adapter will issue the SSO ticket to messages that arrive/depart.
        /// </summary>
        public bool UseSSO
        {
            get { return this.usesso; }
            set { this.usesso = value; }
        }


        #endregion

        #region Receive Location properties

        /// <summary>
        /// Content type of the HTTP response messages that the HTTP adapter sends back to clients from this receive location. This property is valid only for request-response receive ports and is ignored for one-way receive ports.
        /// </summary>
        public string ResponseContentType
        {
            get { return this.responsecontenttype; }
            set { this.responsecontenttype = value; }
        }


        /// <summary>
        /// Specifies that the request message received on this location will be routed either to a send port or back to the receive location to be sent as a response. This property is valid only for request-response receive ports. It is ignored for one-way receive ports.
        /// </summary>
        public bool LoopBack
        {
            get { return this.loopback; }
            set { this.loopback = value; }

        }


        /// <summary>
        /// Specifies that the correlation token of submitted message that the HTTP adapter sends on HTTP response to the client if the submission is successful. This property is valid only for one-way receive ports and is ignored for request-response receive ports.
        /// </summary>
        public bool ReturnCorrelationHandle
        {
            get { return this.returncorrelationhandle; }
            set { this.returncorrelationhandle = value; }
        }

        #endregion

        #region Send Port properties

        /// <summary>
        /// Time-out period of waiting for a response from the server. If set to zero (0), the system calculates the time-out based on the request message size.
        /// </summary>
        public int RequestTimeout
        {
            get { return this.requesttimeout; }
            set { this.requesttimeout = value; }
        }

        /// <summary>
        /// Content type of the request messages.
        /// </summary>
        public string ContentType
        {
            get { return this.contenttype; }
            set { this.contenttype = value; }
        }

        /// <summary>
        /// Maximum number of times that the HTTP adapter can redirect the request.
        /// </summary>
        public int MaxRedirects
        {
            get { return this.maxredirects; }
            set { this.maxredirects = value; }
        }

        /// <summary>
        /// Specifies whether HTTP send port will use the proxy configuration for the send handler.
        /// </summary>
        public bool UseHandlerProxySettings
        {
            get { return this.usehandlerproxysettings; }
            set { this.usehandlerproxysettings = value; }
        }

        /// <summary>
        /// Specifies whether the HTTP adapter will use the proxy server.
        /// </summary>
        public bool UseProxy
        {
            get { return this.useproxy; }
            set { this.useproxy = value; }
        }

        /// <summary>
        /// Specifies the proxy server name. 
        /// </summary>
        public string ProxyName
        {
            get { return this.proxyname; }
            set { this.proxyname = value; }
        }

        /// <summary>
        /// Specifies the proxy server port.
        /// </summary>
        public int ProxyPort
        {
            get { return this.proxyport;  }
            set { this.proxyport = value; }
        }

        /// <summary>
        /// Specifies the user name for authentication with the proxy server. 
        /// </summary>
        public string ProxyUsername
        {
            get { return this.proxyusername; }
            set { this.proxyusername = value; }
        }

        /// <summary>
        /// Specifies the user password for authentication with the proxy server. 
        /// </summary>
        public string ProxyPassword
        {
            get { return this.proxypassword; }
            set { this.proxypassword = value; }
        }

        /// <summary>
        /// Type of authentication to use with the destination server.
        /// </summary>
        /// <value>
        ///One of the following:
        /// Anonymous (Default)
        /// Basic
        /// Digest 
        /// Kerberos 
        ///</value>
        public string AuthenticationScheme
        {
            get { return this.authenticationscheme;  }
            set { this.authenticationscheme = value; }
        }

        /// <summary>
        /// User name to use for authentication with the server. 
        /// </summary>
        public new string Username
        {
            get { return this.username; }
            set { this.username = value;  }
        }

        /// <summary>
        /// User password to use for authentication with the server. 
        /// </summary>
        public new string Password
        {
            get { return this.password; }
            set { this.password = value; }
        }

        /// <summary>
        /// Thumbprint of client the SSL certificate.
        /// </summary>
        public string Certificate
        {
            get { return this.certificate;  }
            set { this.certificate = value; }
        }

        /// <summary>
        /// Name of the affiliate application to use for SSO.
        /// </summary>
        public string AffiliateApplicationName
        {
            get { return this.affliateapplicationname; }
            set { this.affliateapplicationname = value; }
        }

        #endregion 

        #region methods
        public HttpTransportData()
        {

        }

        protected override void InternalExecute()
        {
            Configuration.BizTalkInstallation installation = this.GetInstallation();
            Configuration.TransportDataParentType _parentType = (TransportDataParentType)Enum.Parse(typeof(TransportDataParentType), this.ParentType);

            Configuration.HttpTransport httptransport = new Microsoft.Sdc.Tasks.BizTalk2004.Configuration.HttpTransport(_parentType);


            //comming property
            httptransport.UseSSO = this.usesso;

            switch (_parentType)
            {
                case TransportDataParentType.ReceiveLocation:

                    httptransport.ResponseContentType = this.responsecontenttype;
                    httptransport.LoopBack = this.loopback;
                    httptransport.ReturnCorrelationHandle = this.returncorrelationhandle;
                    break;

                case TransportDataParentType.SendPort:

                    httptransport.RequestTimeout = this.requesttimeout;
                    httptransport.ContentType = this.contenttype;
                    httptransport.MaxRedirects = this.maxredirects;
                    httptransport.UseHandlerProxySettings = this.usehandlerproxysettings;
                    httptransport.UseProxy = this.useproxy;
                    httptransport.ProxyName = this.proxyname;
                    httptransport.ProxyPort = this.proxyport;
                    httptransport.ProxyUsername = this.proxyusername;
                    httptransport.ProxyPassword = this.proxypassword;
                    httptransport.AuthenticationScheme = this.authenticationscheme;
                    httptransport.Username = this.username;
                    httptransport.Password = this.password;
                    httptransport.Certificate = this.certificate;
                    httptransport.AffiliateApplicationName = this.affliateapplicationname;
                    break;

            }

            this.TransportDataXml = httptransport.GetTransportXml();

        }
        #endregion

    }
}

