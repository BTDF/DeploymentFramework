//-------------------------------------------------------------------------------------
// <copyright file="SendHandler.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Represents a send handler, which acts as a container for the handlers of the adapter.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using directives 

	using System;
	using System.Management;

	#endregion 

	/// <summary>
	/// Represents a receive handler, which acts as a container for the handlers of the adapter.
	/// </summary>
	internal class SendHandler : BizTalkNonConfigurableEntityBase
	{
		#region Member variables

		#endregion 

		#region Properties

		#endregion 


		#region methods 

		/// <summary>
		/// Creates a new Receive Handler instance. This is private because instance of this class can only be created with
		/// the Load method.
		/// </summary>
        /// <param name="installation"> The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation"/> of this receive handler.</param>
		/// <param name="name">The name of this receive handler.</param>
		private SendHandler(BizTalkInstallation installation, string name): base(installation, name){}

		/*
		/// <summary>
		/// Loads the details of a Receive Handler
		/// </summary>
		/// <param name="installation"> The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation"/> of this receive handler.</param>
		/// <param name="name">The name of this receive handler.</param>
		/// <param name="transportName">The transport name, e.g. FILE of SQL</param>
		/// <returns></returns>
		public static SendHandler Load(BizTalkInstallation installation, string name, string transportName)
		{
			return null;
		}*/

		public static void MoveHost(BizTalkInstallation installation, string transportType, string newHostName)
		{
			MoveHost(installation, transportType, newHostName, string.Empty);
		}

		public static void MoveHost(BizTalkInstallation installation, string transportType, string newHostName, string oldHostName)
		{
			try
			{
				PutOptions options = new PutOptions();
				options.Type = PutType.UpdateOnly;

				//Look for the target WMI Class MSBTS_ReceiveHandler instance
				string query;
				if (oldHostName != null && oldHostName.Length > 0)
				{
					query = "SELECT * FROM MSBTS_SendHandler WHERE AdapterName =\"" + transportType + "\" AND HostName = \"" + oldHostName + "\"";
				}
				else
				{
					query = "SELECT * FROM MSBTS_SendHandler WHERE AdapterName =\"" + transportType + "\"";
				}
				ManagementScope scope = ManagementHelper.GetManagementScope(installation);
				ManagementObjectSearcher searcherSendHandler = new ManagementObjectSearcher (scope, new WqlObjectQuery(query), null);
   
				if (searcherSendHandler.Get().Count > 0)
				{
					foreach (ManagementObject objSendHandler in searcherSendHandler.Get())
					{
						//update host association
						objSendHandler["HostName"] = newHostName;
						//update the ManagementObject
						objSendHandler.Put(options);
						System.Diagnostics.Trace.WriteLine("SendHandler - " + transportType + " " + newHostName + " - has been updated successfully");
					}
				}
				else
				{
					System.Console.WriteLine("SendHandler - " + transportType + " - cannot be found");               
				}
			}
			catch(Exception ex)
			{
				System.Diagnostics.Trace.WriteLine("SendHandler - " + transportType + " - failed: " + ex.Message);
				throw;
			}
		}
		
		#endregion 

	}
}

