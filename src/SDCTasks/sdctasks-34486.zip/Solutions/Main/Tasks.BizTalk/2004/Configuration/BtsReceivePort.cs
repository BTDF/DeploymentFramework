﻿
namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;
    using System.Reflection;

    #endregion

    internal class BtsReceivePort : BtsBaseObject
    {
        internal BtsReceivePort(object actualParent, BtsCatalogExplorer catalogExplorer)
        {
            this.btsCatalogExplorer = catalogExplorer;
            this.actualBtsObject = actualParent;
        }

        /// <summary>
        /// Gets or sets an enumeration value to specify whether authentication is needed at this receive port.
        /// </summary>
        public AuthenticationType Authentication
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("Authentication", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (AuthenticationType)Enum.Parse(typeof(AuthenticationType), value.ToString());
            }
            set
            {
                object actualValue = Enum.Parse(this.btsCatalogExplorer.BizTalkExplorerOMAssembly.GetType("Microsoft.BizTalk.ExplorerOM.AuthenticationType"), value.ToString());
                this.actualBtsObject.GetType().InvokeMember("Authentication", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { actualValue });
            }
        }

        /// <summary>
        /// Gets or sets the custom data with the receive port.
        /// </summary>
        public string CustomData
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("CustomData", BindingFlags.GetProperty, null, this.actualBtsObject, null);

            }
            set
            {
                this.actualBtsObject.GetType().InvokeMember("CustomData", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? value : string.Empty });

            }

        }

        /// <summary>
        /// Gets the collection of maps to apply to inbound documents.
        /// </summary>
        public System.Collections.IList InboundTransforms
        {
            get
            {
                return (System.Collections.IList)this.actualBtsObject.GetType().InvokeMember("InboundTransforms", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

        }

        /// <summary>
        /// Determines whether the receive port is a two-way port.
        /// </summary>
        public bool IsTwoWay
        {
            get
            {
                return (bool)this.actualBtsObject.GetType().InvokeMember("IsTwoWay", BindingFlags.GetProperty, null, this.actualBtsObject, null);

            }

        }

        /// <summary>
        /// Gets or sets the receive port name.
        /// </summary>
        public string Name
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("Name", BindingFlags.GetProperty, null, this.actualBtsObject, null);

            }
            set
            {
                this.actualBtsObject.GetType().InvokeMember("Name", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? value : string.Empty });

            }
        }

        /// <summary>
        /// Gets the collection of maps to apply to outbound documents on the two-way receive port.
        /// </summary>
        public System.Collections.IList OutboundTransforms
        {
            get
            {
                return (System.Collections.IList)this.actualBtsObject.GetType().InvokeMember("OutboundTransforms", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

        }

        /// <summary>
        /// Gets or sets the primary receive location for this receive port.
        /// </summary>
        public BtsReceiveLocation PrimaryReceiveLocation
        {
            get
            {
                object actualReceiveLocation = this.actualBtsObject.GetType().InvokeMember("PrimaryReceiveLocation", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (actualReceiveLocation != null) ? new BtsReceiveLocation(actualReceiveLocation, this.btsCatalogExplorer) : null;
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("PrimaryReceiveLocation", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? ((BtsReceiveLocation)value).actualBtsObject : null });
            }
        }

        /// <summary>
        /// Gets the collection of receive locations that make up this receive port.
        /// </summary>
        public BtsReceiveLocationCollection ReceiveLocations
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("ReceiveLocations", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsReceiveLocationCollection receiveLocations = new BtsReceiveLocationCollection();

                    foreach (object item in ((System.Collections.IEnumerable)actualCollection))
                    {
                        BtsReceiveLocation receiveLocation = new BtsReceiveLocation(item, this.btsCatalogExplorer);
                        receiveLocations.Add(receiveLocation);
                    }

                    return receiveLocations;
                }
                else
                    return null;
            }
        }

        /// <summary>
        /// Gets or sets the send pipeline used to send a response if this is a two way receive port.
        /// </summary>
        public BtsPipeline SendPipeline
        {
            get
            {
                object actualPipeLine = this.actualBtsObject.GetType().InvokeMember("SendPipeline", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (actualPipeLine != null) ? new BtsPipeline(actualPipeLine, this.btsCatalogExplorer) : null;

            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("SendPipeline", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? ((BtsPipeline)value).actualBtsObject : null });
            }
        }


        /// <summary>
        /// Gets or sets configuration specific data for the Send pipeline of this receive port.
        /// </summary>
        public string SendPipelineData
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("SendPipelineData", BindingFlags.GetProperty, null, this.actualBtsObject, null);

            }
            set
            {
                this.actualBtsObject.GetType().InvokeMember("SendPipelineData", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? value : string.Empty });

            }

        }

        /// <summary>
        /// Gets or sets the tracking needed for this port. 
        /// </summary>
        public TrackingTypes Tracking
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("Tracking", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (TrackingTypes)Enum.Parse(typeof(TrackingTypes), value.ToString());
            }
            set
            {
                object actualValue = Enum.Parse(this.btsCatalogExplorer.BizTalkExplorerOMAssembly.GetType("Microsoft.BizTalk.ExplorerOM.TrackingTypes"), value.ToString());
                this.actualBtsObject.GetType().InvokeMember("Tracking", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { actualValue });
            }


        }

        /// <summary>
        /// Adds a new receive location to this receive port.
        /// </summary>
        public BtsReceiveLocation AddNewReceiveLocation()
        {
            object actualReceiveLocation = this.actualBtsObject.GetType().InvokeMember("AddNewReceiveLocation", BindingFlags.InvokeMethod, null, this.actualBtsObject, null);
            return new BtsReceiveLocation(actualReceiveLocation, this.btsCatalogExplorer);

        }

        /// <summary>
        /// Removes the specified receive location from this receive port.
        /// </summary>
        public void RemoveReceiveLocation(BtsReceiveLocation receiveLocation)
        {
            this.actualBtsObject.GetType().InvokeMember("RemoveReceiveLocation", BindingFlags.InvokeMethod, null, this.actualBtsObject, new object[] { receiveLocation.actualBtsObject });
        }


    }
}
