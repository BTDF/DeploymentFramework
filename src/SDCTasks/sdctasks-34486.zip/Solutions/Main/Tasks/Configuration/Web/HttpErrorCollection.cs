/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Patrick Long</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/


namespace Microsoft.Sdc.Tasks.Configuration.Web 
{
    using System.Collections;
    using System;
    using System.DirectoryServices;
    using System.Globalization;

    /// <summary>
    /// Summary description for HttpErrorCollection.
    /// </summary>
    internal class HttpErrorCollection : ReadOnlyCollectionBase 
    {
        DirectoryEntry parentDirectoryEntry;
        
        internal HttpErrorCollection(DirectoryEntry de) 
        {
            parentDirectoryEntry = de;
            Initialise();
        }

        public int IndexOf(VirtualDirectory value) 
        {
            return( InnerList.IndexOf(value));
        }

        public DirectoryEntry Parent 
        {
            get 
            {
                return parentDirectoryEntry ;
            }
        }   

        public bool Contains(HttpError value) 
        {
            return (InnerList.Contains(value));
        }

        public HttpError this[int index] 
        {
            get 
            {
                return (HttpError) InnerList[index];
            }
        }

        public HttpError GetHttpErrorFromErrorCode(int httpErrorCode)
        {
            return GetHttpErrorFromErrorCode(httpErrorCode,"*");
        }

        public HttpError GetHttpErrorFromErrorCode(int httpErrorCode, string httpSubErrorCode)
        {
            foreach(HttpError error in InnerList)
            {
                if(error.HttpErrorCode == httpErrorCode && error.HttpSubErrorCode == httpSubErrorCode)
                {
                    return error;
                }
            }

            return null;
        }

        private void Initialise()
        {
            HttpError httpError;
            string[] httpErrorConfigStringValues;
			
			object httpErrors = parentDirectoryEntry.Properties["HttpErrors"].Value;

			// check whether httpErrors is null before processing
			if (httpErrors != null)
			{
				// httpErrors may be an Array (if there are 2 or more custom HTTP errors set up for the vdir
				// or it may be a string (if there's only 1 custom HTTP error set up) so we need to test which
				// situation we have before casting and dealing with these two scenarios
				if (httpErrors is string)
				{
					string httpErrorString = (string)httpErrors;

					httpErrorConfigStringValues = httpErrorString.Split(new char[]{','});

					httpError = new HttpError(Convert.ToInt32(httpErrorConfigStringValues[0]),httpErrorConfigStringValues[1],httpErrorConfigStringValues[2],httpErrorConfigStringValues[3]);

					this.InnerList.Add(httpError);
				}
				else if (httpErrors is Array)
				{
					Array httpErrorsPropertyValues = (Array)httpErrors;

					foreach(string httpErrorConfigString in httpErrorsPropertyValues)
					{
						httpErrorConfigStringValues = httpErrorConfigString.Split(new char[]{','});

						httpError = new HttpError(Convert.ToInt32(httpErrorConfigStringValues[0]),httpErrorConfigStringValues[1],httpErrorConfigStringValues[2],httpErrorConfigStringValues[3]);

						this.InnerList.Add(httpError);
					}
				}
			}
        }

        public void Save(DirectoryEntry directoryEntryToSaveIn)
        {
            //PropertyValueCollection newValuesForHttpErrorsCollection = new PropertyValueCollection();

            string[] httpErrorConfigStringValues = new string[InnerList.Count];

            for(int index =0; index <= (InnerList.Count -1);index++)
            {
                HttpError error = this[index];

                httpErrorConfigStringValues[index] = string.Format(CultureInfo.InvariantCulture,"{0},{1},{2},{3}",error.HttpErrorCode,error.HttpSubErrorCode,error.Type,error.Uri);
            }
            
            directoryEntryToSaveIn.Properties["HttpErrors"].Value = httpErrorConfigStringValues;
        }
    }
}
