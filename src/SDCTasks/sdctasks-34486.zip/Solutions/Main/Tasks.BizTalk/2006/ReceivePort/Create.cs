//-----------------------------------------------------------------------
// <copyright file="Create.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.ReceivePort
{
    using System;
    using System.Globalization;
    using BizTalk.ExplorerOM;

    /// <summary>
    /// Creates a new instance of a Receive port. This will fail if the port already exists.
    /// </summary>
    public class Create : BizTalk2004.ReceivePort.Create
    {
        private string application;
        private bool routeFailedMessages;

        /// <summary>
        /// Indicates whether or not failed messages are routed to failed message subscribers.
        /// </summary>
        public bool RouteFailedMessages
        {
            get { return this.routeFailedMessages; }
            set { this.routeFailedMessages = value; }
        }

        /// <summary>
        /// The application that this send port belongs to. If this is not specified, the BizTalk 2004 code 
        /// is executed.
        /// </summary>
        public string Application
        {
            get { return this.application; }
            set { this.application = value; }
        }

        /// <summary>
        /// Executes the task
        /// </summary>
        protected override void InternalExecute()
        {
            if (string.IsNullOrEmpty(this.Application))
            {
                base.InternalExecute();
            }
            else
            {
                BtsCatalogExplorer explorer = this.GetBtsCatalogExplorer(this.Server, this.Database);

                Application app = explorer.Applications[this.Application];
                if (app != null)
                {
                    ReceivePort receivePort = app.AddNewReceivePort(this.TwoWay);
                    receivePort.Name = this.Name;
                    receivePort.Authentication = (this.AuthenticationType != null) ?
                        (AuthenticationType)Enum.Parse(typeof(AuthenticationType), this.AuthenticationType) :
                        Microsoft.BizTalk.ExplorerOM.AuthenticationType.NotRequired;

                    if (!string.IsNullOrEmpty(this.TrackingTypes))
                    {
                        TrackingTypes resultingTypes = 0;
                        string[] trackingTypes = this.TrackingTypes.Split(';');
                        foreach (string type in trackingTypes)
                        {
                            resultingTypes = resultingTypes | (TrackingTypes)Enum.Parse(typeof(TrackingTypes), type);
                        }

                        receivePort.Tracking = resultingTypes;
                    }

                    receivePort.RouteFailedMessage = this.RouteFailedMessages;

                    // inbound maps
                    if (this.InboundMaps != null)
                    {
                        foreach (string fullMapName in this.InboundMaps)
                        {
                            string mapName;
                            string assemblyName;
                            SplitQualifiedTypeName(fullMapName, out mapName, out assemblyName);

                            Transform trans = explorer.Transforms[mapName, assemblyName];
                            
                            // receivePort.InboundTransforms.Clear();
                            receivePort.InboundTransforms.Add(trans);
                        }
                    }

                    if (this.TwoWay)
                    {
                        // send pipeline
                        if (!string.IsNullOrEmpty(this.SendPipeline))
                        {
                            string pipelineName;
                            string assemblyName;
                            SplitQualifiedTypeName(this.SendPipeline, out pipelineName, out assemblyName);

                            Pipeline p = explorer.Pipelines[pipelineName, assemblyName];

                            if (p != null)
                            {
                                receivePort.SendPipeline = p;
                            }
                        }

                        // outbound maps
                        if (this.OutboundMaps != null)
                        {
                            foreach (string fullMapName in this.OutboundMaps)
                            {
                                string mapName;
                                string assemblyName;
                                SplitQualifiedTypeName(fullMapName, out mapName, out assemblyName);

                                Transform t = explorer.Transforms[mapName, assemblyName];

                                // receivePort.OutboundTransforms.Clear();
                                receivePort.OutboundTransforms.Add(t);
                            }
                        }
                    }

                    explorer.SaveChanges();
                }
                else
                {
                    Log.LogError(string.Format(CultureInfo.InvariantCulture, "Application not found: {0}", this.Application));
                    return;
                }
            }
        }
    }
}
