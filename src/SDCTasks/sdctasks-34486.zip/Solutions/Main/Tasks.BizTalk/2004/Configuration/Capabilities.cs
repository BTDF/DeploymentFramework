//-------------------------------------------------------------------------------------
// <copyright file="Capabilities.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      The capabilities of an adapter, which may be combined.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	using System;

	/// <summary>
	/// The capabilities of an adapter, which may be combined.
	/// </summary>
	[Flags]
    public enum Capabilities
    {
		/// <summary>
		/// Indicates an application adapter (currently not used).
		/// </summary>
        ApplicationProtocol = 16,
		/// <summary>
		/// Indicates that the adapter is delete protected.
		/// </summary>
        DeleteProtected = 32,
		/// <summary>
		/// Indicates that the adapter uses adapter framework user interface for receive handler configuration. 
		/// </summary>
        InitInboundProtocolContext = 2048,
		/// <summary>
		/// Indicates that the adapter uses the adapter framework user interface for send handler configuration.
		/// </summary>
        InitOutboundProtocolContext = 1024,
		/// <summary>
		/// Indicates that the adapter uses adapter framework user interface for receive location configuration.
		/// </summary>
        InitReceiveLocationContext = 4096,
		/// <summary>
		/// Indicates that the adapter uses adapter framework user interface for send port configuration.
		/// </summary>
        InitTransmitLocationContext = 8192,
		/// <summary>
		/// Indicates that the send adapter should be created upon service startup as opposed to the default lazy 
		/// creation whereby the adapter is created just before the first message is delivered to it.
		/// </summary>
        InitTransmitterOnServiceStart = 32768,
		/// <summary>
		/// Indicates whether BizTalk service is responsible for creating the receive adapter.
		/// </summary>
        ReceiveIsCreatable = 8,
		/// <summary>
		/// Requires a single instance per server.
		/// </summary>
        RequireSingleInstance = 4,
		/// <summary>
		/// Indicates that one receive and send handler are mapped to the same application; handlers cannot be 
		/// reassigned to different hosts.
		/// </summary>
        StaticHandlers = 64,
		/// <summary>
		/// Indicates that the adapter supports ordered delivery of messages.
		/// </summary>
        SupportsOrderedDelivery = 16384,
		/// <summary>
		/// Indicates a receive adapter.
		/// </summary>
        SupportsReceive = 1,
		/// <summary>
		/// Indicates whether the receive adapter supports request-response message exchanges.
		/// </summary>
        SupportsRequestResponse = 128,
		/// <summary>
		/// Indicates a send adapter.
		/// </summary>
        SupportsSend = 2,
		/// <summary>
		/// Indicates a SOAP adapter.
		/// </summary>
        SupportsSoap = 512,
		/// <summary>
		/// Indicates whether the send adapter supports solicit-response message exchanges.
		/// </summary>
        SupportsSolicitResponse = 256
    }
}

