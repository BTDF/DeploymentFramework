//-----------------------------------------------------------------------
// <copyright file="Stop.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-03-23</date>
// <summary>Stops Code Coverage</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.CodeCoverage
{
    using System;

    /// <summary>
    /// Ends code coverage analysis using CoverageEye
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<CodeCoverage.Stop />]]></code>
    /// <para>There are no properties associated with this task.</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <CodeCoverage.Stop />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Stop : TaskBase
    {
        /// <summary>
        /// Initializes a new instance of the Stop class.
        /// </summary>
        public Stop()
        {
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            string key1 = @"SYSTEM\CurrentControlSet\Control\Session Manager\Environment";
            Microsoft.Win32.RegistryKey regKey = Microsoft.Win32.Registry.LocalMachine.CreateSubKey(key1);
            regKey.DeleteValue("Cor_Enable_Profiling");
            regKey.Close();

            Microsoft.Win32.RegistryKey regKey2 = Microsoft.Win32.Registry.LocalMachine.CreateSubKey(key1);
            regKey2.DeleteValue("Cor_Profiler");
            regKey2.Close();

            int result = NativeMethods.SendMessageTimeout(
                NativeMethods.HWND_BROADCAST,
                NativeMethods.WM_SETTINGCHANGE,
                0,
                "Environment",
                NativeMethods.SMTO_ABORTIFHUNG,
                0,
                0);

            NativeMethods.SetEnvironmentVariableEx("Cor_Enable_Profiling", "");
            NativeMethods.SetEnvironmentVariableEx("Cor_Profiler", "");
        }
    }
}