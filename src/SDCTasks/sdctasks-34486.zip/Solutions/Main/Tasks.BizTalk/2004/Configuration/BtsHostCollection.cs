﻿//-------------------------------------------------------------------------------------
// <copyright file="BtsHostCollection.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      BtsHostCollection
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;

    #endregion

    internal class BtsHostCollection : System.Collections.ReadOnlyCollectionBase
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public BtsHostCollection()
        {
        }

        /// <summary>
        /// Indexer
        /// </summary>
        /// <param name="name">string</param>
        /// <returns>BtsHost</returns>
        public BtsHost this[string name]
        {
            get
            {
                BtsHost item = null;
                foreach (BtsHost currentitem in this.InnerList)
                {
                    if (currentitem.Name == name)
                    {
                        item = currentitem;
                        break;
                    }
                }
                return item;
            }
        }

        /// <summary>
        /// Indexer
        /// </summary>
        /// <param name="index">int</param>
        /// <returns>BtsHost</returns>
        public BtsHost this[int index]
        {
            get
            {
                return (BtsHost)this.InnerList[index];
            }
        }

        internal void Add(BtsHost item)
        {
            this.InnerList.Add(item);
        }
    }
}