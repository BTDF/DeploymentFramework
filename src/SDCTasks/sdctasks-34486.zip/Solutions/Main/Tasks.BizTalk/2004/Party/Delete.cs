//-------------------------------------------------------------------------------------
// <copyright file="Delete.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//     Deletes a party in a Biztalk Server
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2004.Party
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion

    public class Delete : BizTalk2004TaskBase
    {
        private string name;


        [Required]
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        public Delete() { }

        protected override void InternalExecute()
        {
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation installation = this.GetInstallation();

            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party.Delete(installation, this.name);
        }
    }
}

