//-------------------------------------------------------------------------------------
// <copyright file="Schema.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Represents a BizTalk Server schema.
// </summary>  
//-------------------------------------------------------------------------------------


namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region using directives

	using System;
	using System.Collections;
	using System.Xml.Serialization;
	
	#endregion 

	/// <summary>
	/// Represents a BizTalk Server schema.
	/// </summary>
	internal class Schema : BizTalkNonConfigurableEntityBase
	{
		#region Member variables 

		private BizTalkAssembly parentAssembly;
		private IDictionary properties;
		private SchemaType schemaType;
		private string xmlContent;
		
		#endregion


		#region properties
		
		/// <summary>
		/// Gets the reference to the containing assembly.
		/// </summary>
		/// <value> A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> object.</value>
		public BizTalkAssembly ParentAssembly
		{
			get { return this.parentAssembly; }
		}


		/// <summary>
		/// Gets the collection of properties of the property schema.
		/// </summary>
		/// <value> A <see cref="System.Collections.IDictionary"/> object </value>
		[XmlArrayItem("Properties")]
		public IDictionary Properties
		{
			get { return this.properties; }
		}

		/// <summary>
		/// Gets the XML content of the schema.
		/// </summary>
		/// <value> A string containing the xml content.</value>
		[XmlIgnore()]
		public string XmlContent
		{
			get { return this.xmlContent; }
		}

		/// <summary>
		/// Gets the schema type.
		/// </summary>
		/// <value> A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SchemaType"/> object. </value>
		public SchemaType SchemaType
		{
			get { return this.schemaType; }
		}


		#endregion 


		#region methods

		/// <summary>
		/// Creates a new schema instance. This is private because instance of this class can only be created with
		/// the Load method.
		/// </summary>
		/// <param name="assembly"></param>
		/// <param name="name"></param>
		public Schema(BizTalkAssembly assembly, string name): base(assembly.Installation, name) 
		{
			this.parentAssembly = assembly;
            this.xmlContent = string.Empty;
            this.properties = new Hashtable();
		}


		/// <summary>
		/// Loads a schema from a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> object.
		/// </summary>
		/// <param name="assembly">The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly"/> object to load the schema from.</param>
		/// <param name="name">The name of the schema to load.</param>
		/// <returns>A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/> object.</returns>
		public static Schema Load(BizTalkAssembly assembly, string name)
		{
			//check inputs
			if (assembly == null) throw new ArgumentException("assembly");
			if (name == null || name.Length == 0) throw new ArgumentException("name");

			//load the native types
			BtsSchema btsSchema = assembly.GetActualAssembly().Schemas[name];

			Schema schema  = null;

			if (btsSchema != null)
			{
				schema = new  Schema(assembly, btsSchema.FullName);
				schema.schemaType = (SchemaType) Enum.Parse(typeof(SchemaType), ((int)btsSchema.Type).ToString());
				//schema.xmlContent = btsSchema.XmlContent; //TODO: Investigate - calling this causes a failure in BizTalk API
				schema.properties = btsSchema.Properties;

			}

			return schema;
		}

		#endregion



	}
}

