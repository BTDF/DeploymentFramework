/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration 
{
	
	using System;
	using System.Runtime.InteropServices;

	/// <summary>
	/// Provides wrappers for Win32 safe native methods
	/// </summary>
	internal sealed class SafeNativeMethods
	{
		private SafeNativeMethods() 
		{
		}

		[DllImport(ExternalDll.Advapi32, CharSet=CharSet.Auto, SetLastError=false)]
		internal static extern UInt32 LsaClose(IntPtr ObjectHandle);
        
		[DllImport(ExternalDll.Advapi32, CharSet=CharSet.Auto, SetLastError=false)]
		internal static extern UInt32 LsaFreeMemory(IntPtr ptr);

	}
}
