
namespace Microsoft.Sdc.Tasks.BizTalk2004.SendPortGroup
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;

    #endregion

    public class Configure : BizTalk2004TaskBase
    {
        private string name;
        private string newname;
        private string filterXml;

        [Required]
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        public string NewName
        {
            get { return this.newname; }
            set { this.newname = value; }
        }

        public string Filter
        {
            get { return this.filterXml; }
            set { this.filterXml = value; }
        }

        public Configure()
        {
        }

        protected override void InternalExecute()
        {
            BizTalkInstallation installation = this.GetInstallation();
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SendPortGroup sendportGroup = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SendPortGroup.Load(installation, this.name);

            if (sendportGroup == null)
                throw new InvalidOperationException(string.Format("Send Port {0} does not exist.", this.name));

            //changing the name if a new name is specified
            if (!string.IsNullOrEmpty(this.newname))
                sendportGroup.Name = this.newname;

            //filters
            if (!string.IsNullOrEmpty(this.filterXml))
                sendportGroup.FilterGroups.PopulateFromFilterXml(this.filterXml);

            sendportGroup.Save();
        }
    }
}

