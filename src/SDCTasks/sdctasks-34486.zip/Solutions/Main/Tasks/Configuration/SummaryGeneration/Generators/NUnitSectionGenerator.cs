/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Simon Ransom</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.SummaryGeneration.Generators
{
	using System;
	using System.IO;
	using System.Xml;

	/// <summary>
	/// Generates a section based on the *summary* of NUnit tests
	/// </summary>
	internal class NUnitSectionGenerator : ISectionGenerator
	{
		public Section GenerateSection(string sourceFolder, string fileSpec, string name)
		{
			XmlDocument section = new XmlDocument();
			section.AppendChild(section.CreateElement("Section"));
			section.DocumentElement.SetAttribute("Type","NUnit");
			if (name != null)
			{
				section.DocumentElement.SetAttribute("Name",name);
			}
			string [] reportFiles = Directory.GetFiles(sourceFolder,fileSpec);

			foreach (string reportFile in reportFiles)
			{
				XmlDocument document = new XmlDocument();
				document.Load(reportFile);
				// Just take all the XML and put it into the section
				section.DocumentElement.AppendChild(section.ImportNode(document.DocumentElement,true));
			}
			return new Section(section);
		}

		public NUnitSectionGenerator()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}

