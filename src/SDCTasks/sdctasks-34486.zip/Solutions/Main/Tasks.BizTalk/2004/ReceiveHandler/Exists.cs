//-------------------------------------------------------------------------------------
// <copyright file="Exists.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//     Checks if a ReceiveHandler Exists in Biztalk.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.ReceiveHandler
{
    #region Using directives

    using System;
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion


    #region Class Comments
    /// <summary>
    /// Checks whether a ReceiveHandler exists in a BizTalk installation.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2004.ReceiveHandler.Exists 
    ///         HostName="hostname" 
    ///         TransportType="FILE" 
    ///         Server="server" 
    ///         Database="database" />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>HostName (Required)</i></para>
    /// <para>
    /// The host to check for the handler.
    /// </para>
    /// <para><i>TransportType (Required)</i></para>
    /// <para>
    /// The transport type of the handler.
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <PropertyGroup>
    ///         <BTSReceivHandlerExists />
    ///     </PropertyGroup>
    ///     <Target Name="Test" >
    ///            <BizTalk2004.ReceiveHandler.Exists 
    ///                HostName="BizTalkServerApplication" 
    ///                TransportType="FILE" >
    ///                <Output TaskParameter="HandlerExists" PropertyName="BTSReceivHandlerExists" />
    ///            </BizTalk2004.ReceiveHandler.Exists>
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
        #endregion
    public class Exists : BizTalk2004TaskBase
    {
        private string hostName;
        private string transportType;
        private bool handlerExists;

        /// <summary>
        /// The name of the host to add the handler to.
        /// </summary>
        /// <value>The name of the host.</value>
        [Required]
        public string HostName
        {
            get { return this.hostName; }
            set { this.hostName = value; }
        }

        /// <summary>
        /// The transport type, e.g. FILE, SQL, SOAP etc
        /// </summary>
        /// <value></value>
        [Required]
        public string TransportType
        {
            get { return this.transportType; }
            set { this.transportType = value; }
        }

        /// <summary>
        /// Called to determine if the handler exists
        /// </summary>
        [Output]
        public bool HandlerExists
        {
            get { return this.handlerExists; }
        }

        #region Constructors 

        /// <summary>
        /// Creates a new instance of the exists task.
        /// </summary>
        public Exists()
        {
        }

        #endregion 

        #region Methods

        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {
            BizTalkInstallation installation = this.GetInstallation();
            this.handlerExists = ReceiveHandler.Exists(installation, this.hostName, this.transportType);
        }
        #endregion

    }
}
            
