//-----------------------------------------------------------------------
// <Deleteright file="ReceiveHandlerTests.cs" company="Microsoft">
// Deleteright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </Deleteright>
// <author>Thomas Manson</author>
// <email>tmanson</email>
// <date>2006-02-16</date>
// <summary>Tests BizTalk 2004 Receive Handler tasks</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test.BizTalk2006
{
    using System;
    using System.Text;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Sdc.Tasks.BizTalk2006;
    using System.Management;

    /// <summary>
    /// Tests the BizTalk 2006 assembly tasks
    /// </summary>
    [TestClass]
    public class SendPortGroupTests
    {
        private const string AppName = "Send Port Group Test App";
        private const string SendPort1Name = "Test Send Port 1";
        private const string SendPort2Name = "Test Send Port 2";
        private const string SendPortGroupName = "Test Send Port Group";

        public SendPortGroupTests()
        {
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext)
        {
            Microsoft.Sdc.Tasks.BizTalk2006.Application.Create createAppTask = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Create();
            createAppTask.Application = AppName;
            createAppTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Create createTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Create();
            createTask.Name = SendPort1Name;
            createTask.Application = AppName;
            createTask.IsDynamic = false;
            createTask.IsTwoWay = false;
            createTask.PrimaryTransportAddress = @"C:\temp\test.xml";
            createTask.PrimaryTransportProtocolName = "FILE";
            createTask.PrimaryTransportRetryCount = 5;
            createTask.PrimaryTransportRetryInterval = 30;
            createTask.PrimaryTransportOrderedDelivery = false;
            createTask.PrimaryTransportTransportData = @"<CustomProps><BatchSize vt='19'>20</BatchSize><FileMask vt='8'>*.xml</FileMask><FileNetFailRetryCount vt='19'>5</FileNetFailRetryCount><FileNetFailRetryInt vt='19'>5</FileNetFailRetryInt></CustomProps>";
            createTask.SendPipeline = "Microsoft.BizTalk.DefaultPipelines.XMLTransmit, Microsoft.BizTalk.DefaultPipelines, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35";
            createTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Create createTask2 = new Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Create();
            createTask2.Name = SendPort2Name;
            createTask2.Application = AppName;
            createTask2.IsDynamic = false;
            createTask2.IsTwoWay = false;
            createTask2.PrimaryTransportAddress = @"FORMATNAME:DIRECT=OS:.\PRIVATE$\TOFACILITIESQ";
            createTask2.PrimaryTransportProtocolName = "MSMQ";
            createTask2.PrimaryTransportRetryCount = 5;
            createTask2.PrimaryTransportRetryInterval = 30;
            createTask2.PrimaryTransportOrderedDelivery = false;
            createTask2.PrimaryTransportTransportData = @"<CustomProps><AdapterConfig vt='8'>&lt;Config xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:xsd='http://www.w3.org/2001/XMLSchema'&gt;&lt;queue&gt;FORMATNAME:DIRECT=OS:.\PRIVATE$\TOFACILITIESQ&lt;/queue&gt;&lt;uri&gt;FORMATNAME:DIRECT=OS:.\PRIVATE$\TOFACILITIESQ&lt;/uri&gt;&lt;maximumMessageSize&gt;1024&lt;/maximumMessageSize&gt;&lt;acknowledgeType&gt;None&lt;/acknowledgeType&gt;&lt;timeOut&gt;4&lt;/timeOut&gt;&lt;priority&gt;Normal&lt;/priority&gt;&lt;recoverable&gt;false&lt;/recoverable&gt;&lt;encryptionAlgorithm&gt;None&lt;/encryptionAlgorithm&gt;&lt;useAuthentication&gt;false&lt;/useAuthentication&gt;&lt;segmentationSupport&gt;false&lt;/segmentationSupport&gt;&lt;transactional&gt;true&lt;/transactional&gt;&lt;useJournalQueue&gt;false&lt;/useJournalQueue&gt;&lt;useDeadLetterQueue&gt;true&lt;/useDeadLetterQueue&gt;&lt;ackTypeEnumsValue&gt;0&lt;/ackTypeEnumsValue&gt;&lt;timeOutUnits&gt;Days&lt;/timeOutUnits&gt;&lt;bodyType&gt;0&lt;/bodyType&gt;&lt;/Config&gt;</AdapterConfig></CustomProps>";
            createTask2.SendPipeline = "Microsoft.BizTalk.DefaultPipelines.XMLTransmit, Microsoft.BizTalk.DefaultPipelines, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35";
            createTask2.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Start startTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Start();
            startTask.Name = SendPort1Name;
            startTask.Application = AppName;
            startTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Start startTask2 = new Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Start();
            startTask2.Name = SendPort2Name;
            startTask2.Application = AppName;
            startTask2.Execute();

        }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        [ClassCleanup()]
        public static void MyClassCleanup()
        {
            Microsoft.Sdc.Tasks.BizTalk2006.Application.Stop stopAppTask = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Stop();
            stopAppTask.Application = AppName;
            stopAppTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Delete deleteTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Delete();
            deleteTask.Application = AppName;
            deleteTask.Name = SendPort1Name;
            deleteTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Delete deleteTask2 = new Microsoft.Sdc.Tasks.BizTalk2006.SendPort.Delete();
            deleteTask2.Application = AppName;
            deleteTask2.Name = SendPort2Name;
            deleteTask2.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.Application.Delete deleteAppTask = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Delete();
            deleteAppTask.Application = AppName;
            deleteAppTask.Execute();
        }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void TestSendPortGroupActions()
        {
            Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup.Create createTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup.Create();
            createTask.Application = AppName;
            createTask.Name = SendPortGroupName;
            createTask.Description = "Test Description";
            createTask.SendPorts = new string[] { SendPort1Name };
            createTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup.Exists existsTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup.Exists();
            existsTask.Application = AppName;
            existsTask.Name = SendPortGroupName;
            existsTask.Execute();
            if (!existsTask.SendPortGroupExists)
            {
                Assert.Fail("Send port group was not created");
            }

            Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup.AddSendPort addSendPortTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup.AddSendPort();
            addSendPortTask.Application = AppName;
            addSendPortTask.Name = SendPortGroupName;
            addSendPortTask.SendPort = SendPort2Name;
            addSendPortTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup.RemoveSendPort removeSendPortTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup.RemoveSendPort();
            removeSendPortTask.Application = AppName;
            removeSendPortTask.Name = SendPortGroupName;
            removeSendPortTask.SendPort = SendPort1Name;
            removeSendPortTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup.Enlist enlistTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup.Enlist();
            enlistTask.Application = AppName;
            enlistTask.Name = SendPortGroupName;
            enlistTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup.Start startTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup.Start();
            startTask.Application = AppName;
            startTask.Name = SendPortGroupName;
            startTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup.Stop stopTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup.Stop();
            stopTask.Application = AppName;
            stopTask.Name = SendPortGroupName;
            stopTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup.UnEnlist unenlistTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup.UnEnlist();
            unenlistTask.Application = AppName;
            unenlistTask.Name = SendPortGroupName;
            unenlistTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup.Configure configure = new Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup.Configure();
            configure.Application = AppName;
            configure.Name = SendPortGroupName;
            configure.NewName = SendPortGroupName + "Renamed";
            configure.Execute();

            existsTask.Name = SendPortGroupName + "Renamed";
            existsTask.Execute();
            if (!existsTask.SendPortGroupExists)
            {
                Assert.Fail("SendPortGroup was not renamed");
            }

            Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup.Delete deleteTask = new Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup.Delete();
            deleteTask.Application = AppName;
            deleteTask.Name = SendPortGroupName + "Renamed";
            deleteTask.Execute();

            existsTask.Execute();
            if (existsTask.SendPortGroupExists)
            {
                Assert.Fail("SendPortGroup was not deleted");
            }
        }
    }
}
