/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/


namespace Microsoft.Sdc.Tasks.Configuration.Win32Security {
    using System;
    using System.Collections;
    using System.Diagnostics;
    /// <summary>
    /// A strongly typed collection of Ace types
    /// </summary>
    internal class Aces : CollectionBase {
        public Aces() {
        }
        public Ace this[int index] {
            get {
                return (Ace)base.InnerList[index];
            }
        }
        public void SetAce(int i, Ace ace) {
            base.InnerList[i] = ace;
        }
        public void Add(Ace ace) {
            base.InnerList.Add(ace);
        }
    }
}
