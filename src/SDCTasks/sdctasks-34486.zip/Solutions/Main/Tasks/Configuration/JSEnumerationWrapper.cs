/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author></Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/

namespace Microsoft.Sdc.Tasks.Configuration
{
	using System;
	using System.IO;
	using System.Collections;
	using System.Globalization;
	using java.util;
	using java.util.zip;
	using java.io;

	/// <summary>
	/// Wraps the J# enumeration class
	/// </summary>	
	internal class JSEnumerationWrapper : IEnumerable 
	{
		private Enumeration methodEnumeration;

		internal JSEnumerationWrapper(Enumeration method) 
		{
			if (method == null)	throw new ArgumentException();

			this.methodEnumeration = method;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public IEnumerator GetEnumerator() 
		{
			return new JSEnumerator(this.methodEnumeration);
		}
		private class JSEnumerator : IEnumerator 
		{
			private Enumeration methodEnumeration;
			private Enumeration wrappedEnumeration;
			private object      currentObject;		

			/// <summary>
			/// 
			/// </summary>
			public object Current 
			{
				get { return this.currentObject; }
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="method"></param>
			internal JSEnumerator(Enumeration method) 
			{
				this.methodEnumeration = method;
			}

			/// <summary>
			/// 
			/// </summary>
			public void Reset() 
			{
				this.wrappedEnumeration = this.methodEnumeration;
				if (this.wrappedEnumeration == null) throw new InvalidOperationException();
			}

			/// <summary>
			/// 
			/// </summary>
			/// <returns></returns>
			public bool MoveNext() 
			{
				if (this.wrappedEnumeration == null) Reset();
				bool result = this.wrappedEnumeration.hasMoreElements();
				if (result) 
				{
					this.currentObject = this.wrappedEnumeration.nextElement();
				}
				return result;
			}
		}
	}
}
