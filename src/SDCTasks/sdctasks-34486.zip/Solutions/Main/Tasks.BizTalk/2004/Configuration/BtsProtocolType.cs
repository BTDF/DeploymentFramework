﻿//-----------------------------------------------------------------------
// <copyright file="BtsProtocolType.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <summary>BtsProtocolType</summary>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;
    using System.Reflection;

    #endregion

    internal class BtsProtocolType : BtsBaseObject
    {
        /// <summary>
        /// Internal Constructor
        /// </summary>
        /// <param name="actualBtsObject">The actual Microsoft.Biztalk.ExplorerOM.BtsProtocolType object that object will call.</param>
        /// <param name="catalogExplorer">The Microsoft.Sdc.Tasks.Configuration.BtsCatalogExplorer object.</param>
        internal BtsProtocolType(object actualBtsObject, BtsCatalogExplorer catalogExplorer)
        {
            this.btsCatalogExplorer = catalogExplorer;
            this.actualBtsObject = actualBtsObject;
        }

        /// <summary>
        /// Gets the name of the adapter.
        /// </summary>
        public string Name
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("Name", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>
        /// Gets the configuration GUID of the adapter.
        /// </summary>
        public Guid ConfigurationGuid
        {
            get
            {
                return (Guid)this.actualBtsObject.GetType().InvokeMember("ConfigurationGuid", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>
        /// Gets the capabilities of the adapter.
        /// </summary>
        public Capabilities Capabilities
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("Capabilities", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (Capabilities)Enum.Parse(typeof(Capabilities), value.ToString());
            }
        }
    }
}
