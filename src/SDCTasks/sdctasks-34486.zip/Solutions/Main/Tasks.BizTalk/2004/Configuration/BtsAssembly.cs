﻿//-------------------------------------------------------------------------------------
// <copyright file="BtsAssembly.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      BtsAssembly
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;
    using System.Reflection;

    #endregion

    internal class BtsAssembly : BtsBaseObject
    {
        /// <summary>
        /// Internal Constructor
        /// </summary>
        /// <param name="actualBtsObject">The actual Microsoft.Biztalk.ExplorerOM.BtsAssembly object that object will call.</param>
        /// <param name="catalogExplorer">The Microsoft.Sdc.Tasks.Configuration.BtsCatalogExplorer object.</param>
        internal BtsAssembly(object actualBtsObject, BtsCatalogExplorer catalogExplorer)
        {
            this.btsCatalogExplorer = catalogExplorer;
            this.actualBtsObject = actualBtsObject;
        }

        /// <summary>Gets the culture supported by the assembly.</summary>
        public string Culture
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("Culture", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>Gets the display name of the assembly.</summary>
        public string DisplayName
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("DisplayName", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>Indicates whether the assembly is installed during setup.</summary>
        public bool IsSystem
        {
            get
            {
                return (bool)this.actualBtsObject.GetType().InvokeMember("IsSystem", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>Gets the assembly name.</summary>
        public string Name
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("Name", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>Gets the public key token of the assembly.</summary>
        public string PublicKeyToken
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("PublicKeyToken", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>Gets the major, minor, revision, and build number of the assembly.</summary>
        public string Version
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("Version", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>Gets the orchestrations in the assembly.</summary>
        public BtsOrchestrationCollection Orchestrations
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("Orchestrations", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsOrchestrationCollection orchCollection = new BtsOrchestrationCollection();

                    foreach (object item in ((System.Collections.IEnumerable)actualCollection))
                    {
                        BtsOrchestration orch = new BtsOrchestration(item, this.btsCatalogExplorer);
                        orchCollection.Add(orch);
                    }

                    return orchCollection;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>Gets the pipelines in the assembly.</summary>
        public BtsPipelineCollection Pipelines
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("Pipelines", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsPipelineCollection pipelineCollection = new BtsPipelineCollection();

                    foreach (object item in ((System.Collections.IEnumerable)actualCollection))
                    {
                        BtsPipeline pipeline = new BtsPipeline(item, this.btsCatalogExplorer);
                        pipelineCollection.Add(pipeline);
                    }

                    return pipelineCollection;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>Gets the schemas in the assembly.</summary>
        public BtsSchemaCollection Schemas
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("Schemas", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsSchemaCollection schemaCollection = new BtsSchemaCollection();

                    foreach (object item in ((System.Collections.IEnumerable)actualCollection))
                    {
                        BtsSchema schema = new BtsSchema(item, this.btsCatalogExplorer);
                        schemaCollection.Add(schema);
                    }

                    return schemaCollection;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>Gets the transforms in the assembly.</summary>
        public BtsTransformCollection Transforms
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("Transforms", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsTransformCollection transformCollection = new BtsTransformCollection();

                    foreach (object item in ((System.Collections.IEnumerable)actualCollection))
                    {
                        BtsTransform transform = new BtsTransform(item, this.btsCatalogExplorer);
                        transformCollection.Add(transform);
                    }

                    return transformCollection;
                }
                else
                {
                    return null;
                }
            }
        }
    }
}