/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date>October 2003</Date>
  <Description/>
  <Copyright><![CDATA[
    Copyright � 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/

namespace Microsoft.Sdc.Tasks.Configuration
{
    using System.IO;
    using System.Text.RegularExpressions;
    using System;
    using Microsoft.Win32;
    using System.Globalization;
    /// <summary>
    /// Utilities makes available common tasks such as path location methods.
    /// </summary>
    internal sealed class Utilities
    {
        /// <summary>
        /// Default constructor.
        /// </summary>
        private Utilities()
        {
            
        }

        /// <summary>Method to obtain a path to a specified system file.</summary>
        /// <returns>Returns a String value of the system file and path.</returns>
        /// <param name="systemFile"> String value specifying the name of the system file to locate </param>
        public static string GetPathToSystemFile(string systemFile)
        {
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), systemFile);
        }

        /// <summary>Method to obtain a path to the sdk folder of a specified runtime.</summary>
        /// <returns>Returns a String value of the sdk path.</returns>
        /// <param name="runtimeVersion"> String value specifying the version of the sdk to locate </param>
        public static string GetPathToSDK(string runtimeVersion)
        {
            string pathToSdk;
            
            try
            {
                RegistryKey runtimeKey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\.NETFramework");
                if (runtimeVersion == "1.0") 
                {
                    pathToSdk = Convert.ToString(runtimeKey.GetValue("sdkInstallRoot"));
                } 
                else 
                {
                    pathToSdk = Convert.ToString(runtimeKey.GetValue("sdkInstallRoot" + "v" + runtimeVersion));
                }
                runtimeKey.Close();
            }
            catch
            {
                throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "SDK not found"));
            }
            return pathToSdk;
        }

        /// <summary>Method to obtain the full path to the .NET framework runtime for the version specified.
        /// Only the major and minor version elements are checked for as each version could have many build revisions
        /// but only one revision can be installed at any one time.
        /// </summary>
        /// <param name="runtimeVersion">A string value specifying the major and minor version of the runtime to locate.</param>
        /// <returns>Returns a string value of the .NET framework path.</returns>
        public static string GetPathToRuntime(string runtimeVersion)
        {
            // The following regex matches on major and minor version in the format "Major.Minor",
            // starting at version "1.0"
            Regex versionExpression = new Regex(@"[1-9]{1}[0-9]*\.\d+");
            if (!versionExpression.IsMatch(runtimeVersion))
            {
                throw new ArgumentException(String.Format(CultureInfo.InvariantCulture, "The correct format is \"Major.Minor\" starting from version 1.0"), 
                                            String.Format(CultureInfo.InvariantCulture, "runtimeVersion"));
            }

            string pathToSystemRoot;
            string pathToFramework;

            pathToSystemRoot = Environment.GetEnvironmentVariable("SystemRoot");

            if (pathToSystemRoot == null || pathToSystemRoot.Length == 0)
            {
                throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Environment variable 'SystemRoot' not defined."));
            }

            pathToFramework = Path.Combine(pathToSystemRoot, "Microsoft.NET\\Framework");
            string[] frameworkDirectories = Directory.GetDirectories(pathToFramework, "v" + runtimeVersion + "*");

            if (frameworkDirectories.Length != 1)
            {
                throw new ApplicationException(String.Format(CultureInfo.InvariantCulture,"Cannot find a version " + runtimeVersion + " of the .NET Framework."));
            }

            return Path.Combine(pathToFramework, frameworkDirectories[0]);
        }
    }
}
