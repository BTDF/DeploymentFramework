//-------------------------------------------------------------------------------------
// <copyright file="Protocol.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Represents an adapter protocol.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using directives 

    using System;

	#endregion

	/// <summary>
	/// Represents an adapter protocol.
	/// </summary>
	internal class Protocol : BizTalkNonConfigurableEntityBase 
	{
		#region Member variables 
        
		private Capabilities capabilities;
        private Guid configurationGuid;

		#endregion 


		#region Properties
		/// <summary>
		/// Gets the configuration GUID of the adapter.
		/// </summary>
		/// <value>A <see cref="System.Guid"/></value>
		public Guid ConfigurationGuid
		{
			get { return this.configurationGuid; }
			
		}

		/// <summary>
		/// Gets the capabilities of the adapter.
		/// </summary>
		/// <value>A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Capabilities"/> enum</value>
		public Capabilities Capabilities
		{
			get {return this.capabilities;}
		}
		#endregion 


		/// <summary>
		/// Creates a Protocol instance. This is private because instance of this class can only be created with
		/// the Load method
		/// </summary>
		/// <param name="installation"> a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation"/> object.</param>
		public Protocol(BizTalkInstallation installation): this(installation, null){}

		/// <summary>
		/// Creates a Protocol instance. This is private because instance of this class can only be created with
		/// the Load method
		/// </summary>
		/// <param name="installation"> A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation"/> object.</param>
		///<param name="name">The name of the protocol.</param>
		public Protocol(BizTalkInstallation installation, string name) : base(installation, name){}


		/// <summary>
		/// Loads the details of a Protocol
		/// </summary>
		/// <param name="installation">The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation"/> of this protocol.</param>
		/// <param name="name">the name of the protocol.</param>
		/// <returns></returns>
		public static Protocol Load(BizTalkInstallation installation, string name)
		{
			//check inputs
			if (installation == null) throw new ArgumentException("installation");
			if (name == null || name.Length == 0) throw new ArgumentException("name");

			//creating native type
			BtsProtocolType btsProtocol = installation.CatalogExplorer.ProtocolTypes[name];

			if (btsProtocol != null)
			{
				Protocol protocol = new Protocol(installation , name);
				protocol.capabilities = (Capabilities)Enum.Parse(typeof(Capabilities), ((int)btsProtocol.Capabilities).ToString());
				protocol.configurationGuid = btsProtocol.ConfigurationGuid; 
				return protocol;
			}
			else
				return null;
		}


	}
}

