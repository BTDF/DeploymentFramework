//-----------------------------------------------------------------------
// <copyright file="Shutdown.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-03-23</date>
// <summary>Performs a shutdown on the specified ComponentServices Application.</summary>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.ComponentServices.Application
{
    using Microsoft.Sdc.Tasks.Configuration.ComponentServices;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Performs a shutdown on the specified ComponentServices Application.
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<ComponentServices.Application.Shutdown ApplicationName="applicationName" OnlyIfExists="onlyIfExists"/>]]></code>
    /// <para>where:</para>
    /// <para><i>applicationName (Required)</i></para>
    /// <para>The name of the COM+ application to be shutdown. If the application name exists multiple times then all matches will all be deleted.</para>
    /// <para><i>onlyIfExists</i></para>
    /// <para>If set to true, the application will only by shutdown if it exists. If set to false, the task will return an error if the application is not found</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <ComponentServices.Application.Shutdown ApplicationName="MyApplicationName" />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Shutdown : TaskBase
    {
        private string applicationName;
        private bool onlyIfExists;

        /// <summary>
        /// Gets or sets the name of the COM+ application to be shutdown
        /// </summary>
        /// <value>The name of the application that will be shutdown</value>
        [Required]
        public string ApplicationName
        {
            get { return this.applicationName; }
            set { this.applicationName = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [only if exists].
        /// </summary>
        /// <value><c>true</c> if [only if exists]; otherwise, <c>false</c>.</value>
        public bool OnlyIfExists
        {
            get { return this.onlyIfExists; }
            set { this.onlyIfExists = value; }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            Log.LogMessageFromResources("ComponentServices.ShuttingDown", this.ApplicationName);
            if (Application.Exists(this.ApplicationName))
            {
                Application.Shutdown(this.ApplicationName);
                return;
            }

            if (this.OnlyIfExists == false)
            {
                Log.LogError(string.Format("The Application was not found: {0}", this.ApplicationName));
            }
        }
    }
}