//-------------------------------------------------------------------------------------
// <copyright file="ExportBindings.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Exports the bindings of an assembly in BizTalk to an XML file.
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.Assembly
{
    #region Using directives
    using System.Globalization;
    using BizTalk.Deployment;
    #endregion

    /// <summary>
    /// Exports the bindings of an assembly in BizTalk to an XML file.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2004.Assembly.ExportBindings BindingPath="bindingPath" AssemblyPath="assemblyPath" SimpleName="simpleName" Version="version" PublicKeyToken="publicKeyToken" Culture="culture" LogPath="logPath" Server="server" Database="database" />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>bindingPath (Required)</i></para>
    /// <para>
    /// The path to the XML file that the bindings will be exported into.
    /// </para>
    /// <para><i>assemblyPath</i></para>
    /// <para>
    /// The path to the assembly to have its bindings exported. This is used if supplied, but is not required if 
    /// <i>simpleName</i>, <i>version</i>, <i>publicKeyToken</i> and <i>culture</i> are all supplied.
    /// </para>
    /// <para><i>simpleName</i></para>
    /// <para>
    /// The simple name of the assembly to have its bindings exported. This is not used if <i>assemblyPath</i> is supplied.
    /// </para>
    /// <para><i>version</i></para>
    /// <para>
    /// The version of the assembly to have its bindings exported. This is not used if <i>assemblyPath</i> is supplied.
    /// </para>
    /// <para><i>publicKeyToken</i></para>
    /// <para>
    /// The public key token of the assembly to have its bindings exported. This is not used if <i>assemblyPath</i> is supplied.
    /// </para>
    /// <para><i>culture</i></para>
    /// <para>
    /// The culture of the assembly to have its bindings exported. This is not used if <i>assemblyPath</i> is supplied.
    /// </para>
    /// <para><i>logPath</i></para>
    /// <para>
    /// The path to the log file for the binding export. The default is no log file.
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// <para><i>username</i></para>
    /// <para>
    /// The username to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// <para><i>password</i></para>
    /// <para>
    /// The password to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <!-- Export bindings using the assembly file -->
    ///         <BizTalk2004.Assembly.ExportBindings 
    ///             AssemblyPath="C:\Build\Output\MyAssembly.dll" 
    ///             LogPath="C:\Build\Logs\MyAssemblyExportBindings.log" 
    ///             Server="." 
    ///             Database="BizTalkMgmtDb" 
    ///              
    ///              />
    ///         <!-- Export bindings using the assembly details -->
    ///         <BizTalk2004.Assembly.ExportBindings 
    ///             SimpleName="MyAssembly"
    ///             Version="2.0.0.0"
    ///             PublicKeyToken="128bd009fce13573"
    ///             Culture="neutral"
    ///             LogPath="C:\Build\Logs\MyAssemblyExportBindings.log" 
    ///             Server="." 
    ///             Database="BizTalkMgmtDb" 
    ///              
    ///              />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class ExportBindings : BizTalk2004.Assembly.ExportBindings
    {
        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {
            BizTalk2004.Configuration.BizTalkInstallation installation = this.GetInstallation();

            Deployer deployer = new Deployer();
            deployer.SetConnection(installation.Server, installation.Database);

            BizTalkAssemblyName name = new BizTalkAssemblyName(this.AssemblyPath);
            Log.LogMessage(string.Format(CultureInfo.InvariantCulture, "Exporting Binding: {0} to Path: {1}", name, this.BindingPath));
            deployer.ExportBinding(name, this.BindingPath, null);
        }
    }
}

