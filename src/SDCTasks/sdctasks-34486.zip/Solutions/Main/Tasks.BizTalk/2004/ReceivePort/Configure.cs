//-------------------------------------------------------------------------------------
// <copyright file="Configure.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Configures a receive port in a BizTalk Server.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.ReceivePort
{
    #region Using directives

    using System;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion


    #region Class Comments
    /// <summary>
    /// Configures a receive port in a BizTalk Server.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2004.ReceivePort.Configure 
    ///                Name="ReceivePort 2"
    ///                AuthenticationType="RequiredDropMessage"
    ///                TrackingTypes="AfterReceivePipeline, AfterSendPipeline"
    ///                SendPipeline="Microsoft.BizTalk.DefaultPipelines.XMLTransmit, Microsoft.BizTalk.DefaultPipelines, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
    ///                InboundMaps="TestMap, TempSolution.TestMaps, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35; TestMap3, TempSolution.TestMaps, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
    ///                OutboundMaps="TestMap2, TempSolution.TestMaps, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
    ///                />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>Name (Required)</i></para>
    /// <para>
    /// The name of the receive port to Configure.
    /// </para>
    /// <para><i>AuthenticationType</i></para>
    /// <para>
    /// Authentication type for the receive port. If not specified defaults to 'NotRequired'.
    /// </para>
    /// <para><i>TrackingTypes</i></para>
    /// <para>
    /// The Tracking type(s) for the receive port.
    /// </para>
    /// <para><i>InboundMaps </i></para>
    /// <para>
    ///  The AssemblyQualifiedNames of one or more inbound maps to be applied to the receive port, separated by a semi-colon.
    ///</para>
    /// <para><i>OutboundMaps </i></para>
    /// <para>
    ///  The AssemblyQualifiedNames of one or more outbound maps to be applied to the two-way receive port, separated by a semi-colon.
    /// </para>
    /// <para><i>SendPipeline (Required if TwoWay = 'true'</i></para>
    /// <para>
    ///  The AssemblyQualifiedName of the send pipeline for a two-way receive port.
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// <para><i>username</i></para>
    /// <para>
    /// The username to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// <para><i>password</i></para>
    /// <para>
    /// The password to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///            <BizTalk2004.ReceivePort.Configure 
    ///                Name="ReceivePort 1"
    ///                InboundMaps="TestMap, TempSolution.TestMaps, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
    ///            />
    /// 
    ///            <BizTalk2004.ReceivePort.Configure 
    ///                Name="ReceivePort 2"
    ///                AuthenticationType="RequiredDropMessage"
    ///                TrackingTypes="AfterReceivePipeline, AfterSendPipeline"
    ///                SendPipeline="Microsoft.BizTalk.DefaultPipelines.XMLTransmit, Microsoft.BizTalk.DefaultPipelines, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
    ///                InboundMaps="TestMap, TempSolution.TestMaps, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35; TestMap3, TempSolution.TestMaps, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
    ///                OutboundMaps="TestMap2, TempSolution.TestMaps, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
    ///                />
    ///      </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    #endregion
    public class Configure : BizTalk2004TaskBase
    {
        private string name;
        private string authenticationtype;
        private string trackingtypes;
        private string sendPipeLine;
        private string[] inboundMaps;
        private bool removeInboundMaps;
        private string[] outboundMaps;
        private bool removeOutboundMaps;


        /// <summary>
        /// The name of the receive port.
        /// </summary>
        /// <value>The name of the receive port.</value>
        [Required]
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        /// <summary>
        /// The Authentication type for the receive port. 
        /// </summary>
        /// <value>
        ///Any one of the following:
        /// NotRequired,
        /// RequiredDropMessage,
        /// RequiredKeepMessage
        ///</value>
        public string AuthenticationType
        {
            get { return this.authenticationtype; }
            set { this.authenticationtype = value; }
        }

        /// <summary>
        /// The Tracking Type for the recive port.
        /// </summary>
        /// <value>
        ///One or more of the following, separated by a comma:
        /// AfterReceivePipeline,
        /// BeforeReceivePipeline,
        /// AfterSendPipeline, (only for two-way receive ports)
        /// BeforeSendPipeline (only for two-way receive ports) 
        ///</value>
        public string TrackingTypes
        {
            get { return this.trackingtypes; }
            set { this.trackingtypes = value; }
        }

        /// <summary>
        /// The AssemblyQualifiedname of the send pipeline for a two-way receive port.
        /// </summary>
        /// <value>The AssemblyQualifiedname of the send pipeline for a two-way receive port.</value>
        public string SendPipeline
        {
            get { return this.sendPipeLine; }
            set { this.sendPipeLine = value; }
        }

        /// <summary>
        /// The collection of maps to apply to inbound documents.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public string[] InboundMaps
        {
            get { return this.inboundMaps; }
            set { this.inboundMaps = value; }

        }

        /// <summary>
        /// Removes all InboundMaps
        /// </summary>
        /// <value>
        /// True to remove all inbound maps
        /// </value>
        public bool RemoveInboundMaps
        {
            get
            {
                return this.removeInboundMaps;
            }
            set
            {
                this.removeInboundMaps = value;
            }
        }
        /// <summary>
        /// The collection of maps to apply to outbound documents on the two-way receive port.
        /// </summary>
        /// <value>
        /// 
        ///</value>
        public string[] OutboundMaps
        {
            get { return this.outboundMaps; }
            set { this.outboundMaps = value; }
        }

        /// <summary>
        /// Removes all OutboundMaps
        /// </summary>
        /// <value>
        /// True to remove all inbound maps
        /// </value>
        public bool RemoveOutboundMaps
        {
            get
            {
                return this.removeOutboundMaps;
            }
            set
            {
                this.removeOutboundMaps = value;
            }
        }

         /// <summary>
        /// Initializes a new instance of the Configure class.
        /// </summary>
        public Configure()
        {

        }

        /// <summary>
        /// Performs the action for this task
        /// </summary>
        protected override void InternalExecute()
        {
            //getting the installation and creating the new receive port.
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation installation = this.GetInstallation();
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.ReceivePort receivePort = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.ReceivePort.Load(installation, this.name);


            //setting the properties

            //authentication type
            receivePort.AuthenticationType = (this.authenticationtype != null) ?
                (Microsoft.Sdc.Tasks.BizTalk2004.Configuration.AuthenticationType)Enum.Parse(typeof(Microsoft.Sdc.Tasks.BizTalk2004.Configuration.AuthenticationType), this.authenticationtype) :
                receivePort.AuthenticationType;

            //tracking type
            receivePort.TrackingType = (this.trackingtypes != null) ?
                (Microsoft.Sdc.Tasks.BizTalk2004.Configuration.TrackingTypes)Enum.Parse(typeof(Microsoft.Sdc.Tasks.BizTalk2004.Configuration.TrackingTypes), this.trackingtypes) :
                receivePort.TrackingType;

            //inbound maps
            if (this.removeInboundMaps)
            {
                receivePort.InboundTransforms.Clear();
            }
            else
            {
                if (this.inboundMaps != null)
                {
                    receivePort.InboundTransforms.Clear();
                    foreach (string mapName in this.inboundMaps)
                    {
                        string _mapName;
                        string _assemblyName;
                        SplitQualifiedTypeName(mapName, out _mapName, out _assemblyName);

                        receivePort.InboundTransforms.Add(Map.Load(installation.DeployedAssemblies[_assemblyName], _mapName));
                    }
                }
            }

            if (this.removeOutboundMaps)
            {
                receivePort.OutboundTransforms.Clear();
            }
            else
            {
                if (receivePort.TwoWay)
                {
                    //send pipeline
                    if (!string.IsNullOrEmpty(this.sendPipeLine))
                    {
                        string _pipelineName;
                        string _assemblyName;
                        SplitQualifiedTypeName(this.sendPipeLine, out _pipelineName, out _assemblyName);

                        Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkAssembly _assembly = installation.DeployedAssemblies[_assemblyName];

                        if (_assembly != null)
                            receivePort.SendPipeline = _assembly.Pipelines[_pipelineName];

                    }

                    //outbound maps
                    if (this.outboundMaps != null)
                    {
                        receivePort.OutboundTransforms.Clear();
                        foreach (string mapName in this.outboundMaps)
                        {
                            string _mapName;
                            string _assemblyName;

                            SplitQualifiedTypeName(mapName, out _mapName, out _assemblyName);

                            receivePort.OutboundTransforms.Add(Map.Load(installation.DeployedAssemblies[_assemblyName], _mapName));
                        }
                    }

                }
            }
            receivePort.Save();
        }
    }
}

