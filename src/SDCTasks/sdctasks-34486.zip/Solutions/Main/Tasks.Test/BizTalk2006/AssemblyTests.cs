//-----------------------------------------------------------------------
// <Deleteright file="ReceiveHandlerTests.cs" company="Microsoft">
// Deleteright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </Deleteright>
// <author>Thomas Manson</author>
// <email>tmanson</email>
// <date>2006-02-16</date>
// <summary>Tests BizTalk 2004 Receive Handler tasks</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test.BizTalk2006
{
    using System;
    using System.Text;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Sdc.Tasks.BizTalk2004;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks.BizTalk2006;
    using System.Management;

    /// <summary>
    /// Tests the BizTalk 2006 assembly tasks
    /// </summary>
    [TestClass]
    public class AssemblyTests
    {
        private const string hostName = "NewTesthost";
        private const string transport = "FILE";
        public AssemblyTests()
        {
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext)
        {
            Microsoft.Sdc.Tasks.BizTalk2006.Application.Create createApp = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Create();
            createApp.Application = "TestApp";
            createApp.Execute();
        }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        [ClassCleanup()]
        public static void MyClassCleanup()
        {
            Microsoft.Sdc.Tasks.BizTalk2006.Application.Delete deleteAppTask = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Delete();
            deleteAppTask.Application = "TestApp";
            deleteAppTask.Execute();
        }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void TestAssemblyActions()
        {
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.Deploy task = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.Deploy();
            task.Application = "TestApp";
            task.AssemblyPath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Scenarios\BPM\MainAssemblies\Microsoft.Samples.BizTalk.SouthridgeVideo.CableOrderStage1.dll";
            task.InstallInGac = true;
            task.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.Exists existsTask = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.Exists();
            existsTask.Application = "TestApp";
            existsTask.DisplayName = "Microsoft.Samples.BizTalk.SouthridgeVideo.CableOrderStage1, Version=1.1.0.0, Culture=neutral, PublicKeyToken=1fb25adc93e1ab92";
            existsTask.Execute();
            if (!existsTask.DoesExist)
            {
                Assert.Fail("Assembly was expected to exist");
            }

            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.ExportBindings exportTest = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.ExportBindings();
            exportTest.AssemblyPath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Scenarios\BPM\MainAssemblies\Microsoft.Samples.BizTalk.SouthridgeVideo.CableOrderStage1.dll";
            exportTest.BindingPath = "ExportTest.xml";
            exportTest.Execute();
            if (!System.IO.File.Exists("ExportTest.xml"))
            {
                Assert.Fail("Bindings file was not created");
            }

            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.ImportBindings importTask = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.ImportBindings();
            importTask.BindingPath = "ExportTest.xml";
            importTask.AssemblyPath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Scenarios\BPM\MainAssemblies\Microsoft.Samples.BizTalk.SouthridgeVideo.CableOrderStage1.dll";
            importTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.Undeploy undeployTask = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.Undeploy();
            undeployTask.Application = "TestApp";
            undeployTask.AssemblyPath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Scenarios\BPM\MainAssemblies\Microsoft.Samples.BizTalk.SouthridgeVideo.CableOrderStage1.dll";
            undeployTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.Exists existsTask2 = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.Exists();
            existsTask2.Application = "TestApp";
            existsTask2.DisplayName = "Microsoft.Samples.BizTalk.SouthridgeVideo.CableOrderStage1, Version=1.1.0.0, Culture=neutral, PublicKeyToken=1fb25adc93e1ab92";
            existsTask2.Execute();
            if (existsTask2.DoesExist)
            {
                Assert.Fail("Assembly was not expected to exist");
            }

        }
    }
}
