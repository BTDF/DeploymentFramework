//-------------------------------------------------------------------------------------
// <copyright file="BizTalkConfigurableEntityBase.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Base class for BizTalk entities that are programatically configurable.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;

    #endregion

    #region Class Comments
    /// <summary>
    /// Base class for BizTalk entities that are programatically configurable.
    /// </summary>
    /// <remarks>
    /// Configurable entities are entities that affect the runtime behaviour of the BizTalk server, but are
    /// not compiled or deployed into it. This includes things like send ports and receive ports. These entities
    /// can be added to, modified in, and deleted from the installation.
    /// </remarks>
    #endregion
    internal abstract class BizTalkConfigurableEntityBase : BizTalkEntityBase
    {
        private bool loaded;

        #region Constructors

        /// <summary>
        /// Creates a new <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkConfigurableEntityBase"/>.
        /// </summary>
        /// <param name="installation">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation"/> that this object
        /// belongs to.
        /// </param>
        protected BizTalkConfigurableEntityBase(BizTalkInstallation installation)
            : this(installation, null)
        {
        }

        /// <summary>
        /// Creates a new <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkConfigurableEntityBase"/>.
        /// </summary>
        /// <param name="installation">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation"/> that this object
        /// belongs to.
        /// </param>
        /// <param name="name">
        /// The name
        /// </param>
        protected BizTalkConfigurableEntityBase(BizTalkInstallation installation, string name)
            : base(installation, name)
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// set by the Load method if the object was Loaded from BizTalk Server
        /// </summary>
        public bool Loaded
        {
            get { return this.loaded; }
            set { this.loaded = value; }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Saves the changes made to the object.
        /// </summary>
        public void Save()
        {
            try
            {
                this.SaveImpl();
                this.Installation.CatalogExplorer.SaveChanges();
            }
            catch
            {
                this.Installation.CatalogExplorer.DiscardChanges();
                throw;
            }
        }

        /// <summary>
        /// When implemented in a derived class, provides the implementation of the Save method.
        /// </summary>
        /// <remarks>
        /// <para>
        /// The Save method that calls this handles the saving or discarding of the changes to all objects
        /// within the scope of that save. Implementations of this method should not explicitly save or
        /// discard the changes to the object. To indicate a failure in a method, throw an exception which
        /// will cause any previous changes to be discarded.
        /// </para>
        /// <para>
        /// If the item being saved has child objects which also need to be saved, then this method
        /// implementation should also call SaveImpl for each of the child objects. Do not call Save on
        /// those objects because this would save those changes in a seperate transaction to the one that
        /// this method was called in and may leave the BizTalk Server in an inconsistent state.
        /// </para>
        /// </remarks>
        protected internal virtual void SaveImpl() { }

        #endregion
    }
}

