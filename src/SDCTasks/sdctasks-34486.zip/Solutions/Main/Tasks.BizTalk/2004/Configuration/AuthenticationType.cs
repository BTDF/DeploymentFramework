//-------------------------------------------------------------------------------------
// <copyright file="AuthenticationType.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Type of authentication for messaging locations.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    /// <summary>
    /// Type of authentication for messaging locations.
    /// </summary>
    public enum AuthenticationType
    {
        /// <summary>
        /// Authentication is not required for messages.
        /// </summary>
        NotRequired = 0,
        
        /// <summary>
        /// Authentication is required, and if it fails, the message is dropped.
        /// </summary>        
        RequiredDropMessage = 1,
        
        /// <summary>
        /// Authentication is required, but even if it fails, the message is not dropped.
        /// </summary>
        RequiredKeepMessage = 2
    }
}

