﻿namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using directives

	using System;
	using System.Collections;
	using System.Text;
	using System.Reflection;

	#endregion

	internal class BtsTransform : BtsBaseObject
	{
		/// <summary>
		/// Internal Constructor
		/// </summary>
		/// <param name="actualBtsObject">The actual Microsoft.Biztalk.ExplorerOM.BtsTransform object that object will call.</param>
		/// <param name="catalogExplorer">The Microsoft.Sdc.Tasks.Configuration.BtsCatalogExplorer object.</param>
		internal BtsTransform(object actualBtsObject, BtsCatalogExplorer catalogExplorer)
		{
			this.btsCatalogExplorer = catalogExplorer;
			this.actualBtsObject = actualBtsObject;
		}

		/// <summary>
		/// Gets the assembly qualified name of the transform
		/// </summary>
		/// <value></value>
		public string AssemblyQualifiedName
		{
			get
			{
				return (string)this.actualBtsObject.GetType().InvokeMember("AssemblyQualifiedName", BindingFlags.GetProperty, null, this.actualBtsObject, null);
			}
		}

		/// <summary>
		/// Gets the reference to the containing assembly.
		/// </summary>
		public BtsAssembly BtsAssembly
		{
			get
			{
				object value = this.actualBtsObject.GetType().InvokeMember("BtsAssembly", BindingFlags.GetProperty, null, this.actualBtsObject, null);
				BtsAssembly assembly = new BtsAssembly(value, this.btsCatalogExplorer);
				return assembly;
			}
		}

		/// <summary>
		/// Gets the full name of the transform.
		/// </summary>
		public string FullName
		{
			get
			{
				return (string)this.actualBtsObject.GetType().InvokeMember("FullName", BindingFlags.GetProperty, null, this.actualBtsObject, null);
			}
		}

		/// <summary>
		/// Gets the source schema of the map.
		/// </summary>
		/// <value></value>
		public BtsSchema SourceSchema
		{
			get
			{
				object value = this.actualBtsObject.GetType().InvokeMember("SourceSchema", BindingFlags.GetProperty, null, this.actualBtsObject, null);
				return (value!=null)?new BtsSchema(value, this.btsCatalogExplorer):null;
			}
		}

		/// <summary>
		/// Gets the target schema of the map.
		/// </summary>
		/// <value></value>
		public BtsSchema TargetSchema
		{

			get
			{
				object value = this.actualBtsObject.GetType().InvokeMember("TargetSchema", BindingFlags.GetProperty, null, this.actualBtsObject, null);
				return (value!=null)?new BtsSchema(value, this.btsCatalogExplorer):null;
			}
		}

		/// <summary>
		/// Gets the XML content of the map.
		/// </summary>
		/// <value></value>
		public string XmlContent
		{
			get
			{
				return (string)this.actualBtsObject.GetType().InvokeMember("XmlContent", BindingFlags.GetProperty, null, this.actualBtsObject, null);
			}
		}
	}
}
