using System.Globalization;
using System;
using System.Runtime.InteropServices;

namespace Microsoft.Sdc.Tasks
{
    internal sealed class CultureStringUtilities
    {
        static private string[] cultureInfoStrings;

        private CultureStringUtilities()
        {
            // do nothing
        }

        internal static bool IsValidCultureString(string cultureString)
        {
            PopulateCultureInfoArray();

            bool valid = true;

            if (Array.BinarySearch(cultureInfoStrings, cultureString.ToLower(CultureInfo.InvariantCulture)) < 0)
            {
                valid = false;
            }

            return valid;
        }

        internal static void PopulateCultureInfoArray()
        {
            if (cultureInfoStrings == null)
            {
                CultureInfo[] cultureInfos = CultureInfo.GetCultures(CultureTypes.AllCultures);

                cultureInfoStrings = new string[cultureInfos.Length];
                for (int i = 0; i < cultureInfos.Length; i++)
                {
                    cultureInfoStrings[i] = cultureInfos[i].ToString().ToLower(CultureInfo.InvariantCulture);
                }

                Array.Sort(cultureInfoStrings);
            }
        }
    }
}
