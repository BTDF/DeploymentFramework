//-----------------------------------------------------------------------
// <copyright file="AddToReportTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-06-04</date>
// <summary>Tests adding a section to a summary report</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the AddToReport Test Task
    /// </summary>
    [TestClass]
    public class AddToReportTest
    {       
        public AddToReportTest()
        {
        }       

        [TestMethod]
        [Ignore]//("Remove hard coded paths")]
        public void TestSuccess()
        {
            string outputDirectory = TaskTestUtilities.CreateTempFolder();
            string outputFilename = TaskTestUtilities.CreateTempFileInFolder("nunitOutput", outputDirectory);
            string reportFile = outputDirectory + "\\" + "summaryReport.xml";

            string fileSpec = "*.temp";

            GenerateNunitReport(outputDirectory, outputFilename);

            Tasks.Summary.AddToReport addToReportTask = new Tasks.Summary.AddToReport();
            
            string name = "TaskUnitTest";
            string sectionGenerator = "Microsoft.Sdc.Tasks.Configuration.SummaryGeneration.Generators.NUnitSectionGenerator";
            string sourceFolder = outputDirectory;

            addToReportTask.FileSpec = fileSpec;
            addToReportTask.Name = name;
            addToReportTask.ReportFile = reportFile;
            addToReportTask.SectionGenerator = sectionGenerator;
            addToReportTask.SourceFolder = sourceFolder;

            bool addToReportTaskReturnValue = addToReportTask.Execute();

            //Test the task executed successfully
            Assert.IsTrue(addToReportTaskReturnValue, "AddToReportSucceeded");

            //Test the properties
            Assert.IsTrue(addToReportTask.FileSpec == fileSpec, "AddToReportProperties");
            Assert.IsTrue(addToReportTask.Name == name, "AddToReportProperties");
            Assert.IsTrue(addToReportTask.ReportFile == reportFile, "AddToReportProperties");
            Assert.IsTrue(addToReportTask.SectionGenerator == sectionGenerator, "AddToReportProperties");
            Assert.IsTrue(addToReportTask.SourceFolder == sourceFolder, "AddToReportProperties");

            //Ensure the report file exists
            if (!(System.IO.File.Exists(reportFile)))
            {
                Assert.Fail("Can't find the report summary output file");
            }

            //Ensure it contains a section with the supplied name

            string summaryFileContents = System.IO.File.ReadAllText(reportFile);
            if (!(summaryFileContents.Contains(name)))
            {
                Assert.Fail("Can't find the section name in the report summary output file");
            }

            Directory.Delete(outputDirectory, true);
        }

        [TestMethod]
        public void TestUninitializedTaskFails()
        {
            Tasks.Summary.AddToReport task = new Tasks.Summary.AddToReport();
           
            try
            {
                bool taskReturnValue = task.Execute();
                Assert.Fail("Uninitialised tasks should not succeed.");
            }
            catch (ApplicationException)
            {
                Console.WriteLine("Correctly threw exception");
                Console.WriteLine(((PseudoBuildEngine) task.BuildEngine).PreviousMessage);
            }
        }

        private void GenerateNunitReport(string outputDirectory, string outputFilename)
        {
            Tools.NUnit task = new Tools.NUnit();
           

            string toolPath = @"C:\Program Files\NUnit V2.1\bin\nunit-console.exe";
            string version = "2.1";
            string assemblyName = @"C:\Projects\Microsoft.Sdc.Configuration\Main\Src\Solutions\MainSolution\Microsoft.Sdc.Tasks.Configuration.Tasks.Test.AssemblyTest\bin\Debug\TestAssembly.dll";

            //NB: REMOVE .Path property from task
            task.ToolPath = toolPath;

            task.Assemblies = new string[] { assemblyName };
            task.Version = version;

            task.OutputFolder = outputDirectory;

            Assert.IsTrue(task.Assemblies[0] == assemblyName, "TaskProperties");
            Assert.IsTrue(task.ToolPath == toolPath, "TaskProperties");
            Assert.IsTrue(task.Version == version, "TaskProperties");
            Assert.IsTrue(task.OutputFolder == outputDirectory, "TaskProperties");

            bool taskReturnValue = task.Execute();
            Assert.IsTrue(taskReturnValue, "TestNunit");
        }
    }
}


