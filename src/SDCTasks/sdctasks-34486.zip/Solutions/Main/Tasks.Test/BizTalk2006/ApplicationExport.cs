using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Globalization;

namespace Microsoft.Sdc.Tasks.Test.BizTalk2006
{
    /// <summary>
    /// Summary description for ApplicationExport
    /// </summary>
    [TestClass]
    public class ApplicationExport
    {
        private static readonly string APPNAME = "BAMApp";

        public ApplicationExport()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext)
        {
            Microsoft.Sdc.Tasks.BizTalk2006.Application.Create createApp = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Create();
            createApp.Application = ApplicationExport.APPNAME;
            createApp.Execute();
        }

        // Use ClassCleanup to run code after all tests in a class have run
        [ClassCleanup()]
        public static void MyClassCleanup()
        {
            Microsoft.Sdc.Tasks.BizTalk2006.Application.Delete deleteAppTask = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Delete();
            deleteAppTask.Application = ApplicationExport.APPNAME;
            deleteAppTask.Execute();
        }

        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void TestApplicationExportAction()
        {
            // Testing in adding resources, including BizTalk.
            // Add a .NET Assembly
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.DeployResource resource1 = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.DeployResource();
            resource1.Application = ApplicationExport.APPNAME;
            resource1.ResourceType = "System.BizTalk:Assembly";
            resource1.AssemblyPath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\Microsoft.Samples.BizTalk.BamEndToEnd.Components.dll";
            resource1.Overwrite = true;
            resource1.Options = "GacOnAdd,GacOnInstall";
            resource1.Execute();

            // Add a BizTalk Assembly
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.DeployResource resource2 = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.DeployResource();
            resource2.Application = ApplicationExport.APPNAME;
            resource2.ResourceType = "System.BizTalk:BizTalkAssembly";
            resource2.AssemblyPath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\Microsoft.Samples.BizTalk.BamEndToEnd.Services.dll";
            resource2.Overwrite = true;
            resource2.Options = "GacOnAdd,GacOnInstall";
            resource2.Execute();

            // Add a Xml BAM file
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.DeployResource resource4 = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.DeployResource();
            resource4.Application = ApplicationExport.APPNAME;
            resource4.ResourceType = "System.BizTalk:Bam";
            resource4.AssemblyPath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\BAMEndToEnd.xml";
            resource4.Overwrite = true;
            resource4.Execute();

            // Check if the resources are added
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.ExistsResource exists1 = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.ExistsResource();
            exists1.Application = ApplicationExport.APPNAME;
            exists1.ResourceType = "System.BizTalk:Assembly";
            exists1.ResourcePath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\Microsoft.Samples.BizTalk.BamEndToEnd.Components.dll";
            exists1.Execute();

            if (!exists1.DoesExist)
            {
                Assert.Fail(string.Format(CultureInfo.InvariantCulture, "Assembly {0} was expected to exist", exists1.ResourcePath));
            }

            // Check if the resources are added
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.ExistsResource exists2 = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.ExistsResource();
            exists2.Application = ApplicationExport.APPNAME;
            exists2.ResourceType = "System.BizTalk:BizTalkAssembly";
            exists2.ResourcePath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\Microsoft.Samples.BizTalk.BamEndToEnd.Services.dll";
            exists2.Execute();

            if (!exists2.DoesExist)
            {
                Assert.Fail(string.Format(CultureInfo.InvariantCulture, "Assembly {0} was expected to exist", exists2.ResourcePath));
            }

            // Check if the resources are added
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.ExistsResource exists4 = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.ExistsResource();
            exists4.Application = ApplicationExport.APPNAME;
            exists4.ResourceType = "System.BizTalk:Bam";
            exists4.ResourcePath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\BAMEndToEnd.xml";
            exists4.Execute();

            if (!exists4.DoesExist)
            {
                Assert.Fail(string.Format(CultureInfo.InvariantCulture, "Assembly {0} was expected to exist", exists4.ResourcePath));
            }

            // Inmport the binding for the application
            Microsoft.Sdc.Tasks.BizTalk2006.Application.ImportBindings import = new Microsoft.Sdc.Tasks.BizTalk2006.Application.ImportBindings();
            import.Application = ApplicationExport.APPNAME;
            import.BindingPath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\BAMEndToEndBinding.xml";
            import.Execute();

            // Configure the application so the application can be enlisted and started
            Microsoft.Sdc.Tasks.BizTalk2006.Application.Configure configuration = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Configure();
            configuration.Application = ApplicationExport.APPNAME;
            configuration.Execute();

            // Start the application
            Microsoft.Sdc.Tasks.BizTalk2006.Application.Start startApp = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Start();
            startApp.Application = ApplicationExport.APPNAME;
            startApp.Execute();

            // Stop the application
            Microsoft.Sdc.Tasks.BizTalk2006.Application.Stop stopApp = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Stop();
            stopApp.Application = ApplicationExport.APPNAME;
            stopApp.Execute();

            // Export the binding for the application
            Microsoft.Sdc.Tasks.BizTalk2006.Application.ExportBindings exportBinding = new Microsoft.Sdc.Tasks.BizTalk2006.Application.ExportBindings();
            exportBinding.Application = ApplicationExport.APPNAME;
            exportBinding.BindingPath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\Binding\BAMEndToEndBinding.xml";
            exportBinding.Execute();

            // Add a Xml Binding file, as Development
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.DeployResource resource3 = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.DeployResource();
            resource3.Application = ApplicationExport.APPNAME;
            resource3.ResourceType = "System.BizTalk:BizTalkBinding";
            resource3.AssemblyPath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\Binding\BAMEndToEndBinding.xml";
            resource3.Overwrite = true;
            resource3.Properties = "TargetEnvironment=Deployment";
            resource3.Execute();

            // Check if the resources are added
            Microsoft.Sdc.Tasks.BizTalk2006.Assembly.ExistsResource exists3 = new Microsoft.Sdc.Tasks.BizTalk2006.Assembly.ExistsResource();
            exists3.Application = ApplicationExport.APPNAME;
            exists3.ResourceType = "System.BizTalk:BizTalkBinding";
            exists3.ResourcePath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\Binding\BAMEndToEndBinding.xml";
            exists3.Execute();

            if (!exists3.DoesExist)
            {
                Assert.Fail(string.Format(CultureInfo.InvariantCulture, "Assembly {0} was expected to exist", exists3.ResourcePath));
            }

            // Export the application to the MSI Deploy file
            Microsoft.Sdc.Tasks.BizTalk2006.Application.ExportMsi export = new Microsoft.Sdc.Tasks.BizTalk2006.Application.ExportMsi();
            export.Application = ApplicationExport.APPNAME;
            export.Destination = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\MSI\BAMApp.msi";
            export.Execute();

            // Check if the MSI is created
            Assert.IsTrue(System.IO.File.Exists(@"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Samples\BAM\BamEndToEnd\Deploy\MSI\BAMApp.msi"),"Export failed, no output found");
        }
    }
}
