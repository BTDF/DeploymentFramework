//-----------------------------------------------------------------------
// <copyright file="GetEnvironmentVariable.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-03-25</date>
// <summary></summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks
{
    using System;
    using System.Xml;
    using System.Globalization;
    using Microsoft.Build.Framework;

    public class GetEnvironmentVariable : TaskBase
    {
        private string[] value;
        private string variable;
        private EnvironmentVariableTarget target = EnvironmentVariableTarget.Process;

        /// <summary>
        /// Initializes a new instance of the GetEnvironmentVariable class.
        /// </summary>
        public GetEnvironmentVariable()
        {
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            this.value = Environment.GetEnvironmentVariable(this.variable, this.target).Split(';');
        }

        /// <summary>
        /// 
        /// </summary>
        [Output]
        public string[] Value
        {
            get { return this.value; }
        }

        /// <summary>
        /// 
        /// </summary>
        [Required]
        public string Variable
        {
            set { this.variable = value; }
            get { return this.variable; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string Target
        {
            set { this.target = (EnvironmentVariableTarget)Enum.Parse(typeof(EnvironmentVariableTarget), value); }
            get { return this.target.ToString("G"); }
        }        
    }
}
