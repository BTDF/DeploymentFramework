/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.Web {
	using System;

	/// <summary>
	/// Summary description for AccessFlags.
	/// </summary>
	[Flags]
	public enum AccessFlags {
        AccessNoAccess = 0,
		AccessRead = 1,
		AccessWrite = 2,
		AccessExecute = 4,
		AccessSource = 16,
		AccessScript = 512,
		AccessNoRemoteWrite = 1024,
		AccessNoRemoteRead = 4096,
		AccessNoRemoteExecute = 8192, 
		AccessNoRemoteScript = 16384,  
	}
}
