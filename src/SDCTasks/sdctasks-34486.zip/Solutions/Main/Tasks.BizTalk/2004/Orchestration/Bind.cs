﻿//-------------------------------------------------------------------------------------
// <copyright file="Bind.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//     Binds the Orchestration SendPorts, ReceivePorts and Host to actual Send Ports Receive Ports and Host
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Orchestration
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;

    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Build.Framework;

    #endregion

    /// <summary>
    /// Bind
    /// </summary>
    public class Bind : BizTalk2004TaskBase
    {
        #region member variables 

        private string name;
        private string assemblyName;
        private ITaskItem[] orchPorts;
        private string hostName;

        #endregion

        /// <summary>
        /// Bind
        /// </summary>
        public Bind()
        {
        }

        #region properties 

        /// <summary>
        /// The name of the orchestration to configure.
        /// </summary>
        /// <value></value>
        [Required]
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        /// <summary>
        /// The name of the assembly that contains the orchestration.
        /// </summary>
        /// <value></value>
        public string AssemblyName
        {
            get { return this.assemblyName; }
            set { this.assemblyName = value; }
        }

        /// <summary>
        /// The list of ports that need to be bound.
        /// </summary>
        /// <value></value>
        public ITaskItem[] OrchestrationPorts
        {
            get { return this.orchPorts; }
            set { this.orchPorts  = value; }
        }

        /// <summary>
        /// The host name that must be bound to the orchesration
        /// </summary>
        /// <value></value>
        public string HostName
        {
            get { return this.hostName; }
            set { this.hostName = value; }
        }

        #endregion

        #region methods 
              
        /// <summary>
        /// InternalExecute
        /// </summary>
        protected override void InternalExecute()
        {
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation installation = this.GetInstallation();
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration orchestration = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration.Load(installation.DeployedAssemblies[this.assemblyName], this.name);

            if (orchestration != null)
            {
                // setting the host if specified
                orchestration.Host = (!string.IsNullOrEmpty(this.hostName)) ? installation.Hosts[this.hostName] : orchestration.Host;

                if (this.orchPorts != null)
                {
                    foreach (ITaskItem item in this.orchPorts)
                    {
                        string orchPortName = item.GetMetadata("orchestrationPortName");
                        string receivePortName = item.GetMetadata("receivePort");
                        string sendPortName = item.GetMetadata("sendPort");
                        string sendPortGroupName = item.GetMetadata("sendPortGroup");

                        Microsoft.Sdc.Tasks.BizTalk2004.Configuration.OrchestrationPort orchPort = orchestration.Ports[orchPortName];
                        if (orchPort == null) throw new InvalidOperationException(string.Format("Orchestration Port {0} does not exist in this Orchestration", orchPortName));

                        orchPort.SendPort = (!string.IsNullOrEmpty(sendPortName)) ? installation.SendPorts[sendPortName] : orchPort.SendPort;
                        orchPort.ReceivePort = (!string.IsNullOrEmpty(receivePortName)) ? installation.ReceivePorts[receivePortName] : orchPort.ReceivePort;
                        orchPort.SendPortGroup = (!string.IsNullOrEmpty(sendPortGroupName)) ? installation.SendPortGroups[sendPortGroupName] : orchPort.SendPortGroup;
                    }
                }
                orchestration.Save();
            }
            else
            {
                throw new InvalidOperationException(string.Format("Orchestration {0} does not exist.", this.name));
            }
        }
        #endregion 
    }
}
