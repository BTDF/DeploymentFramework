//-----------------------------------------------------------------------
// <copyright file="ExtractFile.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Burns</author>
// <email></email>
// <date>2004-03-23</date>
// <summary>Extracts the file from the CabFile specified.</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Cab
{
    using System;
    using System.Xml;
    using System.Globalization;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Extracts the file from the CabFile specified.
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<Cab.ExtractFile PathToCabFile="pathToCabFile" PathToFiles="pathToFile" FileToExtract="fileToExtract" Path="path" Overwrite="overwrite"/>]]></code>
    /// <para>where:</para>
    /// <para><i>pathToCabFile (Required)</i></para>
    /// <para>The path to the cab file from which the files are to be extracted.</para>
    /// <para><i>pathToFiles (Required)</i></para>
    /// <para>The path to the folder that the files are to be extracted to. If this directory does not exist, it will be created.</para>
    /// <para><i>fileToExtract</i></para>
    /// <para>The specific file to extract from the specified cab file</para>
    /// <para><i>path</i></para>
    /// <para>The path to CabArc.exe. This will default to "C:\Program Files\CabArc\CabArc.exe" if not otherwise specified.</para>
    /// <para><i>overwrite</i></para>
    /// <para>Set to true to overwrite files of the same name without asking.</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <Cab.ExtractFile
    ///             PathToCabFile="C:\Archives\CabFile.cab"
    ///             PathToFiles="C:\Temp"
    ///             Path="C:\CabInstall\Cabarc.exe"  />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class ExtractFile : TaskBase
    {
        private string path = String.Empty;
        private string pathToCabFile = String.Empty;
        private string fileToExtract = String.Empty;
        private string pathToFiles = String.Empty;
        private bool overwrite = false;

        /// <summary>
        /// Initializes a new instance of the ExtractFile class.
        /// </summary>
        public ExtractFile()
        {
        }
      
        /// <summary>
        /// Set to true to overwrite files of the same name without asking.
        /// </summary>
        /// <value>True to overwrite without asking.</value>
        public bool Overwrite
        {
            get
            {
                return (this.overwrite);
            }

            set
            {
                this.overwrite = value;
            }
        }

        /// <summary>
        /// The path to CabArc.exe.
        /// </summary>
        /// <value>The path to CabArc.exe. This will default to "C:\Program Files\CabArc\CabArc.exe" if not otherwise specified.</value>
        public string Path
        {
            get
            {
                return (this.path == null ? String.Empty : this.path);
            }

            set
            {
                this.path = value;
            }
        }

        /// <summary>
        /// The path to the cab file from which the files are to be extracted.
        /// </summary>
        /// <value>The path to the cab file from which the files are to be extracted.</value>
        [Required]
        public string PathToCabFile
        {
            get
            {
                return (this.pathToCabFile == null ? String.Empty : this.pathToCabFile);
            }

            set
            {
                this.pathToCabFile = value;
            }
        }

        /// <summary>
        /// The path to the folder that the files are to be extracted to.
        /// </summary>
        /// <value>The path to the folder that the files are to be extracted to. If this directory does not exist, it will be created.</value>
        [Required]
        public string PathToFiles
        {
            get
            {
                return (this.pathToFiles == null ? String.Empty : this.pathToFiles);
            }

            set
            {
                this.pathToFiles = value;
            }
        }

        /// <summary>
        /// The specific file to extract from the specified cab file.
        /// </summary>
        /// <value>The specific file to extract from the specified cab file.</value>
        public string FileToExtract
        {
            get
            {
                return (this.fileToExtract == null ? String.Empty : this.fileToExtract);
            }

            set
            {
                this.fileToExtract = value;
            }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            #region Execute code

            if (this.fileToExtract.Length == 0)
            {
                Log.LogMessageFromResources("Cab.Extract", this.pathToCabFile, this.pathToFiles);
            }
            else
            {
                Log.LogMessageFromResources("Cab.ExtractFile", this.fileToExtract, this.pathToCabFile, this.pathToFiles);
            }
            Microsoft.Sdc.Tasks.Configuration.Cab.ExtractWithAppPath(this.pathToCabFile, this.pathToFiles, this.fileToExtract, this.path, this.overwrite);
            #endregion
        }
    }
}
