/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date><Date/>
  <Description>Implementation of the Service Task <Description/>
  <Copyright><![CDATA[
    Copyright � 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.Configuration.ComponentServices;

    /// <summary>
    /// Unit test for the ShutdownComponentServicesApplicationTest Task
    /// </summary>
    [TestClass]
    public class ShutdownComponentServicesApplicationTest
    {
        public ShutdownComponentServicesApplicationTest()
        {           
        }      

        [TestMethod]
        public void TestShutdownComponentServicesApplication()
        {
            string applicationName = "IIS Out-Of-Process Pooled Applications";

            //Ensure the App is started
            Application app = Application.Load(applicationName);
            app.Start();

            Tasks.ComponentServices.Application.Shutdown task = new Tasks.ComponentServices.Application.Shutdown();
           

            task.ApplicationName = applicationName;

            bool taskReturnValue = task.Execute();
            Assert.IsTrue(taskReturnValue, "ShutdownComponentServicesApplicationTest");

            //Check the COM+ Application is now shutdown
            //TODO          
        }
    }
}


