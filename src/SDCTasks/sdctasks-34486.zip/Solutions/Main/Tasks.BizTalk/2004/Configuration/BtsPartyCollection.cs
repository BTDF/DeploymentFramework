﻿//-------------------------------------------------------------------------------------
// <copyright file="BtsPartyCollection.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      BtsPartyCollection
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;

    #endregion

    internal class BtsPartyCollection : System.Collections.ReadOnlyCollectionBase
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public BtsPartyCollection()
        {
        }

        /// <summary>
        /// Indexer
        /// </summary>
        /// <param name="name">name</param>
        /// <returns></returns>
        public BtsParty this[string name]
        {
            get
            {
                BtsParty item = null;
                foreach (BtsParty currentitem in this.InnerList)
                {
                    if (currentitem.Name == name)
                    {
                        item = currentitem;
                        break;
                    }
                }
                return item;
            }
        }

        /// <summary>
        /// Indexer
        /// </summary>
        /// <param name="index">index</param>
        /// <returns></returns>
        public BtsParty this[int index]
        {
            get
            {
                return (BtsParty)this.InnerList[index];
            }
        }

        internal void Add(BtsParty item)
        {
            this.InnerList.Add(item);
        }
    }
}