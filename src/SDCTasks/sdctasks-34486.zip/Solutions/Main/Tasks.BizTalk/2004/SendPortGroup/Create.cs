
namespace Microsoft.Sdc.Tasks.BizTalk2004.SendPortGroup
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;

    #endregion

    public class Create : BizTalk2004TaskBase  
    {

        private string name;
        private string filterXml;
        private string[] sendPorts;


        [Required]
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        [Required]
        public string[] SendPorts
        {
            get { return this.sendPorts; }
            set { this.sendPorts = value; }

        }

        public string Filter
        {
            get { return this.filterXml; }
            set { this.filterXml = value; }
        }

        public Create()
        {
        }

        protected override void InternalExecute()
        {
            BizTalkInstallation installation = this.GetInstallation();
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SendPortGroup sendportGroup = new Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SendPortGroup(installation, this.name);

            //send ports
            foreach (string port in this.sendPorts)
                sendportGroup.SendPorts.Add(installation.SendPorts[port]);

            //filters
            if (!string.IsNullOrEmpty(this.filterXml))
                sendportGroup.FilterGroups.PopulateFromFilterXml(this.filterXml);

            sendportGroup.Save();
        }
    }
}

