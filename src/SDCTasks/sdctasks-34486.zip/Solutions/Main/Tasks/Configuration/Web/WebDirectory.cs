/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Patrick Long</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/


namespace Microsoft.Sdc.Tasks.Configuration.Web 
{
    using System.Globalization;
    using System;
    using System.DirectoryServices;
    using System.Security.Principal;
    using System.Collections;
    using System.Runtime.InteropServices;
    using Microsoft.Sdc.Tasks.Configuration.Framework;

    internal class WebDirectory 
    {

        AuthFlags          authFlags;
        string             name;
        DirectoryEntry     parent;
        DirectoryEntry     de;
        AccessFlags        accessFlags;
        string             anonymousUserName;
        string             anonymousUserPassword;
        int                aspScriptTimeout=90;
        WebDirectoryCollection     webDirectories;

        HttpErrorCollection httpErrors;

        public WebDirectory(string name) 
        {
            this.name = name;
        }

        public WebDirectory(DirectoryEntry de) 
        {
            this.name = de.Name;
            this.parent = de.Parent;
                     
            Initialize(de);
            
        }
        
        void Initialize(DirectoryEntry wdir) 
        {
            de = wdir;
            authFlags = (AuthFlags)wdir.Properties["AuthFlags"][0];
            accessFlags = (AccessFlags)wdir.Properties["AccessFlags"][0];
            anonymousUserName = (string)wdir.Properties["AnonymousUserName"][0];
            anonymousUserPassword = (string)wdir.Properties["AnonymousUserPass"][0];
                       
            aspScriptTimeout = (int)wdir.Properties["AspScriptTimeout"][0];
                     
            if (webDirectories == null) 
            {
               
                foreach(DirectoryEntry dir in de.Children) 
                {
                    if (dir.SchemaClassName == "IIsWebDirectory") 
                    {
                        WebDirectories.Add(new WebDirectory(dir));
                    }
                }
            }
            
            try
            {
                PropertyValueCollection httpErrorsCollection = wdir.Properties["HttpErrors"];

                httpErrors = new HttpErrorCollection(wdir);
                
            }
            catch(COMException)
            {
                //it will come here if this webdirectory has no configured HttpErrors
            }
        }

        public void Save() 
        {
            //TODO need to check that all the properties we need have been provided
            // path
            // 
            // if we don't have a directory entry
            // and if the identifier is zero
            // then try and create a new site
            // otherwise if no dir entry but identifier is set check to see if the site exists
            // if it does throw an exception (as you should have called load)
            //otherwise try to create it with the identifier provided
                                           
            ComWrapper app = new ComWrapper(de.NativeObject);
            app.CallMethod("Put", new Object[] {"AuthFlags", authFlags});
            
            app.CallMethod("Put", new Object[] {"AccessFlags", accessFlags});
            
            app.CallMethod("Put", new Object[] {"AspScriptTimeout", aspScriptTimeout});
            
            if (anonymousUserName != null) 
            {
                app.CallMethod("Put", new Object[] {"AnonymousUserName", anonymousUserName});
                app.CallMethod("Put", new Object[] {"AnonymousUserPass", anonymousUserPassword});
            }

            if(httpErrors != null)
            {
                httpErrors.Save(de);
            }
            
            de.CommitChanges();
        }
            
        //de.Dispose();    

        public AuthFlags AuthFlags 
        {
            get 
            {
                return authFlags ;
            }
            set 
            {
                authFlags = value;
            }
        }

        public DirectoryEntry Parent 
        {
            get 
            {
                return parent ;
            }
            set 
            { 
                parent = value;
            }
        }   

        public DirectoryEntry DirectoryEntry 
        {
            get 
            {
                return de;
            }
        }

        public string Name 
        {
            get 
            {
                return (name == null ? String.Empty : name);
            }
            set 
            {
                name = value;
            }
        }

        public static bool Exists(string name, int webSiteIdentifier, string machineName) 
        {
            
            try 
            {
                if (DirectoryEntry.Exists("IIS://" + machineName + "/W3SVC/" + Convert.ToString(webSiteIdentifier,CultureInfo.InvariantCulture) + "/root/" + name)) 
                {
                    return true;
                }
            }
            catch 
            {
                return false;
            }
            return false;
        }

        public static void Delete(string name, int webSiteIdentifier, string machineName) 
        {
            if (name.ToLower(CultureInfo.InvariantCulture) == "root") 
            {
                throw new ApplicationException("You cannot delete the root virtual directory. Delete the Website instead.");
            }
            DirectoryEntry web = new DirectoryEntry("IIS://" + machineName + "/W3SVC/" + Convert.ToString(webSiteIdentifier,CultureInfo.InvariantCulture) + "/root");
            object[] args = {"IIsWebDirectory", name};
            web.Invoke("Delete", args);
            web.Dispose();                      
        }

        public void Delete() 
        {
            if (this.name.ToLower(CultureInfo.InvariantCulture) == "root") 
            {
                throw new ApplicationException("You cannot delete the root virtual directory. Delete the Website instead.");
            }
            
            object[] args = {"IIsWebDirectory", name};
            parent.Invoke("Delete", args);
        }

        public AccessFlags AccessFlags 
        {
            get 
            {
                return accessFlags ;
            }
            set 
            {
                accessFlags = value;
            }
        }   

        public string AnonymousUserName 
        {
            get 
            {
                return (anonymousUserName == null ? String.Empty : anonymousUserName);
            }
            set 
            {
                anonymousUserName = value;
            }
        }

        public string AnonymousUserPassword 
        {
            get 
            {
                return (anonymousUserPassword == null ? String.Empty : anonymousUserPassword);
            }
            set 
            {
                anonymousUserPassword = value;
            }
        }       

        public int AspScriptTimeout 
        {
            get 
            {
                return aspScriptTimeout ;
            }
            set 
            {
                aspScriptTimeout = value;
            }
        }

        public HttpErrorCollection HttpErrors
        {
            get
            {
                return httpErrors;
            }
        }

        public WebDirectoryCollection WebDirectories 
        {
            get 
            {
                if (webDirectories == null) 
                {
                    webDirectories = new WebDirectoryCollection(this.DirectoryEntry);

                }
                return webDirectories;
            }
            /*
            made readonly for FxCop
            set {
                webDirectories = value;
            }
            */
        }
    }
}

