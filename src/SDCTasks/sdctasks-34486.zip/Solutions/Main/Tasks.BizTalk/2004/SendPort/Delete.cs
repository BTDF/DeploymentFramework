//-------------------------------------------------------------------------------------
// <copyright file="Delete.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Deletes a send port.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.SendPort
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Text;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion

    public class Delete : BizTalk2004TaskBase
    {
        #region Member Variables

        private string name;

        #endregion

        #region Constructors

        /// <summary>
        /// Creates a new task to Delete a send port.
        /// </summary>
        public Delete()
        {
        }

        #endregion

        #region Properties - General

        /// <summary>
        /// Gets or sets the name of the send port to delete.
        /// </summary>
        /// <value>
        /// The name of the send port to delete.
        /// </value>
        [Required]
        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }


        #endregion


        #region Methods

        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {

            BizTalkInstallation installation = this.GetInstallation();

            //deleting the sendport
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SendPort.Delete(installation, this.name); 
        }

        #endregion
    }
}

