//-----------------------------------------------------------------------
// <copyright file="DeleteApplication.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-03-23</date>
// <summary>Deletes the specified Component Services Application.</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.ComponentServices.Application
{
    using System;
    using Microsoft.Sdc.Tasks.Configuration.ComponentServices;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Deletes the specified ComponentServices Application and all its components.
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<ComponentServices.Application.DeleteApplication ApplicationName="applicationName" />]]></code>
    /// <para>where:</para>
    /// <para><i>applicationName (Required)</i></para>
    /// <para>The name of the COM+ application to be deleted. If the application name exists multiple times then all matches will all be deleted.</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <ComponentServices.Application.DeleteApplication
    ///             ApplicationName="MyApplicationName" />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class DeleteApplication : TaskBase
    {
        private string applicationName;

        /// <summary>
        /// Gets or sets the name of the COM+ application to be deleted
        /// </summary>
        /// <value>The name of the application to be deleted. If the application name exists multiple times then all matches will all be deleted.</value>
        [Required]
        public string ApplicationName
        {
            get { return this.applicationName; }
            set { this.applicationName = value; }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            Log.LogMessageFromResources("ComponentServices.DeleteApplication", this.ApplicationName);
            if (Application.Exists(this.ApplicationName))
            {
                Application.Delete(this.ApplicationName);
            }
        }
    }
}