/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Simon Ransom</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.SummaryGeneration.Generators
{
	using System;
	using System.IO;
	using System.Xml;

	/// <summary>
	/// Summary description for CodeCoverageSectionGenerator.
	/// </summary>
	internal class CodeCoverageSectionGenerator: ISectionGenerator
	{
		/// <summary>
		/// Create a CoverageEye section within the report
		/// </summary>
		/// <param name="sourceFolder"></param>
		/// <param name="fileSpec"></param>
		/// <param name="name">Optional name for the section</param>
		/// <returns></returns>
		public Section GenerateSection(string sourceFolder, string fileSpec, string name)
		{
			XmlDocument section = new XmlDocument();
			section.AppendChild(section.CreateElement("Section"));
			section.DocumentElement.SetAttribute("Type","CoverageEye");
			if (name != null)
			{
				section.DocumentElement.SetAttribute("Name",name);
			}
			string [] reportFiles = Directory.GetFiles(sourceFolder,fileSpec);

			foreach (string reportFile in reportFiles)
			{
				XmlReader reader = new XmlTextReader(reportFile);			
				bool reportHeaderFound = false;
				while (reader.Read() && (! reportHeaderFound))
				{
					switch (reader.NodeType)
					{
						case XmlNodeType.Element:
							if (reader.Name=="Assembly")
							{
								string assemblyName =  reader.GetAttribute("AssemblyName");
								string percentageCovered = reader.GetAttribute("PercentageCovered");
								string instructionCount = reader.GetAttribute("InstructionCount");
								string coveredCount =  reader.GetAttribute("CoveredCount");

								// Put the information into an XmlDocument
								XmlElement assemblyElement = section.CreateElement("Assembly");
								assemblyElement.SetAttribute("AssemblyName",assemblyName);
								assemblyElement.SetAttribute("PercentageCovered",percentageCovered);
								assemblyElement.SetAttribute("InstructionCount",instructionCount);
								assemblyElement.SetAttribute("CoveredCount",coveredCount);
				
								section.DocumentElement.AppendChild(assemblyElement);
								reportHeaderFound = true;						
							}
							break;
					}
					
				}
				reader.Close();
			}
			return new Section(section);
		}

		public CodeCoverageSectionGenerator()
		{
		}
	}
}
