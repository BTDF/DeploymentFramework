//-------------------------------------------------------------------------------------
// <copyright file="Deploy.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Deploys an assembly into BizTalk.
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.Assembly
{
    #region Using directives
    using System.Globalization;
    using System;
    using System.Collections.Generic;
    using BizTalk.ApplicationDeployment;
    #endregion

    /// <summary>
    /// Deploys an assembly into BizTalk.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2004.Assembly.Deploy AssemblyPath="assemblyPath" InstallInGac="installInGac" BindingPath="bindingPath" LogPath="logPath" Server="server" Database="database" />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>assemblyPath (Required)</i></para>
    /// <para>
    /// The path to the assembly to deploy.
    /// </para>
    /// <para><i>installInGac</i></para>
    /// <para>
    /// <b>true</b> to install the assembly in the GAC, or <b>false</b> otherwise. The default is <b>false</b>.
    /// </para>
    /// <para><i>bindingPath</i></para>
    /// <para>
    /// The path to the XML bindings file for the assembly. The default is no binding file.
    /// </para>
    /// <para><i>logPath</i></para>
    /// <para>
    /// The path to the log file for the installation. The default is no log file.
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// <para><i>username</i></para>
    /// <para>
    /// The username to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// <para><i>password</i></para>
    /// <para>
    /// The password to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <BizTalk2004.Assembly.Deploy 
    ///             AssemblyPath="C:\Build\Output\MyAssembly.dll" 
    ///             InstallInGac="true"
    ///             BindingPath="C:\Build\Config\MyAssemblyBindings.xml" 
    ///             LogPath="C:\Build\Logs\MyAssemblyInstall.log" 
    ///             Server="." 
    ///             Database="BizTalkMgmtDb" 
    ///              
    ///              />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Deploy : BizTalk2004.Assembly.Deploy
    {
        #region Member Variables

        private string application;
        private bool overwrite;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the application.
        /// </summary>
        /// <value>The application.</value>
        public string Application
        {
            get { return this.application; }
            set { this.application = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="Deploy"/> overwrites an existing assembly.
        /// </summary>
        /// <value><c>true</c> if overwrite; otherwise, <c>false</c>.</value>
        public bool Overwrite
        {
            get { return this.overwrite; }
            set { this.overwrite = value; }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {
            if (string.IsNullOrEmpty(this.Application))
            {
                base.InternalExecute();
            }
            else
            {
                BizTalk2004.Configuration.BizTalkInstallation installation = this.GetInstallation();

                string resourceType = "System.BizTalk:BizTalkAssembly";
                resourceType = SdmParser.GetInstance().TransformResourceType(resourceType);

                using (Group group = new Group())
                {
                    group.DBServer = installation.Server;
                    group.DBName = installation.Database;

                    try
                    {
                        Application app = group.Applications[this.Application];
                        if (app != null)
                        {
                            app.UILevel = 2;
                            Dictionary<string, object> options = new Dictionary<string,object>();
                            options.Add("GacOnAdd", this.InstallInGac);
                            Log.LogMessage(string.Format(CultureInfo.InvariantCulture, "Adding Assembly: {0} to Application: {1}", this.AssemblyPath, this.Application));
                            app.ResourceCollection.Add(resourceType, this.AssemblyPath, null, options, this.Overwrite);
                        }
                        else
                        {
                            Log.LogError(string.Format(CultureInfo.InvariantCulture, "Application not found: {0}", this.Application));
                            return;
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.LogError(string.Format(CultureInfo.InvariantCulture, "Deploy Assembly failure: {0}", ex));
                        group.Abort();
                        throw;
                    }
                }
            }
        }

        #endregion
    }
}

