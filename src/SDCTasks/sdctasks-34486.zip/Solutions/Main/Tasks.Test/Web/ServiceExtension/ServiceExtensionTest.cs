//-----------------------------------------------------------------------
// <copyright file="ServiceExtensionTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-06-08</date>
// <summary>Tests service extension tasks</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the service extension task
    /// </summary>
    [TestClass]
    public class ServiceExtensionTest
    {
        

        public ServiceExtensionTest()
        {
        }

       

        [TestMethod]
        [Ignore]
        public void TestServiceExtensionAddDeleteFile()
        {
            //Create and set the properties for the add file task    
            Tasks.Web.ServiceExtension.AddFile addFileTask = new Tasks.Web.ServiceExtension.AddFile();
            
            bool addFileTaskReturnValue = addFileTask.Execute();

            //Test the task returned successfully
            Assert.IsTrue(addFileTaskReturnValue);

            bool deleteable = true;
            string description = "(description)";
            string groupID = "(groupid)";
            string filePath = "(filepath)";
            string permission = "(permission)";

            addFileTask.Deleteable = deleteable;
            addFileTask.Description = description;
            addFileTask.GroupID = groupID;
            addFileTask.Path = filePath;
            addFileTask.Permission = permission;

            //Test the properties of the task
            Assert.IsTrue( addFileTask.Deleteable == deleteable);
            Assert.IsTrue( addFileTask.Description == description);
            Assert.IsTrue( addFileTask.GroupID == groupID);
            Assert.IsTrue( addFileTask.Path == filePath);
            Assert.IsTrue( addFileTask.Permission == permission);

            //Similarly remove the file
            Tasks.Web.ServiceExtension.DeleteFile deleteFileTask = new Tasks.Web.ServiceExtension.DeleteFile();
            deleteFileTask.Path = filePath;

            bool deleteFileTaskReturnValue = deleteFileTask.Execute();

            //Test the task returned successfully
            Assert.IsTrue( deleteFileTaskReturnValue);

        }
    }
}


