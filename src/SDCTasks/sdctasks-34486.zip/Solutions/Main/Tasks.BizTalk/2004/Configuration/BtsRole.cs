﻿namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;
    using System.Reflection;

    #endregion

    internal class BtsRole : BtsBaseObject
    {
        /// <summary>
        /// Internal Constructor
        /// </summary>
        /// <param name="actualBtsObject">The actual BtsRole object that object will call.</param>
        /// <param name="catalogExplorer">The BtsCatalogExplorer object.</param>
        internal BtsRole(object actualBtsObject, BtsCatalogExplorer catalogExplorer)
        {
            this.btsCatalogExplorer = catalogExplorer;
            this.actualBtsObject = actualBtsObject;
        }

        /// <summary>
        /// Gets the reference to the containing assembly.
        /// </summary>
        public BtsAssembly BtsAssembly
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("BtsAssembly", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                BtsAssembly assembly = new BtsAssembly(value, this.btsCatalogExplorer);
                return assembly;
            }
        }

        /// <summary>
        /// Returns the collection of enlisted parties (IEnlistedParty) for the role.
        /// </summary>
        /// <value></value>
        public System.Collections.ICollection EnlistedParties
        {
            get
            {
                return (System.Collections.ICollection)this.actualBtsObject.GetType().InvokeMember("EnlistedParties", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>
        /// Gets the name of the role.
        /// </summary>
        public string Name
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("Name", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        //TODO:portTypes

        /// <summary>
        /// Gets the name of the role link type that to which this role belongs.
        /// </summary>
        /// <value></value>
        public string ServiceLinkType
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("ServiceLinkType", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }
    }
}
