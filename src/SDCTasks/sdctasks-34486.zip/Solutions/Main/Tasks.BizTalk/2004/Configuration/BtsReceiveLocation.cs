﻿namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;
    using System.Reflection;

    #endregion

    internal class BtsReceiveLocation : BtsBaseObject
    {
        /// <summary>
        /// Internal Constructor
        /// </summary>
        /// <param name="actualBtsObject">The actual Microsoft.Biztalk.ExplorerOM.BtsReceiveLocation object that object will call.</param>
        /// <param name="catalogExplorer">The Microsoft.Sdc.Tasks.Configuration.BtsCatalogExplorer object.</param>
        internal BtsReceiveLocation(object actualBtsObject, BtsCatalogExplorer catalogExplorer)
        {
            this.btsCatalogExplorer = catalogExplorer;
            this.actualBtsObject = actualBtsObject;
        }

        /// <summary>
        /// Gets or sets the address of the receive location.
        /// </summary>
        public string Address
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("Address", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("Address", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? value : string.Empty });
            }
        }

        /// <summary>
        /// Gets or sets the custom data with the receive location.
        /// </summary>
        public string CustomData
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("CustomData", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("CustomData", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? value : string.Empty });
            }
        }

        /// <summary>
        /// Gets and sets the field to enable the receive location. An enabled receive location cannot be deleted.
        /// </summary>
        public bool Enable
        {
            get
            {
                return (bool)this.actualBtsObject.GetType().InvokeMember("Enable", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("Enable", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });
            }
        }

        /// <summary>
        /// Gets or sets the end date of the service window.
        /// </summary>
        public DateTime EndDate
        {
            get
            {
                return (DateTime)this.actualBtsObject.GetType().InvokeMember("EndDate", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("EndDate", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });
            }
        }

        /// <summary>
        /// Gets or sets the field to enable the end date of the service window.
        /// </summary>
        public bool EndDateEnabled
        {
            get
            {
                return (bool)this.actualBtsObject.GetType().InvokeMember("EndDateEnabled", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("EndDateEnabled", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });
            }
        }

        //fragment messages

        /// <summary>
        /// Gets or sets the start time of the service window.
        /// </summary>
        public DateTime FromTime
        {
            get
            {
                return (DateTime)this.actualBtsObject.GetType().InvokeMember("FromTime", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("FromTime", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });
            }
        }

        //fragment messages

        /// <summary>
        /// Determines whether the receive location is primary.
        /// </summary>
        public bool IsPrimary
        {
            get
            {
                return (bool)this.actualBtsObject.GetType().InvokeMember("IsPrimary", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("IsPrimary", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });
            }
        }

        /// <summary>
        /// Gets or sets the name of the receive location.
        /// </summary>
        /// <value></value>
        public string Name
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("Name", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("Name", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? value : string.Empty });
            }
        }

        /// <summary>
        /// Gets or sets the public address of the receive location.
        /// </summary>
        /// <value></value>
        public string PublicAddress
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("PublicAddress", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("PublicAddress", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? value : string.Empty });
            }
        }

        /// <summary>
        /// Gets or sets the receive handler to use for this receive location.
        /// </summary>
        /// <value></value>
        public BtsReceiveHandler ReceiveHandler
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("ReceiveHandler", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (value != null) ? new BtsReceiveHandler(value, this.btsCatalogExplorer) : null;
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("ReceiveHandler", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? ((BtsReceiveHandler)value).actualBtsObject : null });
            }
        }

        /// <summary>
        /// Gets or sets the receive pipeline to use to receive messages at this receive location.
        /// </summary>
        /// <value></value>
        public BtsPipeline ReceivePipeline
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("ReceivePipeline", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (value != null) ? new BtsPipeline(value, this.btsCatalogExplorer) : null;
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("ReceivePipeline", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? ((BtsPipeline)value).actualBtsObject : null });
            }
        }

        /// <summary>
        /// Gets or sets the receive pipeline to use to receive messages at this receive location.
        /// </summary>
        /// <value></value>
        public string ReceivePipelineData
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("ReceivePipelineData", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("ReceivePipelineData", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? value : string.Empty });
            }
        }

        /// <summary>
        /// Gets the receive port that this receive location belongs to.
        /// </summary>
        /// <value></value>
        public BtsReceivePort ReceivePort
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("ReceivePort", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (value != null) ? new BtsReceivePort(value, this.btsCatalogExplorer) : null;
            }
        }

        /// <summary>
        /// Gets or sets the field to enable the service window.
        /// </summary>
        /// <value></value>
        public bool ServiceWindowEnabled
        {
            get
            {
                return (bool)this.actualBtsObject.GetType().InvokeMember("ServiceWindowEnabled", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("ServiceWindowEnabled", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });
            }
        }

        /// <summary>
        /// Gets or sets the start date of the service window.
        /// </summary>
        /// <value></value>
        public DateTime StartDate
        {
            get
            {
                return (DateTime)this.actualBtsObject.GetType().InvokeMember("StartDate", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("StartDate", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });
            }
        }

        /// <summary>
        /// Gets or sets the field to enable the start date of the service window.
        /// </summary>
        /// <value></value>
        public bool StartDateEnabled
        {
            get
            {
                return (bool)this.actualBtsObject.GetType().InvokeMember("StartDateEnabled", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("StartDateEnabled", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });
            }
        }

        /// <summary>
        /// Gets or sets the end time of the service window.
        /// </summary>
        /// <value></value>
        public DateTime ToTime
        {
            get
            {
                return (DateTime)this.actualBtsObject.GetType().InvokeMember("ToTime", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("ToTime", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });
            }
        }

        /// <summary>
        /// Gets and sets the transport type for this receive location. 
        /// </summary>
        /// <value></value>
        public BtsProtocolType TransportType
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("TransportType", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (value != null) ? new BtsProtocolType(value, this.btsCatalogExplorer) : null;
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("TransportType", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? ((BtsProtocolType)value).actualBtsObject : null });
            }
        }

        /// <summary>
        /// Gets or sets the transport type properties of the receive location.
        /// </summary>
        /// <value></value>
        public string TransportTypeData
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("TransportTypeData", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("TransportTypeData", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? value : string.Empty });
            }
        }
    }
}
