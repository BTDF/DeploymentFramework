﻿//-----------------------------------------------------------------------
// <copyright file="BtsPartyAlias.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <summary>BtsPartyAlias</summary>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;
    using System.Reflection;

    #endregion

    internal class BtsPartyAlias : BtsBaseObject
    {
        /// <summary>
        /// Internal Constructor
        /// </summary>
        /// <param name="actualBtsObject">The actual Microsoft.Biztalk.ExplorerOM.BtsPartyAlias object that object will call.</param>
        /// <param name="catalogExplorer">The Microsoft.Sdc.Tasks.Configuration.BtsCatalogExplorer object.</param>
        internal BtsPartyAlias(object actualBtsObject, BtsCatalogExplorer catalogExplorer)
        {
            this.btsCatalogExplorer = catalogExplorer;
            this.actualBtsObject = actualBtsObject;
        }

        /// <summary>
        /// Gets a boolean value that specifies whether the alias was automatically generated.
        /// </summary>
        public bool IsAutoCreated
        {
            get
            {
                return (bool)this.actualBtsObject.GetType().InvokeMember("IsAutoCreated", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>
        /// Gets or sets the name of the alias.
        /// </summary>
        public string Name
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("Name", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("Name", BindingFlags.SetProperty, null, this.actualBtsObject, new string[] { value });
            }
        }

        /// <summary>
        /// Gets or sets the qualifier for the alias.
        /// </summary>
        public string Qualifier
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("Qualifier", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("Qualifier", BindingFlags.SetProperty, null, this.actualBtsObject, new string[] { value });
            }
        }

        /// <summary>
        /// Gets or sets the value of the party alias.
        /// </summary>
        public string Value
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("Value", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("Value", BindingFlags.SetProperty, null, this.actualBtsObject, new string[] { value });
            }
        }

        /// <summary>
        /// Gets the reference to the party.
        /// </summary>
        public BtsParty Party
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("Party", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return new BtsParty(value, this.btsCatalogExplorer);
            }
        }
    }
}
