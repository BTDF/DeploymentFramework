/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Mark Phillips</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.Web 
{
    using System;
    using System.DirectoryServices;
    using System.Security.Principal;
    using System.Collections;
    using System.Net;
    using System.Runtime.InteropServices;
    using System.Globalization;

    /// <summary>
    /// Summary description for SmtpService.
    /// </summary>
    internal class SmtpService
    {
        const IPAddress DEFAULT_IPADDRESS = null;
        string                         hostName;
        int                            port = 25;
        int                            identifier;
        System.Net.IPAddress           ipAddress;
        string                         defaultDomain;
        string                         fqdn;
        string                         queueDir;
        string                         pickupDir;
        string                         dropDir;
        string                         badMailDir;
        string                         description;
        string                         smartHost;
        string                         masqueradeDomain;
        DirectoryEntry                 directoryEntry;
//        FtpVirtualDirectoryCollection  virtualDirectories;
        AuthFlags                      authFlags;

        public SmtpService(string description, string hostName, int port, IPAddress ipAddress, string queueDir, string pickupDir, string dropDir, string badMailDir, string defaultDomain, string fqdn, string masqueradeDomain, string smartHost, int identifier) 
        {
            this.identifier = identifier;
            this.hostName = hostName;
            this.port = port;
            this.description = description;
            this.queueDir = queueDir;
            this.pickupDir = pickupDir;
            this.dropDir = dropDir;
            this.badMailDir = badMailDir;
            this.ipAddress = ipAddress;
            this.defaultDomain = defaultDomain;
            this.fqdn = fqdn;
            this.masqueradeDomain = masqueradeDomain;
            this.smartHost = smartHost;
        }

        public SmtpService() 
        {
            
        }
        private SmtpService(DirectoryEntry smtpService) 
        {
            try 
            {
                Initialize(smtpService);                
            } 
            catch (Exception e) 
            {
                throw new ApplicationException("Could not load smtpService from given DirectoryEntry", e);
            }
        }

        public void Start() 
        {
            directoryEntry.Invoke("Start", null);
        }
        public void Stop() 
        {
            directoryEntry.Invoke("Stop", null);
        }
        public void Pause() 
        {
            directoryEntry.Invoke("Pause", null);
        }
        public void Continue() 
        {
            directoryEntry.Invoke("Continue", null);
        }

        void Initialize(DirectoryEntry de) 
        {
            directoryEntry = de;
            identifier = Convert.ToInt32(de.Name);
            description = Convert.ToString(de.Properties["ServerComment"][0]);
            
//            machineName = de.Path.Substring(6).Split('/')[0];

            authFlags = (AuthFlags)de.Properties["AuthFlags"][0];
            this.queueDir = Convert.ToString(de.Properties["QueueDirectory"][0]);
            this.pickupDir = Convert.ToString(de.Properties["PickupDirectory"][0]);
            this.dropDir = Convert.ToString(de.Properties["DropDirectory"][0]);
            this.badMailDir = Convert.ToString(de.Properties["BadMailDirectory"][0]);

            this.smartHost = Convert.ToString(de.Properties["SmartHost"][0]);
            this.defaultDomain = Convert.ToString(de.Properties["DefaultDomain"][0]);
            this.fqdn = Convert.ToString(de.Properties["FullyQualifiedDomainName"][0]);
            this.masqueradeDomain = Convert.ToString(de.Properties["MasqueradeDomain"][0]);

            string bindings  = Convert.ToString(de.Properties["ServerBindings"][0]);

            string[] bindingsSplit = bindings.Split(':');
            //IP:Port:Hostname
            if (bindingsSplit[0].Length != 0) 
            {
                ipAddress = System.Net.IPAddress.Parse(bindingsSplit[0]);
            }
            if (bindingsSplit[1].Length != 0) 
            {
                port = Convert.ToInt32(bindingsSplit[1]);
            }
            hostName = bindingsSplit[2];
/*
            if (root == null) 
            {
                DirectoryEntry rootDE = new DirectoryEntry(de.Path + "/ROOT"); 
                root = new FtpVirtualDirectory(rootDE, this);
            }
            if (virtualDirectories == null) 
            {
                // Load all the ftps
                DirectoryEntry rootDE = new DirectoryEntry(de.Path + "/ROOT"); 
                foreach(DirectoryEntry vdir in rootDE.Children) 
                {

                    if (vdir.SchemaClassName == "IIsFtpVirtualDir") 
                    {
                        VirtualDirectories.Add(new FtpVirtualDirectory(vdir, this));
                    }
                }
            }
*/
            
        }

        static public void Delete(string description, string machineName) 
        {
            int identifier = GetIdentifierFromDescription(machineName, description);
            Delete(identifier, machineName);
        }           
        
        static public void Delete(string description) 
        {
            Delete(description, "localhost");       
        }

        static public void Delete(int identifier, string machineName) 
        {
            DirectoryEntry smtpSvc = new DirectoryEntry("IIS://" + machineName + "/SmtpSvc"); 
            
            if (smtpSvc == null) 
            {
                throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to load smtpSvc {0} when trying to delete it", identifier));
            } 
            else 
            {
                object[] args = {"IIsSmtpServer", identifier};
                smtpSvc.Invoke("Delete", args);
                smtpSvc.Dispose();
            }           
        }

        static public void Delete(int identifier) 
        {
            Delete(identifier, "localhost");        
        }       

        static public int GetIdentifierFromDescription(string description) 
        {
            return GetIdentifierFromDescription("localhost", description);
        }

        static public int GetIdentifierFromDescription(string machineName, string description) 
        {

            //load the SMTPSVC and check all the children for a property that matches

            DirectoryEntry de = null;
            de = new DirectoryEntry("IIS://" + machineName + "/SmtpSvc");
                    
            foreach(DirectoryEntry o in de.Children) 
            {
                if (o.SchemaClassName == "IIsSmtpServer") 
                {
                    if ((string)o.Properties["ServerComment"][0] == description) 
                    {
                        return Convert.ToInt32(o.Name);
                    }
                }
            }
            return 0;
        }

        static public SmtpService Load(string machineName, int identifier) 
        {
            DirectoryEntry smtpSvc = new DirectoryEntry("IIS://" + machineName + "/SmtpSvc/" + Convert.ToString(identifier)); 
                        
            if (smtpSvc != null) 
            {
                return new SmtpService(smtpSvc);
            } 
            else 
            {
                return null;
            }           
        }

        static public SmtpService Load(int identifier) 
        {
            return Load("localhost", identifier);
        }

        static public SmtpService Load(string machineName, string description) 
        {
            //load the SMTPSVC and check all the children for a property that matches

            int identifier = GetIdentifierFromDescription(machineName, description);

            if (identifier == 0) 
            {
                throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to load smtp service {0}", description));
            }

            DirectoryEntry o = new DirectoryEntry("IIS://" + machineName + "/SmtpSvc/" + Convert.ToString(identifier));
            return new SmtpService(o);
        }

        static public SmtpService Load(string description) 
        {
            return Load("localhost", description);
        }

        void CreateNewServer() 
        {
            DirectoryEntry de = null;
            DirectoryEntry de2 = null;

            if (Description.Length == 0) 
            {
                throw new ApplicationException("You must provide a description before saving a Smtp Server.");
            }
            try 
            {
                de = new DirectoryEntry("IIS://localhost/SmtpSvc");

                string binding = String.Empty;
                if (ipAddress != null) 
                {
                    binding = IPAddress.ToString();
                }
            
                binding += ":" + Port.ToString() + ":" + HostName;

                DirectoryEntry oServer = null;
                
                bool bDone = false;
                int nIndex;
                if (identifier == 0) 
                {
                    nIndex = 1;
                } 
                else 
                {
                    nIndex = identifier;
                }
                while (!bDone) 
                {
                    DirectoryEntry oSite = new DirectoryEntry("IIS://localhost/SmtpSvc/"+ nIndex);

                    try 
                    {
                        object oTemp = oSite.NativeObject;
                        nIndex++;
                        
                    }
                    catch (COMException) 
                    {
                        object[] args = new object[2];
                        args[0] = (object)"IIsSmtpServer";
                        args[1] = (object)nIndex;
                        try 
                        {     
                            oServer = (DirectoryEntry)de.Invoke("Create", args);
                            oServer.CommitChanges(); 
                            DirectoryEntry oSite2 = new DirectoryEntry("IIS://localhost/SmtpSvc/"+ nIndex);
                            try 
                            {
                                object oTemp = oSite.NativeObject;
                                bDone = true;
                                break;
                            }
                            catch 
                            {
                                nIndex++;
                            }
                        }
                        catch 
                        {
                            nIndex++; 
                        }
                    }                    
                    
                    if (nIndex >1000) 
                    {
                        throw new ApplicationException("Unable to create new Smtp Server");
                    }
    
                }

                DirectoryEntry oRootDir = (DirectoryEntry)oServer.Invoke("Create","IIsSmtpVirtualDir", "ROOT");
                
//                oRootDir.Properties["Path"][0] = Path;

                oRootDir.CommitChanges();

//                oRootDir.Properties["AccessFlags"][0] = accessFlags;
//                oRootDir.CommitChanges();    

                de2 = new DirectoryEntry("IIS://localhost/SmtpSvc/" + nIndex); 

                de2.Properties["ServerComment"][0] = Description;

                de2.Properties["AuthFlags"][0] = this.authFlags;
                de2.Properties["QueueDirectory"][0] = this.queueDir;
                de2.Properties["PickupDirectory"][0] = this.pickupDir;
                de2.Properties["DropDirectory"][0] = this.dropDir;
                de2.Properties["BadMailDirectory"][0] = this.badMailDir;

                de2.Properties["SmartHost"][0] = this.smartHost;
                de2.Properties["FullyQualifiedDomainName"][0] = this.fqdn;
                de2.Properties["DefaultDomain"][0] = this.defaultDomain;
                de2.Properties["MasqueradeDomain"][0] = this.masqueradeDomain;
                if (this.MasqueradeDomain != String.Empty)
                {
                    de2.Properties["DoMasquerade"][0] = "TRUE";
                }
                else
                {
                    de2.Properties["DoMasquerade"][0] = "FALSE";
                }

                ComWrapper obj = new ComWrapper(de2.NativeObject);
                obj.CallMethod("Put", new Object[] {"ServerBindings", binding});
                de2.CommitChanges();
                DirectoryEntry de3 = (DirectoryEntry)de2.Invoke("Create", "IIsSmtpDomain", "Domain");
                de3.CommitChanges();
                DirectoryEntry de4 = (DirectoryEntry)de2.Invoke("Create", "IIsSmtpSessions", "Sessions");
                de4.CommitChanges();
                DirectoryEntry de5 = (DirectoryEntry)de2.Invoke("Create", "IIsSmtpRoutingSource", "RoutingSources");
                de5.CommitChanges();
                
                Initialize(de2);

            }

            catch(COMException) 
            {
            }

            catch(Exception e) 
            {
                throw new ApplicationException("Unable to create new smtp server", e);
            }
        
            finally 
            {
                de.Dispose();
                
            }           
        }       

        static public bool Exists(string machineName, int identifier) 
        {
            try 
            {
                if (DirectoryEntry.Exists("IIS://" + machineName + "/SmtpSvc/" + identifier)) 
                {
                    return true;
                }
            }
            catch 
            {
                return false;
            }
            return false;
        }

        static public bool Exists(int identifier) 
        {
            return Exists("localhost", identifier);         
        }

        static public bool Exists(string description) 
        {
            return Exists("localhost", description);
        }

        static public bool Exists(string machineName, string description) 
        {
            int identifier = GetIdentifierFromDescription(machineName, description);
            return Exists(machineName, identifier);
        }

        public bool Save() 
        {            
            // if we don't have a directory entry
            // and if the identifier is zero
            // then try and create a new site
            // otherwise if no dir entry but identifier is set check to see if the site exists
            // if it does throw an exception (as you should have called load)
            // otherwise try to create it with the identifier provided
            if (directoryEntry == null) 
            {               
                if (identifier == 0) 
                {
                    //we don't have an identifier so try and create it
                    CreateNewServer();                        
                } 
                else 
                {
                    if (Exists("localhost", identifier)) 
                    {
                        throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "The Smtp Server '{0}' already exists. Use SmtpService.Load to load it first", identifier));
                    } 
                    else 
                    {
                        //couldn't load the site with that identifier so try and create it now
                        CreateNewServer();
                    }
                }               
            }

            directoryEntry.CommitChanges();             
                
//            // Now save the root smtp server
//            root.Parent = this;
//            root.Save();
/*
            foreach(FtpVirtualDirectory vdir in VirtualDirectories) 
            {
                vdir.Parent = this;
                vdir.Save();
            }
*/            
            return true;            
        }

        public string DefaultDomain 
        {
            get 
            {
                return (this.defaultDomain == null ? String.Empty : this.defaultDomain);
            }
            set 
            {
                this.defaultDomain = value;
                if (this.directoryEntry != null)
                {
                    this.directoryEntry.Properties["DefaultDomain"][0] = this.defaultDomain;
                }
            }
        }

        public string FullyQualifiedDomainName 
        {
            get 
            {
                return (this.fqdn == null ? String.Empty : this.fqdn);
            }
            set 
            {
                this.fqdn = value;
                if (this.directoryEntry != null)
                {
                    this.directoryEntry.Properties["FullyQualifiedDomainName"][0] = this.fqdn;
                }
            }
        }

        public string MasqueradeDomain 
        {
            get 
            {
                return ((this.masqueradeDomain == null || this.masqueradeDomain.Length == 0) ? String.Empty : this.masqueradeDomain);
            }
            set 
            {
                this.masqueradeDomain = value;
                if (this.directoryEntry != null)
                {
                    this.directoryEntry.Properties["MasqueradeDomain"][0] = this.masqueradeDomain;
                    if (this.masqueradeDomain == null || this.masqueradeDomain.Length == 0)
                    {
                        this.directoryEntry.Properties["DoMasquerade"][0] = "TRUE";
                    }
                    else
                    {
                        this.directoryEntry.Properties["DoMasquerade"][0] = "FALSE";
                    }

                }
            }
        }

        public string SmartHost 
        {
            get 
            {
                return (this.smartHost == null ? String.Empty : this.smartHost);
            }
            set 
            {
                this.smartHost = value;
                if (this.directoryEntry != null)
                {
                    this.directoryEntry.Properties["SmartHost"][0] = this.smartHost;
                }
            }
        }

        public string QueueDirectory
        {
            get 
            {
                return (this.queueDir == null ? String.Empty : this.queueDir);
            }
            set 
            {
                this.queueDir = value;
                if (this.directoryEntry != null)
                {
                    this.directoryEntry.Properties["QueueDirectory"][0] = this.queueDir;
                }
            }
        }

        public string PickupDirectory
        {
            get 
            {
                return (this.pickupDir == null ? String.Empty : this.pickupDir);
            }
            set 
            {
                this.pickupDir = value;
                if (this.directoryEntry != null)
                {
                    this.directoryEntry.Properties["PickupDirectory"][0] = this.pickupDir;
                }
            }
        }

        public string DropDirectory
        {
            get 
            {
                return (this.dropDir == null ? String.Empty : this.dropDir);
            }
            set 
            {
                this.dropDir = value;
                if (this.directoryEntry != null)
                {
                    this.directoryEntry.Properties["DropDirectory"][0] = this.dropDir;
                }
            }
        }

        public string BadMailDirectory
        {
            get 
            {
                return (this.badMailDir == null ? String.Empty : this.badMailDir);
            }
            set 
            {
                this.badMailDir = value;
                if (this.directoryEntry != null)
                {
                    this.directoryEntry.Properties["BadMailDirectory"][0] = this.badMailDir;
                }
            }
        }

        public string Description 
        {
            get 
            {
                return (description == null ? String.Empty : description);
            }
            set 
            {
                description = value;
                if (this.directoryEntry != null)
                {
                    this.directoryEntry.Properties["ServerComment"][0] = this.description;
                }
            }
        }

        public int Identifier 
        {
            get 
            {
                return identifier ;
            }
            set 
            {
                identifier = value;
            }
        }
/*
        public FtpVirtualDirectory Root 
        {
            get 
            {
                if (root == null) 
                {
                    root = new FtpVirtualDirectory("ROOT", this);
                }
                return root ;
            }           
        }

        public FtpVirtualDirectoryCollection VirtualDirectories 
        {
            get 
            {
                if (virtualDirectories == null) 
                {
                    virtualDirectories = new FtpVirtualDirectoryCollection(this);

                }
                return virtualDirectories ;
            }
        }
*/
        public AuthFlags RootAuthFlags 
        {
            get 
            {
                return authFlags ;
            }
            set 
            {
                authFlags = value;
                if (this.directoryEntry != null)
                {
                    this.directoryEntry.Properties["SmartHost"][0] = this.smartHost;
                }
            }
        }   

        public int Port 
        {
            get 
            {
                return port;
            }
            set 
            {
                port = value;
            }
        }

        public System.Net.IPAddress IPAddress 
        {
            get 
            {
                return ipAddress;
            }
            set 
            {
                ipAddress = value;
            }
        }

        public string HostName 
        {
            get 
            {
                return (hostName == null ? String.Empty : hostName);
            }
            set 
            {
                hostName = value;
            }
        }

        internal DirectoryEntry GetDirectoryEntry() 
        {
            return directoryEntry ;
        }
    }
}
