﻿//-----------------------------------------------------------------------
// <copyright file="InsertBefore.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-07-01</date>
// <summary>Inserts a node into a hhc file</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Help
{
    #region Using directives
    using System;
    using System.Xml;
    using System.Globalization;
    using System.IO;
    using System.Text.RegularExpressions;
    using Microsoft.Win32;
    using Microsoft.Build.Framework;
    using Microsoft.Build.Tasks;
    #endregion
    /// <summary>
    /// Inserts a node inot a hhc project.
    /// </summary>          
    /// <remarks>
    /// <code><![CDATA[
    /// <Help.CreateProject SourceFolder="folder" />
    /// ]]></code>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class InsertBefore : Microsoft.Sdc.Tasks.Help.InsertBase
    {
        /// <summary>
        /// Initializes a new instance of the InsertBefore class.
        /// </summary>
        public InsertBefore()
        {
        }       

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            //insert a node like this
            /*
            <LI>
              <OBJECT type="text/sitemap">
                <param name="Name" value="API Reference">
                <param name="Local" value="(global).html">
              </OBJECT>
            <LI>
            */

            string contents = System.IO.File.ReadAllText(this.ContentsFilePath);
            contents = this.InsertStart(contents, false, false);
            System.IO.File.WriteAllText(this.ContentsFilePath, contents);
        }
    }
}

