
using System;

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	/// <summary>
	/// The ParentType enum for TransportData
	/// </summary>
	public enum TransportDataParentType : int
	{
		/// <summary>
		/// Transport Data will be generated for a Receive location
		/// </summary>
		ReceiveLocation = 0,
		
		/// <summary>
		/// Transport Data will be generated for a Send Port
		/// </summary>
		SendPort = 1
	}
}

