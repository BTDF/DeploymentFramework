using System;
using System.Reflection;

namespace Microsoft.Sdc.Tasks.Configuration.InstalledProducts
{
	/// <summary>
	/// Represents a single test which can be bundled up into Criteria
	/// </summary>
	/// <remarks>
	/// This is a convenience class to be used in conjunction with the 
	/// InstalledProductManager.AddForAnd or
	/// InstalledComponentManager.AddForAnd
	/// </remarks>
	internal class Criterion
	{
		private object _Value;
		public object Value
		{
			get
			{
				return _Value;
			}
			set
			{
				this._Value = value;
			}
		}

		private PropertyInfo _PropertyToExamine;
		public PropertyInfo PropertyToExamine
		{
			get
			{
				return _PropertyToExamine;
			}
			set
			{
				this._PropertyToExamine = value;
			}
		}

		private UnaryLogicalOperator _Operator;
		public UnaryLogicalOperator Operator
		{
			get
			{
				return _Operator;
			}
			set
			{
				this._Operator = value;
			}
		}

		private IBinaryComparisonChecker _ComparisonChecker;
		public IBinaryComparisonChecker ComparisonChecker
		{
			get
			{
				return _ComparisonChecker;
			}
			set
			{
				this._ComparisonChecker = value;
			}
		}

		public Criterion(PropertyInfo property, IBinaryComparisonChecker comparisonChecker, object compareValue) : 
			this(property,comparisonChecker,compareValue,UnaryLogicalOperator.None)
		{
		}

		public Criterion(PropertyInfo property, IBinaryComparisonChecker comparisonChecker, object compareValue, UnaryLogicalOperator op)
		{
			this.PropertyToExamine = property;
			this.ComparisonChecker= comparisonChecker;
			this.Operator = op;
			this.Value = compareValue;
		}

		public Criterion()
		{
		}
	}
}
