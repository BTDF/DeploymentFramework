//-------------------------------------------------------------------------------------
// <copyright file="ExportBindings.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Exports the bindings of an assembly in BizTalk to an XML file.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Assembly
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion

    #region Class Comments
    /// <summary>
    /// Exports the bindings of an assembly in BizTalk to an XML file.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2004.Assembly.ExportBindings BindingPath="bindingPath" AssemblyPath="assemblyPath" SimpleName="simpleName" Version="version" PublicKeyToken="publicKeyToken" Culture="culture" LogPath="logPath" Server="server" Database="database" />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>bindingPath (Required)</i></para>
    /// <para>
    /// The path to the XML file that the bindings will be exported into.
    /// </para>
    /// <para><i>assemblyPath</i></para>
    /// <para>
    /// The path to the assembly to have its bindings exported. This is used if supplied, but is not required if 
    /// <i>simpleName</i>, <i>version</i>, <i>publicKeyToken</i> and <i>culture</i> are all supplied.
    /// </para>
    /// <para><i>simpleName</i></para>
    /// <para>
    /// The simple name of the assembly to have its bindings exported. This is not used if <i>assemblyPath</i> is supplied.
    /// </para>
    /// <para><i>version</i></para>
    /// <para>
    /// The version of the assembly to have its bindings exported. This is not used if <i>assemblyPath</i> is supplied.
    /// </para>
    /// <para><i>publicKeyToken</i></para>
    /// <para>
    /// The public key token of the assembly to have its bindings exported. This is not used if <i>assemblyPath</i> is supplied.
    /// </para>
    /// <para><i>culture</i></para>
    /// <para>
    /// The culture of the assembly to have its bindings exported. This is not used if <i>assemblyPath</i> is supplied.
    /// </para>
    /// <para><i>logPath</i></para>
    /// <para>
    /// The path to the log file for the binding export. The default is no log file.
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// <para><i>username</i></para>
    /// <para>
    /// The username to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// <para><i>password</i></para>
    /// <para>
    /// The password to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <!-- Export bindings using the assembly file -->
    ///         <BizTalk2004.Assembly.ExportBindings 
    ///             AssemblyPath="C:\Build\Output\MyAssembly.dll" 
    ///             LogPath="C:\Build\Logs\MyAssemblyExportBindings.log" 
    ///             Server="." 
    ///             Database="BizTalkMgmtDb" 
    ///              
    ///              />
    ///         <!-- Export bindings using the assembly details -->
    ///         <BizTalk2004.Assembly.ExportBindings 
    ///             SimpleName="MyAssembly"
    ///             Version="2.0.0.0"
    ///             PublicKeyToken="128bd009fce13573"
    ///             Culture="neutral"
    ///             LogPath="C:\Build\Logs\MyAssemblyExportBindings.log" 
    ///             Server="." 
    ///             Database="BizTalkMgmtDb" 
    ///              
    ///              />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    #endregion
    public class ExportBindings : BizTalk2004TaskBase
    {
        #region Member Variables

        private string assemblyPath;
        private string bindingPath;
        private string culture;
        private string simpleName;
        private string logPath;
        private string publicKeyToken;
        private Version version;

        #endregion

        #region Constructors

        /// <summary>
        /// Creates a new instance of the export bindings task.
        /// </summary>
        public ExportBindings()
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the path to the assembly to undeploy.
        /// </summary>
        /// <value>
        /// The path to the assembly to undeploy.
        /// </value>
        public string AssemblyPath
        {
            get
            {
                return this.assemblyPath;
            }
            set
            {
                this.assemblyPath = value;
            }
        }

        /// <summary>
        /// Gets or sets the path to the assembly binding XML file.
        /// </summary>
        /// <value>
        /// The path to the assembly binding XML file.
        /// </value>
        [Required]
        public string BindingPath
        {
            get
            {
                return this.bindingPath;
            }
            set
            {
                this.bindingPath = value;
            }
        }


        /// <summary>
        /// Gets or sets the culture supported by the assembly.
        /// </summary>
        /// <value>
        /// The culture supported by the assembly.
        /// </value>
        public string Culture
        {
            get
            {
                return this.culture;
            }
            set
            {
                this.culture = value;
            }
        }

        /// <summary>
        /// Gets or sets the path to the log file for the uninstallation.
        /// </summary>
        /// <value>
        /// The path to the log file for the uninstallation.
        /// </value>
        public string LogPath
        {
            get
            {
                return this.logPath;
            }
            set
            {
                this.logPath = value;
            }
        }

        /// <summary>
        /// Gets or sets the public key token of the assembly.
        /// </summary>
        /// <value>
        /// The public key token of the assembly.
        /// </value>
        public string PublicKeyToken
        {
            get
            {
                return this.publicKeyToken;
            }
            set
            {
                this.publicKeyToken = value;
            }
        }

        /// <summary>
        /// Gets or sets the simple name of the assembly.
        /// </summary>
        /// <value>
        /// The simple name of the assembly.
        /// </value>
        public string SimpleName
        {
            get
            {
                return this.simpleName;
            }
            set
            {
                this.simpleName = value;
            }
        }

        /// <summary>
        /// Gets or sets the version of the assembly.
        /// </summary>
        /// <value>
        /// The version of the assembly.
        /// </value>
        public string Version
        {
            get
            {
                return (this.version == null) ? string.Empty : this.version.ToString();
            }
            set
            {
                this.version = (string.IsNullOrEmpty(value)) ? null : new Version(value);
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {
            BizTalkInstallation installation = this.GetInstallation();
            if (!string.IsNullOrEmpty(this.assemblyPath))
            {
                BizTalkAssembly.ExportBindings(installation, this.assemblyPath, this.bindingPath, this.logPath);
            }
            else
            {
                BizTalkAssembly.ExportBindings(installation, this.simpleName, this.version, this.culture, this.publicKeyToken, this.bindingPath, this.logPath);
            }
        }

        #endregion
    }
}

