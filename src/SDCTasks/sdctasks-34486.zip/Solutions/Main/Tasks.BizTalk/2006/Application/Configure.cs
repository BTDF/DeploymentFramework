//-----------------------------------------------------------------------
// <copyright file="Configure.cs" company="Quintush">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.Application
{
    using System.Globalization;
    using BizTalk.ExplorerOM;

    /// <summary>
    /// Configures a BizTalk application.
    /// </summary>
    /// <remarks>
    ///     <code>
    ///         <![CDATA[<BizTalk2006.Application.Configure Application="applicationName" AssemblyName = "assemblyname" Name="name" Server="server" Database="database" Username="username" Password="password" />]]>
    ///     </code>
    ///     <para>where:</para>
    ///     <para><i>Application</i></para>
    ///     <para>
    /// The name of the application
    /// </para>
    ///     <para><i>assemblyName (Optional)</i></para>
    ///     <para>
    /// The name of the assembly that contains the orchestration.
    /// </para>
    ///     <para><i>name (Optional)</i></para>
    ///     <para>
    /// The name of the orchestration to enlist.
    /// </para>
    ///     <para><i>server</i></para>
    ///     <para>
    /// The logical name of the server Orchestrationing the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    ///     <para><i>database</i></para>
    ///     <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified
    /// then the installation will default to the local installation.
    /// </para>
    ///     <para><i>username</i></para>
    ///     <para>
    /// The username to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    ///     <para><i>password</i></para>
    ///     <para>
    /// The password to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// </remarks>
    /// <example>
    ///     <code><![CDATA[
    /// <Project>
    /// <Target Name="Test" >
    /// <BizTalk2006.Application.Configure
    /// Application="EAIApplication"/>
    /// </Target>
    /// </Project>
    /// ]]></code>
    /// </example>
    public class Configure : BizTalk2006.Orchestration.Bind
    {
        /// <summary>
        /// InternalExecute
        /// </summary>
        protected override void InternalExecute()
        {
            using (BtsCatalogExplorer explorer = this.GetBtsCatalogExplorer(this.Server, this.Database))
            {
                Application app = explorer.Applications[this.Application];
                if (app != null)
                {
                    Host orchestrationHost = null;

                    // If HostName is set, use it. Else set the default host as Orchestration host.
                    if (!string.IsNullOrEmpty(this.HostName))
                    {
                        orchestrationHost = explorer.Hosts[this.HostName];
                        Log.LogMessage(string.Format(CultureInfo.InvariantCulture, "Hostname: {0} found.", this.HostName));
                    }
                    else
                    {
                        // Look for the default host
                        foreach (Host findHost in explorer.Hosts)
                        {
                            if (findHost.IsDefault)
                            {
                                orchestrationHost = findHost;
                                Log.LogMessage(string.Format(CultureInfo.InvariantCulture, "Default Host: {0} will be used.", findHost.Name));
                                break;
                            }
                        }
                    }

                    // Walk through all the orchestrations found in this application.
                    foreach (BtsOrchestration orchestration in app.Orchestrations)
                    {
                        if (orchestration.Host != null)
                        {
                            HostName = orchestration.Host.Name;
                        }
                        else
                        {
                            HostName = orchestrationHost.Name;
                        }
                        
                        // Reuse the Orchestration Bind code to bind the port info.
                        Name = orchestration.FullName;
                        base.InternalExecute();
                    }
                }
                else
                {
                    Log.LogError(string.Format(CultureInfo.InvariantCulture, "Application not found: {0}", this.Application));
                    return;
                }
            }
        }
    }
}
