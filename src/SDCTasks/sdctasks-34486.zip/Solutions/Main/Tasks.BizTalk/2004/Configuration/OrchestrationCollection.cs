//-------------------------------------------------------------------------------------
// <copyright file="OrchestrationCollection.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      A collection of BizTalk 2004 objects.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using directives

    using System;
    using System.Collections;

	#endregion

    /// <summary>
    /// A collection of <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/> objects.
    /// </summary>
    internal class OrchestrationCollection : CollectionBase
    {
		#region Constructors

        /// <summary>
        /// Creates a new collection of <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/> objects.
        /// </summary>
        public OrchestrationCollection()
        {
        }

		#endregion

		#region Indexers

        /// <summary>
        /// Gets or sets the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/> at a specified 
        /// position within the collection.
        /// </summary>
        /// <param name="index">
        /// The zero based index in the collection.
        /// </param>
        /// <value>
        /// A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/>.
        /// </value>
        public Orchestration this[int index]
        {
            get 
			{ 
				return (Orchestration)this.List[index]; 
			}
            set 
			{ 
				this.List[index] = value; 
			}
        }

		/// <summary>
		/// Gets or sets the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/> with
		/// a particular name.
		/// </summary>
		/// <param name="name">
		/// The name of the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/>.
		/// </param>
		/// <value>
		/// A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/>.
		/// </value>
		/// <exception cref="System.ArgumentNullException">
		/// Thrown when <paramref name="name"/> is <b>null</b> or zero length.
		/// </exception>
		/// <exception cref="System.ArgumentOutOfRangeException">
		/// Thrown when no object matching <paramref name="name"/> is found in the collection.
		/// </exception>
		public Orchestration this[string name]
		{
			get 
			{ 
				int index = this.IndexOf(name);
				if (index >= 0)
				{
					return this[index];
				}
				else
				{
					throw new ArgumentOutOfRangeException("No object with the specified name was found.", name, "name");
				}
			}
			set 
			{ 
				int index = this.IndexOf(name);
				if (index >= 0)
				{
					this[index] = value;
				}
				else
				{
					throw new ArgumentOutOfRangeException("No object with the specified name was found.", name, "name");
				}
			}
		}

		#endregion

		#region Methods

        /// <summary>
        /// Adds a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/> to the collection.
        /// </summary>
        /// <param name="orchestration">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/> to add.
        /// </param>
        public void Add(Orchestration orchestration) 
        {
            this.List.Add(orchestration);
        }

		/// <summary>
		/// Gets whether a particular <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/>
		/// is contained in the collection.
		/// </summary>
		/// <param name="orchestration">
		/// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/> to check for.
		/// </param>
		/// <returns>
		/// <b>true</b> if <paramref name="orchestration"/> is contained in the collection, or <b>false</b> otherwise.
		/// </returns>
		public bool Contains(Orchestration orchestration) 
		{
			return this.List.Contains(orchestration);
		}

		/// <summary>
		/// Gets whether a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/> with the
		/// specified name is contained in the collection.
		/// </summary>
		/// <param name="name">
		/// The name of the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/>.
		/// </param>
		/// <returns>
		/// <b>true</b> if an object with the name is contained in the collection, or <b>false</b> otherwise.
		/// </returns>
		public bool Contains(string name)
		{
			int index = this.IndexOf(name);
			return (index != -1);
		}

		/// <summary>
		/// Copies the collection into an <see cref="System.Array"/>.
		/// </summary>
		/// <param name="objects">
		/// The <see cref="System.Array"/> to copy the collection int.
		/// </param>
		/// <param name="index">
		/// The zero based index in the array at which to begin copying.
		/// </param>
		public void CopyTo(Orchestration[] objects, int index) 
		{
			this.List.CopyTo(objects, index);
		}

		/// <summary>
		/// Gets the index of a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/>.
		/// </summary>
		/// <param name="orchestration">
		/// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/> to get the index of.
		/// </param>
		/// <returns>
		/// The index of <paramref name="orchestration"/> if it is contained in the collection, or -1 otherwise.
		/// </returns>
		public int IndexOf(Orchestration orchestration) 
		{
			return this.List.IndexOf(orchestration);
		}

		/// <summary>
		/// Retrieves the index of a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/> from 
		/// the collection with the specified name.
		/// </summary>
		/// <param name="name">
		/// The name of the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/>.
		/// </param>
		/// <returns>
		/// The index of the item if found, or -1 otherwise.
		/// </returns>
		public int IndexOf(string name)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			for (int index = 0; index < this.List.Count; index++)
			{
				if (((Orchestration)this.List[index]).Name == name)
				{
					return index;
				}
			}
			return -1;
		}

        /// <summary>
        /// Inserts a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/> into the collection.
        /// </summary>
        /// <param name="index">
        /// The zero based index at which to insert <paramref name="orchestration"/>.
        /// </param>
        /// <param name="orchestration">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/> to insert.
        /// </param>
        public void Insert(int index, Orchestration orchestration) 
        {
            this.List.Insert(index, orchestration);
        }

        /// <summary>
        /// Removes a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/> from the collection.
        /// </summary>
        /// <param name="orchestration">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Orchestration"/> to remove.
        /// </param>
        public void Remove(Orchestration orchestration) 
        {
            this.List.Remove(orchestration); 
        }

		#endregion
    }
}

