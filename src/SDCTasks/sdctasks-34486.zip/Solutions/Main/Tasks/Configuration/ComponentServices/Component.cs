/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/

namespace Microsoft.Sdc.Tasks.Configuration.ComponentServices {
    using System;

    /// <summary>
    /// Summary description for Component.
    /// </summary>
    internal class Component {
        private string             name;
        private ComWrapper         component;
        private ComWrapper         components;
        private string             dll;
        private string             description;
        private string             constructor;
        private bool               constructionEnabled;
        private bool               objectPoolingEnabled;
        private long               minPoolSize;
        private long               maxPoolSize;
        private long               transactionTimeout;
        private bool               transactionTimeoutEnabled;


        private bool               isDirty; //default to false

        internal Component(string name) {
            this.name = name;
            isDirty = true;
        }

        internal Component(ComWrapper component, ComWrapper collection) {
            this.component = component;
            this.components = collection;
            this.name = component.GetProperty("Name").ToString();
            this.dll = component.GetProperty("Value", "DLL").ToString();
            this.description = component.GetProperty("Value", "Description").ToString();
            this.constructor = component.GetProperty("Value", "ConstructorString").ToString();
            this.constructionEnabled = (bool)component.GetProperty("Value", "ConstructionEnabled");

            this.objectPoolingEnabled = (bool)component.GetProperty("Value", "ObjectPoolingEnabled");
            this.minPoolSize = Convert.ToInt64(component.GetProperty("Value", "MinPoolSize"));
            this.maxPoolSize = Convert.ToInt64(component.GetProperty("Value", "MaxPoolSize"));
            this.transactionTimeout = Convert.ToInt64(component.GetProperty("Value", "ComponentTransactionTimeout"));
            this.transactionTimeoutEnabled = (bool)component.GetProperty("Value", "ComponentTransactionTimeoutEnabled");
            isDirty = false;                            
        }

        public void Save() {
            if (isDirty) {          
                component.SetProperty("Value", new object [] {"ConstructionEnabled", constructionEnabled}); 
                component.SetProperty("Value", new object [] {"ConstructorString", constructor}); 
                component.SetProperty("Value", new object [] {"Description", description}); 

                component.SetProperty("Value", new object [] {"ObjectPoolingEnabled", objectPoolingEnabled});
                component.SetProperty("Value", new object [] {"MinPoolSize", minPoolSize.ToString()});
                component.SetProperty("Value", new object [] {"MaxPoolSize", maxPoolSize.ToString()});
                component.SetProperty("Value", new object [] {"ComponentTransactionTimeout", transactionTimeout.ToString()});
                component.SetProperty("Value", new object [] {"ComponentTransactionTimeoutEnabled", transactionTimeoutEnabled});    

                components.CallMethod("SaveChanges");

                isDirty = false;
            }
        }

        public string Name {
            get {
                return (name == null ? String.Empty : name);
            }           
        }

        public string Dll {
            get {
                return (dll == null ? String.Empty : dll);
            }           
        }

        public string Description {
            get {
                return (description == null ? String.Empty : description);
            }
            set {
                if (description != value) {
                    description = value;
                    isDirty = true;
                }
            }
        }

        public string Constructor {
            get {
                return (constructor == null ? String.Empty : constructor);
            }
            set {
                if (constructor != value) {
                    constructor = value;
                    isDirty = true;
                }
            }
        }

        public bool ConstructionEnabled {
            get {
                return constructionEnabled ;
            }
            set {
                if (constructionEnabled != value) {
                    constructionEnabled = value;
                    isDirty = true; 
                }
            }
        }
        public bool ObjectPoolingEnabled
        {
            get 
            {
                return objectPoolingEnabled ;
            }
            set 
            {
                if (objectPoolingEnabled != value) 
                {
                    objectPoolingEnabled= value;
                    isDirty = true; 
                }
            }
        }
        public long MinPoolSize
        {
            get 
            {
                return minPoolSize ;
            }
            set 
            {
                if (minPoolSize != value) 
                {
                    minPoolSize= value;
                    isDirty = true; 
                }
            }
        }
        public long MaxPoolSize
        {
            get 
            {
                return maxPoolSize ;
            }
            set 
            {
                if (maxPoolSize != value) 
                {
                    maxPoolSize= value;
                    isDirty = true; 
                }
            }
        }

        public long TransactionTimeout
        {
            get 
            {
                return transactionTimeout ;
            }
            set 
            {
                if (transactionTimeout != value) 
                {
                    transactionTimeout= value;
                    isDirty = true; 
                }
            }
        }

        public bool TransactionTimeoutEnabled
        {
            get 
            {
                return transactionTimeoutEnabled ;
            }
            set 
            {
                if (transactionTimeoutEnabled != value) 
                {
                    transactionTimeoutEnabled= value;
                    isDirty = true; 
                }
            }
        }
    }
}
