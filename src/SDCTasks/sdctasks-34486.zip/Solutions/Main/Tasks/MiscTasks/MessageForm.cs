using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Microsoft.Sdc.Tasks
{
    public partial class MessageForm : Form
    {
        private string buttonPressedText = "None";

        public string ButtonPressedText
        {
            get { return buttonPressedText; }
            set { buttonPressedText = value; }
        }

        public MessageForm()
        {
            InitializeComponent();
        }

        public MessageForm(string title, string text, string[] buttonsText)
        {
            InitializeComponent();
            this.Text = title;
            this.label1.Text = text;
            Button[] buttons = {this.button1, this.button2, this.button3, this.button4 };

            int offset = 4 - buttonsText.Length;
            for (int i = 0; i < buttonsText.Length; i++)
            {
                buttons[i+offset].Text = buttonsText[i];
            }
            for (int i = 0; i < offset; i++)
            {
                buttons[i].Hide();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            buttonPressedText = ((Button)sender).Text;
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            buttonPressedText = ((Button)sender).Text;
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            buttonPressedText = ((Button)sender).Text;
            this.Close();
        }

    }
}