//-----------------------------------------------------------------------
// <copyright file="DocumentExceptions.cs" company="Microsoft">
// DocumentExceptionsright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-03-25</date>
// <summary>DocumentExceptions </summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Help
{
    using System;
    using System.Xml;
    using System.Globalization;
    using System.IO;
    using System.Collections;
    using System.Web.UI;
    using Microsoft.Build.Framework;
    using System.Collections.ObjectModel;

    /// <summary>
    /// Creates an HTML page that summarises all exception classes found within project documentation files.
    /// </summary>
    /// <remarks>    
    /// To use this task projects within the solution must be set to generate XML documenation files. Also
    /// The summary comments for all exception classes should be of the following format:-
    ///  
    /// <![CDATA[          /// <summary>
    ///                    /// The specified Credential does not exist
    ///                    /// </summary>
    ///                    /// <remarks>
    ///                    /// This error occurs when the user supplies credentials that cannot be validated.     
    ///                    /// Either the password or the user id are invalid.        
    ///                    ///    <ErrorNumber>2120</ErrorNumber>
    ///                    /// </remarks>
    /// ]]>
    /// <code><![CDATA[<Help.DocumentExceptions DocumentationFiles="File1.xml;File2.xml" OutputFile="Exceptions.htm" />]]></code>
    /// <para>where:</para>
    /// <para><i>DocumentationFiles</i></para>
    /// <para>List of XML documentation files, one for each project in the solution</para>
    /// <para><i>OutputFile</i></para>
    /// <para>Name of HTML documentation file to generate</para>
    /// </remarks>
    public class DocumentExceptions : TaskBase
    {
        private struct ExceptionEntry
        {
            public string ClassName;
            public string Namespace;
            public int ErrorNumber;
            public string Description;
            public string Details;
        }

        private Collection<ExceptionEntry> exceptionsList = new Collection<ExceptionEntry>();
        private string[] documentationFiles;
        private string outputFile;

        /// <summary>
        /// Initializes a new instance of the DocumentExceptions class.
        /// </summary>
        public DocumentExceptions()
        {
        }

        /// <summary>
        /// The array of the full paths of the files to be documented
        /// </summary>
        /// <value>The file names and full path of the files to be documented</value>
        public string[] DocumentationFiles
        {
            get
            {
                return this.documentationFiles;
            }

            set
            {
                this.documentationFiles = value;
            }
        }

        /// <summary>
        /// The full path to the Html File to create.
        /// </summary>
        /// <value>Html File to create</value>
        public string OutputFile
        {
            get
            {
                return (this.outputFile == null ? String.Empty : this.outputFile);
            }

            set
            {
                this.outputFile = value;
            }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            for (int i = 0; i < this.documentationFiles.Length; i++)
            {
                AddExceptions(this.documentationFiles[i]);
            }

            using (TextWriter streamWriter = new StreamWriter(this.outputFile))
            {
                HtmlTextWriter writer = new HtmlTextWriter(streamWriter);
                RenderPage(writer);
            }
        }

        /// <summary>
        /// Add exceptions found in the documentation file to this class'
        /// exception list.
        /// </summary>
        /// <param name="filename"></param>
        protected void AddExceptions(string filename)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(filename);
            XmlNamespaceManager ns = new XmlNamespaceManager(doc.NameTable);
            // the documentation files have no namespace so use empty namespace for queries
            ns.AddNamespace("e", "");

            XmlNodeList members = doc.SelectNodes("//e:member", ns);
            foreach (XmlNode member in members)
            {
                XmlAttribute name = member.Attributes["name", ""];
                if (name == null) continue;

                string memberName = name.Value;
                if (memberName.StartsWith("T:") && memberName.EndsWith("Exception"))
                {
                    // this is a documentation entry for an exception type definition 
                    // extract the details
                    ExceptionEntry e = new ExceptionEntry();
    
                    int classStarts = memberName.LastIndexOf('.');
                    e.ClassName = memberName.Substring(classStarts+1);
                    e.Namespace = memberName.Substring(2, classStarts-2);

                    XmlNode details = member.SelectSingleNode("e:summary", ns);
                    if (details != null) e.Description = details.InnerText;

                    details = member.SelectSingleNode("e:remarks", ns);
                    if (details != null) e.Details = details.InnerText;

                    details = member.SelectSingleNode("e:remarks/e:ErrorNumber", ns);
                    if (details != null) e.ErrorNumber = int.Parse(details.InnerText);

                    exceptionsList.Add(e);
                }
            }
        }
        /// <summary>
        /// Output the HTML 
        /// </summary>
        /// <param name="writer">output writer</param>
        protected void RenderPage(HtmlTextWriter writer)
        {
            writer.WriteBeginTag("html");
            writer.WriteAttribute("dir", "LTR");
            writer.Write(HtmlTextWriter.TagRightChar);
            writer.WriteLine();

            writer.Indent++;
            writer.WriteFullBeginTag("head");
            writer.WriteLine();

            writer.Indent++;
            writer.WriteFullBeginTag("title");
            writer.Write("Exception Reference");
            writer.WriteEndTag("title");
            writer.WriteLine();

            writer.WriteBeginTag("link");
            writer.WriteAttribute("rel", "stylesheet");
            writer.WriteAttribute("type", "text/css");
            writer.WriteAttribute("href", "MSDN.css");
            writer.Write(HtmlTextWriter.TagRightChar);
            writer.WriteEndTag("link");
            writer.WriteLine();

            writer.Indent--;
            writer.WriteEndTag("head");
            writer.WriteLine();

            writer.WriteBeginTag("body");
            writer.WriteAttribute("id", "bodyID");
            writer.WriteAttribute("class", "dtBODY");
            writer.Write(HtmlTextWriter.TagRightChar);
            writer.WriteLine();

            writer.Indent++;
            writer.WriteBeginTag("div");
            writer.WriteAttribute("id", "nsbanner");
            writer.Write(HtmlTextWriter.TagRightChar);
            writer.WriteLine();

            writer.Indent++;
            writer.WriteBeginTag("div");
            writer.WriteAttribute("id", "bannerrow1");
            writer.Write(HtmlTextWriter.TagRightChar);
            writer.WriteLine();

            writer.Indent++;
            writer.WriteBeginTag("table");
            writer.WriteAttribute("class", "bannerparthead");
            writer.WriteAttribute("cellspacing", "0");
            writer.Write(HtmlTextWriter.TagRightChar);
            writer.WriteLine();

            writer.Indent++;
            writer.WriteBeginTag("tr");
            writer.WriteAttribute("id", "hdr");
            writer.Write(HtmlTextWriter.TagRightChar);
            writer.WriteLine();

            writer.Indent++;
            writer.WriteBeginTag("td");
            writer.WriteAttribute("class", "runninghead");
            writer.Write(HtmlTextWriter.TagRightChar);
            writer.Write("Microsoft UK BBC Digital Curriculum");
            writer.WriteEndTag("td");
            writer.WriteLine();

            writer.WriteBeginTag("td");
            writer.WriteAttribute("class", "product");
            writer.Write(HtmlTextWriter.TagRightChar);
            writer.Write("&nbsp;");
            writer.WriteEndTag("td");
            writer.WriteLine();

            writer.Indent--;
            writer.WriteEndTag("tr");
            writer.WriteLine();

            writer.Indent--;
            writer.WriteEndTag("table");
            writer.WriteLine();

            writer.Indent--;
            writer.WriteEndTag("div");
            writer.WriteLine();

            writer.WriteBeginTag("div");
            writer.WriteAttribute("id", "TitleRow");
            writer.Write(HtmlTextWriter.TagRightChar);
            writer.WriteLine();

            writer.Indent++;
            writer.WriteBeginTag("h1");
            writer.WriteAttribute("class", "dtH1");
            writer.Write(HtmlTextWriter.TagRightChar);
            writer.Write("Exception Reference");
            writer.WriteEndTag("h1");
            writer.WriteLine();

            writer.Indent--;
            writer.WriteEndTag("div");
            writer.WriteLine();

            writer.Indent--;
            writer.WriteEndTag("div");
            writer.WriteLine();

            writer.WriteBeginTag("div");
            writer.WriteAttribute("id", "nstext");
            writer.Write(HtmlTextWriter.TagRightChar);
            writer.WriteLine();

            writer.Indent++;
            writer.WriteFullBeginTag("p");
            writer.WriteLine();
            writer.Indent++;

            // Content starts here
            writer.WriteBeginTag("table");
            writer.WriteAttribute("class", "dtTABLE");
            writer.Write(HtmlTextWriter.TagRightChar);
            writer.WriteLine();

            writer.Indent++;
            writer.WriteFullBeginTag("tr");
            writer.WriteLine();

            writer.Indent++;
            RenderCell(writer, "Error Number");
            RenderCell(writer, "Class");
            RenderCell(writer, "Description");
            RenderCell(writer, "Details");

            writer.Indent--;
            writer.WriteEndTag("tr");
            writer.WriteLine();

            foreach (ExceptionEntry e in exceptionsList)
            {
                writer.WriteFullBeginTag("tr");
                writer.WriteLine();

                writer.Indent++;
                RenderCell(writer, e.ErrorNumber.ToString());
                RenderCell(writer, e.ClassName);
                RenderCell(writer, e.Description);
                RenderCell(writer, e.Details);

                writer.Indent--;
                writer.WriteEndTag("tr");
                writer.WriteLine();
            }

            writer.Indent--;
            writer.WriteEndTag("table");
            writer.WriteLine();

            // Content ended, tidy up
            writer.Indent--;
            writer.WriteEndTag("p");
            writer.WriteLine();

            writer.WriteFullBeginTag("hr");
            writer.WriteEndTag("hr");
            writer.WriteLine();

            writer.WriteBeginTag("div");
            writer.WriteAttribute("id", "footer");
            writer.Write(HtmlTextWriter.TagRightChar);
            writer.WriteEncodedText("Copyright � 2005 Microsoft Corporation. All rights reserved.");
            writer.WriteEndTag("div");
            writer.WriteLine();

            writer.Indent--;
            writer.WriteEndTag("div");
            writer.WriteLine();

            writer.Indent--;
            writer.WriteEndTag("body");
            writer.WriteLine();

            writer.Indent--;
            writer.WriteEndTag("html");
            writer.WriteLine();
        }

        protected void RenderCell(HtmlTextWriter writer, string text)
        {
            writer.WriteFullBeginTag("td");
            writer.Write(text);
            writer.WriteEndTag("td");
            writer.WriteLine();
        }

    }
}