/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date><Date/>
  <Description>Implementation of the Service Task <Description/>
  <Copyright><![CDATA[
    Copyright � 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.Configuration.ComponentServices;

    /// <summary>
    /// Unit test for the UpdateComponentServicesApplicationTest Task
    /// </summary>
    [TestClass]
    public class UpdateComponentServicesApplicationTest
    {
        public UpdateComponentServicesApplicationTest()
        {
        }      

        [TestMethod]
        public void TestUpdateComponentServicesApplication()
        {
            //string applicationName = "XLANG Scheduler";
            string applicationName = ".NET Utilities";

            Tasks.ComponentServices.Application.Update task = new Tasks.ComponentServices.Application.Update();
           

            task.ApplicationName = applicationName;

            task.ActivationString = "Local";
            task.EnforceAccessChecks = false;
            task.Identity = @"Interactive User";
            task.RunForever = true;
            task.ShutdownAfter = "5";

            bool taskReturnValue = task.Execute();
            Assert.IsTrue(taskReturnValue);

            //Check the COM+ Application is now updated

            Application app = Application.Load(applicationName);
            Assert.IsFalse(app.AccessChecksEnabled, "UpdateComponentServicesApplicationTest");
            Assert.AreEqual(app.Activation, Activation.Local);
            Assert.IsTrue(app.RunForever, "UpdateComponentServicesApplicationTest");
            Assert.AreEqual(app.ShutdownAfter, 5);
            Assert.AreEqual(app.Identity, "Interactive User");

            //Now set it back
            task.ActivationString = "InProc";
            task.EnforceAccessChecks = true;
            task.RunForever = false;
            task.ShutdownAfter = "3";

            taskReturnValue = task.Execute();
            Assert.IsTrue(taskReturnValue, "UpdateComponentServicesApplicationTest");

            app = Application.Load(applicationName);
            Assert.IsTrue(app.AccessChecksEnabled, "UpdateComponentServicesApplicationTest");
            Assert.AreEqual(app.Activation, Activation.Inproc);
            Assert.IsFalse(app.RunForever, "UpdateComponentServicesApplicationTest");
            Assert.AreEqual(app.ShutdownAfter, 3);
        }
    }
}



