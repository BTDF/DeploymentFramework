﻿//-------------------------------------------------------------------------------------
// <copyright file="BtsHost.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      BtsHost
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;
    using System.Reflection;

    #endregion

    internal class BtsHost : BtsBaseObject
    {
        /// <summary>
        /// Internal Constructor
        /// </summary>
        /// <param name="actualBtsObject">The actual Microsoft.Biztalk.ExplorerOM.BtsHost object that object will call.</param>
        /// <param name="catalogExplorer">The Microsoft.Sdc.Tasks.Configuration.BtsCatalogExplorer object.</param>
        internal BtsHost(object actualBtsObject, BtsCatalogExplorer catalogExplorer)
        {
            this.btsCatalogExplorer = catalogExplorer;
            this.actualBtsObject = actualBtsObject;
        }

        /// <summary>Gets the host name.</summary>
        public string Name
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("Name", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>Gets the Windows NT group name of the host.</summary>
        public string NTGroupName
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("NTGroupName", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>
        /// Denotes a default host.
        /// </summary>
        public bool IsDefault
        {
            get
            {
                return (bool)this.actualBtsObject.GetType().InvokeMember("IsDefault", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>Gets the host type.</summary>
        public HostType Type
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("Type", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (HostType)Enum.Parse(typeof(HostType), value.ToString());
            }
        }
    }
}