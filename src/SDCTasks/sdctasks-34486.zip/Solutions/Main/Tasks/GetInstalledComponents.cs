//-----------------------------------------------------------------------
// <copyright file="GetInstalledComponents.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Ransom</author>
// <email></email>
// <date>2004-03-23</date>
// <summary>Get installed windows components</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks
{
    using System;
    using System.Xml;
    using System.Globalization;
    using System.IO;
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.Configuration.InstalledProducts;

    /// <summary>
    /// Gets a list of installed products on the specified machine
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[ <GetInstalledComponents>
    ///                     <Output TaskParameter="InstalledComponentsXml" ItemName="InstalledComponentsXmlItem" /> /> 
    ///                 </GetInstalledComponents> />]]></code>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <GetInstalledComponents>
    ///             <Output TaskParameter="InstalledComponentsXml" ItemName="InstalledComponentsXmlItem" >
    ///         </GetInstalledComponents>            
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class GetInstalledComponents : TaskBase
    {
        private string installedComponentsXml;

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            InstalledComponentsManager mgr = new InstalledComponentsManager();
            ComponentList components = mgr.GetInstalledComponents();
            this.installedComponentsXml = mgr.ConvertToXml(components);
        }

        /// <summary>
        /// The list of components installed on the specified machine.
        /// </summary>
        /// <value>The list of components installed on the specified machine</value>
        [Output]
        public string[] InstalledComponentsXml
        {
            get
            {
                return new string[] { this.installedComponentsXml };
            }
        }

        /// <summary>
        /// Initializes a new instance of the GetInstalledComponents class.
        /// </summary>
        public GetInstalledComponents()
        {
        }
    }
}