/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Simon Ransom</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.SummaryGeneration.Generators
{
	using System;
	using System.IO;
	using System.Collections;
	using System.Xml;

	/// <summary>
	/// Summary description for StyleCopSummarySectionGenerator.
	/// </summary>
	internal class StyleCopSummarySectionGenerator : ISectionGenerator
	{
		/// <summary>
		/// Create a StyleCopy summary section within the report
		/// </summary>
		/// <param name="sourceFolder">Path to folder where output files are</param>
		/// <param name="fileSpec">e.g. Report*.xml</param>
		/// <param name="name">Optional name for the section for use by an XSLT</param>
		/// <returns>New section</returns>
		public Section GenerateSection(string sourceFolder, string fileSpec, string name)
		{
			XmlDocument section = new XmlDocument();
			section.AppendChild(section.CreateElement("Section"));
			section.DocumentElement.SetAttribute("Type","StyleCop");
			if (name != null)
			{
				section.DocumentElement.SetAttribute("Name",name);
			}
			string [] reportFiles = Directory.GetFiles(sourceFolder,fileSpec);

			Hashtable violationsPerSection = new Hashtable();
			int violationCount = 0;
			foreach (string reportFile in reportFiles)
			{
				XmlReader reader = new XmlTextReader(reportFile);				
				while (reader.Read())
				{
					if (reader.NodeType==XmlNodeType.Element && reader.Name=="Violation")
					{
						string scSection = reader.GetAttribute("Section");
                        if (string.IsNullOrEmpty(scSection))
                        {
                            scSection = "";
                        }
						if (violationsPerSection[scSection]==null)
						{
							violationsPerSection[scSection]=1;
						}
						else
						{
							violationsPerSection[scSection]=((int)violationsPerSection[scSection])+1;
						}
						violationCount++;						
					}					
				}
				reader.Close();
			}

			XmlElement totalElement = section.CreateElement("TotalViolations");
			totalElement.InnerText = Convert.ToString(violationCount);
			section.DocumentElement.AppendChild(totalElement);
			foreach (string scSection in violationsPerSection.Keys)
			{
				XmlElement violationSection = section.CreateElement("ViolationSection");
				violationSection.SetAttribute("Name",scSection);
				XmlElement numberOfViolations = section.CreateElement("NumberOfViolations");
				numberOfViolations.InnerText = Convert.ToString(violationsPerSection[scSection]);
				violationSection.AppendChild(numberOfViolations);
				section.DocumentElement.AppendChild(violationSection);
			}
			return new Section(section);
		}

		public StyleCopSummarySectionGenerator()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
