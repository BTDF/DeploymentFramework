﻿//-----------------------------------------------------------------------
// <copyright file="ShortenPath.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Giles Knap</author>
// <email>gilesk</email>
// <date>2005-10-05</date>
// <summary>
// shortens a file path.
// </summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks
{
    #region Using directives
    using System;
    using System.Text;
    using System.IO;
    using Microsoft.Build.BuildEngine;
    using Microsoft.Build.Framework;
    using Microsoft.Build.Utilities;
    using Microsoft.Build.Shared;
    #endregion

    /// <summary>
    /// Takes a long file name and compress it down removing all relative parts (ie. '..')
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<ShortenPath inputPath="inputPath" Separator="separator">
    ///                 <Output TaskParameter="outputPath" PropertyName="outputPath" />
    ///                </ShortenPath>]]></code>
    /// <para>where:</para>
    /// <para><i>inputPath (Required)</i></para>
    /// <para>The the string containing path to shorten</para>
    /// <para><i>outputPath (Required)</i></para>
    /// <para>the resulting shortened</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <ShortenPath
    ///             inputPath="c:\projects\testproject\src\build\bin\..\..\Test\TestData">
    ///                 <Output TaskParameter="outputPath" PropertyName="ShortPath" />
    ///         </ShortenPath>
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class ShortenPath : TaskBase
    {
        private string inputPath;
        private string result;

        public ShortenPath()
        {
        }

        [Output]
        public string outputPath
        {
            get { return this.result; }
            set { this.result = value; }
        }

        [Required]
        public string InputPath
        {
            get { return this.inputPath; }
            set { this.inputPath = value; }
        }

        protected override void InternalExecute()
        {
            result = Path.GetFullPath(inputPath);
        }
    }
}
