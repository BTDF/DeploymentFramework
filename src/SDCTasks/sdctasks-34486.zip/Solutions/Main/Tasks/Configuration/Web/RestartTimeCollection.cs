/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.Web {
	using System.Collections;
	using System;
	/// <summary>
	/// Summary description for RestartTimeCollection.
	/// </summary>
	internal class RestartTimeCollection : CollectionBase {
		
		internal RestartTimeCollection() {
		}

		public void CopyTo(RestartTimeCollection collection, int index) {
			if (collection == null)
				throw new ArgumentNullException("collection");
			if (index < 0)
				throw new ArgumentOutOfRangeException("index", index, "index needs to be greater than 0");
			
			int i = 0;			
			while(i < List.Count) {
				collection[i+index] = (RestartTime)List[i];
				i++;
			}
		}	

		public int Add(RestartTime restartTime) {
			return List.Add(restartTime);
		}

		public int IndexOf(RestartTime value) {
			return( List.IndexOf(value));
		}

		public void Insert(int index, RestartTime value) {
			List.Insert(index, value);
		}

		public void Remove(RestartTime value) {
			List.Remove(value);
		}

		public bool Contains(RestartTime value) {
			return (List.Contains(value));
		}

		public RestartTime this[int index] {
			get {
				return (RestartTime) List[index];
			}
			set {
				List[index] = value;
			}
		}		
	}
}

