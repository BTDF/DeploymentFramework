//-----------------------------------------------------------------------
// <copyright file="Sum.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <summary>Sums the ItemList passed in</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Math
{
    using System;
    using System.Xml;
    using System.Globalization;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Returns the sum of the ItemList
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[ 
    /// <Math.Sum Numbers="numbers">
    ///        <Output TaskParameter="Result" PropertyName="result" />
    /// </Math.Sum>
    /// ]]></code>
    /// 
    /// <para>where:</para>
    /// <para><i>numbers (Required)</i></para>
    /// <para>ItemList of the numbers to total
    /// </para>
    /// <para>result</para>
    /// <para> The total of the numbers 
    /// </para>   
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <Math.Sum Numbers="2;3;4;5;">
    ///             <Output TaskParameter="Result" PropertyName="MyResult" />
    ///         </Math.Sum>
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Sum : TaskBase
    {
        private int result;
        private int[] numbers;
        
        /// <summary>
        /// Initializes a new instance of the Sum class.
        /// </summary>
        public Sum()
        {
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            int total = 0;
            foreach (int number in this.numbers)
            {
                total += number;
            }
            this.result = total;
        }

        /// <summary>
        /// </summary>
        [Required]
        public int[] Numbers
        {
            get
            {
                return this.numbers;
            }
            set
            {
                this.numbers = value;
            }
        }

        /// <summary>
        /// </summary>
        [Output]
        public int Result
        {
            get
            {
                return this.result;
            }
        }       
    }
}