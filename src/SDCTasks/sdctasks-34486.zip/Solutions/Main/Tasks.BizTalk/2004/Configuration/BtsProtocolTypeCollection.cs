﻿//-------------------------------------------------------------------------------------
// <copyright file="BtsProtocolTypeCollection.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      BtsProtocolTypeCollection
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;

    #endregion

    internal class BtsProtocolTypeCollection : System.Collections.ReadOnlyCollectionBase
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public BtsProtocolTypeCollection() 
        {
        }

        /// <summary>
        /// Indexer
        /// </summary>
        /// <param name="name">string</param>
        /// <returns>BtsProtocolType</returns>
        public BtsProtocolType this[string name]
        {
            get
            {
                BtsProtocolType item = null;
                foreach (BtsProtocolType currentitem in this.InnerList)
                {
                    if (currentitem.Name == name)
                    {
                        item = currentitem;
                        break;
                    }
                }
                return item;
            }
        }

        /// <summary>
        /// Indexer
        /// </summary>
        /// <param name="index">int</param>
        /// <returns>BtsProtocolType</returns>
        public BtsProtocolType this[int index]
        {
            get
            {
                return (BtsProtocolType)this.InnerList[index];
            }
        }

        internal void Add(BtsProtocolType item)
        {
            this.InnerList.Add(item);
        }
    }
}
