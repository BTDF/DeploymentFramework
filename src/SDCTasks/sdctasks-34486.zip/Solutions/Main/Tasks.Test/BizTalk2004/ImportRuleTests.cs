namespace Microsoft.Sdc.Tasks.Test.BizTalk2004
{
    using System;
    using System.Text;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Microsoft.Sdc.Tasks.BizTalk2004.Rules;

    /// <summary>
    /// Summary description for ImportRuleTests
    /// </summary>
    [TestClass]
    public class ImportRuleTests
    {
        public ImportRuleTests()
        {
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void TestImportRuleSet()
        {
            Import importRule = new Import();
            importRule.AssemblyPath = @"C:\Program Files\Microsoft BizTalk Server 2006\SDK\Scenarios\BPM\Rules\DecodeAndValidateOrderRules.xml";
            importRule.Execute();

            // Check if the rule exists
            Exists existsRule = new Exists();
            existsRule.Name = "DecodeAndValidateOrder";
            existsRule.Execute();

            Assert.IsTrue(existsRule.PolicyExists, "The correct policy doesn't exist");

            // Delete the ruleset
            Delete deleteRule = new Delete();
            deleteRule.Name = "DecodeAndValidateOrder";
            deleteRule.Execute();

            // Check if the ruleset still exists
            Exists existsRule2 = new Exists();
            existsRule2.Name = "DecodeAndValidateOrder";
            existsRule2.Execute();

            Assert.IsFalse(existsRule2.PolicyExists, "The correct policy still exists");

        }
    }
}
