//-----------------------------------------------------------------------
// <copyright file="VirtualDirectoryTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-06-01</date>
// <summary>Tests creating and deleting a virtual directory</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.Configuration.Web;

    /// <summary>
    /// Unit test for the create/delete virtual directory tasks
    /// </summary>
    [TestClass]
    public class VirtualDirectoryTest
    {
        

        public VirtualDirectoryTest()
        {
        }

        

        [TestMethod]
        public void CreateAndDeleteVirtualDirectory()
        {
            //Create a temporary directory
            string tempDirectory = TaskTestUtilities.CreateTempFolder();

            //Create a virtual directory
            Tasks.Web.WebSite.CreateVirtualDirectory createdVirtualDirectory = new Tasks.Web.WebSite.CreateVirtualDirectory();
            createdVirtualDirectory.Path = tempDirectory;
            string virtualDirectoryName = TaskTestUtilities.GenerateNewGuid().Replace("-", "");
            createdVirtualDirectory.VirtualDirectoryName = virtualDirectoryName;

            //Attempt to create it with a task
            bool createVirtualDirectorySuccess = createdVirtualDirectory.Execute();
            Assert.IsTrue(createVirtualDirectorySuccess);

            //Ensure it exists
            Assert.IsTrue(VirtualDirectory.Exists(createdVirtualDirectory.VirtualDirectoryName, 1, "localhost"));

            //Check properties
            Assert.IsTrue(createdVirtualDirectory.Path == tempDirectory);
            Assert.IsTrue(createdVirtualDirectory.VirtualDirectoryName == virtualDirectoryName);


            //Remove the virtual directory
            Tasks.Web.WebSite.DeleteVirtualDirectory deletedVirtualDirectory = new Tasks.Web.WebSite.DeleteVirtualDirectory();
            deletedVirtualDirectory.VirtualDirectoryName = createdVirtualDirectory.VirtualDirectoryName;
            bool deleteVirtualDirectorySuccess = deletedVirtualDirectory.Execute();

            //Ensure task success
            Assert.IsTrue(deleteVirtualDirectorySuccess);

            //Ensure it has been removed
            Assert.IsTrue(!(VirtualDirectory.Exists(deletedVirtualDirectory.VirtualDirectoryName, 1, "localhost")));

            //Check properties
            Assert.IsTrue(deletedVirtualDirectory.VirtualDirectoryName == virtualDirectoryName);

            //Delete the directory
            Directory.Delete(tempDirectory, true);
        }
    }
}


