/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Erwin Wendland</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
using System;
using System.Collections;
using System.Collections.Specialized;

namespace Microsoft.Sdc.Tasks.Configuration.SqlServer
{

    /// <summary>
    /// Provides all the information necessary to execute a SQL script using the
    /// class <see cref="Microsoft.Sdc.Tasks.Configuration.SqlServer.ScriptExecutor"/>.
    /// </summary>
    internal class ScriptExecutionInfo
    {

        #region Private members

        string serverName;
        string databaseName;
        string connectionString;
        int commandTimeout;
        string path;
        string sql;
        Hashtable substitutionParameters = null;
        Hashtable exclusions = null;
        bool retryFailures = false;
        bool rollbackOnError = false;

        #endregion

        /// <summary>
        /// Default Constructor
        /// </summary>
        public ScriptExecutionInfo()
        {
            // Default of 30 seconds
            commandTimeout = 30;
        }

        /// <summary>
        /// The SQL Server name.
        /// </summary>
        public string ServerName
        {
            get
            {
                return (serverName == null ? String.Empty : serverName);
            }
            set
            {
                serverName = value;
            }
        }

        /// <summary>
        /// Name of the database that the script will be run against.
        /// </summary>
        public string DatabaseName
        {
            get
            {
                return (databaseName == null ? String.Empty : databaseName);
            }
            set
            {
                databaseName = value;
            }
        }

        /// <summary>
        /// Set this property to define a database connection string. This
        /// property can be used instead of the combination of <see cref="Microsoft.Sdc.Tasks.Configuration.SqlServer.ScriptExecutionInfo.ServerName"/> and
        /// <see cref="Microsoft.Sdc.Tasks.Configuration.SqlServer.ScriptExecutionInfo.DatabaseName"/>.
        /// </summary>
        public string ConnectionString
        {
            get
            {
                return (connectionString == null ? String.Empty : connectionString);
            }
            set
            {
                connectionString = value;
            }
        }

        /// <summary>
        /// Gets or sets the wait time in seconds before terminating the 
        /// attempt to execute a command and generating an error.
        /// </summary>
        /// <remarks>
        /// Has a default value of 30 seconds.
        /// </remarks>
        public int CommandTimeout
        {
            get
            {
                return commandTimeout;
            }
            set
            {
                commandTimeout = value;
            }
        }

        /// <summary>
        /// The location of the script file to execute. The path can include wild-card
        /// characters '*' and '?'.
        /// </summary>
        /// <remarks>
        /// This property can only be set if <see cref="Microsoft.Sdc.Tasks.Configuration.SqlServer.ScriptExecutionInfo.Sql"/> is not set.
        /// </remarks>
        public string Path
        {
            get
            {
                return (path == null ? String.Empty : path);
            }
            set
            {
                path = value;
            }
        }

        /// <summary>
        /// SQL command text to be executed.
        /// </summary>
        /// <remarks>
        /// This property can only be set if <see cref="Microsoft.Sdc.Tasks.Configuration.SqlServer.ScriptExecutionInfo.Path"/> is not set.
        /// </remarks>
        public string Sql
        {
            get
            {
                return (sql == null ? String.Empty : sql);
            }
            set
            {
                sql = value;
            }
        }

        /// <summary>
        /// Contains the names of parameters that need to be substituted with 
        /// their given values before the script is executed.
        /// </summary>
        public Hashtable SubstitutionParameters
        {
            get
            {
                if (substitutionParameters == null) substitutionParameters = new Hashtable(20);
                return substitutionParameters;
            }
        }

        /// <summary>
        /// A hash table of exclusions that are keyed on the path of the script file(s) that are to be
        /// omitted from execution. The paths can include wild-card characters '*' and '?'. The value
        /// entries for the corresponding keys are ignored.
        /// </summary>
        public Hashtable Exclusions
        {
            get
            {
                if (exclusions == null) exclusions = new Hashtable(20);
                return exclusions;
            }
        }

        /// <summary>
        /// If true, scripts that failed will be retried. Execution will stop
        /// when there is no improvement in the number of scripts that failed.
        /// </summary>
        public bool RetryFailures
        {
            get
            {
                return retryFailures;
            }
            set
            {
                retryFailures = value;
            }
        }

        /// <summary>
        /// If true, scripts will be executed in a transaction and will be
        /// rolled back if an error occurs.
        /// </summary>
        public bool RollbackOnError
        {
            get
            {
                return rollbackOnError;
            }
            set
            {
                rollbackOnError = value;
            }
        }
    }
}
