//-------------------------------------------------------------------------------------
// <copyright file="Alias.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Represents the logical port through which partners interact with the business process for sending messages.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;

    #endregion

    /// <summary>
    /// Represents a party alias. An alias is a combination of name, qualifier, and value.
    /// </summary>
    internal class Alias : BizTalkNonConfigurableEntityBase
    {
        #region constants

        /// <summary>
        /// This is the readonly 'Organization' Alias Name in BizTalk
        /// </summary>
        public const string Organization = "Organization";

        /// <summary>
        /// This is the readonly 'OrganizationName' Alias Qualifier in BizTalk
        /// </summary>
        public const string OrganizationName = "OrganizationName";

        #endregion

        #region member variables

        private bool isAutoCreated;

        private Party party;
        private string qualifier;
        private string value;

        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="party">The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/> of this alias.</param>
        /// <param name="name">The name of this alias.</param>
        /// <param name="qualifier">The qualifier of this alias.</param>
        /// <param name="value">The value of this alias.</param>
        public Alias(Party party, string name, string qualifier, string value)
            : base(party.Installation, name)
        {
            this.party = party;
            this.qualifier = qualifier;
            this.value = value;
            this.isAutoCreated = false;
        }

        #region properties

        /// <summary>
        /// Gets the reference to the party.
        /// </summary>
        public Party Party
        {
            get { return this.party; }
        }
        
        /// <summary>
        /// Gets or sets the qualifier for the alias.
        /// </summary>
        public string Qualifier
        {
            get { return this.qualifier; }
            set { this.qualifier = value; }
        }
        
        /// <summary>
        /// Gets or sets the value of the party alias.
        /// </summary>
        public string Value
        {
            get { return this.value; }
            set { this.value = value; }
        }
        
        /// <summary>
        /// Gets a Boolean value that specifies whether the alias was automatically generated.
        /// </summary>
        public bool IsAutoCreated
        {
            get { return this.IsAutoCreated; }
        }

        #endregion

        #region methods
                
        /// <summary>
        /// Loads the details of an existing alias 
        /// </summary>
        /// <param name="party">The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party"/> of this alias.</param>
        /// <param name="qualifier">The qualifier of this alias.</param>
        /// <param name="value">The value of this alias.</param>
        /// <returns>An <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Alias"/> object.</returns>
        public static Alias Load(Party party, string qualifier, string value)
        {
            // loading native type
            BtsPartyAlias actualAlias = party.Installation.CatalogExplorer.Parties[party.Name].Aliases[qualifier, value];

            Alias alias = null;

            if (actualAlias != null)
            {
                alias = new Alias(party, actualAlias.Name, actualAlias.Qualifier, actualAlias.Value);
                alias.isAutoCreated = actualAlias.IsAutoCreated;
            }

            return alias;
        }

        #endregion
    }
}

