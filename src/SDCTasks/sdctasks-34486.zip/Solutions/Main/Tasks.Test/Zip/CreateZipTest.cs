//-----------------------------------------------------------------------
// <copyright file="CreateZipTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>andyr</email>
// <date>2004-05-25</date>
// <summary>Tests zip file creation</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the Create Guid Task
    /// </summary>
    [TestClass]
    public class CreateZipTest
    {
        

        public CreateZipTest()
        {
        }

        

        [TestMethod]
        
        //[Ignore("Failing on sdc-build03. Update when not usign J#")]
        public void TestCreateZip()
        {

            Tasks.Zip.Create task = new Tasks.Zip.Create();
            
            //Create a temp directory
            string pathToZipFolder = TaskTestUtilities.GenerateTempDirectoryPath();

            // Ensure it doesn't exist
            if (Directory.Exists(pathToZipFolder))
            {
                Assert.Fail("Temp directory already existed");
            }

            DirectoryInfo createdFolder = Directory.CreateDirectory(pathToZipFolder);

            if (!(Directory.Exists(pathToZipFolder)))
            {
                Assert.Fail("Folder created does not exist");
            }

            string pathToZipFile = pathToZipFolder + TaskTestUtilities.GenerateTempFilename("zip");

            try
            {
                task.PathToZipFile = pathToZipFile;

                bool taskReturnValue = task.Execute();

                //Test the new zip file was created
                Assert.IsTrue(taskReturnValue, "CreateZipSucceeded");

                //Check that the zip file exists at the proposed location
                if (!(System.IO.File.Exists(pathToZipFile)))
                {
                    Assert.Fail("Zip file does not exist");
                }
            }
            finally
            {
                Directory.Delete(pathToZipFolder, true);
            }

        }
    }
}


