﻿
namespace Microsoft.Sdc.Tasks.Mithran
{
    using System.Globalization;
    using System;
    using System.Xml;
    using Microsoft.Build.Framework;
    using System.IO;
    using Microsoft.Sdc.Tasks.Configuration;

    
    public class CreateProduct : TaskBase
    {
        private string productRootPath;
        private string productName;
        private string templatePath;

        /// <summary>
        /// Initializes a new instance of the CreateProduct class.
        /// </summary>
        public CreateProduct()
        {
        }


        [Required]
        public string ProductRootPath
        {
            get { return (this.productRootPath == null ? String.Empty : this.productRootPath); }
            set { this.productRootPath = value; }
        }

        [Required]
        public string ProductName
        {
            get { return (this.productName == null ? String.Empty : this.productName); }
            set { this.productName = value; }
        }

        /// <summary>
        /// Defaults to the folder we are running from with a Templates suffix
        /// </summary>
        /// <value></value>
        public string TemplatePath
        {
            get {

                if (this.templatePath == null)
                {
                    //Get our executing path and use that if not provided by the user

                    Uri uri = new Uri(this.GetType().Assembly.CodeBase);
                    this.templatePath = Path.Combine(Path.GetDirectoryName(uri.LocalPath), "Templates");
                }

                return this.templatePath;
            
            }
            set { this.templatePath = value; }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            // create our product path
            // then copy the blank product template
            // now do a replace across the copied folder to sort out our product name

            string destinationFolder = Path.Combine(this.productRootPath, this.ProductName);
          
            if (Directory.Exists(destinationFolder))
            {
                throw new TaskException("Folder.Exists");
            } 
            
            Log.LogMessage(MessageImportance.Low, "Using template path of {0}", this.TemplatePath);

            Directory.CreateDirectory(destinationFolder);

            Folder.CopyFolder copy = new Folder.CopyFolder();
            copy.BuildEngine = this.BuildEngine;

            copy.Source = Path.Combine(this.TemplatePath, "BlankProduct");

            copy.Destination = destinationFolder;

            copy.Execute();

            
        }
    }
}



