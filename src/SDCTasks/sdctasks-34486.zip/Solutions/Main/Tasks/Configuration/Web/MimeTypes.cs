/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Giles Knap/Author>
  <Date 09 JUL 2005/>
  <Description 6' 4" Brown Eyes, Dark Hair/>
  <Copyright><![CDATA[
    Copyright � 2001 - 2005 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/


namespace Microsoft.Sdc.Tasks.Configuration.Web 
{
    using System.Globalization;
    using System;
    using System.DirectoryServices;
    using System.Security.Principal;
    using System.Collections;
    using System.Runtime.InteropServices;
    using Microsoft.Sdc.Tasks.Configuration.Framework;
    using System.Text;

    /// <summary>
    /// Represents the list of configured allowable MimeTypes in a WebSite (todo, should be a site or VDIR)
    /// </summary>
    internal class MimeTypes 
    {
        private WebSite                     site = null;
        private DirectoryEntry              rootDe = null;
        private DirectoryEntry              siteDe = null;
        private PropertyValueCollection     mimeTypeList;
        // failed to create IISMImeType ProgID so we are using CLSID (not sure why)
        private Guid IISMimeType = new Guid("{9036B028-A780-11D0-9B3D-0080C710EF95}");

        public MimeTypes(WebSite site) 
        {
            this.site = site;
            siteDe = site.GetDirectoryEntry();

            rootDe = siteDe.Children.Find("ROOT", "IIsWebVirtualDir");
            
            // MimeMap property in the metabase is a PropertyValueCollection of
            // IISMimeType objects
            mimeTypeList = (PropertyValueCollection)rootDe.Properties["MimeMap"];
        }

        private ComWrapper CreateMimeTypeObject(string fileExtension, string mimeType)
        {
            ComWrapper c = new ComWrapper(IISMimeType);
            c.SetProperty("Extension", fileExtension);
            c.SetProperty("MimeType", mimeType);

            return c;
        }

        /// <summary>
        /// Check if a given mime type exists
        /// </summary>
        /// <param name="fileExtension">fileExtension</param>
        /// <param name="mimeType">Mime type to look for</param>
        /// <returns>true if the mime type exists</returns>
        public bool Exists(string fileExtension, string mimeType)
        {
            ComWrapper c = CreateMimeTypeObject(fileExtension, mimeType);
            return mimeTypeList.Contains(c.comObject);
        }

        public void Add(string fileExtension, string mimeType)
        {
            ComWrapper c = CreateMimeTypeObject(fileExtension, mimeType);
            if(!mimeTypeList.Contains(c.comObject))
            {
                mimeTypeList.Add(c.comObject);
                rootDe.CommitChanges();
            }
        }

        public void Delete(string fileExtension, string mimeType)
        {
            ComWrapper c = CreateMimeTypeObject(fileExtension, mimeType);
            mimeTypeList.Remove(c.comObject);
            rootDe.CommitChanges();      
        }
    }
}

