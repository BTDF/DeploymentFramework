/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date><Date/>
  <Description>Implementation of the Service Task <Description/>
  <Copyright><![CDATA[
    Copyright � 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.Configuration.Web;

    /// <summary>
    /// Unit test for the CreateAppPoolTest Task
    /// </summary>
    [TestClass]
    public class CreateAppPoolTest
    {
        public CreateAppPoolTest()
        {
        }

        [TestMethod]
        public void TestCreateAppPool()
        {
            Tasks.Web.AppPool.Create task = new Tasks.Web.AppPool.Create();
           

            //Generate a new random appPool name
            Guid guid = Guid.NewGuid();
            string poolName = guid.ToString();
            poolName = poolName.Replace("-", "").Substring(0, 11);

            if (AppPool.Exists(poolName))
            {
                Assert.Fail("AppPool already existed");
            }

            task.AppPoolName = poolName;
            bool taskReturnValue = task.Execute();
            Assert.IsTrue(taskReturnValue, "CreateAppPoolTest");

            //Check the pool now exists
            bool exists = AppPool.Exists(poolName);
            Assert.IsTrue(exists, "CreateAppPoolTest");

            //Update the app Pool properties and save
            AppPool pool20 = AppPool.Load(poolName, Environment.MachineName);
            pool20.Identity.Name = "testname";
            pool20.Identity.Password = "1234$abcd";
            pool20.Identity.Type = AppPoolIdentityType.SpecifiedUserAccount;
            pool20.Recycling.RestartRequests = 23;
            pool20.Recycling.RestartTime = 12;
            RestartTimeCollection schedule = pool20.Recycling.RestartSchedule;
            schedule.Add(new RestartTime(9, 45));
            schedule.Add(new RestartTime("11:46"));
            pool20.Recycling.MaximumVirtualMemory = 496;
            pool20.Recycling.MaximumUsedMemory = 191;

            pool20.Performance.IdleTimeout = 21;
            pool20.Performance.RequestQueueLimit = 999;
            pool20.Performance.CpuRefreshInterval = 4;
            pool20.Performance.CpuMaximumUse = 99;
            pool20.Performance.CpuAction = CpuAction.Shutdown;
            pool20.Performance.WorkerProcesses = 2;

            pool20.Health.PingEnabled = false;
            pool20.Health.PingInterval = 29;
            pool20.Health.RapidFailProtectionEnabled = false;
            pool20.Health.RapidFailProtectionMaximumFailures = 4;
            pool20.Health.RapidFailProtectionInterval = 3;
            pool20.Health.StartupTimeLimit = 89;
            pool20.Health.ShutdownTimeLimit = 88;
            pool20.Save();

            AppPool pool21 = AppPool.Load(poolName, Environment.MachineName);

            if (pool21.Identity.Name != "testname")
            {
                Assert.Fail("TestCreateAppPool");
            }

            if (pool21.Identity.Type != AppPoolIdentityType.SpecifiedUserAccount)
            {
                Assert.Fail("TestCreateAppPool");
            }

            if (pool21.Health.PingEnabled)
            {
                Assert.Fail("TestCreateAppPool");
            }
            if (pool21.Health.PingInterval != 29)
            {
                Assert.Fail("TestCreateAppPool");
            }

            if (pool21.Health.RapidFailProtectionEnabled)
            {
                Assert.Fail("TestCreateAppPool");
            }

            if (pool21.Health.RapidFailProtectionMaximumFailures != 4)
            {
                Assert.Fail("TestCreateAppPool");
            }

            if (pool21.Health.RapidFailProtectionInterval != 3)
            {
                Assert.Fail("TestCreateAppPool");
            }

            if (pool21.Health.StartupTimeLimit != 89)
            {
                Assert.Fail("TestCreateAppPool");
            }

            if (pool21.Health.ShutdownTimeLimit != 88)
            {
                Assert.Fail("TestCreateAppPool");
            }

            if (pool21.Performance.IdleTimeout != 21)
            {
                Assert.Fail("TestCreateAppPool");
            }

            if (pool21.Performance.RequestQueueLimit != 999)
            {
                Assert.Fail("TestCreateAppPool");
            }

            if (pool21.Performance.CpuRefreshInterval != 4)
            {
                Assert.Fail("TestCreateAppPool");
            }

            if (pool21.Performance.CpuAction != CpuAction.Shutdown)
            {
                Assert.Fail("TestCreateAppPool");
            }

            if (pool21.Performance.WorkerProcesses != 2)
            {
                Assert.Fail("TestCreateAppPool");
            }

            if (pool21.Performance.CpuMaximumUse != 99)
            {
                Assert.Fail("TestCreateAppPool");
            }

            if (pool21.Recycling.MaximumVirtualMemory != 496)
            {
                Assert.Fail("TestCreateAppPool");
            }

            if (pool21.Recycling.MaximumUsedMemory != 191)
            {
                Assert.Fail("TestCreateAppPool");
            }

            if (pool21.Recycling.RestartRequests != 23)
            {
                Assert.Fail("TestCreateAppPool");
            }

            if (pool21.Recycling.RestartTime != 12)
            {
                Assert.Fail("TestCreateAppPool");
            }

            schedule = pool20.Recycling.RestartSchedule;
            if (schedule[0].ToString() != "09:45" || schedule[1].ToString() != "11:46")
            {
                Assert.Fail("TestCreateAppPool");
            }

            //Now delete the pool
            AppPool.Delete(poolName);
            exists = AppPool.Exists(poolName);
            Assert.IsFalse(exists, "CreateAppPoolTest");
        }
    }
}



