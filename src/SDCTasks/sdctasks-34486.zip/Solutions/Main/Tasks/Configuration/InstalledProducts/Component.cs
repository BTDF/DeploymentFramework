using System;

namespace Microsoft.Sdc.Tasks.Configuration.InstalledProducts
{
	/// <summary>
	/// Summary description for Component.
	/// </summary>
    public class Component
	{
		private string _id;
		public string Id
		{
			get
			{
				return _id;
			}
			set
			{
				this._id = value;
			}
		}

		private string _description;
		public string Description 
		{
			get
			{
				return _description;
			}
			set
			{
				this._description = value;
			}
		}

		public Component()
		{
		}
	}
}
