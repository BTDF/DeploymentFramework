using System;

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.Collections;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the Error logging functionality
    /// </summary>
    /// <remarks>
    /// Ensures that inner exceptions are logged and that property/values are logged.
    /// </remarks>  
    [TestClass]
    public class ErrorLoggingTest
    {
        [TestMethod]        
        public void TestErrorCase()
        {
            TestErrorTask task = new TestErrorTask();
           
            task.TestProperty = "New Test Property Value";

            try
            {
                bool taskReturnValue = task.Execute();
                Assert.Fail("Should not get here as task should fail.");
            }
            catch (ApplicationException)
            {
                string lastMessage = ((PseudoBuildEngine)task.BuildEngine).PreviousMessage;
                // Make sure the error message matches what was expected
                Assert.IsTrue(lastMessage.IndexOf("This error wraps a FileNotFoundException") >= 0, "The text 'This error wraps a FileNotFoundException' was not found in " + lastMessage);
                // Make sure that the properties are dumped out
                //Assert.IsTrue("The text 'Properties of task were:' was not found in " + lastMessage, lastMessage.IndexOf("Properties of task were:") >= 0);
                // Check specific known property value
                Assert.IsTrue(lastMessage.IndexOf("TestProperty         = New Test Property Value") >= 0, "The text 'TestProperty = New Test Property Value' was not found in " + lastMessage);
                // Check that the inner exception is shown
                Assert.IsTrue(lastMessage.IndexOf("Test FileNotFound exception as an inner exception") >= 0, "The text 'Test FileNotFound exception as an inner exception' was not found in " + lastMessage);
            }
        }

        public ErrorLoggingTest()
        {
        }
    }
    /// <summary>
    /// Dummy task to test error cases thrown by InternalExecute
    /// </summary>
    public class TestErrorTask : TaskBase
    {


        private string _TestProperty;

        public string this[int i]
        {
            get { return "Test indexed property"; }
        }

        public string TestReadonlyProperty
        {
            get { return "Test Readonly Property Value"; }
        }

        public string TestProperty
        {
            get { return _TestProperty; }
            set { this._TestProperty = value; }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            try
            {
                throw new FileNotFoundException("Test FileNotFound exception as an inner exception");
            }
            catch (FileNotFoundException ex)
            {
                throw new TaskException(ex, "TestException");
            }
        }
    }
}
