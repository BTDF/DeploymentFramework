//-----------------------------------------------------------------------
// <Deleteright file="SendHandlerTests.cs" company="Microsoft">
// Deleteright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </Deleteright>
// <author>Thomas Manson</author>
// <email>tmanson</email>
// <date>2006-02-16</date>
// <summary>Tests BizTalk 2004 Receive Handler tasks</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test.BizTalk2006
{
    using System;
    using System.Text;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Sdc.Tasks.BizTalk2006;
    using Microsoft.Sdc.Tasks.BizTalk2006.SendHandler;
    using System.Management;

    /// <summary>
    /// Tests the BizTalk 2006 assembly tasks
    /// </summary>
    [TestClass]
    public class SendHandlerTests
    {
        private const string AppName = "Send Handler Test App";
        const string hostName = "TestHost";
        const string hostName2 = "TestHost2";

        public SendHandlerTests()
        {
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext)
        {
            Microsoft.Sdc.Tasks.BizTalk2006.Application.Create createTask = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Create();
            createTask.Application = AppName;
            createTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2004.Host.Create createHost = new Microsoft.Sdc.Tasks.BizTalk2004.Host.Create();
            createHost.GroupName = "BizTalk Application Users";
            createHost.HostType = "InProcess";
            createHost.HostServerName = Environment.MachineName;
            createHost.HostUsername = @"bts2006rc0\BTSService";
            createHost.HostPassword = "password";
            createHost.Name = hostName;
            createHost.Execute();

            Microsoft.Sdc.Tasks.BizTalk2004.Host.Create createHost2 = new Microsoft.Sdc.Tasks.BizTalk2004.Host.Create();
            createHost2.GroupName = "BizTalk Application Users";
            createHost2.HostType = "InProcess";
            createHost2.HostServerName = Environment.MachineName;
            createHost2.HostUsername = @"bts2006rc0\BTSService";
            createHost2.HostPassword = "password";
            createHost2.Name = hostName2;
            createHost2.Execute();

        }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        [ClassCleanup()]
        public static void MyClassCleanup()
        {
            Microsoft.Sdc.Tasks.BizTalk2006.Application.Stop stopAppTask = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Stop();
            stopAppTask.Application = AppName;
            stopAppTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2006.Application.Delete deleteTask = new Microsoft.Sdc.Tasks.BizTalk2006.Application.Delete();
            deleteTask.Application = AppName;
            deleteTask.Execute();

            Microsoft.Sdc.Tasks.BizTalk2004.Host.Delete delHost = new Microsoft.Sdc.Tasks.BizTalk2004.Host.Delete();
            delHost.Name = hostName;
            delHost.Execute();

            Microsoft.Sdc.Tasks.BizTalk2004.Host.Delete delHost2 = new Microsoft.Sdc.Tasks.BizTalk2004.Host.Delete();
            delHost2.Name = hostName2;
            delHost2.Execute();

        }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void TestSendHandlerActions()
        {
            const string transportType = "FTP";

            Microsoft.Sdc.Tasks.BizTalk2006.SendHandler.Exists existsTask = new Exists();
            existsTask.HostName = hostName;
            existsTask.TransportType = transportType;
            existsTask.Execute();
            if (existsTask.HandlerExists)
            {
                Assert.Fail("The File handler was not expected to exist");
            }

            Create createTask = new Create();
            createTask.HostName = hostName;
            createTask.TransportType = transportType;
            createTask.Execute();

            existsTask.Execute();
            if (!existsTask.HandlerExists)
            {
                Assert.Fail("The new File handler was expected to exist");
            }

            Move moveTask = new Move();
            moveTask.NewHostName = hostName2;
            moveTask.OldHostName = hostName;
            moveTask.TransportType = transportType;
            moveTask.Execute();

            existsTask.Execute();
            if (existsTask.HandlerExists)
            {
                Assert.Fail("The new File handler was not expected to exist on the old host");
            }

            existsTask.HostName = hostName2;
            existsTask.Execute();
            if (!existsTask.HandlerExists)
            {
                Assert.Fail("The new File handler was expected to exist");
            }

            Delete delTask = new Delete();
            delTask.HostName = hostName;
            delTask.TransportType = transportType;
            delTask.Execute();

            existsTask.Execute();
            if (existsTask.HandlerExists)
            {
                Assert.Fail("The File handler was not expected to exist");
            }
        }
    }
}
