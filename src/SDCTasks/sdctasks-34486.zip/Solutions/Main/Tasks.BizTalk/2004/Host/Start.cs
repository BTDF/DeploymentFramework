﻿//-------------------------------------------------------------------------------------
// <copyright file="Start.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Starts the given instance of the BizTalk host.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Host
{
    #region Using directives

    using System;
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion


    #region Class Comments
    /// <summary>
    /// Starts the given instance of the BizTalk host.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2004.Host.Start DisplayName="displayName" Server="server" Database="database" />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>displayName (Required)</i></para>
    /// <para>
    /// The name of the host to start.
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// <para><i>username</i></para>
    /// <para>
    /// The username to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// <para><i>password</i></para>
    /// <para>
    /// The password to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///            <BizTalk2004.Host.Start
    ///                DisplayName="BizTalkServerApplication" />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    #endregion
    public class Start : BizTalk2004TaskBase
    {
        #region Member Variables

        private string displayName;

        #endregion

        #region Constructors

        /// <summary>
        /// Creates a new instance of the Start task.
        /// </summary>
        public Start()
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the display name of the Host.
        /// </summary>
        /// <value>
        /// The display name of the Host.
        /// </value>
        [Required]
        public string DisplayName
        {
            get
            {
                return this.displayName;
            }
            set
            {
                this.displayName = value;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {
            BizTalkInstallation installation = this.GetInstallation();
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Host host =  Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Host.Load(installation, this.displayName);

            if (host != null)
                host.Start();
            else
                throw new InvalidOperationException("Host does not exist.");

        }
        #endregion

    }
}

