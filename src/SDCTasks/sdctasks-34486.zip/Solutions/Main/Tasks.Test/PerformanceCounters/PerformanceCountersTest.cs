//-----------------------------------------------------------------------
// <copyright file="PerformanceCountersTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-05-28</date>
// <summary>Tests performance counter creation and removal</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit tests for performance counter creation and removal
    /// </summary>
    [TestClass]
    public class PerformanceCountersTest
    {
        

        private const string CATEGORY_HELP = "Category Help";

        public PerformanceCountersTest()
        {
        }

       

        [TestMethod]
        [Ignore]//("Please complete with bug #")]
        public void TestPerformanceCounters()
        {

            Tasks.PerformanceCounters.Add addCounterTask = new Tasks.PerformanceCounters.Add();
            bool addCounterTaskReturnValue = false;

            Tasks.PerformanceCounters.Remove removeCounterTask = new Tasks.PerformanceCounters.Remove();
            bool removeCounterTaskReturnValue = false;

            try
            {
                addCounterTask.CategoryHelp = CATEGORY_HELP;

                string categoryName = "AddedCounterCategoryName";
                addCounterTask.CategoryName = categoryName;

                addCounterTaskReturnValue = addCounterTask.Execute();

                //Test the counter was added
                Assert.IsTrue(addCounterTaskReturnValue);

                removeCounterTaskReturnValue = removeCounterTask.Execute();

                //Test the counter was added
                Assert.IsTrue(removeCounterTaskReturnValue);
            }
            finally
            {
            }
        }

        [TestMethod]
        public void TestUninitializedRemoveTaskFails()
        {
            Tasks.PerformanceCounters.Remove task = new Tasks.PerformanceCounters.Remove();
           

            try
            {
                bool taskReturnValue = task.Execute();
                Assert.Fail("Uninitialised tasks should not succeed.");
            }
            catch (ApplicationException)
            {
                Console.WriteLine("Correctly threw exception");
                Console.WriteLine(((PseudoBuildEngine) task.BuildEngine).PreviousMessage);
            }

        }

        [TestMethod]
        public void TestUninitializedAddTaskFails()
        {
            Tasks.PerformanceCounters.Add task = new Tasks.PerformanceCounters.Add();
           

            try
            {
                bool taskReturnValue = task.Execute();
                Assert.Fail("Uninitialised tasks should not succeed.");
            }
            catch (ApplicationException)
            {
                Console.WriteLine("Correctly threw exception");
                Console.WriteLine(((PseudoBuildEngine) task.BuildEngine).PreviousMessage);
            }

        }

    }
}


