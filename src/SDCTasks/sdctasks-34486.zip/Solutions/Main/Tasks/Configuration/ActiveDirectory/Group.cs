/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.ActiveDirectory {
    using System;
    using System.DirectoryServices;
    using System.Security.Principal;
    using System.Collections;
    using System.Runtime.InteropServices;
    using System.Globalization;

    using Microsoft.Sdc.Tasks.Configuration.Framework;
    /// <summary>
    /// This represents a Group in the Active Directory.
    /// </summary>
    internal class Group 
    {
        private string              groupName;
        private string              domainName;
        private bool                isValidInDirectory;
        private string              description;
        private string              path;
        private string              fullName;
        private DirectoryEntry      groupDirectoryEntry;
        private bool                connected = false;
        DirectoryEntry              AD = null;

        static readonly string DefaultLoginPath = "WinNT://" + Environment.MachineName + ",computer";

        #region Public Properties
        public string GroupName 
        {
            get 
            {
                return groupName;
            }
            set 
            {
                groupName = value;
            }
        }

        public bool IsValidInDirectory 
        { 
            get 
            { 
                return isValidInDirectory;
            }
            set 
            { 
                isValidInDirectory = value;
            }
        }

        public string Description 
        { 
            get 
            { 
                return description; 
            }
            set 
            {
                description = value;
            }
        }

        public string FullName 
        {
            get 
            {
                return fullName;
            }
            set 
            {
                fullName = value;
            }
        }

        public DirectoryEntry GroupDirectoryEntry 
        {
            get 
            {
                return groupDirectoryEntry;
            }
            set 
            {
                groupDirectoryEntry = value;
            }
        }

        #endregion
        
        #region Constructors
        public Group(string groupName) : this(groupName, null) 
        {
        }

        public Group(string groupName, string domainName) 
        {
            if (domainName != null && domainName.Length > 0) 
            {
                this.domainName = domainName;
            }
            this.GroupName = groupName;
        }

        internal Group(DirectoryEntry group) 
        {
            this.path = group.Path;
            this.GroupName = group.Name;
            try 
            {
                this.GroupDirectoryEntry = group;
                this.Description = Convert.ToString(group.Invoke("Get", new object[] {"Description"}),CultureInfo.InvariantCulture);
                this.FullName = Convert.ToString(group.Invoke("Get", new object[] {"FullName"}),CultureInfo.InvariantCulture);
            }
            catch (System.Reflection.TargetInvocationException) 
            {               
            }
        }
    

        #endregion

        #region Static Methods

        static public Group Load(string groupName, string domainName) 
        {    
            DirectoryEntry AD = null;
            
            try 
            {
                if (domainName.ToUpper(CultureInfo.InvariantCulture) != Environment.MachineName.ToUpper(CultureInfo.InvariantCulture)) 
                {
                    AD = new DirectoryEntry("WinNT://" + domainName + ",domain");
                }
                else 
                {
                    AD = new DirectoryEntry("WinNT://" + Environment.MachineName + ",computer");
                }            
            
                DirectoryEntry group = AD.Children.Find(groupName, "Group");
                if (group != null) 
                {
                    Group grp = new Group(group);
                    grp.domainName = domainName;
                    return grp;
                } 
                else 
                {
                    return null;
                } 
            }   
            finally 
            {
                if (AD != null) AD.Close();
            }
        }

        static public Group Load(string groupName) {
            return Load(groupName, Environment.MachineName);
        }

        /// <summary>
        /// This checks the provided Active Directory for the groupName provided
        /// </summary>
        /// <param name="groupName">The groupName to check for</param>
        /// <param name="domainName">The domain name to check in</param>
        /// <returns></returns>
        static public bool Exists(string groupName, string domainName) {
            DirectoryEntry AD = null;
            if (domainName.ToUpper(CultureInfo.InvariantCulture) != Environment.MachineName.ToUpper(CultureInfo.InvariantCulture)) {
                AD = new DirectoryEntry("WinNT://" + domainName + ",domain");
            }
            else {
                AD = new DirectoryEntry("WinNT://" + Environment.MachineName + ",computer");
            }
            try {
                DirectoryEntry group = AD.Children.Find(groupName, "Group");
                if (group != null) {
                    return true;
                } else {
                    return false;
                }   
            }   
            catch (COMException e) {
                if (e.ErrorCode == -2147022676) {
                    return false;
                }
                throw e;
            }
            catch (System.IO.FileNotFoundException) {
                return false;
            }
            finally {
                AD.Dispose();
            }
            
        }

        static public bool Exists(string groupName) {
            
            using (DirectoryEntry AD = new DirectoryEntry("WinNT://" + Environment.MachineName + ",computer")) {
                try {
                    DirectoryEntry group = AD.Children.Find(groupName, "Group");
                    if (group != null) {
                        return true;
                    } else {
                        return false;
                    }   
                }   
                catch (COMException e) {
                    if (e.ErrorCode == -2147022676) {
                        return false;
                    }
                    throw e;
                }
            }
        }
        #endregion

        #region Public Methods
        public bool Connect() {
            return Connect(DefaultLoginPath);
        }   

        public bool Connect(string loginPath) {
            if (!connected) {
                try {
                    AD = new DirectoryEntry(loginPath);
                    connected = true;
                } catch (Exception e) {
                    throw new ApplicationException("Unable to connect to directory", e);
                }
            }
            return connected;
        }

        public bool Delete() {
            try {
                Connect();
                AD.Children.Remove(this.GroupDirectoryEntry);
                return true;
                    
            } catch(Exception e) {
                throw new ApplicationException("Unable to delete group", e);
            }
        }

        public bool Save() {
            try {
                if (this.domainName != null && this.domainName.Length > 0 && 
                    this.domainName.ToUpper() != Environment.MachineName.ToUpper()) {
                    // Only connect to the domain if we have been given a domain, and it is
                    // not the same as the current machine
                    Connect("WinNT://" + this.domainName + ",domain");
                }
                else {
                    Connect(DefaultLoginPath);
                }
                if (GroupDirectoryEntry == null) {
                    try {
                        GroupDirectoryEntry = AD.Children.Find(this.GroupName, "group");
                    }
                    catch {
                        GroupDirectoryEntry = AD.Children.Add(this.GroupName, "group");
                        //GroupDirectoryEntry.Properties["samAccountName"].Value = this.GroupName;

                    }
                }
                InvokeProperty("FullName", this.FullName);
                InvokeProperty("Description", this.Description);

                this.GroupDirectoryEntry.CommitChanges();
                this.IsValidInDirectory = true;
                return true;
            }
            catch (Exception ex) {
                throw new ApplicationException("Unable to create new group", ex);
            }
        }

        public bool IsInGroup(string groupName)
        {
            return IsInGroup(groupName, System.Environment.MachineName);
        }

        protected bool IsInGroup(string groupName, string machineName)
        {
            DirectoryEntry machine = null;
            bool returnValue = false;
            try
            {
                machine = new DirectoryEntry("WinNT://" + machineName + ",computer");

                foreach (DirectoryEntry dir in machine.Children)
                {
                    if (dir.SchemaClassName == "Group" && dir.Name == groupName)
                    {
                        ComWrapper o = new ComWrapper(dir.NativeObject);
                        returnValue = (bool)o.CallMethod("IsMember", new object[] { groupDirectoryEntry.Path });
                        break;
                    }
                }
            }
            finally
            {
                if (machine != null)
                {
                    machine.Close();
                }
            }
            return returnValue;
        }

        public bool AddToGroup(string groupName)
        {
            if (IsInGroup(groupName))
            {
                return true;
            }
            else
            {
                try
                {
                    Connect();
                    DirectoryEntry group;
                    group = AD.Children.Find(groupName, "Group");

                    if (group != null)
                    {
                        //ImpersonateIfRequired();
                        group.Invoke("Add", new object[] { groupDirectoryEntry.Path.ToString(CultureInfo.InvariantCulture)+",group" });
                        //ImpersonateUndo();
                    }
                    return true;

                }
                catch (Exception e)
                {
                    //TODO Throws an exception if already in the group
                    throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to add group '{0}' to group '{1}'.", this.groupName, groupName), e);
                }
            }
        }

        protected bool AddToGroup(string groupName, string machineName)
        {
            if (IsInGroup(groupName, machineName))
            {
                return true;
            }
            else
            {
                try
                {
                    Connect("WinNT://" + machineName + ",computer");
                    DirectoryEntry group;
                    group = AD.Children.Find(groupName, "Group");

                    if (group != null)
                    {
                        //ImpersonateIfRequired();
                        group.Invoke("Add", new object[] { groupDirectoryEntry.Path.ToString(CultureInfo.InvariantCulture) + ",group" });
                        //ImpersonateUndo();
                    }
                    return true;

                }
                catch (Exception e)
                {
                    //TODO Throws an exception if already in the group
                    throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to add group '{0}' to group '{1}'.", this.groupName, groupName), e);
                }
            }
        }

        #endregion

        #region Private Methods
        void InvokeProperty(string objectName, string objectValue) {
            try {
                if (objectValue != null && Convert.ToString(objectValue, CultureInfo.InvariantCulture).Length != 0) {
                    groupDirectoryEntry.Invoke("Put", new object[] {objectName, objectValue});
                }
            } catch {
                
            }
        }
        #endregion
    }

}
