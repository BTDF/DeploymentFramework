//-----------------------------------------------------------------------
// <copyright file="CopyFolderTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-05-27</date>
// <summary>Tests folder copying</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the Create Folder Task
    /// </summary>
    [TestClass]
    public class CopyFolderTest
    {
        public CopyFolderTest()
        {
        }

        /// <summary>
        /// Creates a source and destination folder. Creates a sub folder
        /// to the source folder and creates two files in the source folder and its sub folder. Executes
        /// the Folder.Copy task and independently ensures that the task succeeded before clearing up.
        /// </summary>
        [TestMethod]
        public void TestSuccess()
        {
            //Create a source folder. 
            string sourceFolder = TaskTestUtilities.CreateTempFolder();

            //Create a sub folder.
            string subFolderName = TaskTestUtilities.GenerateNewGuid();
            string sourceSubFolder = sourceFolder + "\\" + subFolderName;
            Directory.CreateDirectory(sourceSubFolder);

            //Create two files in both folders.
            string[] sourceFiles = new string[2];
            string[] subFiles = new string[2];
            for (int i = 0; i < 2; i++)
            {
                sourceFiles[i] = TaskTestUtilities.CreateTempFileInFolder(sourceFolder);
                subFiles[i] = TaskTestUtilities.CreateTempFileInFolder(sourceSubFolder);
            }

            //Create a destination folder
            string destinationFolder = TaskTestUtilities.CreateTempFolder();

            //Copy the source folder
            Tasks.Folder.CopyFolder task = new Tasks.Folder.CopyFolder();
           

            task.Source = sourceFolder;
            task.Destination = destinationFolder;

            bool taskReturnValue = task.Execute();

            //Test the folder was copied
            Assert.IsTrue(taskReturnValue, "FolderCopySucceeded");

            //Test the properties return expected results
            Assert.IsTrue(task.Source == sourceFolder, "CopyFolderProperties");
            Assert.IsTrue(task.Destination == destinationFolder, "CopyFolderProperties");

            //Ensure all the files and subfolders have been copied
            for (int i = 0; i < 2; i++)
            {
                Assert.IsTrue( System.IO.File.Exists(destinationFolder + "\\" + sourceFiles[i]), "SourceFileExists");
                Assert.IsTrue(System.IO.File.Exists(destinationFolder + "\\" + subFolderName + "\\" + subFiles[i]), "SubFileExists");
            }

            //Clean up
            Directory.Delete(sourceFolder, true);
            Directory.Delete(destinationFolder, true);
        }

        /// <summary>
        /// Creates a source and destination folder with spaces in their path names. Creates a sub folder
        /// to the source folder and creates two files in the source folder and its sub folder. Executes
        /// the Folder.Copy task and independently ensures that the task succeeded before clearing up.
        /// </summary>
        [TestMethod]
        public void TestSuccessWithPathSpaces()
        {
            //Create a source folder. 
            string sourceFolder = TaskTestUtilities.CreateTempFolderWithSpaces();

            //Create a sub folder.
            string subFolderName = TaskTestUtilities.GenerateNewGuid();
            string sourceSubFolder = sourceFolder + "\\" + subFolderName;
            Directory.CreateDirectory(sourceSubFolder);

            //Create two files in both folders.
            string[] sourceFiles = new string[2];
            string[] subFiles = new string[2];
            for (int i = 0; i < 2; i++)
            {
                sourceFiles[i] = TaskTestUtilities.CreateTempFileInFolder(sourceFolder);
                subFiles[i] = TaskTestUtilities.CreateTempFileInFolder(sourceSubFolder);
            }

            //Create a destination folder
            string destinationFolder = TaskTestUtilities.CreateTempFolderWithSpaces();

            //Copy the source folder
            Tasks.Folder.CopyFolder task = new Tasks.Folder.CopyFolder();
           

            task.Source = sourceFolder;
            task.Destination = destinationFolder;

            bool taskReturnValue = task.Execute();

            //Test the folder was copied
            Assert.IsTrue(taskReturnValue, "FolderCopySucceeded");

            //Test the properties return expected results
            Assert.IsTrue(task.Source == sourceFolder, "CopyFolderProperties");
            Assert.IsTrue(task.Destination == destinationFolder, "CopyFolderProperties");

            //Ensure all the files and subfolders have been copied
            for (int i = 0; i < 2; i++)
            {
                Assert.IsTrue( System.IO.File.Exists(destinationFolder + "\\" + sourceFiles[i]), "SourceFileExists");
                Assert.IsTrue(System.IO.File.Exists(destinationFolder + "\\" + subFolderName + "\\" + subFiles[i]), "SubFileExists");
            }

            //Clean up
            Directory.Delete(sourceFolder, true);
            Directory.Delete(destinationFolder, true);
        }

    }
}


