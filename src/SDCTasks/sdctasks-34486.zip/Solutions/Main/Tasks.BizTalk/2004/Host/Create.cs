//-------------------------------------------------------------------------------------
// <copyright file="Create.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Creates a host in a BizTalk Server.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Host
{
    #region Using directives

    using System;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion


    #region Class Comments
    /// <summary>
    /// Creates a host in a BizTalk Server.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2004.Host.Create 
    ///                Name="HostName"
    ///                GroupName="BizTalk Application Users"
    ///                HostType="InProcess"
    ///                HostServerName="Servername"
    ///                HostUsername="Name"
    ///                HostPassword="password"
    ///                Trusted="false"
    ///                Tracking="false"
    ///                IsDefault="false"
    ///                />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>Name (Required)</i></para>
    /// <para>
    /// The name of the host to create.
    /// </para>
    /// <para><i>GroupName</i></para>
    /// <para>
    /// The name of the group that the host runs under 
    /// </para>
    /// <para><i>HostType</i></para>
    /// <para>
    /// The type of host to create - InProcess or Isolated
    /// </para>
    /// <para><i>HostServerName</i></para>
    /// <para>
    /// The server where an instance of the host should be created.
    /// </para>
    /// <para><i>Username </i></para>
    /// <para>
    ///  The username of the user that the instance will run as.
    ///</para>
    /// <para><i>Password </i></para>
    /// <para>
    ///  The password for the user.
    /// </para>
    /// <para><i>Trusted </i></para>
    /// <para>
    ///  (Boolean) True if the host is to be a trusted host.
    /// </para>
    /// <para><i>Tracking </i></para>
    /// <para>
    ///  (Boolean) True if the host is to be a tracking host.
    /// </para>
    /// <para><i>IsDefault </i></para>
    /// <para>
    ///  (Boolean) True if the host is to be the default host.
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///            <BizTalk2004.Host.Create 
    ///                Name="SendPort 1"
    ///                TwoWay="false"
    ///                InboundMaps="TestMap, TempSolution.TestMaps, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
    ///            />
    /// 
    ///            <BizTalk2004.SendPort.Create 
    ///                Name="SendPort 2"
    ///                TwoWay="true"
    ///                AuthenticationType="RequiredDropMessage"
    ///                TrackingTypes="AfterReceivePipeline, AfterSendPipeline"
    ///                SendPipeline="Microsoft.BizTalk.DefaultPipelines.XMLTransmit, Microsoft.BizTalk.DefaultPipelines, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
    ///                InboundMaps="TestMap, TempSolution.TestMaps, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35; TestMap3, TempSolution.TestMaps, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
    ///                OutboundMaps="TestMap2, TempSolution.TestMaps, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
    ///                />
    ///      </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    #endregion
    public class Create : BizTalk2004TaskBase
    {
        private string name;
        private string groupName;
        private string hostType;
        private string hostServerName;
        private string hostUsername;
        private string hostPassword;
        private bool trusted;
        private bool tracking;
        private bool isDefault;


        /// <summary>
        /// The name of the host.
        /// </summary>
        /// <value>The name of the host.</value>
        [Required]
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        /// <summary>
        /// Name of the group the host is a member of
        /// </summary>
        /// <value>The name of the group</value>
        [Required]
        public string GroupName
        {
            get { return this.groupName; }
            set { this.groupName = value; }
        }

        /// <summary>
        /// The type of the host. 
        /// </summary>
        /// <value>
        ///Any one of the following:
        /// InProcess,
        /// Isolated
        ///</value>
        public string HostType
        {
            get { return this.hostType; }
            set { this.hostType = value; }
        }

        /// <summary>
        /// The server where an instance of the host is to be created.
        /// </summary>
        /// <value>
        /// The name of the server.
        ///</value>
        public string HostServerName
        {
            get { return this.hostServerName; }
            set { this.hostServerName = value; }
        }

        /// <summary>
        /// The user name to use to run the instance of the host as.
        /// </summary>
        /// <value>The user name.</value>
        public string HostUsername
        {
            get { return this.hostUsername; }
            set { this.hostUsername = value; }
        }

        /// <summary>
        /// The password for the host instance user
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public string HostPassword
        {
            get { return this.hostPassword; }
            set { this.hostPassword = value; }

        }

        /// <summary>
        /// Whether the host is a trusted host or not.
        /// </summary>
        /// <value>
        /// 
        ///</value>
        public bool Trusted
        {
            get { return this.trusted; }
            set { this.trusted = value; }
        }

        /// <summary>
        /// True is this is a tracking host
        /// </summary>
        public bool Tracking
        {
            get { return this.tracking; }
            set { this.tracking = value; }
        }

        /// <summary>
        /// True if this is the default host
        /// </summary>
        public bool IsDefault
        {
            get { return this.isDefault; }
            set { this.isDefault = value; }
        }


        /// <summary>
        /// Initializes a new instance of the Create class.
        /// </summary>
        public Create()
        {

        }

        /// <summary>
        /// Performs the action for this task
        /// </summary>
        protected override void InternalExecute()
        {
            //getting the installation and creating the new host.
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation installation = this.GetInstallation();
            HostType hostType = (HostType)Enum.Parse(typeof(HostType), this.HostType);
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Host.CreateInstance(installation, this.name, hostType,
                this.groupName, this.trusted, this.hostServerName, this.hostUsername, this.hostPassword, 
                this.tracking, this.isDefault);
        }
    }
}
        
