//-------------------------------------------------------------------------------------
// <copyright file="ImportBindings.cs" company="Achmea">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Imports the bindings of an assembly into BizTalk from an XML file.
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.Application
{
    using System.Globalization;
    using BizTalk.Deployment;
    using BizTalk.ExplorerOM;

    /// <summary>
    /// Imports the bindings of an BizTalk application
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2006.Application.ImportBindings AssemblyPath="" BindingPath="bindingPath" Application="EAIApplication" GlobalParties="True" Server="server" Database="database" />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>AssemblyPath (Required)</i></para>
    /// <para>
    /// The path of the assemlby (for BizTalk 2006 application it isn't used.
    /// </para>
    /// <para><i>bindingPath (Required)</i></para>
    /// <para>
    /// The path to the XML file that will import the binding.
    /// </para>
    /// <para><i>Application</i></para>
    /// <para>
    /// The BizTalk application from where the Binding file will be imported.
    /// </para>
    /// <para><i>GroupLevel</i></para>
    /// <para>
    /// Indicates toe imoprt the binding at GroupLevel instead of an appication.
    /// </para>
    /// <para><i>GlobalParties</i></para>
    /// <para>
    /// Indicates toe import also the global parties
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <!-- Export bindings using the application name -->
    ///         <BizTalk2006.Application.ImportBindings 
    ///             Application="EAIApplication"
    ///             GlobalParties="True"
    ///             Server="." 
    ///             Database="BizTalkMgmtDb" />
    ///         <!-- Export bindings at GroupLevel -->
    ///         <BizTalk2006.Application.ImportBindings 
    ///             GroupLevel="True"
    ///             Server="." 
    ///             Database="BizTalkMgmtDb" />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class ImportBindings : BizTalk2004.Assembly.ImportBindings
    {
        #region Member Variables

        private string application;
        private bool globalParties;
        private bool groupLevel;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the application.
        /// </summary>
        /// <value>The application.</value>
        public string Application
        {
            get { return this.application; }
            set { this.application = value; }
        }

        /// <summary>
        /// Gets or sets to export global parties
        /// </summary>
        /// <value>
        /// <b>true</b> to export the global parties, or <b>false</b> otherwise. The default is
        /// <b>false</b>.
        /// </value>
        public bool GlobalParties
        {
            get { return this.globalParties; }
            set { this.globalParties = value; }
        }

        /// <summary>
        /// Gets or sets to export group level
        /// </summary>
        /// <value>
        /// <b>true</b> to export from group level, or <b>false</b> otherwise. The default is
        /// <b>false</b>.
        /// </value>
        public bool GroupLevel
        {
            get { return this.groupLevel; }
            set { this.groupLevel = value; }
        }

        #endregion

        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {
            if (string.IsNullOrEmpty(this.Application) && this.GroupLevel == false)
            {
                base.InternalExecute();
            }
            else
            {
                using (BtsCatalogExplorer explorer = this.GetBtsCatalogExplorer(this.Server, this.Database))
                {
                    using (DeployerComponent deployComponent = new DeployerComponent())
                    {
                        string resultMessage = string.Empty;

                        ImportBindingError result = deployComponent.ImportBindingWithValidation(explorer.ConnectionString, this.BindingPath, this.Application, false, ref resultMessage);

                        switch (result)
                        {
                            case ImportBindingError.Failed:
                                throw new TaskException("Tasks.BizTalk2006.Application::ImportBindings", resultMessage);
                            case ImportBindingError.SucceededWithWarning:
                                Log.LogMessage(string.Format(CultureInfo.InvariantCulture, "Importing Binding file succeeded with the following warning {0}", resultMessage));
                                break;
                            default:
                                if (!this.GroupLevel)
                                {
                                    Log.LogMessage(string.Format(CultureInfo.InvariantCulture, "Importing Binding file succeeded for application {0}", this.Application));
                                }
                                else
                                {
                                    Log.LogMessage(string.Format(CultureInfo.InvariantCulture, "Importing Binding file succeeded for the Group {0}", explorer.GroupName));
                                }

                                break;
                        }
                    }
                }
            }
        }
    }
}

