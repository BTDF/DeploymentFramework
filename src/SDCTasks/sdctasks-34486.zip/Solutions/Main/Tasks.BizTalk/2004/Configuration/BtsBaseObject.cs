﻿//-------------------------------------------------------------------------------------
// <copyright file="BtsBaseObject.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      BtsBaseObject
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Reflection;
    using System.Collections;
    using System.Text;

    #endregion

    internal abstract class BtsBaseObject
    {
        #region private member variables

        protected internal object actualBtsObject;
        protected BtsCatalogExplorer btsCatalogExplorer;

        #endregion
        
        /// <summary>
        /// Constructor
        /// </summary>
        public BtsBaseObject()
        {
        }

        #region properties

        /// <summary>
        /// BtsCatalogExplorer
        /// </summary>
        public BtsCatalogExplorer BtsCatalogExplorer
        {
            get { return this.btsCatalogExplorer; }
        }

        #endregion        
    }
}
