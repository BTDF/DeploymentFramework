/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/

namespace Microsoft.Sdc.Tasks.Configuration.Win32Security {
    using System;
    using System.Diagnostics;
    using System.Runtime.InteropServices;
    using DWORD = System.UInt32;
    using WORD = System.UInt16;
    using BOOL = System.Int32;
    using HKEY = System.IntPtr;
    using HANDLE = System.IntPtr;

    /// <summary>
    /// Summary description for SecurityDescriptor.
    /// </summary>
    internal class SecurityDescriptor : DisposableObject {
        /// <summary>
        ///  Return the security descriptor of a given filename
        /// </summary>
        /// <param name="fileName">The filename</param>
        /// <returns>The security descriptor with DACL, GROUP and OWNER information</returns>
        public static SecurityDescriptor GetFileSecurity(string fileName) {
            return GetFileSecurity(fileName, 
                SECURITY_INFORMATION.DACL_SECURITY_INFORMATION |
                //SECURITY_INFORMATION.SACL_SECURITY_INFORMATION | // SACL requires SE_SECURITY_NAME privilege
                SECURITY_INFORMATION.GROUP_SECURITY_INFORMATION |
                SECURITY_INFORMATION.OWNER_SECURITY_INFORMATION);
        }
        /// <summary>
        ///  Return the selected components of the security descriptor of a given filename
        /// </summary>
        /// <param name="fileName">The filename</param>
        /// <param name="secInfo">The components of the security descriptor to return</param>
        /// <returns>The security descriptor</returns>
        public static SecurityDescriptor GetFileSecurity(string fileName, SECURITY_INFORMATION secInfo) {
            DWORD cbLength;
            BOOL rc = NativeMethods.GetFileSecurity(fileName, secInfo, IntPtr.Zero, 0, out cbLength);
            switch(Win32.GetLastError()) {
                case Win32.SUCCESS:
                    throw new InvalidOperationException("Unexpected return code from GetFileSecurity()");

                case Win32.ERROR_INSUFFICIENT_BUFFER:
                    IntPtr secDescPtr = Win32.AllocGlobal(cbLength);
                    try {
                        rc = NativeMethods.GetFileSecurity(fileName, secInfo, secDescPtr, cbLength, out cbLength);
                        Win32.CheckCall(rc);

                        return new SecurityDescriptor(secDescPtr);
                    }
                    catch {
                        Win32.FreeGlobal(secDescPtr);
                        throw;
                    }

                default:
                    Win32.ThrowLastError();
                    return null; // Never executed
            }
        }
		
        // Pointer to unmanged memory containing the security descriptor
        private IntPtr _secDesc;
        private bool _useLocalFree;

        /// <summary>
        /// Internal: Create a security decriptor from a pointer to unmanged memory
        /// </summary>
        /// <param name="secDesc">The pointer to unmanged memory. This instance becomes the owner
        ///  of the memory.</param>
        internal SecurityDescriptor(IntPtr secDesc)
            : this(secDesc, false) {
        }
        /// <summary>
        ///  Create an emtpy security descriptor
        /// </summary>
        public SecurityDescriptor()
            : this(IntPtr.Zero, false) {
        }
        internal SecurityDescriptor(IntPtr secDesc, bool useLocalFree) {
            _secDesc = secDesc;
            _useLocalFree = useLocalFree;
        }
        protected override void Dispose(bool disposing) {
            Clear();
        }
        private void AllocateAndInitializeSecurityDescriptor() {
            Clear();

            IntPtr secDesc = Win32.AllocGlobal(SECURITY_DESCRIPTOR.SizeOf);
            try {
                BOOL rc = NativeMethods.InitializeSecurityDescriptor(secDesc, 
                    (DWORD)SecurityDescriptorRevision.SECURITY_DESCRIPTOR_REVISION);
                Win32.CheckCall(rc);
            }
            catch {
                Win32.FreeGlobal(secDesc);
                throw;
            }
            _secDesc = secDesc;
        }
		
        private void Clear() {
            if (_secDesc == IntPtr.Zero)
                return;

            if (! IsSelfRelative) {
                BOOL defaulted;
                IntPtr owner;
                BOOL rc = NativeMethods.GetSecurityDescriptorOwner(_secDesc, out owner, out defaulted);
                if (rc != Win32.FALSE)
                    Win32.FreeGlobal(owner);

                IntPtr group;
                rc = NativeMethods.GetSecurityDescriptorGroup(_secDesc, out group, out defaulted);
                if (rc != Win32.FALSE)
                    Win32.FreeGlobal(group);

                BOOL present;
                IntPtr dacl = IntPtr.Zero;
                rc = NativeMethods.GetSecurityDescriptorDacl(_secDesc, out present, ref dacl, out defaulted);
                if (rc != Win32.FALSE)
                    if (present != Win32.FALSE)
                        Win32.FreeGlobal(dacl);

                IntPtr sacl = IntPtr.Zero;
                rc = NativeMethods.GetSecurityDescriptorSacl(_secDesc, out present, ref sacl, out defaulted);
                if (rc != Win32.FALSE)
                    if (present != Win32.FALSE)
                        Win32.FreeGlobal(dacl);

            }
            if (_useLocalFree)
                NativeMethods.LocalFree(_secDesc);
            else
                Win32.FreeGlobal(_secDesc);
            _secDesc = IntPtr.Zero;
        }
		
        private bool IsSelfRelative {
            get {
                return ((ControlFlags & SecurityDescriptorControlFlags.SE_SELF_RELATIVE) != 0);
            }
        }
		
        public SecurityDescriptorControlFlags ControlFlags {
            get {
                CheckIsValid();

                SecurityDescriptorControlFlags controlFlags;
                DWORD revision;
                BOOL rc = NativeMethods.GetSecurityDescriptorControl(_secDesc, out controlFlags, out revision);
                Win32.CheckCall(rc);
                return (SecurityDescriptorControlFlags)controlFlags;
            }
        }
		
        public Dacl Dacl {
            get {
                CheckIsValid();

                BOOL present;
                BOOL defaulted;
                IntPtr dacl = IntPtr.Zero;
                BOOL rc = NativeMethods.GetSecurityDescriptorDacl(_secDesc, out present, ref dacl, out defaulted);
                Win32.CheckCall(rc);
                if (present == Win32.FALSE)
                    return null;
                else
                    return new Dacl(dacl);
            }
            set {
                SetDacl(value);
            }
        }
		
        private void CheckIsValid() {
            if (!IsValid) {
                throw new InvalidOperationException("Security descriptor internal struct is NULL");
            }
        }

        public bool IsValid {
            get {
                return !IsNull;
            }
        }
        private bool IsNull {
            get {
                return (_secDesc == IntPtr.Zero);
            }
        }

        public void MakeSeflRelative() {
            if (IsNull || IsSelfRelative)
                return;

            DWORD dwLen = 0;
            BOOL rc = NativeMethods.MakeSelfRelativeSD(_secDesc, IntPtr.Zero, ref dwLen);
            if (Marshal.GetLastWin32Error() != Win32.ERROR_INSUFFICIENT_BUFFER)
                Win32.ThrowLastError();

            IntPtr pSD = Win32.AllocGlobal((int)dwLen);
            try {
                rc = NativeMethods.MakeSelfRelativeSD(_secDesc, pSD, ref dwLen);
                Win32.CheckCall(rc);

                Clear();
                _secDesc = pSD;
            }
            catch {
                Win32.FreeGlobal(pSD);
                throw;
            }
        }

		
        public void MakeAbsolute() {
            if (IsNull)
                return;

            if (!IsSelfRelative)
                return;


            DWORD dwSD = 0, dwOwner = 0, dwGroup = 0, dwDacl = 0, dwSacl = 0;
            BOOL rc = NativeMethods.MakeAbsoluteSD(
                _secDesc, 
                IntPtr.Zero, ref dwSD, 
                IntPtr.Zero, ref dwDacl,
                IntPtr.Zero, ref dwSacl, 
                IntPtr.Zero, ref dwOwner, 
                IntPtr.Zero, ref dwGroup);

            if (Marshal.GetLastWin32Error() != Win32.ERROR_INSUFFICIENT_BUFFER)
                Win32.ThrowLastError();

            IntPtr secDesc = Win32.AllocGlobal(dwSD);
            try {
                IntPtr pDacl = Win32.AllocGlobal(dwDacl);
                try {
                    IntPtr pSacl = Win32.AllocGlobal(dwSacl);
                    try {
                        IntPtr pOwner = Win32.AllocGlobal(dwOwner);
                        try {
                            IntPtr pGroup = Win32.AllocGlobal(dwGroup);
                            try {
                                rc = NativeMethods.MakeAbsoluteSD(
                                    _secDesc, 
                                    secDesc, ref dwSD, pDacl, ref dwDacl, pSacl, ref dwSacl, 
                                    pOwner, ref dwOwner, pGroup, ref dwGroup);
                                Win32.CheckCall(rc);

                                Clear();
                                _secDesc = secDesc;
                            } 
                            catch { 
                                Win32.FreeGlobal(pGroup); 
                                throw;
                            }
                        } 
                        catch { 
                            Win32.FreeGlobal(pOwner); 
                            throw;
                        }
                    } 
                    catch { 
                        Win32.FreeGlobal(pSacl); 
                        throw;
                    }
                } 
                catch { 
                    Win32.FreeGlobal(pDacl); 
                    throw;
                }
            } 
            catch { 
                Win32.FreeGlobal(secDesc); 
                throw;
            }
        }
		
        public void SetDacl(Dacl dacl) {
            SetDacl(dacl, false);
        }
        public void SetDacl(Dacl dacl, bool defaulted) {
            if (dacl == null)
                throw new ArgumentException("Can't set null DACL on a security descriptor", "dacl");

            UnsafeSetDacl(this, dacl, defaulted);
        }
        public void SetNullDacl(bool defaulted) {
            UnsafeSetDacl(this, null, defaulted);
        }
        private static void UnsafeSetDacl(SecurityDescriptor secDesc, Dacl dacl, bool defaulted) {
            secDesc.MakeAbsolute();

            // First we have to get a copy of the old group ptr, so that
            // we can free it if everything goes well.
            BOOL rc;
            IntPtr pOldDacl = IntPtr.Zero;
            if(!secDesc.IsNull) {
                BOOL oldDefaulted, oldPresent;
                rc = NativeMethods.GetSecurityDescriptorDacl(secDesc._secDesc, out oldPresent, ref pOldDacl, out oldDefaulted);
                Win32.CheckCall(rc);
            }
            else {
                secDesc.AllocateAndInitializeSecurityDescriptor();
            }


            IntPtr pNewDacl = IntPtr.Zero;
            try {
                if((dacl != null) && !dacl.IsNull && !dacl.IsEmpty) {
                    byte []pacl = dacl.GetNativeACL();
                    pNewDacl = Win32.AllocGlobal(pacl.Length);
                    Marshal.Copy(pacl, 0, pNewDacl, pacl.Length);
                }

                bool present = ((dacl == null) || dacl.IsNull || (pNewDacl != IntPtr.Zero));
                rc = NativeMethods.SetSecurityDescriptorDacl(
                    secDesc._secDesc, (present ? Win32.TRUE : Win32.FALSE),
                    pNewDacl, (defaulted ?  Win32.TRUE : Win32.FALSE));
                Win32.CheckCall(rc);

                Win32.FreeGlobal(pOldDacl);
            }
            catch {
                Win32.FreeGlobal(pNewDacl);
                throw;
            }
        }
        /*
        internal IntPtr Ptr {
            get {
                return _secDesc;
            }
        }
        */
        public void SetFileSecurity(string fileName, SECURITY_INFORMATION secInfo) {
            Win32.CheckCall(NativeMethods.SetFileSecurity(fileName, secInfo, this._secDesc));
        }
    }
}
