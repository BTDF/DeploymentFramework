﻿//-------------------------------------------------------------------------------------
// <copyright file="BtsParty.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      BtsParty
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;
    using System.Reflection;

    #endregion

    internal class BtsParty : BtsBaseObject
    {
        /// <summary>
        /// Internal Constructor
        /// </summary>
        /// <param name="actualBtsObject">The actual Microsoft.Biztalk.ExplorerOM.BtsParty object that object will call.</param>
        /// <param name="catalogExplorer">The Microsoft.Sdc.Tasks.Configuration.BtsCatalogExplorer object.</param>
        internal BtsParty(object actualBtsObject, BtsCatalogExplorer catalogExplorer)
        {
            this.btsCatalogExplorer = catalogExplorer;
            this.actualBtsObject = actualBtsObject;
        }

        /// <summary>
        /// Gets the collection of aliases for the party.
        /// </summary>
        public BtsPartyAliasCollection Aliases
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("Aliases", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsPartyAliasCollection aliases = new BtsPartyAliasCollection();

                    foreach (object item in ((System.Collections.IEnumerable)actualCollection))
                    {
                        BtsPartyAlias alias = new BtsPartyAlias(item, this.btsCatalogExplorer);
                        aliases.Add(alias);
                    }
                    return aliases;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Gets or sets a string containing custom data associated with the party. 
        /// </summary>
        public string CustomData
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("CustomData", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("CustomData", BindingFlags.SetProperty, null, this.actualBtsObject, new string[] { value });
            }
        }

        /// <summary>
        /// Gets or sets the name of the party.
        /// </summary>
        public string Name
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("Name", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("Name", BindingFlags.SetProperty, null, this.actualBtsObject, new string[] { value });
            }
        }

        /// <summary>
        /// Gets the list of send ports that the party references.
        /// </summary>
        public System.Collections.IList SendPorts
        {
            get
            {
                return (System.Collections.IList)this.actualBtsObject.GetType().InvokeMember("SendPorts", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>
        /// Gets or sets the signature certificate used to verify the signature of the documents from this party.
        /// </summary>
        public BtsCertificateInfo SignatureCert
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("SignatureCert", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                if (value != null)
                {
                    BtsCertificateInfo certificateInfo = new BtsCertificateInfo(value, this.btsCatalogExplorer);
                    return certificateInfo;
                }
                else
                {
                    return null;
                }
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("SignatureCert", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { ((BtsCertificateInfo)value).actualBtsObject });
            }
        }

        /// <summary>
        /// Creates and adds a new alias to the party.
        /// </summary>
        /// <returns>A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BtsPartyAlias"/> object.</returns>
        public BtsPartyAlias AddNewAlias()
        {
            object actualAlias = this.actualBtsObject.GetType().InvokeMember("AddNewAlias", BindingFlags.InvokeMethod, null, this.actualBtsObject, null);
            return new BtsPartyAlias(actualAlias, this.btsCatalogExplorer);
        }

        /// <summary>
        /// Removes the specified alias from the party alias collection. 
        /// </summary>
        /// <param name="alias"> a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BtsPartyAlias"/> object.</param>
        public void RemoveAlias(BtsPartyAlias alias)
        {
            this.actualBtsObject.GetType().InvokeMember("RemoveAlias", BindingFlags.InvokeMethod, null, this.actualBtsObject, new object[] { alias.actualBtsObject });
        }
    }
}
