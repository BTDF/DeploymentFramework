//-------------------------------------------------------------------------------------
// <copyright file="FilterGroupCollection.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      A collection of BizTalk 2004 objects.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using directives

    using System;
    using System.Collections;
	using System.IO;
	using System.Xml.Serialization;

	#endregion

    /// <summary>
    /// A collection of <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.FilterGroup"/> objects.
    /// </summary>
    [Serializable]
	public class FilterGroupCollection : CollectionBase
	{
		#region Constructors

		/// <summary>
		/// Creates a new collection of <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.FilterGroup"/> objects.
		/// </summary>
		public FilterGroupCollection()
		{
		}

		#endregion

		#region Indexers

        /// <summary>
        /// Gets or sets the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.FilterGroup"/> at a specified 
        /// position within the collection.
        /// </summary>
        /// <param name="index">
        /// The zero based index in the collection.
        /// </param>
        /// <value>
        /// A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.FilterGroup"/>.
        /// </value>
        public FilterGroup this[int index]
        {
            get 
			{ 
				return (FilterGroup)this.List[index]; 
			}
            set 
			{ 
				this.List[index] = value; 
			}
        }

		#endregion

		#region Methods

        /// <summary>
        /// Adds a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.FilterGroup"/> to the collection.
        /// </summary>
        /// <param name="group">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.FilterGroup"/> to add.
        /// </param>
        public void Add(FilterGroup group) 
        {
            this.List.Add(group);
        }

		/// <summary>
		/// Gets whether a particular <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.FilterGroup"/>
		/// is contained in the collection.
		/// </summary>
		/// <param name="group">
		/// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.FilterGroup"/> to check for.
		/// </param>
		/// <returns>
		/// <b>true</b> if <paramref name="group"/> is contained in the collection, or <b>false</b> otherwise.
		/// </returns>
		public bool Contains(FilterGroup group) 
		{
			return this.List.Contains(group);
		}

		/// <summary>
		/// Copies the collection into an <see cref="System.Array"/>.
		/// </summary>
		/// <param name="objects">
		/// The <see cref="System.Array"/> to copy the collection int.
		/// </param>
		/// <param name="index">
		/// The zero based index in the array at which to begin copying.
		/// </param>
		public void CopyTo(FilterGroup[] objects, int index) 
		{
			this.List.CopyTo(objects, index);
		}

		/// <summary>
		/// Gets the index of a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.FilterGroup"/>.
		/// </summary>
		/// <param name="group">
		/// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.FilterGroup"/> to get the index of.
		/// </param>
		/// <returns>
		/// The index of <paramref name="group"/> if it is contained in the collection, or -1 otherwise.
		/// </returns>
		public int IndexOf(FilterGroup group) 
		{
			return this.List.IndexOf(group);
		}

        /// <summary>
        /// Inserts a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.FilterGroup"/> into the collection.
        /// </summary>
        /// <param name="index">
        /// The zero based index at which to insert <paramref name="group"/>.
        /// </param>
        /// <param name="group">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.FilterGroup"/> to insert.
        /// </param>
        public void Insert(int index, FilterGroup group) 
        {
            this.List.Insert(index, group);
        }

		/// <summary>
		/// Populates the filter group collection populate from a filter XML string. This will clear any
		/// existing filters groups already in the collection.
		/// </summary>
		/// <param name="filterXml">
		/// The filter XML string.
		/// </param>
		/// <returns>
		/// A populated <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.FilterGroupCollection"/>.
		/// </returns>
		public void PopulateFromFilterXml(string filterXml)
		{
			this.List.Clear();
			XmlRootAttribute root = new XmlRootAttribute("Filter");
			XmlSerializer serializer = new XmlSerializer(typeof(FilterGroupCollection), root);
			FilterGroupCollection collection;
			using (StringReader reader = new StringReader(filterXml))
			{
				collection = (FilterGroupCollection)serializer.Deserialize(reader);
			}
			foreach (FilterGroup group in collection)
			{
				this.List.Add(group);
			}
		}

        /// <summary>
        /// Removes a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.FilterGroup"/> from the collection.
        /// </summary>
        /// <param name="group">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.FilterGroup"/> to remove.
        /// </param>
        public void Remove(FilterGroup group) 
        {
            this.List.Remove(group); 
        }

		/// <summary>
		/// Gets the filter XML string represented by the collection.
		/// </summary>
		/// <returns>
		/// A filter XML string representing the collection.
		/// </returns>
		public string ToFilterXml()
		{
			string filterXml = null;
			if (this.Count > 0)
			{
				XmlRootAttribute root = new XmlRootAttribute("Filter");
				XmlSerializer serializer = new XmlSerializer(typeof(FilterGroupCollection), root);
				using (StringWriter writer = new StringWriter())
				{
					serializer.Serialize(writer, this);
					filterXml = writer.ToString();
				}
			}
			return filterXml;
		}

		#endregion
    }
}

