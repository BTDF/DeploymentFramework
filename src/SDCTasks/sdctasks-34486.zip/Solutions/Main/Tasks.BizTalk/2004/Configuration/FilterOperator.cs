//-------------------------------------------------------------------------------------
// <copyright file="FilterOperator.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      The operator used to compare filter values with actual values in a message 
//		context.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	/// <summary>
	/// The operator used to compare filter values with actual values in a message context.
	/// </summary>
	public enum FilterOperator
	{
		/// <summary>
		/// Items are compared for equality.
		/// </summary>
		Equal = 0,
		/// <summary>
		/// The actual value should be less than the filter value.
		/// </summary>
		LessThan = 1,
		/// <summary>
		/// The actual value should be less than or equal to the filter value.
		/// </summary>
		LessThanOrEqual = 2,
		/// <summary>
		/// The actual value should be greater than the filter value.
		/// </summary>
		GreaterThan = 3,
		/// <summary>
		/// The actual value should be greater than or equal to the filter value.
		/// </summary>
		GreaterThanOrEqual = 4,
		/// <summary>
		/// Items are compared for inequality.
		/// </summary>
		NotEqual = 5,		
		/// <summary>
		/// The actual value should exist in the message context.
		/// </summary>
		Exists = 6,
		/// <summary>
		/// A bitwise AND of the values is used.
		/// </summary>
		BitwiseAnd = 7,
		/// <summary>
		/// The actual value should be like the filter value.
		/// </summary>
		IsLike = 8
	}
}

