//-----------------------------------------------------------------------
// <copyright file="Start.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.Application
{
    using BizTalk2004;
    using System.Globalization;
    using BizTalk.ExplorerOM;
    using Build.Framework;

    /// <summary>
    /// Starts an application
    /// </summary>
    public class Start : BizTalk2004TaskBase
    {
        private string application;

        /// <summary>
        /// Gets or sets the application.
        /// </summary>
        /// <value>The application.</value>
        [Required]
        public string Application
        {
            get { return this.application; }
            set { this.application = value; }
        }

        /// <summary>
        /// This is the main execute method that all tasks should implement
        /// </summary>
        /// <remarks>
        /// TaskException should be thrown in the event of errors
        /// </remarks>
        protected override void InternalExecute()
        {
            BtsCatalogExplorer explorer = this.GetBtsCatalogExplorer(this.Server, this.Database);

            Application app = explorer.Applications[this.Application];
            if (app != null)
            {
                ApplicationStartOption option = ApplicationStartOption.StartAll;

                Log.LogMessage(string.Format(CultureInfo.InvariantCulture, "Starting Application: {0}", this.Application));
                app.Start(option);
                explorer.SaveChanges();
            }
            else
            {
                Log.LogError(string.Format(CultureInfo.InvariantCulture, "Application not found: {0}", this.Application));
                return;
            }
        }
    }
}
