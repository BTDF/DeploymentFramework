﻿//-----------------------------------------------------------------------
// <copyright file="Compile.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-07-01</date>
// <summary>Compiles a chm file.</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Help
{
    #region Using directives
    using System;
    using System.Xml;
    using System.Globalization;
    using System.IO;
    using System.Text.RegularExpressions;
    using Microsoft.Win32;
    using Microsoft.Build.Framework;
    using Microsoft.Build.Tasks;
    using Microsoft.Build.Utilities;

    #endregion
    /// <summary>
    /// Decompiles a chm file into the specified folder.
    /// </summary>          
    /// <remarks>
    /// <code><![CDATA[
    /// <Help.Compile DestinationFolder="folder"
    ///              ChmFilePath="chmFilePath">
    /// </Help.Compile>
    /// ]]></code>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Compile : Microsoft.Sdc.Tasks.Tools.ToolTaskBase
    {
        /// <summary>
        /// Initializes a new instance of the Compile class.
        /// </summary>
        public Compile()
        {
        }

        /// <summary>
        /// The full path to a hhp file
        /// </summary>
        /// <value>Must be a full path.</value>
        [Required]
        public string ProjectFilePath
        {
            get { return (string)Bag["ProjectFilePath"]; }
            set { Bag["ProjectFilePath"] = value; }
        }       

        /// <summary>
        /// The name of the exe we call.
        /// </summary>
        /// <value>The name of the exe we call.</value>
        protected override string ToolName
        {
            get { return "hhc.exe"; }
        }

        /// <summary>
        /// Builds the commandline for this tool
        /// </summary>
        /// <param name="commandLine">The object to append the args to.</param>
        /// <returns>True if successfully added args.</returns>
        protected override void AddCommandLineCommands(CommandLineBuilderExtension commandLine)
        {
            commandLine.AppendSwitch(this.ProjectFilePath);
        }

        /// <summary>
        /// Full calculated path to tool including exe name
        /// </summary>
        /// <returns>Defaults to default install location of HTML Help</returns>
        protected override string GenerateFullPathToTool()
        {
            //"C:\Program Files\HTML Help Workshop\hhc.exe"
            string path = System.Environment.GetEnvironmentVariable("PROGRAMFILES");
            
            return System.IO.Path.Combine(path, @"HTML Help Workshop\" + this.ToolName);
        }        
    }
}
