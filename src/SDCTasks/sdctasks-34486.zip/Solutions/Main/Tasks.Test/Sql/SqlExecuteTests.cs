//-----------------------------------------------------------------------
// <copyright file="SqlExecuteTests.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Barry Dorrans</author>
// <email>barryd@charteris.com</email>
// <date>2004-06-04</date>
// <summary>Unit test cases for the SqlServer Execute action.</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;


    // We need these to create suitable users to add into SQL
    using Microsoft.Sdc.Tasks.Configuration.ActiveDirectory;
    using Microsoft.Sdc.Tasks.ActiveDirectory;

    // And we need these to impersonate users without adequate permissions in SQL to add people
    using System.Runtime.InteropServices;
    using System.Security.Principal;
    using System.Security.Permissions;

    // And we need these to check our results
    using System.Data;
    using System.Data.SqlClient;
    using System.Data.SqlTypes;

    /// <summary>
    /// Unit tests for Tasks.Sql.Execute scenarios
    /// </summary>
    [TestClass]
    public class SqlExecuteTests
    {
        public SqlExecuteTests()
        {
        }

        /// <summary>
        /// Try executing the task with no parameters set
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(ApplicationException))]
        public void TestExecuteWithNoParameters()
        {
            Tasks.Sql.Execute task = new Tasks.Sql.Execute();
           
            task.Execute();
        }

        /// <summary>
        /// Try executing the task with varying parameters set
        /// </summary>
        [TestMethod]
        public void TestExecuteWithWeirdParameterCombinations()
        {
            Tasks.Sql.Execute task;

            task = new Tasks.Sql.Execute();
            
            try 
            {
                task.CommandTimeout = -1;
                //Assert.Fail("Command Timeout accepted a negative value");
            }
            catch (ApplicationException) // Swallow it
            {
            }

            task = new Tasks.Sql.Execute();
            task.DatabaseName = "master";
            // Try with no server set
            try
            {
                task.Execute();
            }
            catch (ApplicationException) // Swallow it
            { 
            }

            try
            {
                task.DatabaseName = string.Empty;
                //Assert.Fail("Database name accepted an empty database name when connection string is not set");

            }
            catch (ApplicationException) // Swallow it
            {
            }
        }


        internal class NativeMethods
        {
            [DllImport("advapi32.dll", CharSet = CharSet.Auto)]
            public static extern bool LogonUser(String lpszUserName, String lpszDomain, String lpszPassword, int dwLogonType, int dwLogonProvider, ref IntPtr phToken);
            [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
            public extern static bool CloseHandle(IntPtr handle);

        }
    }
}