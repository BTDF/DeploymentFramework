//-----------------------------------------------------------------------
// <copyright file="GetInstalledProducts.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Ransom</author>
// <email></email>
// <date>2004-03-23</date>
// <summary>Get installed products</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks
{
    using System;
    using System.Xml;
    using System.Globalization;
    using System.IO;
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.Configuration.InstalledProducts;

    /// <summary>
    /// Gets a list of installed products on the specified machine
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[ <GetInstalledProducts MachineName="machineName" Username="username" Password="password" InstalledProductsXml="installedProductsXml">
    ///                     <Output TaskParameter="InstalledProductsXml" ItemName="InstalledProductsXmlItem" /> /> 
    ///                 </GetInstalledProducts> />]]></code>
    /// <para>where:</para>
    /// <para><i>machineName</i></para>
    /// <para>The name of the remote machine or "." for local machine. Defaults to "."</para>
    /// <para><i>username</i></para>
    /// <para>The username to be used for the connection operation.</para>
    /// <para><i>password</i></para>
    /// <para>The password to be used for the connection operation.</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <GetInstalledProducts
    ///             MachineName="remote"
    ///             Username="myDomain\myAuthorisedUser"
    ///             Password="123$abc>
    ///             <Output TaskParameter="InstalledProductsXml" ItemName="InstalledProductsXmlItem" >
    ///         </GetInstalledProducts>            
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class GetInstalledProducts : TaskBase
    {
        private string machineName = ".";
        private string username;
        private string password;
        private string installedProductsXml;

        /// <summary>
        /// The name of the machine being examined
        /// </summary>
        /// <value>The name of the remote machine or "." for local machine. Defaults to "."</value>
        public string MachineName
        {
            get
            {
                return this.machineName;
            }
            set
            {
                this.machineName = value;
            }
        }

        /// <summary>
        /// The username to be used for the connection operation.
        /// </summary>
        /// <value>The username to be used for the connection operation, in the format "DOMAIN\username".</value>
        public string Username
        {
            get
            {
                return this.username;
            }
            set
            {
                this.username = value;
            }
        }

        /// <summary>
        /// The password to be used for the connection operation.
        /// </summary>
        /// <value>The password to be used for the connection operation.</value>
        public string Password
        {
            set
            {
                this.password = value;
            }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            InstalledProductManager mgr = new InstalledProductManager();
            ProductList products = mgr.GetInstalledProducts(this.machineName, this.username, this.password);
            this.installedProductsXml = mgr.ConvertToXml(products);
        }

        /// <summary>
        /// The list of products installed on the specified machine.
        /// </summary>
        /// <value>The list of products installed on the specified machine</value>
        [Output]
        public string[] InstalledProductsXml
        {
            get
            {
                return new string[] { this.installedProductsXml };
            }
        }

        /// <summary>
        /// Initializes a new instance of the GetInstalledProducts class.
        /// </summary>
        public GetInstalledProducts()
        {
        }
    }
}