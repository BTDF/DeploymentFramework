//-----------------------------------------------------------------------
// <copyright file="Email.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Chris Williams</author>
// <email>andyr</email>
// <date>2004-03-23</date>
// <summary>Send an email message</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks
{
    using System;
    using System.Xml;
    using System.Globalization;
    //using System.Web.Mail;
    using System.Net.Mail;
    using System.Text;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Sends an email message
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[ <Email MailTo="mailTo" MailFrom="mailFrom" SmtpServer="smtpServer" Subject="subject" Body="body" Format="format" Priority="priority" Attachments="attachments"  />
    /// ]]></code>
    /// <para><i>mailTo (Required)</i></para>
    /// <para>The email address to send the email to.
    /// </para>
    /// <para><i>mailFrom (Required)</i></para>
    /// <para>The email address to send the email from.
    /// </para>
    /// <para><i>smtpServer (Required)</i></para>
    /// <para>The SMTP server to use to send the email.
    /// </para>
    /// <para><i>subject (Required)</i></para>
    /// <para>The subject of the email.
    /// </para>
    /// <para><i>body</i></para>
    /// <para>The body of the email.
    /// </para>
    /// <para><i>format</i></para>
    /// <para>The text encoding format of the email. Defaults to "HTML".
    /// </para>
    /// <para><i>priority</i></para>
    /// <para>The priority of the email. Defaults to "Normal".
    /// </para>
    /// <para><i>attachments</i></para>
    /// <para>A list of full paths of files to attach to the email.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///                 <Email MailTo="myDeveloper@myCompany.com;bob@myCompany.com" 
    ///                        MailFrom="buildServer@myCompany.com" 
    ///                        SmtpServer="mySmtpServer" 
    ///                        Subject="Build succeeded" 
    ///                        Body="Your changes have been successfully built." 
    ///                        Format="HTML" 
    ///                 />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Email : TaskBase
    {
        private string smtpServer = String.Empty;
        private string mailFrom = String.Empty;
        private string[] mailTo = new string[0];
        private string subject = String.Empty;
        private string[] attachments = new string[0];
        private string priority = "Normal";
        private string format = "HTML";
        private string body = String.Empty;

        /// <summary>
        /// Initializes a new instance of the Email class.
        /// </summary>
        public Email()
        {
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            Log.LogMessageFromResources("Email.To", mailTo);

            SmtpClient client = new SmtpClient(smtpServer);
            client.UseDefaultCredentials = true;

            //MailMessage msg = new MailMessage(mailFrom, mailTo);
            MailMessage msg = new MailMessage();
            msg.From = new MailAddress(this.MailFrom);
            
            foreach(string mail in this.MailTo)
            {
               msg.To.Add(new MailAddress(mail));
            }
            
            foreach (string attachmentPath in this.attachments)
            {
                Attachment attachment = new Attachment(attachmentPath);
                msg.Attachments.Add(attachment);
                
            }
            //msg.Priority = (MailPriority)Enum.Parse(typeof(MailPriority), this.priority, true);

            msg.Subject = this.subject;

            if (this.format.ToUpperInvariant() == "HTML")
            {
                msg.IsBodyHtml = true;
                StringBuilder sb = new StringBuilder();
                sb.Append("<html><body style='font-family:Verdana;font-size:10pt;'>");
                sb.Append(this.body);
                sb.Append("<hr>");
                sb.Append("<div style='font-family:Verdana;font-size:8pt;'>");
                sb.Append(String.Format(CultureInfo.InvariantCulture, "Current user:    {0}<br>", Environment.UserName));
                sb.Append(String.Format(CultureInfo.InvariantCulture, "Current machine: {0}<br>", Environment.MachineName));
                sb.Append(String.Format(CultureInfo.InvariantCulture, "Current path:    {0}<br>", Environment.CurrentDirectory));
                sb.Append("</body><html>");
                msg.Body = sb.ToString();
            }
            else
            {
                msg.Body = this.body;
            }

            client.Send(msg);
        }

        /// <summary>
        /// The SMTP server to use to send the email.
        /// </summary>
        /// <value>The SMTP server to use to send the email.</value>
        [Required]
        public string SmtpServer
        {
            get
            {
                return smtpServer;
            }
            set
            {
                smtpServer = value;
            }
        }

        /// <summary>
        /// The email address to send the email from.
        /// </summary>
        /// <value>The email address to send the email from.</value>
        [Required]
        public string MailFrom
        {
            get
            {
                return mailFrom;
            }
            set
            {
                mailFrom = value;
            }
        }

        /// <summary>
        /// The email address to send the email to.
        /// </summary>
        /// <value>The email address to send the email to.</value>
        [Required]
        public string[] MailTo
        {
            get
            {
                return mailTo;
            }
            set
            {
                mailTo = value;
            }
        }

        /// <summary>
        /// The subject of the email.
        /// </summary>
        /// <value>The subject of the email.</value>
        [Required]
        public string Subject
        {
            get
            {
                return subject;
            }
            set
            {
                subject = value;
            }
        }

        /// <summary>
        /// The priority of the email.
        /// </summary>
        /// <value>The priority of the email. Defaults to "Normal".</value>
        public string Priority
        {
            get
            {
                return this.priority;
            }
            set
            {
                this.priority = value;
            }
        }

        /// <summary>
        /// The body of the email.
        /// </summary>
        /// <value>The body of the email.</value>
        public string Body
        {
            get
            {
                return this.body;
            }
            set
            {
                this.body = value;
            }
        }
        
        /// <summary>
        /// The text encoding format of the email.
        /// </summary>
        /// <value>The text encoding format of the email. Defaults to "HTML".</value>
        public string Format
        {
            get
            {
                return this.format;
            }
            set
            {
                this.format = value;
            }
        }

        /// <summary>
        /// A list of full paths of files to attach to the email.
        /// </summary>
        /// <value>A list of full paths of files to attach to the email.</value>
        public string[] Attachments
        {
            get
            {
                return this.attachments;
            }
            set
            {
                this.attachments = value;
            }
        }
    }
}
