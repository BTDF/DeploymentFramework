//-----------------------------------------------------------------------
// <copyright file="InstallMsiTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-06-01</date>
// <summary>Tests msi installation and removal</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the msi installation/removal tasks
    /// </summary>
    [TestClass]
    public class InstallMsiTest
    {
        /// <summary>
        /// a path to a dummy msi file - copy file from Main\Src\Samples\MSI
        /// </summary>
        private const string MSIPATH = @"C:\downloads\sample.msi";

        /// <summary>
        /// The name of the log file
        /// </summary>
        private const string MSILOGPATH = @"C:\downloads\sample.log";

        /// <summary>
        /// basic constructor
        /// </summary>
        public InstallMsiTest()
        {
        }

        /// <summary>
        /// Test Msi Install Task
        /// </summary>
        [TestMethod]
        [Ignore]
        public void TestMsiInstall()
        {
            Tasks.Msi.Install installMsiTask = new Tasks.Msi.Install();
            
            installMsiTask.Features = null;
            installMsiTask.LoadUserProfile = true;
            installMsiTask.MsiPath = MSIPATH;
            //// installMsiTask.ProductCode = PRODUCT_CODE;
            //// installMsiTask.Properties = 
            //// installMsiTask.PropertyFiles = 
            installMsiTask.LogFile = MSILOGPATH;
            installMsiTask.UserInterfaceLevel = Tasks.Msi.MsiTaskBase.MsiExecUILevel.None;
            //// installMsiTask.LogOptions = Tasks.Msi.MsiTaskBase.MsiLoggingOptions.Verbose;

            bool installTaskReturnValue = installMsiTask.Execute();

            //// Test the task executed correctly
            Assert.IsTrue(installTaskReturnValue, "InstallMsiTaskSucceeded");

            Tasks.Msi.Uninstall uninstallMsiTask = new Tasks.Msi.Uninstall();
            uninstallMsiTask.LoadUserProfile = true;
            uninstallMsiTask.MsiPath = MSIPATH;
            uninstallMsiTask.LogFile = MSILOGPATH;

            bool uninstallTaskReturnValue = uninstallMsiTask.Execute();

            // Test the task executed correctly
            Assert.IsTrue(uninstallTaskReturnValue, "UninstallMsiTaskSucceeded");

            Tasks.Msi.EmbedInstallProperties embedTask = new Microsoft.Sdc.Tasks.Msi.EmbedInstallProperties();
            embedTask.Features = null;
            embedTask.LoadUserProfile = true;
            embedTask.MsiPath = MSIPATH;
            //// installMsiTask.ProductCode = PRODUCT_CODE;
            embedTask.Properties = new string[] { "SlamData=" + DateTime.Now.ToString() };
            //// installMsiTask.PropertyFiles = 
            embedTask.LogFile = MSILOGPATH;
            embedTask.UserInterfaceLevel = Tasks.Msi.MsiTaskBase.MsiExecUILevel.None;
            embedTask.EmbedProperties = true;
            //// installMsiTask.LogOptions = Tasks.Msi.MsiTaskBase.MsiLoggingOptions.Verbose;

            bool embedTaskReturnValue = embedTask.Execute();

            Assert.IsTrue(embedTaskReturnValue, "EmbedInstallMsiTaskFailed");

            Tasks.Msi.EmbedUninstallProperties embed2Task = new Microsoft.Sdc.Tasks.Msi.EmbedUninstallProperties();
            embed2Task.LoadUserProfile = true;
            embed2Task.MsiPath = MSIPATH;
            //// installMsiTask.ProductCode = PRODUCT_CODE;
            embed2Task.Properties = new string[] { "SlamData2=" + DateTime.Now.ToString() };
            //// installMsiTask.PropertyFiles = 
            embed2Task.LogFile = MSILOGPATH;
            embed2Task.UserInterfaceLevel = Tasks.Msi.MsiTaskBase.MsiExecUILevel.None;
            embed2Task.EmbedProperties = true;
            //// installMsiTask.LogOptions = Tasks.Msi.MsiTaskBase.MsiLoggingOptions.Verbose;

            embedTaskReturnValue = embed2Task.Execute();

            Assert.IsTrue(embedTaskReturnValue, "EmbedUninstallMsiTaskFaile");

        }

        /// <summary>
        /// Test that unintialized Install Task fails
        /// </summary>
        [TestMethod]
        public void TestUninitializedInstallTaskFails()
        {
            Tasks.Msi.Install task = new Tasks.Msi.Install();

            try
            {
                bool taskReturnValue = task.Execute();
                Assert.Fail("Uninitialised tasks should not succeed.");
            }
            catch (ApplicationException)
            {
                Console.WriteLine("Correctly threw exception");
                Console.WriteLine(((PseudoBuildEngine) task.BuildEngine).PreviousMessage);
            }
        }

        /// <summary>
        /// Test that unintialized Uninstall Task fails
        /// </summary>
        [TestMethod]
        public void TestUninitializedUnInstallTaskFails()
        {
            Tasks.Msi.Uninstall task = new Tasks.Msi.Uninstall();
           
            try
            {
                bool taskReturnValue = task.Execute();
                Assert.Fail("Uninitialised tasks should not succeed.");
            }
            catch (ApplicationException)
            {
                Console.WriteLine("Correctly threw exception");
                Console.WriteLine(((PseudoBuildEngine) task.BuildEngine).PreviousMessage);
            }
        }

        /// <summary>
        /// Test that unintialized EmbedInstallProperties Task fails
        /// </summary>
        [TestMethod]
        public void TestUninitializedEmbedInstallPropertiesTaskFails()
        {
            Tasks.Msi.EmbedInstallProperties task = new Tasks.Msi.EmbedInstallProperties();

            try
            {
                bool taskReturnValue = task.Execute();
                Assert.Fail("Uninitialised tasks should not succeed.");
            }
            catch (ApplicationException)
            {
                Console.WriteLine("Correctly threw exception");
                Console.WriteLine(((PseudoBuildEngine)task.BuildEngine).PreviousMessage);
            }
        }

        /// <summary>
        /// Test that unintialized EmbedUninstallProperties Task fails
        /// </summary>
        [TestMethod]
        public void TestUninitializedEmbedUninstallPropertiesTaskFails()
        {
            Tasks.Msi.EmbedUninstallProperties task = new Tasks.Msi.EmbedUninstallProperties();

            try
            {
                bool taskReturnValue = task.Execute();
                Assert.Fail("Uninitialised tasks should not succeed.");
            }
            catch (ApplicationException)
            {
                Console.WriteLine("Correctly threw exception");
                Console.WriteLine(((PseudoBuildEngine)task.BuildEngine).PreviousMessage);
            }
        }
    }
}
