/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.SqlServer {
	using System;
    using System.Globalization;

	/// <summary>
	/// Summary description for Login.
	/// </summary>
	internal sealed class Login  {
		private Login() {			
		}

		static public bool Exists(string name){
			return Exists(name, "localhost");
		}

		static public bool Exists(string loginName, string serverName){
            return ScriptExecutor.ExecuteExistsScript(
                "master",
                serverName,
                "EXEC sp_helplogins N'{0}'",
                loginName );
		}

        static public bool Exists(string loginName, string serverName, int connectionTimeOut, int commandTimeOut)
        {
            return ScriptExecutor.ExecuteExistsScript(
                "master",
                serverName,
                "EXEC sp_helplogins N'{0}'",
                loginName );
        }

        static public bool ExistsWithConnectionString(string loginName, string connectionString)
        {
            return ScriptExecutor.ExecuteExistsScriptSpecifyConnection(
                connectionString, 
                "EXEC sp_helplogins N'{0}'",
                loginName );
        }

		static public void Delete(string name) {
			Delete(name, "localhost");
		}

		static public void Delete(string loginName, string serverName){
            ScriptExecutor.ExecuteActionScript(
                "master",
                serverName,
                "EXEC sp_revokelogin N'{0}'",
                loginName );
		}		

        static public void DeleteWithConnectionString(string loginName, string connectionString)
        {
            ScriptExecutor.ExecuteActionScriptSpecifyConnection(
                connectionString,
                "EXEC sp_revokelogin N'{0}'",
                loginName );
        }		

		static public void Create(string name)
        {
			Create(name, "localhost");
		}

		static public void Create(string loginName, string serverName){
            ScriptExecutor.ExecuteActionScript(
                "master",
                serverName,
                "EXEC sp_grantlogin N'{0}'; EXEC sp_defaultdb N'{0}', N'master'; EXEC sp_defaultlanguage N'{0}', N'us_english'",
                loginName );
        }

        static public void Create(string loginName, string serverName, string databaseName)
        {
            ScriptExecutor.ExecuteActionScript(
                "master",
                serverName,
                "EXEC sp_grantlogin N'{0}'; EXEC sp_defaultdb N'{0}', N'{1}'; EXEC sp_defaultlanguage N'{0}', N'us_english'",
                loginName,
                databaseName);
        }

        static public void CreateWithConnectionString(string loginName, string connectionString)
        {
            ScriptExecutor.ExecuteActionScriptSpecifyConnection(
                connectionString,
                "EXEC sp_grantlogin N'{0}'; EXEC sp_defaultdb N'{0}', N'master'; EXEC sp_defaultlanguage N'{0}', N'us_english'",
                loginName );        
        }

        static public void CreateWithConnectionString(string loginName, string connectionString, string databaseName)
        {
            ScriptExecutor.ExecuteActionScriptSpecifyConnection(
                connectionString,
                "EXEC sp_grantlogin N'{0}'; EXEC sp_defaultdb N'{0}', N'{1}'; EXEC sp_defaultlanguage N'{0}', N'us_english'",
                loginName,
                databaseName);        
        }

	}
}
