﻿//-----------------------------------------------------------------------
// <copyright file="Decompile.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Reeves</author>
// <email>andyr</email>
// <date>2004-07-01</date>
// <summary>Decompiles a chm file.</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Help
{
    #region Using directives
    using System;
    using System.Xml;
    using System.Globalization;
    using System.IO;
    using System.Text.RegularExpressions;
    using Microsoft.Win32;
    using Microsoft.Build.Framework;
    using Microsoft.Build.Tasks;
    using Microsoft.Build.Utilities;

    #endregion
    /// <summary>
    /// Decompiles a chm file into the specified folder.
    /// </summary>          
    /// <remarks>
    /// <code><![CDATA[
    /// <Help.Decompile DestinationFolder="folder"
    ///              ChmFilePath="chmFilePath">
    /// </Help.Decompile>
    /// ]]></code>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Decompile : Microsoft.Sdc.Tasks.Tools.ToolTaskBase
    {
        /// <summary>
        /// Initializes a new instance of the Decompile class.
        /// </summary>
        public Decompile()
        {
        }

        /// <summary>
        /// The full path to a chm file
        /// </summary>
        /// <value>Must be a full path.</value>
        [Required]
        public string ChmFilePath
        {
            get { return (string)Bag["ChmFilePath"]; }
            set { Bag["ChmFilePath"] = value; }
        }

        /// <summary>
        /// The folder where the decompiled chm file will be.
        /// </summary>
        /// <value>Must be a full path.</value>
        [Required]
        public string DestinationFolder
        {
            get { return (string)Bag["DestinationFolder"]; }
            set { Bag["DestinationFolder"] = value; }
        }

        /// <summary>
        /// The name of the exe we call.
        /// </summary>
        /// <value>The name of the exe we call.</value>
        protected override string ToolName
        {
            get { return "hh.exe"; }
        }

        /// <summary>
        /// Builds the commandline for this tool
        /// </summary>
        /// <param name="commandLine">The object to append the args to.</param>
        /// <returns>True if successfully added args.</returns>
        protected override void AddCommandLineCommands(CommandLineBuilderExtension commandLine)
        {
            commandLine.AppendSwitch("-decompile");
            commandLine.AppendSwitch(this.DestinationFolder);
            commandLine.AppendSwitch(this.ChmFilePath);
        }

        /// <summary>
        /// Full calculated path to tool including exe name
        /// </summary>
        /// <returns>Defaults to default install location of hh.exe</returns>
        protected override string GenerateFullPathToTool()
        {
            //c:\windows\hh.exe
            string path = System.Environment.GetEnvironmentVariable("WINDIR");
            return System.IO.Path.Combine(path, this.ToolName);
        }
    }
}