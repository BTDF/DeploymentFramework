namespace Microsoft.Sdc.Tasks.BizTalk2004.Rules
{
    using System;
    using System.Collections;
    using Microsoft.Build.Framework;
    using Microsoft.RuleEngine;
    using Microsoft.RuleEngine.RemoteUpdateService;
    using System.Globalization;

    /// <summary>
    /// Import a Rule policy from the RulesEngine database
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2004.Rules.Import AssemblyPath="policyfile" RulesServer="server" RulesDatabase="database" />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>AssemblyPath (Required)</i></para>
    /// <para>
    /// The assemblypath of the rule policy. (Mostly an XML File)
    /// </para>
    /// <para><i>RulesServer</i></para>
    /// <para>
    /// The name of the BizTalk RulesEngine database server. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// <para><i>RulesDatabase</i></para>
    /// <para>
    /// The name of the BizTalk RulesEngine database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <ItemGroup>
    ///         <BTRulesItem Include="C:\RulesPolicy.xml">
    ///     </ItemGroup>
    ///     <Target Name="Test" >
    ///         <BizTalk2004.Rules.Import
    ///             AssemblyPath="%(RulesPolicies.FullPath)"
    ///             Server="." 
    ///             Database="BizTalkRulesDb">
    ///         </BizTalk2004.Rules.Import>
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Import : TaskBase
    {

        #region Private Members

        private string rulesDatabase;
        private string rulesServer;
        private string assemblyPath;

        #endregion

        #region Public Properties

        /// <summary>
        /// Gets or sets the path to the assembly to deploy.
        /// </summary>
        /// <value>
        /// The path to the assembly to deploy.
        /// </value>
        [Required]
        public string AssemblyPath
        {
            get
            {
                return this.assemblyPath;
            }
            set
            {
                this.assemblyPath = value;
            }
        }

        /// <summary>
        /// Gets or sets the name of the BizTalk Rules Engine database.
        /// </summary>
        /// <value>
        /// The name of the BizTalk Rules Engine database.
        /// </value>
        public string RulesDatabase
        {
            get { return this.rulesDatabase; }
            set { this.rulesDatabase = value; }
        }
        
        /// <summary>
        /// Gets or sets the logical name of the server hosting the BizTalk Rules Engine database.
        /// </summary>
        /// <value>
        /// The logical name of the server hosting the BizTalk Rules Engine database.
        /// </value>
        public string RulesServer
        {
            get { return this.rulesServer; }
            set { this.rulesServer = value; }
        }

        #endregion

        protected override void InternalExecute()
        {
            string rulesServer = string.IsNullOrEmpty(this.rulesServer) ? Configuration.DatabaseServer : this.rulesServer;
            string rulesDatabase = string.IsNullOrEmpty(this.rulesDatabase) ? Configuration.DatabaseName : this.rulesDatabase;

            // Get the interface to import / publish / deploy / undeploy rulesets
            IRuleSetDeploymentDriver dd;

            ArrayList list = new ArrayList();
            list.Add(rulesServer);
            list.Add(rulesDatabase);

            try
            {
                // Get the Remote Interface so it is possible to set a remote database
                dd = (IRuleSetDeploymentDriver)RemoteUpdateService.LocateObject(Configuration.DeploymentDriverClass, Configuration.DeploymentDriverDll, list.ToArray());

                // Publish and import the RuleSet
                dd.ImportAndPublishFileRuleStore(this.AssemblyPath);
                Log.LogMessage(string.Format(CultureInfo.InvariantCulture, "Importing and publishing policy : {0}", this.AssemblyPath));
            }
            catch (Exception ex)
            {
                // An error occurred during the location of the object, or the import and publish of 
                // the ruleset

                throw new TaskException(ex, "Microsoft.Sdc.Tasks.BizTalk2004.Rules::Import");
            }
        }
    }
}
