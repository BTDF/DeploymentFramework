//-------------------------------------------------------------------------------------
// <copyright file="Delete.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Deletes a host in a BizTalk Server.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Host
{
    #region Using directives

    using System;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion


    #region Class Comments
    /// <summary>
    /// Deletes a host in a BizTalk Server.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2004.Host.Delete 
    ///                Name="HostName"
    ///                />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>Name (Required)</i></para>
    /// <para>
    /// The name of the host to create.
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// <para><i>username</i></para>
    /// <para>
    /// The username to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// <para><i>password</i></para>
    /// <para>
    /// The password to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///            <BizTalk2004.Host.Delete 
    ///                Name="HostName"
    ///            />
    ///      </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    #endregion
    public class Delete : BizTalk2004TaskBase
    {
        private string name;

        /// <summary>
        /// The name of the host.
        /// </summary>
        /// <value>The name of the host.</value>
        [Required]
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        /// <summary>
        /// Initializes a new instance of the Delete class.
        /// </summary>
        public Delete()
        {

        }

        /// <summary>
        /// Performs the action for this task
        /// </summary>
        protected override void InternalExecute()
        {
            //getting the installation and creating the new host.
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation installation = this.GetInstallation();
            Host.Delete(installation, this.name);
        }
    }
}
        
