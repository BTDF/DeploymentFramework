//-------------------------------------------------------------------------------------
// <copyright file="PipelineType.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      The type of a pipeline.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	/// <summary>
	/// The type of a pipeline.
	/// </summary>
    public enum PipelineType
    {
		/// <summary>
		/// The type of the pipeline is not known.
		/// </summary>
		Unknown = 0,
		/// <summary>
		/// A receive pipeline.
		/// </summary>
        Receive = 1,
		/// <summary>
		/// A send pipeline.
		/// </summary>
        Send = 2      
    } 
}

