//-----------------------------------------------------------------------
// <copyright file="SleepTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>andyr</email>
// <date>2004-05-25</date>
// <summary>Tests sleep task</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the Sleep Task
    /// </summary>
    [TestClass]
    public class SleepTest
    {
        

        public SleepTest()
        {
        }       

        [TestMethod]
        public void TestSleep()
        {
            //Define maximum and minimum timeout lengths
            int MIN_TIMEOUT = 100;
            int MAX_TIMEOUT = 500;

            Tasks.Sleep task = new Tasks.Sleep();
           

            Random randomObj = new Random();
            int sleepTimeout = randomObj.Next(MIN_TIMEOUT, MAX_TIMEOUT);

            task.SleepTimeout = sleepTimeout;

            bool taskReturnValue = task.Execute();

            Assert.IsTrue(taskReturnValue);
            Assert.IsTrue( task.SleepTimeout == sleepTimeout);

        }
    }
}


