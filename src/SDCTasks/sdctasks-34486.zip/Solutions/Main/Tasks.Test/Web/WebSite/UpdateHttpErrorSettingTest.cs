﻿//-----------------------------------------------------------------------
// <copyright file="VirtualDirectoryTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Patrick Long</author>
// <email>v-plong</email>
// <date>2004-09-02</date>
// <summary>Tests the updating of Custom Error page settings</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.Configuration.Web;
    using Microsoft.Sdc.Tasks.Web;

    /// <summary>
    /// Unit test for the update to HttpError config
    /// </summary>
    [TestClass]
    public class UpdateHttpErrorSettingTest
    {
        public UpdateHttpErrorSettingTest()
        {
        }             

        [TestMethod]
        public void SetVDir404ToUrl()
        {
            Console.Out.WriteLine("HEllo1");

            //Create a temporary directory
            string tempDirectory = TaskTestUtilities.CreateTempFolder();

            //Create a virtual directory
            Tasks.Web.WebSite.CreateVirtualDirectory createdVirtualDirectory = new Tasks.Web.WebSite.CreateVirtualDirectory();
            createdVirtualDirectory.Path = tempDirectory;
            string virtualDirectoryName = TaskTestUtilities.GenerateNewGuid().Replace("-", "");
            createdVirtualDirectory.VirtualDirectoryName = virtualDirectoryName;

            Console.Out.WriteLine("HEllo2");

            //Attempt to create it with a task
            bool createVirtualDirectorySuccess = createdVirtualDirectory.Execute();
            Assert.IsTrue(createVirtualDirectorySuccess, "CreateVirtualDirectory");

            Console.Out.WriteLine("HEllo3");

            //Ensure it exists
            Assert.IsTrue(VirtualDirectory.Exists(createdVirtualDirectory.VirtualDirectoryName, 1, "localhost"), "VirtualDirectoryExists");

            Console.Out.WriteLine("HEllo4");

            //VDirectory exists now try updating the HttpErrors of it
            Tasks.Web.WebSite.UpdateHttpErrorSetting updatedHttpErrorSetting = new Microsoft.Sdc.Tasks.Web.WebSite.UpdateHttpErrorSetting();

            Console.Out.WriteLine("HEllo5");

            updatedHttpErrorSetting.DirectoryType = Microsoft.Sdc.Tasks.Web.WebSite.UpdateHttpErrorSetting.IisDirectoryType.VirtualWebDir.ToString();
            updatedHttpErrorSetting.ErrorCode = 404;
            updatedHttpErrorSetting.SubErrorCode = "*";
            updatedHttpErrorSetting.Type = "URL";
            updatedHttpErrorSetting.Uri = "/Errors/Error.htm";
            updatedHttpErrorSetting.DirectoryName = virtualDirectoryName;

            bool updatedHttpErrorSettingSuccess = updatedHttpErrorSetting.Execute();
            Assert.IsTrue(updatedHttpErrorSettingSuccess, "UpdateHttpErrorSetting");

            Console.Out.WriteLine("HEllo6");

            //Ensure it has been changed
            VirtualDirectory vd = WebSite.Load("localhost",1).VirtualDirectories[virtualDirectoryName];
             
            HttpError errorSetting = vd.HttpErrors.GetHttpErrorFromErrorCode(404);

            Console.Out.WriteLine("HEllo7");

            Assert.IsTrue(errorSetting.Uri == "/Errors/Error.htm", "UriUpdated");
            Assert.IsTrue(errorSetting.Type == "URL", "TypeUpdated");

            //Remove the virtual directory
            Tasks.Web.WebSite.DeleteVirtualDirectory deletedVirtualDirectory = new Tasks.Web.WebSite.DeleteVirtualDirectory();
            deletedVirtualDirectory.VirtualDirectoryName = createdVirtualDirectory.VirtualDirectoryName;
            bool deleteVirtualDirectorySuccess = deletedVirtualDirectory.Execute();

            //Ensure task success
            Assert.IsTrue(deleteVirtualDirectorySuccess, "VirtualDirectoryDeleted");
            
            //Delete the directory
            Directory.Delete(tempDirectory, true);
        }
    }
}


