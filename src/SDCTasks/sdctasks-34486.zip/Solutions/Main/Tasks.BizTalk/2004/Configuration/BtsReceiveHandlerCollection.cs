﻿namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;

    #endregion

    internal class BtsReceiveHandlerCollection : System.Collections.ReadOnlyCollectionBase
    {
        public BtsReceiveHandlerCollection() { }

        public BtsReceiveHandler this[string name]
        {
            get
            {
                BtsReceiveHandler item = null;
                foreach (BtsReceiveHandler currentitem in this.InnerList)
                {
                    if (currentitem.Name == name)
                    {
                        item = currentitem;
                        break;
                    }
                }
                return item;

            }
        }
        public BtsReceiveHandler this[int index]
        {
            get
            {
                return (BtsReceiveHandler)this.InnerList[index];
            }
        }

        internal void Add(BtsReceiveHandler item)
        {
            this.InnerList.Add(item);
        }


    }

}
