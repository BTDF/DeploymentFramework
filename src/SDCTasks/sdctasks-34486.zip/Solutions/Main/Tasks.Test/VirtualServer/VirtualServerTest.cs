//-----------------------------------------------------------------------
// <copyright file="CreateFTPTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Ashter Chomoko</author>
// <email>ashter_chomoko@charteris.com</email>
// <date>2004-06-07</date>
// <summary>Unit test for Virtual Server</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for Virtual Server Tasks
    /// </summary>
    [TestClass]
    public class VirtualServerTest
    {
        
        private string MACHINENAME = "TestVirtualMachine";
        private string SERVERNAME = "";

        public VirtualServerTest()
        {
        }

        [TestMethod]
        public void TestErrorCondition()
        {
        }

        [TestMethod]
        [Ignore]//("Please complete with bug #")]
        public void TestSuccess()
        {
            VirtualServer.VirtualMachine.Start startTask = new VirtualServer.VirtualMachine.Start();
            startTask.MachineName = MACHINENAME;
            startTask.ServerName = SERVERNAME;
            startTask.Execute();

//          VirtualServer.VirtualMachine.OS.CheckOS checkOSTask = new VirtualServer.VirtualMachine.CheckOS();
//          checkOSTask.BuildEngine = pseudoBuildEngine;
//          checkOSTask.MachineName = MACHINENAME;
//          checkOSTask.ServerName = SERVERNAME;
//          checkOSTask.Execute();

            VirtualServer.VirtualMachine.Stop stopTask = new VirtualServer.VirtualMachine.Stop();
            stopTask.MachineName = MACHINENAME;
            stopTask.ServerName = SERVERNAME;
            stopTask.Execute();
        }

    }
}
