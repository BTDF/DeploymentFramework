//-------------------------------------------------------------------------------------
// <copyright file="Delete.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Deletes a host in a BizTalk Server.
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.SendHandler
{
    #region Using directives
    using System;
    using System.Globalization;
    using System.Management;
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    #endregion

    /// <summary>
    /// Deletes a send handler in a BizTalk Server.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2006.SendHandler.Delete 
    ///                HostName="HostName"
    ///                TransportType="FILE"
    ///                />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>HostName (Required)</i></para>
    /// <para>
    /// The name of the host where the handler to delete exists.
    /// </para>
    /// <para><i>TransportType (Required)</i></para>
    /// <para>
    /// The transport type of the handler - FILE, FTP etc.
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// <para><i>username</i></para>
    /// <para>
    /// The username to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// <para><i>password</i></para>
    /// <para>
    /// The password to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///            <BizTalk2006.SendHandler.Delete 
    ///                HostName="HostName"
    ///                TranportType="FILE"
    ///            />
    ///      </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Delete : BizTalk2004TaskBase
    {
        private string hostName;
        private string transportType;

        /// <summary>
        /// The name of the host to add the handler to.
        /// </summary>
        /// <value>The name of the host.</value>
        [Required]
        public string HostName
        {
            get { return this.hostName; }
            set { this.hostName = value; }
        }

        /// <summary>
        /// The transport type, e.g. FILE, SQL, SOAP etc
        /// </summary>
        /// <value>The type of the transport.</value>
        [Required]
        public string TransportType
        {
            get { return this.transportType; }
            set { this.transportType = value; }
        }

        /// <summary>
        /// Performs the action for this task
        /// </summary>
        protected override void InternalExecute()
        {
            BizTalkInstallation installation = this.GetInstallation();

            try
            {
                Log.LogMessage(string.Format(CultureInfo.InvariantCulture, "Deleting send handler: {0} on Host {1}", this.transportType, this.hostName));
                string query = "SELECT * FROM MSBTS_SendHandler2 WHERE AdapterName =\"" + this.transportType + "\" AND HostName = \"" + this.hostName + "\"";
                ManagementScope scope = ManagementHelper.GetManagementScope(installation);
                ManagementObjectSearcher searcherSendHandler = new ManagementObjectSearcher(scope, new WqlObjectQuery(query), null);

                if (searcherSendHandler.Get().Count > 0)
                {
                    foreach (ManagementObject objSendHandler in searcherSendHandler.Get())
                    {
                        objSendHandler.Delete();
                    }
                }
            }
            catch (Exception ex)
            {
                Log.LogError(string.Format(CultureInfo.InvariantCulture, "Delete SendHandler: {0} - failed {1}", this.transportType, ex.Message));
                return;
            }
        }
    }
}
        
