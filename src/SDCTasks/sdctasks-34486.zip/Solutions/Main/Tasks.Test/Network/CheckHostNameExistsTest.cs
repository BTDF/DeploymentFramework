using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Sdc.Tasks.Network;
//-----------------------------------------------------------------------
// <Deleteright file="CheckHostNameExistsTest.cs" company="Microsoft">
// Deleteright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </Deleteright>
// <author>Martin peck</author>
// <email>mpeck</email>
// <date>2006-02-21</date>
// <summary>Tests CheckHostNameExists task</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using System.Text;
    using System.Configuration;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Network;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;
    using Microsoft.Build.Utilities;

    /// <summary>
    /// 
    /// </summary>
    [TestClass]
    public class CheckHostNameExistsTest
    {
        public CheckHostNameExistsTest()
        {
        }

        /// <summary>
        /// Performs a GetIPByName
        /// </summary>
        [TestMethod]
        public void TestCheckHostNameExists()
        {
            string hostname = ConfigurationManager.AppSettings["TestGetIPByNameHost"];

            CheckHostNameExists task = new CheckHostNameExists();
            task.HostName = hostname;
            task.Execute();

            Assert.IsTrue(task.HostExists, "HostExists should return true for {0}", hostname);
        }

        /// <summary>
        /// Performs a GetIPByName with a bad hostname
        /// </summary>
        [TestMethod]        
        public void TestCheckHostNameExistsBad()
        {
            string hostname = ConfigurationManager.AppSettings["TestGetIPByNameHostBad"];

            CheckHostNameExists task = new CheckHostNameExists();
            task.HostName = hostname;
            task.Execute();
            Assert.IsFalse(task.HostExists, "HostExists should return false for {0}", hostname);
        }
    }
}


