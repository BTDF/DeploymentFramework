﻿namespace Microsoft.Sdc.Tasks.BizTalk2004.TransportData
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion


    public class SoapTransportData : TransportDataBase
    {
        #region member variables


        private string uri;

        private string addressableuri;
        private bool usesso;


        private string username;
        private string password;
        private string clientcertificate;
        private string affliateapplicationname;
        private bool useproxy;
        private string proxyaddress;
        private int proxyport;
        private string proxyusername;
        private string proxypassword;

#endregion


        #region common properties

        /// <summary>
        /// Virtual directory containing the Web service on the deployment server.
        /// </summary>
        /// 
        public string URI
        {
            get { return this.uri; }
            set { this.uri = value; }
        }


        #endregion

        #region Receive Location properties

        /// <summary>
        /// Public address field containing the entire, callable URL. 
        /// </summary>
        public string AddressableURI
        {
            get { return this.addressableuri; }
            set { this.addressableuri = value; }
        }


        /// <summary>
        /// Specifies whether the Soap adapter will issue the SSO ticket to messages that arrive.
        /// </summary>
        public bool UseSSO
        {
            get { return this.usesso; }
            set { this.usesso = value;  }
        }

        #endregion

        #region Send Port properties

        /// <summary>
        /// User name to specify for accessing the target Web service. 
        /// </summary>
        public new string Username
        {
            get { return this.username; }
            set { this.username = value; }
        }


        /// <summary>
        /// User password to use for authentication with the server.  
        /// </summary>
        public new string Password
        {
            get { return this.password; }
            set { this.password = value; }
        }


        /// <summary>
        /// Thumbprint of client SSL certificate. 
        /// </summary>
        public string ClientCertificate
        {
            get { return this.clientcertificate; }
            set { this.clientcertificate = value; }
        }


        /// <summary>
        /// The name of the SSO application to use to redeem the ticket for client credentials. 
        /// The <b>AffiliateApplicationName</b> is mutually exclusive to a <b>Username></b> and <b>Password</b> pair.
        /// </summary>
        public string AffiliateApplicationName
        {
            get { return this.affliateapplicationname; }
            set { this.affliateapplicationname = value;  }
        }


        /// <summary>
        /// Indicates whether the SOAP send port uses a proxy server to access the target Web service. 
        /// </summary>
        public bool UseProxy
        {
            get { return this.useproxy; }
            set { this.useproxy = value; }
        }


        /// <summary>
        /// Address of the HTTP proxy to use for the Web service call. 
        /// </summary>
        public string ProxyAddress
        {
            get { return this.proxyaddress;  }
            set { this.proxyaddress = value; }
        }


        /// <summary>
        /// Port of the HTTP proxy to use for the Web service call. 
        /// </summary>
        public int ProxyPort
        {
            get { return this.proxyport; }
            set { this.proxyport = value; }
        }


        /// <summary>
        /// User name to use for the proxy. 
        /// </summary>
        public string ProxyUsername
        {
            get { return this.proxyusername; }
            set { this.proxyusername = value;  }
        }


        /// <summary>
        /// Password to use for the proxy.
        /// </summary>
        public string ProxyPassword
        {
            get { return this.proxypassword;  }
            set { this.proxypassword = value; }
        }

        #endregion

        #region methods

        public SoapTransportData()
        {

        }

        protected override void InternalExecute()
        {
            Configuration.BizTalkInstallation installation = this.GetInstallation();
            Configuration.TransportDataParentType _parentType = (TransportDataParentType)Enum.Parse(typeof(TransportDataParentType), this.ParentType);

            Configuration.SoapTransport soapttransport = new Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SoapTransport(_parentType);

            //comming property
            soapttransport.URI = this.uri;

            switch (_parentType)
            {
                case TransportDataParentType.ReceiveLocation:

                    soapttransport.AddressableURI = this.addressableuri;
                    soapttransport.UseSSO = this.usesso;
                    break;

                case TransportDataParentType.SendPort:

                    soapttransport.Username = this.username;
                    soapttransport.Password = this.password;
                    soapttransport.ClientCertificate = this.clientcertificate;
                    soapttransport.AffiliateApplicationName = this.affliateapplicationname;
                    soapttransport.UseProxy = this.useproxy;
                    soapttransport.ProxyAddress = this.proxyaddress;
                    soapttransport.ProxyPort = this.proxyport;
                    soapttransport.ProxyUsername = this.proxyusername;
                    soapttransport.ProxyPassword = this.proxypassword;

                    break;

            }

            this.TransportDataXml = soapttransport.GetTransportXml();
        }
        #endregion

    }
}

