//-------------------------------------------------------------------------------------
// <copyright file="SchemaCollection.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      A collection of BizTalk 2004 objects.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using directives

    using System;
    using System.Collections;

	#endregion

    /// <summary>
    /// A collection of <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/> objects.
    /// </summary>
    internal class SchemaCollection : CollectionBase
    {
		#region Constructors

        /// <summary>
        /// Creates a new collection of <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/> objects.
        /// </summary>
        public SchemaCollection()
        {
        }

		#endregion

		#region Indexers

        /// <summary>
        /// Gets or sets the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/> at a specified 
        /// position within the collection.
        /// </summary>
        /// <param name="index">
        /// The zero based index in the collection.
        /// </param>
        /// <value>
        /// A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/>.
        /// </value>
        public Schema this[int index]
        {
            get 
			{ 
				return (Schema)this.List[index]; 
			}
            set 
			{ 
				this.List[index] = value; 
			}
        }

		/// <summary>
		/// Gets or sets the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/> with
		/// a particular name.
		/// </summary>
		/// <param name="name">
		/// The name of the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/>.
		/// </param>
		/// <value>
		/// A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/>.
		/// </value>
		/// <exception cref="System.ArgumentNullException">
		/// Thrown when <paramref name="name"/> is <b>null</b> or zero length.
		/// </exception>
		/// <exception cref="System.ArgumentOutOfRangeException">
		/// Thrown when no object matching <paramref name="name"/> is found in the collection.
		/// </exception>
		public Schema this[string name]
		{
			get 
			{ 
				int index = this.IndexOf(name);
				if (index >= 0)
				{
					return this[index];
				}
				else
				{
					throw new ArgumentOutOfRangeException("No object with the specified name was found.", name, "name");
				}
			}
			set 
			{ 
				int index = this.IndexOf(name);
				if (index >= 0)
				{
					this[index] = value;
				}
				else
				{
					throw new ArgumentOutOfRangeException("No object with the specified name was found.", name, "name");
				}
			}
		}

		#endregion

		#region Methods

        /// <summary>
        /// Adds a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/> to the collection.
        /// </summary>
        /// <param name="schema">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/> to add.
        /// </param>
        public void Add(Schema schema) 
        {
            this.List.Add(schema);
        }

		/// <summary>
		/// Gets whether a particular <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/>
		/// is contained in the collection.
		/// </summary>
		/// <param name="schema">
		/// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/> to check for.
		/// </param>
		/// <returns>
		/// <b>true</b> if <paramref name="schema"/> is contained in the collection, or <b>false</b> otherwise.
		/// </returns>
		public bool Contains(Schema schema) 
		{
			return this.List.Contains(schema);
		}

		/// <summary>
		/// Gets whether a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/> with the
		/// specified name is contained in the collection.
		/// </summary>
		/// <param name="name">
		/// The name of the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/>.
		/// </param>
		/// <returns>
		/// <b>true</b> if an object with the name is contained in the collection, or <b>false</b> otherwise.
		/// </returns>
		public bool Contains(string name)
		{
			int index = this.IndexOf(name);
			return (index != -1);
		}

		/// <summary>
		/// Copies the collection into an <see cref="System.Array"/>.
		/// </summary>
		/// <param name="objects">
		/// The <see cref="System.Array"/> to copy the collection int.
		/// </param>
		/// <param name="index">
		/// The zero based index in the array at which to begin copying.
		/// </param>
		public void CopyTo(Schema[] objects, int index) 
		{
			this.List.CopyTo(objects, index);
		}

		/// <summary>
		/// Gets the index of a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/>.
		/// </summary>
		/// <param name="schema">
		/// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/> to get the index of.
		/// </param>
		/// <returns>
		/// The index of <paramref name="schema"/> if it is contained in the collection, or -1 otherwise.
		/// </returns>
		public int IndexOf(Schema schema) 
		{
			return this.List.IndexOf(schema);
		}

		/// <summary>
		/// Retrieves the index of a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/> from 
		/// the collection with the specified name.
		/// </summary>
		/// <param name="name">
		/// The name of the <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/>.
		/// </param>
		/// <returns>
		/// The index of the item if found, or -1 otherwise.
		/// </returns>
		public int IndexOf(string name)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			for (int index = 0; index < this.List.Count; index++)
			{
				if (((Schema)this.List[index]).Name == name)
				{
					return index;
				}
			}
			return -1;
		}

        /// <summary>
        /// Inserts a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/> into the collection.
        /// </summary>
        /// <param name="index">
        /// The zero based index at which to insert <paramref name="schema"/>.
        /// </param>
        /// <param name="schema">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/> to insert.
        /// </param>
        public void Insert(int index, Schema schema) 
        {
            this.List.Insert(index, schema);
        }

        /// <summary>
        /// Removes a <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/> from the collection.
        /// </summary>
        /// <param name="schema">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Schema"/> to remove.
        /// </param>
        public void Remove(Schema schema) 
        {
            this.List.Remove(schema); 
        }

		#endregion
    }
}

