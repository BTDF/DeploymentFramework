/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Ben Lilley</Author>
  <Date>2007-08-07</Date>
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
using System;

namespace Microsoft.Sdc.Tasks.Configuration.Web
{
    [Flags]
    public enum DirBrowseFlags : long
    {
        None = 0,
        ShowDate = 2,
        ShowExtension = 16,
        ShowLongDate = 32,
        ShowSize = 8,
        ShowTime = 4,
        EnableDefaultDoc = 1073741824,
        EnableDirBrowsing = 2147483648
    }
}
