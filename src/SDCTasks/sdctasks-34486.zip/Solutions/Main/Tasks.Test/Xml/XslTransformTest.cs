//-----------------------------------------------------------------------
// <copyright file="XslTransformTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-06-01</date>
// <summary>Tests xsl transformation</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using System.Security.Cryptography;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the Xsl Transform Task
    /// </summary>
    [TestClass]
    public class XslTransformTest
    {
        private const string XML_FILE = @"TestData\TestXslTransformTask.xml";
        private const string XSL_FILE = @"TestData\TestXslTransformTask.xsl";
        private const string OUTPUT_FILE = @"TestData\Output.htm";
        private const string COMPARISON_FILE = @"TestData\TestXslTransformTask.htm";

        public XslTransformTest()
        {
        }
        
        [TestMethod]
        [Ignore]
        public void TestXslTransform()
        {

            Tasks.Xml.XslTransform xsltTask = new Tasks.Xml.XslTransform();
           
            xsltTask.XmlFile = XML_FILE;
            xsltTask.XslFile = XSL_FILE;
            xsltTask.ResultFile = OUTPUT_FILE;

            bool xsltTaskReturnValue = xsltTask.Execute();

            //Test the task was executed successfully
            Assert.IsTrue(xsltTaskReturnValue, "XslTransformSucceeded");

            //Test the properties are persisted correctly
            Assert.IsTrue(xsltTask.XmlFile == XML_FILE, "XmlFile");
            Assert.IsTrue(xsltTask.XslFile == XSL_FILE, "XslFile");
            Assert.IsTrue(xsltTask.ResultFile == OUTPUT_FILE, "OutputFile");
            
            //Test the output file was created
            Assert.IsTrue(System.IO.File.Exists(OUTPUT_FILE), "OutputFileCreated");

            //Test the contents are as expected
            Assert.IsTrue(CompareFiles(OUTPUT_FILE, COMPARISON_FILE), "FilesDifferent");
        }

        /// <summary>
        /// Compares two files, returning true if they are identical
        /// </summary>
        /// <param name="file1">The first file to compare</param>
        /// <param name="file2">The second file to compare</param>
        /// <returns>True if the files are identical, otherwise false</returns>
        private bool CompareFiles(string file1, string file2)
        {
            Stream stream1 = System.IO.File.OpenRead(file1);
            Stream stream2 = System.IO.File.OpenRead(file2);

            //Create hashes of the two streams
            MD5CryptoServiceProvider hashAlgorithm = new MD5CryptoServiceProvider();
            Byte[] hashValue1 = hashAlgorithm.ComputeHash(stream1);
            Byte[] hashValue2 = hashAlgorithm.ComputeHash(stream2);

            //Close the files and compare the hashes
            stream1.Close();
            stream2.Close();

            string hash1 = BitConverter.ToString(hashValue1);
            string hash2 = BitConverter.ToString(hashValue2);

            if (hash1 == hash2)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

    }
}


