//-----------------------------------------------------------------------
// <copyright file="RemoveReceiveLocation.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.ReceivePort
{
    using BizTalk.ExplorerOM;
    using System.Globalization;

    /// <summary>
    /// Remove ReceiveLocation
    /// </summary>
    public class RemoveReceiveLocation : BizTalk2004.ReceiveLocation.RemoveReceiveLocation
    {
        private string application;

        /// <summary>
        /// Gets or sets the application.
        /// </summary>
        /// <value>The application.</value>
        public string Application
        {
            get { return this.application; }
            set { this.application = value; }
        }

        /// <summary>
        /// Executes the task
        /// </summary>
        protected override void InternalExecute()
        {
            if (string.IsNullOrEmpty(this.Application))
            {
                base.InternalExecute();
            }
            else
            {
                BtsCatalogExplorer explorer = this.GetBtsCatalogExplorer(this.Server, this.Database);

                Application app = explorer.Applications[this.Application];
                if (app != null)
                {
                    ReceivePort port = app.ReceivePorts[this.ReceivePort];
                    if (port != null)
                    {
                        ReceiveLocation loc = port.ReceiveLocations[this.Name];
                        if (loc != null)
                        {
                            if (loc.Enable)
                            {
                                loc.Enable = false;
                            }

                            port.RemoveReceiveLocation(loc);
                            explorer.SaveChanges();
                        }
                        else
                        {
                            Log.LogError(string.Format(CultureInfo.InvariantCulture, "ReceiveLocation not found: {0} for RecievePort: {1}", this.Name, this.ReceivePort));
                            return;
                        }
                    }
                    else
                    {
                        Log.LogError(string.Format(CultureInfo.InvariantCulture, "ReceivePort not found: {0} for Application: {1}", this.ReceivePort, this.Application));
                        return;
                    }
                }
                else
                {
                    Log.LogError(string.Format(CultureInfo.InvariantCulture, "Application not found: {0}", this.Application));
                    return;
                }
            }
        }
    }
}
