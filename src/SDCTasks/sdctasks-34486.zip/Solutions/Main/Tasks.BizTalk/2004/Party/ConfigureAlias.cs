//-------------------------------------------------------------------------------------
// <copyright file="CreateAlias.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Configures an Alias for a Party in Biztalk
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2004.Party
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion

    public class ConfigureAlias : BizTalk2004TaskBase
    {
        #region member variables

        private string partyname;

        private string oldName;
        private string oldQualifier;
        private string oldValue;

        private string newName;
        private string newQualifier;
        private string newValue;

        #endregion


        #region properties


        [Required]
        public string OldName
        {
            get { return this.oldName ; }
            set { this.oldName = value; }
        }


        [Required]
        public string OldQualifier
        {
            get { return this.oldQualifier ; }
            set { this.oldQualifier = value; }
        }


        [Required]
        public string OldValue
        {
            get { return this.oldValue; }
            set { this.oldValue = value; }
        }

        public string NewName
        {
            get { return this.newName; }
            set { this.newName = value; }
        }

        public string NewQualifier
        {
            get { return this.newQualifier; }
            set { this.newQualifier = value; }
        }

        public string NewValue
        {
            get { return this.newValue; }
            set { this.newValue = value; }
        }

        [Required]
        public string PartyName
        {
            get { return this.partyname; }
            set { this.partyname = value; }

        }

        public ConfigureAlias() { }

        #endregion

        protected override void InternalExecute()
        {

            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation installation = this.GetInstallation();
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party party = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.Party.Load(installation, this.partyname);

            if (party != null)
                party.UpdateAlias(this.oldName, this.oldQualifier, this.oldValue, this.newName, this.newQualifier, this.newValue);
            else
                throw new InvalidOperationException("Party does not exist.");

        }
    }
}

