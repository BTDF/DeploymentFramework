This is the CodePlex Readme for SDC Tasks.

There's nothing to read at the moment. I'll add useful information here as time goes on and as people ask questions regarding building or debugging the SDC Tasks.