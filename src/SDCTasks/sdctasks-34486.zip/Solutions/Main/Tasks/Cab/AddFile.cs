//-----------------------------------------------------------------------
// <copyright file="AddFile.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Andy Burns</author>
// <email></email>
// <date>2004-03-23</date>
// <summary>Adds the specified file to the specified cabfile</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Cab
{
    using System;
    using System.Xml;
    using System.Globalization;
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.Configuration;

    /// <summary>
    /// Adds the specified file to the specified cabfile
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<Cab.AddFile PathToCabFile="pathToCabFile" PathToFile="pathToFile" Path="path" Overwrite="overwrite"/>]]></code>
    /// <para>where:</para>
    /// <para><i>pathToCabFile (Required)</i></para>
    /// <para>The path to the cab file that the specified file will be added to.</para>
    /// <para><i>pathToFile (Required)</i></para>
    /// <para>The path to the file that will be added to the specified cab file.</para>
    /// <para><i>path</i></para>
    /// <para>The path to CabArc.exe. This will default to "C:\Program Files\CabArc\CabArc.exe" if not otherwise specified.</para>
    /// <para><i>overwrite</i></para>
    /// <para>Set to true to overwrite files of the same name that exist within the specified archive. If set to false
    /// and a file with the same name is found in the archive, an exception will be thrown.</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///         <Cab.AddFile
    ///             PathToCabFile="C:\Archives\CabFile.cab"
    ///             PathToFile="C:\Assemblies\MyAssembly.dll"
    ///             Path="C:\CabInstall\Cabarc.exe"  />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class AddFile : TaskBase
    {
        private string pathToCabFile = String.Empty;
        private string pathToFile = String.Empty;
        private string path = null;
        private bool overwrite = false;

        /// <summary>
        /// Initializes a new instance of the AddFile class.
        /// </summary>
        public AddFile()
        {
        }

        /// <summary>
        /// The path to the cab file that the specified file will be added to.
        /// </summary>
        /// <value>The path to the cab file that the specified file will be added to.</value>
        [Required]
        public string PathToCabFile
        {
            get
            {
                return (this.pathToCabFile == null ? String.Empty : this.pathToCabFile);
            }

            set
            {
                this.pathToCabFile = value;
            }
        }

        /// <summary>
        /// The path to the file that will be added to the specified cab file.
        /// </summary>
        /// <value>The path to the file that will be added to the specified cab file.</value>
        [Required]
        public string PathToFile
        {
            get
            {
                return (this.pathToFile == null ? String.Empty : this.pathToFile);
            }

            set
            {
                this.pathToFile = value;
            }
        }

        /// <summary>
        /// The path to CabArc.exe. 
        /// </summary>
        /// <value>This will default to "C:\Program Files\CabArc\CabArc.exe" if not otherwise specified.</value>
        public string Path
        {
            get
            {
                return (this.path == null ? String.Empty : this.path);
            }

            set
            {
                this.path = value;
            }
        }

        /// <summary>
        /// Set to true to overwrite files of the same name that exist within the specified archive. If set to false
        /// and a file with the same name is found in the archive, an exception will be thrown.
        /// </summary>
        /// <value>True to overwrite any files of the same name that exist within the archive. Defaults to "false"</value>
        public bool Overwrite
        {
            get
            {
                return this.overwrite;
            }

            set
            {
                this.overwrite = value;
            }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            #region Execute code

            Log.LogMessageFromResources("Cab.Create", this.pathToCabFile);
            Cab.Add(this.pathToCabFile, this.pathToFile, this.path, this.overwrite);
            #endregion
        }
    }
}