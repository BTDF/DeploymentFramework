//-------------------------------------------------------------------------------------
// <copyright file="Exists.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Checks whether an assembly is deployed in a BizTalk installation.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2006.Assembly
{
    #region Using directives

    using BizTalk.ExplorerOM;

    #endregion

    /// <summary>
    /// Checks whether an assembly is deployed in a BizTalk installation.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2006.Assembly.Exists DisplayName="displayName" Server="server" Database="database" />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>displayName (Required)</i></para>
    /// <para>
    /// The display name of the assembly to check for.
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// <para><i>username</i></para>
    /// <para>
    /// The username to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// <para><i>password</i></para>
    /// <para>
    /// The password to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <PropertyGroup>
    ///         <AssemblyExists />
    ///     </PropertyGroup>
    ///     <Target Name="Test" >
    ///         <BizTalk2006.Assembly.Exists 
    ///             DisplayName="MyAssembly, Version=1.0.40823.3, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, Custom=null"
    ///             Server="." 
    ///             Database="BizTalkMgmtDb" 
    ///              
    ///             >
    ///             <Output TaskParameter="DoesExist" PropertyName="AssemblyExists" />
    ///         </BizTalk2006.Assembly.Exists>
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Exists : BizTalk2004.Assembly.Exists
    {
        #region Member Variables

        private string application;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the application.
        /// </summary>
        /// <value>The application.</value>
        public string Application
        {
            get { return this.application; }
            set { this.application = value; }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {
            if (string.IsNullOrEmpty(this.Application))
            {
                base.InternalExecute();
            }
            else
            {
                this.DoesExist = false;

                BtsCatalogExplorer explorer = this.GetBtsCatalogExplorer(this.Server, this.Database);

                Application appl = explorer.Applications[this.Application];
                if (appl != null)
                {
                    // The assemblies are in the collection by short name, so have to loop through them
                    foreach (BtsAssembly assembly in appl.Assemblies)
                    {
                        if (assembly.DisplayName == this.DisplayName)
                        {
                            this.DoesExist = true;
                            break;
                        }
                    }
                }
                else
                {
                    this.DoesExist = false;
                }
            }
        }
        #endregion
    }
}

