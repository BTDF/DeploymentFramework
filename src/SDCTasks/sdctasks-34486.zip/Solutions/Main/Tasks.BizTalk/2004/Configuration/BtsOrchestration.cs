﻿//-------------------------------------------------------------------------------------
// <copyright file="BtsOrchestration.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      BtsOrchestration
// </summary>  
//-------------------------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;
    using System.Reflection;

    #endregion

    internal class BtsOrchestration : BtsBaseObject
    {
        /// <summary>
        /// Internal Constructor
        /// </summary>
        /// <param name="actualBtsObject">The actual Microsoft.Biztalk.ExplorerOM.BtsOrchestration object that object will call.</param>
        /// <param name="catalogExplorer">The Microsoft.Sdc.Tasks.Configuration.BtsCatalogExplorer object.</param>
        internal BtsOrchestration(object actualBtsObject, BtsCatalogExplorer catalogExplorer)
        {
            this.btsCatalogExplorer = catalogExplorer;
            this.actualBtsObject = actualBtsObject;
        }

        /// <summary>
        /// Gets the full name of the orchestration
        /// </summary>
        public string FullName
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("FullName", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>
        /// Gets or sets the flag to specify whether to resume all suspended instances automatically when the user changes the status of the orchestration from enlisted to started.
        /// </summary>
        /// <value></value>
        public bool AutoResumeSuspendedInstances
        {
            get
            {
                return (bool)this.actualBtsObject.GetType().InvokeMember("AutoResumeSuspendedInstances", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("AutoResumeSuspendedInstances", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });
            }
        }

        /// <summary>
        /// Gets or sets the flag to specify whether to suspend all running instances automatically when the user changes the status of the orchestration from started to enlisted.
        /// </summary>
        /// <value></value>
        public bool AutoSuspendRunningInstances
        {
            get
            {
                return (bool)this.actualBtsObject.GetType().InvokeMember("AutoSuspendRunningInstances", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("AutoSuspendRunningInstances", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });
            }
        }

        /// <summary>
        /// Gets or sets the field to autoterminate instances while unenlisting an orchestration.
        /// </summary>
        /// <value></value>
        public bool AutoTerminateInstances
        {
            get
            {
                return (bool)this.actualBtsObject.GetType().InvokeMember("AutoTerminateInstances", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("AutoTerminateInstances", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });
            }
        }

        /// <summary>
        /// Gets the reference to the containing assembly.
        /// </summary>
        public BtsAssembly BtsAssembly
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("BtsAssembly", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (value != null) ? new BtsAssembly(value, this.btsCatalogExplorer) : null;
            }
        }

        /// <summary>
        ///Gets the assembly qualified name of the orchestration.
        /// </summary>
        /// <value></value>
        public string AssemblyQualifiedName
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("AssemblyQualifiedName", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
        }

        /// <summary>
        /// Gets or sets the host associated with the orchestration.
        /// </summary>
        /// <value></value>
        public BtsHost Host
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("Host", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (value != null) ? new BtsHost(value, this.btsCatalogExplorer) : null;
            }

            set
            {
                this.actualBtsObject.GetType().InvokeMember("Host", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? ((BtsHost)value).actualBtsObject : null });
            }
        }

        /// <summary>
        /// Gets the collection of roles implemented by this orchestration.
        /// </summary>
        /// <value></value>
        public BtsRoleCollection ImplementedRoles
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("ImplementedRoles", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsRoleCollection roles = new BtsRoleCollection();

                    foreach (object item in ((System.Collections.IEnumerable)actualCollection))
                    {
                        BtsRole role = new BtsRole(item, this.btsCatalogExplorer);
                        roles.Add(role);
                    }
                    return roles;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Gets the collection of orchestrations that are invoked from the current orchestration (either by CALL or EXEC). 
        /// </summary>
        /// <value></value>
        public BtsOrchestrationCollection InvokedOrchestrations
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("InvokedOrchestrations", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsOrchestrationCollection orchestrations = new BtsOrchestrationCollection();

                    foreach (object item in ((System.Collections.IEnumerable)actualCollection))
                    {
                        BtsOrchestration orch = new BtsOrchestration(item, this.btsCatalogExplorer);
                        orchestrations.Add(orch);
                    }
                    return orchestrations;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Gets the collection of ports.
        /// </summary>
        /// <value></value>
        public BtsOrchestrationPortCollection Ports
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("Ports", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsOrchestrationPortCollection ports = new BtsOrchestrationPortCollection();

                    foreach (object item in ((System.Collections.IEnumerable)actualCollection))
                    {
                        BtsOrchestrationPort port = new BtsOrchestrationPort(item, this.btsCatalogExplorer);
                        ports.Add(port);
                    }
                    return ports;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Get or sets the orchestration status associated with the orchestration. 
        /// </summary>
        /// <value></value>
        public OrchestrationStatus Status
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("Status", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (OrchestrationStatus)Enum.Parse(typeof(OrchestrationStatus), value.ToString());
            }

            set
            {
                object actualValue = Enum.Parse(this.btsCatalogExplorer.BizTalkExplorerOMAssembly.GetType("Microsoft.BizTalk.ExplorerOM.OrchestrationStatus"), value.ToString());
                this.actualBtsObject.GetType().InvokeMember("Status", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { actualValue });
            }
        }

        /// <summary>
        /// Gets the collection of roles used in this orchestration.
        /// </summary>
        /// <value></value>
        public BtsRoleCollection UsedRoles
        {
            get
            {
                object actualCollection = this.actualBtsObject.GetType().InvokeMember("UsedRoles", BindingFlags.GetProperty, null, this.actualBtsObject, null);

                if (actualCollection != null)
                {
                    BtsRoleCollection roles = new BtsRoleCollection();

                    foreach (object item in ((System.Collections.IEnumerable)actualCollection))
                    {
                        BtsRole role = new BtsRole(item, this.btsCatalogExplorer);
                        roles.Add(role);
                    }
                    return roles;
                }
                else
                {
                    return null;
                }
            }
        }
    }
}
