/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Configuration.SqlServer {
	using System;
    using System.Data;
    using System.Data.SqlClient;
	using System.Globalization;

	/// <summary>
	/// Summary description for User.
	/// </summary>
	internal sealed class User {
		private User() {
		}

		public static void Delete(string userName, string databaseName) {
			Delete(userName, databaseName, "localhost");
		}

		public static void Delete(string userName, string databaseName, string serverName) {
            ScriptExecutor.ExecuteActionScript(
                databaseName,
                serverName,
                "EXEC sp_dropuser N'{0}'",
                userName );
		}

		public static bool IsInRole(string userName, string role, string databaseName) {
			return IsInRole(userName, role, databaseName, "localhost");
		}

		public static bool IsInRole(string userName, string role, string databaseName, string serverName) {
            bool exists = false;
            // Prepare dynamic SQL statement to query the existence of the database item
            string commandText = string.Format (
                "EXEC sp_helprolemember N'{0}'",
                role.Replace ("'", "''") );
            // Connect to database
            using (SqlConnection sqlConnection = new SqlConnection(
                       ScriptExecutor.DetermineConnectionString (databaseName, serverName) ) ){
                SqlCommand command = new SqlCommand (commandText, sqlConnection);
                sqlConnection.Open();
                SqlDataReader dataReader;
                dataReader = command.ExecuteReader (CommandBehavior.CloseConnection);
                // Reader will return false if no matching entries found otherwise true
                while (dataReader.Read()) {
                    if (string.Compare (userName, 0, (string)dataReader["MemberName"], 0, userName.Length, true, CultureInfo.InvariantCulture) == 0) {
                        exists = true;
                        break;
                    }
                }
                // Reader will automatically close connection
                dataReader.Close();
            }
            return exists;
		}

		public static bool Exists(string userName, string databaseName) {
			return Exists(userName, databaseName, "localhost");
		}

		public static bool Exists(string userName, string databaseName, string serverName) {
            return ScriptExecutor.ExecuteExistsScript(
                databaseName,
                serverName,
                "SELECT 1 from dbo.sysusers WHERE name = N'{0}'",
                userName );
		}

        public static bool ExistsWithConnectionString(string userName, string databaseName, string connectionString) 
        {
            return ScriptExecutor.ExecuteExistsScriptSpecifyConnection(
                connectionString,
                "use {0};SELECT 1 from dbo.sysusers WHERE name = N'{1}'",
                databaseName, userName );
        }



		static public void Create(string loginName, string databaseName) 
        {
			Create(loginName, databaseName, String.Empty, "localhost");
		}

		static public void Create(string loginName, string databaseName, string userName) {
			Create(loginName, databaseName, userName, "localhost");
		}
		
		static public void Create(string loginName, string databaseName, string userName, string serverName) {
		
			if (userName.Length == 0) {
				userName = loginName;
			}

			if (!Login.Exists(loginName,serverName)) {
				throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to Create User '{0}' in database '{1}' because the database security login '{2}' does not exist.", userName, databaseName, loginName));
			}

            ScriptExecutor.ExecuteActionScript(
                databaseName,
                serverName,
                "EXEC sp_grantdbaccess N'{0}', N'{1}'",
                loginName,
                userName );
		}

        static public void GrantDBAccessWithConnectionString(string loginName, string databaseName, string userName, 
            string connectionString) 
        {
		
            if (userName.Length == 0) 
            {
                userName = loginName;
            }

            if (!Login.ExistsWithConnectionString(loginName,connectionString)) 
            {
                throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to Create User '{0}' in database '{1}' because the database security login '{2}' does not exist.", userName, databaseName, loginName));
            }

            ScriptExecutor.ExecuteActionScriptSpecifyConnection(
                connectionString,
                "use {0}; EXEC sp_grantdbaccess N'{1}', N'{2}'",
                databaseName,
                loginName,
                userName );
        }

        static public void GrantDBAccess(string loginName, string databaseName, string userName, 
            string connectionString, int timeout) 
        {
		
            if (userName.Length == 0) 
            {
                userName = loginName;
            }

            if (!Login.ExistsWithConnectionString(loginName,connectionString)) 
            {
                throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to Create User '{0}' in database '{1}' because the database security login '{2}' does not exist.", userName, databaseName, loginName));
            }

            ScriptExecutor.ExecuteActionScriptSpecifyConnection(
                connectionString,
                timeout,
                "use {0}; EXEC sp_grantdbaccess N'{1}', N'{2}'",
                databaseName,
                loginName,
                userName );
        }

		static public void RemoveFromRole(string userName, string role, string databaseName) 
        {
			RemoveFromRole(userName, role, databaseName, "localhost");
		}

		static public void RemoveFromRole(string userName, string role, string databaseName, string serverName) {
			if (!User.Exists(userName, databaseName, serverName)) {
				throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to remove user '{0}' from role '{1}' because the user does not exist in the database '{2}'", userName, role, databaseName));
			}
            ScriptExecutor.ExecuteActionScript(
                databaseName,
                serverName,
                "EXEC sp_droprolemember N'{0}', N'{1}'",
                role,
                userName );
		}	
		
		static public void AddToRole(string user, string role, string database) {
			AddToRole(user,role,database,"localhost");
		}

		static public void AddToRole(string userName, string role, string databaseName, string serverName) {
			if (!User.Exists(userName,databaseName,serverName)) {
				throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to add user '{0}' to role '{1}' because the user does not exist in the database '{2}'",  userName, role, databaseName));
			}
            ScriptExecutor.ExecuteActionScript(
                databaseName,
                serverName,
                "EXEC sp_addrolemember N'{0}', N'{1}'",
                role,
                userName );
		}		

        static public void AddToRoleWithConnectionString(string userName, string role, string databaseName, string connectionString) 
        {
            if (!User.ExistsWithConnectionString(userName,databaseName,connectionString)) 
            {
                throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to add user '{0}' to role '{1}' because the user does not exist in the database '{2}'",  userName, role, databaseName));
            }
            ScriptExecutor.ExecuteActionScriptSpecifyConnection(
                connectionString,
                "use {0};EXEC sp_addrolemember N'{1}', N'{2}';",
                databaseName,
                role,
                userName );
        }		

        static public void AddToRoleWithConnectionString(string userName, string role, string databaseName, string connectionString, int timeout) 
        {
            if (!User.ExistsWithConnectionString(userName,databaseName,connectionString)) 
            {
                throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to add user '{0}' to role '{1}' because the user does not exist in the database '{2}'",  userName, role, databaseName));
            }
            ScriptExecutor.ExecuteActionScriptSpecifyConnection(
                connectionString,
                timeout,
                "use {0};EXEC sp_addrolemember N'{1}', N'{2}';",
                databaseName,
                role,
                userName );
        }		
	}
}
