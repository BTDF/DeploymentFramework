/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Patrick Longs</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/


namespace Microsoft.Sdc.Tasks.Configuration.Web 
{
    using System.Collections;
    using System;
    using System.Globalization;
    using System.DirectoryServices;
    /// <summary>
    /// Summary description for WebDirectoryCollection.
    /// </summary>
    internal class WebDirectoryCollection : CollectionBase 
    {
        DirectoryEntry parentDirectoryEntry;

        internal WebDirectoryCollection(DirectoryEntry parent) 
        {
            parentDirectoryEntry = parent;
        }

        public int Add(WebDirectory directory) 
        {

            if (directory.Name.Trim().Length == 0) 
            {
                throw new ApplicationException("Web Directory name must be provided before adding to a collection");
            }
            int index = GetIndexFromName(directory.Name);
            if (index > -1) 
            {
                throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "A WebDirectory with the name '{0}' already exists.", directory.Name));
            }
            directory.Parent = parentDirectoryEntry;
            return InnerList.Add(directory);
        }

        public int IndexOf(WebDirectory value) 
        {
            return( InnerList.IndexOf(value));
        }

        public void Insert(int index, WebDirectory value) 
        {
            value.Parent = parentDirectoryEntry;
            InnerList.Insert(index, value);
        }

        public void Remove(WebDirectory value) 
        {
            InnerList.Remove(value);
        }

        public void CopyTo(WebDirectoryCollection collection, int index) 
        {
            if (collection == null)
                throw new ArgumentNullException("collection");
            if (index < 0)
                throw new ArgumentOutOfRangeException("index", index, "index needs to be greater than 0");
			
            int i = 0;			
            while(i < InnerList.Count) 
            {
                collection[i+index] = (WebDirectory)InnerList[i];
                i++;
            }
        }	

        public bool Contains(WebDirectory value) 
        {
            return (InnerList.Contains(value));
        }

        public WebDirectory this[int index] 
        {
            get 
            {
                return (WebDirectory) InnerList[index];
            }
            set 
            {
                InnerList[index] = value;
            }
        }

        int GetIndexFromName(string name) 
        {
            WebDirectory wdir;
            for(int i=0; i < InnerList.Count; i++) 
            {
                wdir = (WebDirectory)InnerList[i];
                if (wdir.Name == name) 
                {
                    return i;
                }
            }		
            return -1;
        }

        public WebDirectory this[string name] 
        {
            get 
            {
                int index = GetIndexFromName(name);
                if (index == -1) 
                {
                    return null;
                }
                return (WebDirectory) InnerList[index];
            }
            set 
            {
                int index = GetIndexFromName(name);
                if (index == -1) 
                {
                    throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Could not find virtual directory called {0}", name));
                }
                InnerList[index] = value;
            }
        }
    }
}
