﻿namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using directives

	using System;
	using System.Collections;
	using System.Text;
	using System.Reflection;

	#endregion

	internal class BtsTransportInfo : BtsBaseObject
	{
		/// <summary>
		/// Internal Constructor
		/// </summary>
		/// <param name="actualBtsObject">The actual Microsoft.Biztalk.ExplorerOM.BtsTransportInfo object that object will call.</param>
		/// <param name="catalogExplorer">The Microsoft.Sdc.Tasks.Configuration.BtsCatalogExplorer object.</param>
		internal BtsTransportInfo(object actualBtsObject, BtsCatalogExplorer catalogExplorer)
		{
			this.btsCatalogExplorer = catalogExplorer;
			this.actualBtsObject = actualBtsObject;
		}

		/// <summary>
		/// Gets or sets the address property for the adapter.
		/// </summary>
		/// <value></value>
		public string Address
		{
			get
			{
				return (string)this.actualBtsObject.GetType().InvokeMember("Address", BindingFlags.GetProperty, null, this.actualBtsObject, null);
			}

			set
			{
				this.actualBtsObject.GetType().InvokeMember("Address", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });
			}
		}

		/// <summary>
		/// Gets or sets the field to request that the adapter will send delivery notification back, whether transmission is successful.
		/// </summary>
		/// <value></value>
		public NotificationTypes DeliveryNotification
		{
			get
			{
				object value = this.actualBtsObject.GetType().InvokeMember("DeliveryNotification", BindingFlags.GetProperty, null, this.actualBtsObject, null);
				return (NotificationTypes)Enum.Parse(typeof(NotificationTypes), value.ToString());
			}
			set
			{
				object actualValue = Enum.Parse(this.btsCatalogExplorer.BizTalkExplorerOMAssembly.GetType("Microsoft.BizTalk.ExplorerOM.NotificationTypes"), value.ToString());
				this.actualBtsObject.GetType().InvokeMember("DeliveryNotification", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { actualValue });
			}

		}

		/// <summary>
		/// Gets or sets the start time for the service window.
		/// </summary>
		/// <value></value>
		public DateTime FromTime
		{
			get
			{
				return (DateTime)this.actualBtsObject.GetType().InvokeMember("FromTime", BindingFlags.GetProperty, null, this.actualBtsObject, null);

			}
			set
			{
				this.actualBtsObject.GetType().InvokeMember("FromTime", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });

			}
		}

		/// <summary>
		/// Gets the flag that specifies whether the BizTalk Message Queuing adapter supports ordered delivery.
		/// </summary>
		/// <value></value>
		public bool OrderedDelivery
		{
			get
			{
				return (bool)this.actualBtsObject.GetType().InvokeMember("OrderedDelivery", BindingFlags.GetProperty, null, this.actualBtsObject, null);

			}
			set
			{
				this.actualBtsObject.GetType().InvokeMember("OrderedDelivery", BindingFlags.SetProperty, null, this.actualBtsObject, new object[]{ value });

			}

		}

		/// <summary>
		/// Gets the flag that specifies whether this transport is primary or secondary.
		/// </summary>
		/// <value></value>
		public bool Primary
		{
			get
			{
				return (bool)this.actualBtsObject.GetType().InvokeMember("Primary", BindingFlags.GetProperty, null, this.actualBtsObject, null);

			}
		}

		/// <summary>
		/// Gets or sets the retry count for the adapter.
		/// </summary>
		/// <value></value>
		public int RetryCount
		{
			get
			{
				return (int)this.actualBtsObject.GetType().InvokeMember("RetryCount", BindingFlags.GetProperty, null, this.actualBtsObject, null);

			}
			set
			{
				this.actualBtsObject.GetType().InvokeMember("RetryCount", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });

			}

		}

		/// <summary>
		/// Gets or sets the retry interval for the adapter.
		/// </summary>
		/// <value></value>
		public int RetryInterval
		{
			get
			{
				return (int)this.actualBtsObject.GetType().InvokeMember("RetryInterval", BindingFlags.GetProperty, null, this.actualBtsObject, null);

			}
			set
			{
				this.actualBtsObject.GetType().InvokeMember("RetryInterval", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });

			}

		}

		/// <summary>
		/// Gets the send port that this adapter is associated with.
		/// </summary>
		/// <value></value>
		public BtsSendPort SendPort
		{
			get
			{
				object value = this.actualBtsObject.GetType().InvokeMember("RetryInterval", BindingFlags.GetProperty, null, this.actualBtsObject, null);
				return (value!=null)?new BtsSendPort(value, this.btsCatalogExplorer):null;
			}

		}

		/// <summary>
		/// Gets or sets the field to enable the service window.
		/// </summary>
		/// <value></value>
		public bool ServiceWindowEnabled
		{
			get
			{
				return (bool)this.actualBtsObject.GetType().InvokeMember("ServiceWindowEnabled", BindingFlags.GetProperty, null, this.actualBtsObject, null);

			}
			set
			{
				this.actualBtsObject.GetType().InvokeMember("ServiceWindowEnabled", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });

			}
		}

		/// <summary>
		/// Gets the end time for the service window.
		/// </summary>
		/// <value></value>
		public DateTime ToTime
		{
			get
			{
				return (DateTime)this.actualBtsObject.GetType().InvokeMember("ToTime", BindingFlags.GetProperty, null, this.actualBtsObject, null);

			}
			set
			{
				this.actualBtsObject.GetType().InvokeMember("ToTime", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });

			}
		}

		/// <summary>
		/// Gets or sets the transport type.
		/// </summary>
		/// <value></value>
		public BtsProtocolType TransportType
		{
			get
			{
				object value = this.actualBtsObject.GetType().InvokeMember("TransportType", BindingFlags.GetProperty, null, this.actualBtsObject, null);
				return (value!=null)?new BtsProtocolType(value, this.btsCatalogExplorer):null;

			}
			set
			{
				this.actualBtsObject.GetType().InvokeMember("TransportType", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value!=null)?((BtsProtocolType)value).actualBtsObject:null });

			}

		}

		/// <summary>
		/// Gets or sets the configuration specific data to the adapter.
		/// </summary>
		/// <value></value>
		public string TransportTypeData
		{
			get
			{
				return (string)this.actualBtsObject.GetType().InvokeMember("TransportTypeData", BindingFlags.GetProperty, null, this.actualBtsObject, null);

			}
			set
			{
				this.actualBtsObject.GetType().InvokeMember("TransportTypeData", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });

			}
		}

	}
}
