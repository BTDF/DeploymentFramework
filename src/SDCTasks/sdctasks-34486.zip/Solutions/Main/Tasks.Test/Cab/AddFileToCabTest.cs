//-----------------------------------------------------------------------
// <copyright file="AddFileToCabTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-05-27</date>
// <summary>Unit test for the add file to cab task</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.Globalization;
    using System.IO;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the add file to cab task
    /// </summary>
    [TestClass]
    public class AddFileToCabTest
    {
        
        private string PATH_TO_CABARC_EXE = @"C:\Program Files\CabArc\Cabarc.exe";

        /// <summary>
        /// Default constructor
        /// </summary>
        public AddFileToCabTest()
        {
        }       

        /// <summary>
        /// Tests adding a file to a cab file and then extracting it.
        /// </summary>
        [TestMethod]
        [Ignore]//("See Defect ID 283")]
        public void TestAddExtractFilesToCab()
        {
            //Create a folder for the cab file and a folder to extact to
            string cabFolder = TaskTestUtilities.CreateTempFolder();
            string extractFolder = TaskTestUtilities.CreateTempFolder();

            try
            {
                string pathToCabFile = cabFolder + "\\" + TaskTestUtilities.GenerateTempFilename("cab");

                //Create the cab file
                Tasks.Cab.Create cabCreateTask = new Tasks.Cab.Create();
                cabCreateTask.PathToCabFile = pathToCabFile;

                bool taskReturnValue = cabCreateTask.Execute();

                //Test the new cab file was created
                Assert.IsTrue(taskReturnValue, "CreateCabSucceeded");
                Assert.IsTrue(System.IO.File.Exists(pathToCabFile), "CreateCabValid");

                //Create temporary files in the cab file folder
                int NUM_FILES = 2;
                string[] fileToAdd = new string[NUM_FILES];
                System.IO.FileStream newFile;
                Byte[] info;
                string FILE_PREFIX = "addFile";
                string FILE_EXTENSION = ".test";

                //Set up the AddFile task
                Tasks.Cab.AddFile addFileTask = new Tasks.Cab.AddFile();
                addFileTask.PathToCabFile = pathToCabFile;
                addFileTask.Path = PATH_TO_CABARC_EXE;

                //Add the files to the previously created cab file
                for (int i = 0; i < NUM_FILES; i++)
                {
                    fileToAdd[i] = FILE_PREFIX + i.ToString(CultureInfo.InvariantCulture) + FILE_EXTENSION;
                    newFile = System.IO.File.Create(cabFolder + "\\" + fileToAdd[i]);

                    // Add some information to the file.
                    info = new UTF8Encoding(true).GetBytes("Test text");
                    newFile.Write(info, 0, info.Length);
                    newFile.Close();

                    //Create the cab add file task and execute
                    addFileTask.PathToFile = cabFolder + "\\" + fileToAdd[i];

                    taskReturnValue = addFileTask.Execute();

                    //Test the file was added
                    Assert.IsTrue(taskReturnValue, "AddToCabSucceeded - file " + i.ToString(CultureInfo.InvariantCulture));
                    Console.WriteLine("Successfully added file " + fileToAdd[i]);
                }

                //Set up the extract task
                Tasks.Cab.ExtractFile extractTask = new Tasks.Cab.ExtractFile();
                extractTask.PathToCabFile = pathToCabFile;
                extractTask.PathToFiles = extractFolder;
                extractTask.Overwrite = true;
                extractTask.Path = PATH_TO_CABARC_EXE;

                for (int i = 0; i < NUM_FILES; i++)
                {
                    extractTask.FileToExtract = fileToAdd[i];
                    taskReturnValue = extractTask.Execute();

                    //Test the file was extracted
                    Assert.IsTrue(taskReturnValue, "ExtractCabSucceeded - file " + i.ToString(CultureInfo.InvariantCulture));
                }

                //Ensure all the files were extracted
                for (int i = 0; i < NUM_FILES; i++)
                {
                    Assert.IsTrue(System.IO.File.Exists(extractFolder + "\\" + fileToAdd[i]), "ExtractFileExists");
                }
            }
            catch (ApplicationException e)
            {
                Console.WriteLine(e.ToString());
            }
            finally
            {
                //Tidy up
                Directory.Delete(cabFolder, true);
                Directory.Delete(extractFolder, true);
            }
        }

        /// <summary>
        /// Ensure that the task will fail without [Required] parameters
        /// </summary>
        [TestMethod]
        public void TestUninitializedCreateTaskFails()
        {
            Tasks.Cab.Create task = new Tasks.Cab.Create();
           

            try
            {
                bool taskReturnValue = task.Execute();
                Assert.Fail("Uninitialised tasks should not succeed.");
            }
            catch (ApplicationException)
            {
                Console.WriteLine("Correctly threw exception");
                Console.WriteLine(((PseudoBuildEngine) task.BuildEngine).PreviousMessage);
            }

        }

        /// <summary>
        /// Ensure that the task will fail without [Required] parameters
        /// </summary>
        [TestMethod]
        public void TestUninitializedAddTaskFails()
        {
            Tasks.Cab.AddFile task = new Tasks.Cab.AddFile();
           

            try
            {
                bool taskReturnValue = task.Execute();
                Assert.Fail("Uninitialised tasks should not succeed.");
            }
            catch (ApplicationException)
            {
                Console.WriteLine("Correctly threw exception");
                Console.WriteLine(((PseudoBuildEngine) task.BuildEngine).PreviousMessage);
            }
        }
    }
}


