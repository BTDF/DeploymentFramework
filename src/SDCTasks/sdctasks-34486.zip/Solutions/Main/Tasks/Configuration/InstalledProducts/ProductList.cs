using System;
using System.Collections;

namespace Microsoft.Sdc.Tasks.Configuration.InstalledProducts
{
	/// <summary>
	/// A collection of products
	/// </summary>
    public class ProductList : CollectionBase
	{
		public Product this[int index]
		{
			get { return ((Product)(List[index])); }
			set { List[index] = value; }
		}

		public int Add(Product product)
		{
			return List.Add(product);
		}

		public void Insert(int index, Product product)
		{
			List.Insert(index, product);
		}

		public void Remove(Product product)
		{
			List.Remove(product);
		}

		public bool Contains(Product product)
		{
			return List.Contains(product);
		}

		public ProductList()
		{
		}
	}
}
