//-------------------------------------------------------------------------------------
// <copyright file="AssignCulture.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
// Replaces the Asign Culture task      
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks
{
    using System;
    using System.IO;
    using System.Diagnostics;
    using System.Resources;
    using System.Reflection;
    using System.Globalization;
    using System.Collections;
    using Microsoft.Build.Framework;
    using Microsoft.Build.Utilities;

    /// <summary>
    /// AssignCulture
    /// </summary>
    public class AssignCulture : TaskBase
    {
        private ITaskItem[] files = new TaskItem[0];
        private ITaskItem[] assignedFiles = null;
        private ITaskItem[] assignedFilesWithCulture = null;
        private ITaskItem[] assignedFilesWithNoCulture = null;
        private ITaskItem[] cultureNeutralAssignedFiles = null;
        private string[] userDefinedCultures = null;

        /// <summary>
        /// AssignCulture
        /// </summary>
        public AssignCulture()
        {
        }
                
        /// <summary>
        /// Files
        /// </summary>
        [Required]
        public ITaskItem[] Files
        {
            get { return this.files; }
            set { this.files = value; }
        }

        /// <summary>
        /// AssignedFiles
        /// </summary>
        [Output]
        public ITaskItem[] AssignedFiles
        {
            get { return this.assignedFiles; }
        }

        /// <summary>
        /// AssignedFilesWithCulture
        /// </summary>
        [Output]
        public ITaskItem[] AssignedFilesWithCulture
        {
            get { return this.assignedFilesWithCulture; }
        }

        /// <summary>
        /// AssignedFilesWithNoCulture
        /// </summary>
        [Output]
        public ITaskItem[] AssignedFilesWithNoCulture
        {
            get { return this.assignedFilesWithNoCulture; }
        }

        /// <summary>
        /// CultureNeutralAssignedFiles
        /// </summary>
        [Output]
        public ITaskItem[] CultureNeutralAssignedFiles
        {
            get { return this.cultureNeutralAssignedFiles; }
        }

        /// <summary>
        /// This is the only extra property we have over Microsoft.Build.Tasks.AssignCulture 
        /// </summary>
        public string[] UserDefinedCultures
        {
            get { return this.userDefinedCultures; }
            set { this.userDefinedCultures = value; }
        }

        /// <summary>
        /// The execute method
        /// </summary>
        protected override void InternalExecute()
        {
            this.assignedFiles = new TaskItem[this.Files.Length];
            this.cultureNeutralAssignedFiles = new TaskItem[this.Files.Length];
            ArrayList cultureList = new ArrayList();
            ArrayList noCultureList = new ArrayList();

            for (int i = 0; i < this.Files.Length; ++i)
            {
                Culture.ItemCultureInfo info = Culture.GetItemCultureInfo(this.Files[i].ItemSpec);
                this.AssignedFiles[i] = new TaskItem(this.Files[i]);

                string dependantUpon = this.AssignedFiles[i].GetMetadata("DependentUpon");
                bool alreadyAssigned = false;
                if ((dependantUpon != null) && (dependantUpon.Length > 0))
                {
                    string dependantFilenameNoExtension = Path.GetFileNameWithoutExtension(dependantUpon);
                    string assignedFilenameNoExtension = Path.GetFileNameWithoutExtension(this.AssignedFiles[i].ItemSpec);
                    if (string.Compare(dependantFilenameNoExtension, assignedFilenameNoExtension, true, CultureInfo.InvariantCulture) == 0)
                    {
                        alreadyAssigned = true;
                    }
                }

                if (((info.culture != null) && (info.culture.Length > 0)) && !alreadyAssigned)
                {
                    this.AssignedFiles[i].SetMetadata("Culture", info.culture);
                    cultureList.Add(this.AssignedFiles[i]);
                }
                else
                {
                    // This is where we differ to the Build.Tasks.AssignCulture
                    // We check now for a culture extension that doesn't have to be a framework culture like Welsh
                    bool foundCulture = false;

                    if (this.UserDefinedCultures != null && this.UserDefinedCultures.Length > 0)
                    {
                        // If the item is defined as "Strings.cy-GB.resx", then ...

                        // ... base file name will be "Strings.cy-GB" ...            
                        string baseFileNameWithCulture = Path.GetFileNameWithoutExtension(this.Files[i].ItemSpec);
                        
                        // ... and cultureName will be ".cy-GB".
                        string cultureName = Path.GetExtension(baseFileNameWithCulture);

                        if ((cultureName != null) && (cultureName.Length > 1))
                        {
                            cultureName = cultureName.Substring(1);

                            foreach (string userCulture in this.UserDefinedCultures)
                            {
                                if (userCulture == cultureName)
                                {
                                    this.AssignedFiles[i].SetMetadata("Culture", cultureName);
                                    cultureList.Add(this.AssignedFiles[i]);
                                    foundCulture = true;
                                    break;
                                }
                            }
                        }
                    }

                    if (!foundCulture)
                    {
                        noCultureList.Add(this.AssignedFiles[i]);
                    }
                }

                this.CultureNeutralAssignedFiles[i] = new TaskItem(this.AssignedFiles[i]);
                this.CultureNeutralAssignedFiles[i].ItemSpec = info.cultureNeutralFilename;
            }

            this.assignedFilesWithCulture = (ITaskItem[])cultureList.ToArray(typeof(ITaskItem));
            this.assignedFilesWithNoCulture = (ITaskItem[])noCultureList.ToArray(typeof(ITaskItem));
        }
    }
}
