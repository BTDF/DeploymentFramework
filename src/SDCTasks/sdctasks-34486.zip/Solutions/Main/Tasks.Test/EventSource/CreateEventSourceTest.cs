//-----------------------------------------------------------------------
// <copyright file="EventSourceTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>andyr</email>
// <date>2004-05-25</date>
// <summary>Tests creating an event source</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for creating an event source
    /// </summary>
    [TestClass]
    public class CreateEventSourceTest
    {
        public CreateEventSourceTest()
        {
        }      

        [TestMethod]
        public void TestCreateEventSource()
        {
            Tasks.EventSource.Create task = new Tasks.EventSource.Create();

            //Create a new source
            Guid guid = Guid.NewGuid();
            string source = guid.ToString();

            //Set up the new event source
            task.Source = source;

            //Test that it can be created
            bool taskReturnValue = task.Execute();
            Assert.IsTrue(taskReturnValue, "CreateEventSource");

            //Ensure that it cannot be created again
            try
            {
                taskReturnValue = task.Execute();
                Assert.Fail("Should not have allowed the same event source to be created twice.");
            }

            catch (ApplicationException)
            {
                Console.WriteLine("Correctly threw TaskException on attempting to create an event source that already exists.");
            }

            //Keep the test atomic by removing this source
            System.Diagnostics.EventLog.DeleteEventSource(source);
        }

        [TestMethod]
        public void TestUninitializedTaskFails()
        {
            Tasks.EventSource.Create task = new Tasks.EventSource.Create();           

            try
            {
                bool taskReturnValue = task.Execute();
                Assert.Fail("Uninitialised tasks should not succeed.");
            }
            catch (ApplicationException)
            {
                Console.WriteLine("Correctly threw exception");
                Console.WriteLine(((PseudoBuildEngine) task.BuildEngine).PreviousMessage);
            }
        }
    }
}


