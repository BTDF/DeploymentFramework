﻿using System;

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	/// <summary>
	///Denotes the status of a send port or a send port group. 
	/// </summary>

	public enum PortStatus : int
	{
		/// <summary>
		/// Default state
		/// </summary>
		Bound = 1,

		/// <summary>
		/// Indicates the send port or send port group is started, and subscriptions are activated.
		/// </summary>
		Started = 3,

		/// <summary>
		/// Indicates the send port or send port group is enlisted, and subscriptions are created but they are deactivated.
		/// </summary>
		Stopped = 2,


	}
}

