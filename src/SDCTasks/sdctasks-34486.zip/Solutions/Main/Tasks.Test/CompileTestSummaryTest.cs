//-----------------------------------------------------------------------
// <copyright file="CreateFTPTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Ashter Chomoko</author>
// <email>ashter_chomoko@charteris.com</email>
// <date>2004-05-26</date>
// <summary>Unit test for the Sn tool</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    [TestClass]
    public class CompileTestSummaryTest
    {
        public CompileTestSummaryTest()
        {
        }      

        [TestMethod]
        public void Success()
        {
            string[] caregories = new string[4] { "Cat1", "Cat2", "Cat3", "Cat4" };
            string[] testPass = new string[4] { "2", "1", "2", "2" };
            string[] testFail = new string[4] { "2", "1", "2", "2" };
            string[] testNoRun = new string[4] { "2", "1", "2", "2" };
            string[] testTotal = new string[4] { "2", "1", "2", "2" };
            string[] testTimeTaken = new string[4] { "2", "1", "2", "2" };


            //Run task
            CompileTestSummary ctsTest = new CompileTestSummary();
            ctsTest.Categories = caregories;
            ctsTest.TestPass = testPass;
            ctsTest.TestFail = testFail;
            ctsTest.TestNoRun = testNoRun;
            ctsTest.TestTotal = testTotal;
            ctsTest.TestTimeTaken = testTimeTaken;

            ctsTest.Execute();

            Assert.AreEqual(Convert.ToInt32(ctsTest.TotalTestFailures[0]), 7);

            //Parameter test
            Assert.IsTrue(ctsTest.Categories == caregories, "CompileTestSummary parameters");
            Assert.IsTrue(ctsTest.TestPass == testPass, "CompileTestSummary parameters");
            Assert.IsTrue(ctsTest.TestFail == testFail, "CompileTestSummary parameters");
            Assert.IsTrue(ctsTest.TestNoRun == testNoRun, "CompileTestSummary parameters");
            Assert.IsTrue(ctsTest.TestTotal == testTotal, "CompileTestSummary parameters");
            Assert.IsTrue(ctsTest.TestTimeTaken == testTimeTaken, "CompileTestSummary parameters");

        }

        [TestMethod]
        public void TestUninitializedTaskFails()
        {
            CompileTestSummary task = new CompileTestSummary();
           

            try
            {
                bool taskReturnValue = task.Execute();
                Assert.Fail("Uninitialised tasks should not succeed.");
            }
            catch (ApplicationException)
            {
                Console.WriteLine("Correctly threw exception");
                Console.WriteLine(((PseudoBuildEngine) task.BuildEngine).PreviousMessage);
            }

        }

    }
}