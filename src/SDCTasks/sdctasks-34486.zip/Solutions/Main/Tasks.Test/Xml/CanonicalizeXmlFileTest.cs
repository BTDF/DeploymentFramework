//-----------------------------------------------------------------------
// <copyright file="CanonicalizeXmlFileTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Simon Bell</author>
// <email>v-sibell</email>
// <date>2004-06-02</date>
// <summary>Tests xml file canonicalize tasks</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit test for the canonicalize xml file test
    /// </summary>
    [TestClass]
    public class CanonicalizeXmlFileTest
    {
        

        public CanonicalizeXmlFileTest()
        {
        }

        /// <summary>
        /// Creates two Xml files in a temporary source folder, and canonicalises them
        /// to a temporary destination folder. It tests the files are written into the 
        /// destination folder before clearing up.
        /// </summary>
        [TestMethod]
        public void TestCanonicalizeXmlFile()
        {
            //Create a temp directory as source and one as destination
            string sourceFolder = TaskTestUtilities.CreateTempFolder();
            string destinationFolder = TaskTestUtilities.CreateTempFolder();

            string[] sourceFilename = new string[2];
            string[] sourceFiles = new string[2];
            string[] destinationFilename = new string[2];
            string[] destinationFiles = new string[2];

            try
            {
                for (int i = 0; i < 2; i++)
                {
                    //Create two temporary xml files in the source directory
                    sourceFilename[i] = TaskTestUtilities.GenerateTempFilename("xml");
                    sourceFiles[i] = sourceFolder + "\\" + TaskTestUtilities.CreateTempFileInFolder(sourceFilename[i], sourceFolder);

                    //Write some xml in them
                    InsertTestXmlToSourceFile(sourceFiles[i]);

                    //Setup the destination files
                    destinationFilename[i] = TaskTestUtilities.GenerateTempFilename("xml");
                    destinationFiles[i] = destinationFolder + "\\" + destinationFilename[i];
                }

                Tasks.Xml.CanonicalizeFile canonicalizeXmlTask = new Tasks.Xml.CanonicalizeFile();
               
                canonicalizeXmlTask.SourceFiles = sourceFiles;
                canonicalizeXmlTask.DestinationFiles = destinationFiles;

                bool canonicalizeXmlTaskReturnValue = canonicalizeXmlTask.Execute();

                //Test the task was executed successfully
                Assert.IsTrue(canonicalizeXmlTaskReturnValue, "XmlModificationSucceeded");

                //Test the properties are persisted correctly
                Assert.IsTrue(canonicalizeXmlTask.SourceFiles == sourceFiles, "XmlCanonicalize - Source Files");
                Assert.IsTrue(canonicalizeXmlTask.DestinationFiles == destinationFiles, "XmlCanonicalize - Destination Files");

                for (int i = 0; i < 2; i++)
                {
                    Assert.IsTrue(System.IO.File.Exists(destinationFiles[i]), "XmlCanonicalize - Destination Files Exist");
                }
            }
            finally
            {
                //Tidy up
                Directory.Delete(sourceFolder, true);
                Directory.Delete(destinationFolder, true);
            }
        }

        /// <summary>
        /// Creates two Xml files in a temporary source folder that contains spaces in its
        /// path name, and canonicalises them to a temporary destination folder that also contains
        /// spaces in its path name. It tests the files are written into the 
        /// destination folder before clearing up.
        /// </summary>
        [TestMethod]
        public void TestCanonicalizeXmlFileWithPathSpaces()
        {
            //Create a temp directory as source and one as destination
            string sourceFolder = TaskTestUtilities.CreateTempFolderWithSpaces();
            string destinationFolder = TaskTestUtilities.CreateTempFolderWithSpaces();

            string[] sourceFilename = new string[2];
            string[] sourceFiles = new string[2];
            string[] destinationFilename = new string[2];
            string[] destinationFiles = new string[2];

            try
            {
                for (int i = 0; i < 2; i++)
                {
                    //Create two temporary xml files in the source directory
                    sourceFilename[i] = TaskTestUtilities.GenerateTempFilename("xml");
                    sourceFiles[i] = sourceFolder + "\\" + TaskTestUtilities.CreateTempFileInFolder(sourceFilename[i], sourceFolder);

                    //Write some xml in them
                    InsertTestXmlToSourceFile(sourceFiles[i]);

                    //Setup the destination files
                    destinationFilename[i] = TaskTestUtilities.GenerateTempFilename("xml");
                    destinationFiles[i] = destinationFolder + "\\" + destinationFilename[i];
                }

                Tasks.Xml.CanonicalizeFile canonicalizeXmlTask = new Tasks.Xml.CanonicalizeFile();
                
                canonicalizeXmlTask.SourceFiles = sourceFiles;
                canonicalizeXmlTask.DestinationFiles = destinationFiles;

                bool canonicalizeXmlTaskReturnValue = canonicalizeXmlTask.Execute();

                //Test the task was executed successfully
                Assert.IsTrue(canonicalizeXmlTaskReturnValue, "XmlModificationSucceeded");

                //Test the properties are persisted correctly
                Assert.IsTrue(canonicalizeXmlTask.SourceFiles == sourceFiles, "XmlCanonicalize - Source Files");
                Assert.IsTrue(canonicalizeXmlTask.DestinationFiles == destinationFiles, "XmlCanonicalize - Destination Files");

                for (int i = 0; i < 2; i++)
                {
                    Assert.IsTrue(System.IO.File.Exists(destinationFiles[i]), "XmlCanonicalize - Destination Files Exist");
                }
            }
            finally
            {
                //Tidy up
                Directory.Delete(sourceFolder, true);
                Directory.Delete(destinationFolder, true);
            }
        }


        private void InsertTestXmlToSourceFile(string filename)
        {
            System.Xml.XmlTextWriter writer = new System.Xml.XmlTextWriter(filename, System.Text.Encoding.UTF8);
            writer.WriteStartElement("Customers");
            writer.WriteStartElement("Customer");
            writer.WriteAttributeString("name", "Customer1");
            writer.WriteEndElement();
            writer.WriteStartElement("Customer");
            writer.WriteAttributeString("name", "Customer2");
            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.Close();
        }
    }
}


