//-------------------------------------------------------------------------------------
// <copyright file="BizTalkNonConfigurableEntityBase.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Base class for BizTalk entities that are not programatically configurable.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;

    #endregion

    #region Class Comments
    /// <summary>
    /// Base class for BizTalk entities that are not programatically configurable.
    /// </summary>
    /// <remarks>
    /// Non-configurable entities are entities that are compiled and deployed into an installation, such
    /// as assemblies, pipelines and orchestrations. These objects cannot be changed as they are already
    /// compiled and deployed, however they may be able to have actions performed on them such as being
    /// started or stopped.
    /// </remarks>
    #endregion
    internal abstract class BizTalkNonConfigurableEntityBase : BizTalkEntityBase
    {
        #region Constructors

        /// <summary>
        /// Creates a new <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkNonConfigurableEntityBase"/>.
        /// </summary>
        /// <param name="installation">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation"/> that this object
        /// belongs to.
        /// </param>
        protected BizTalkNonConfigurableEntityBase(BizTalkInstallation installation)
            : this(installation, null)
        {
        }

        /// <summary>
        /// Creates a new <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkNonConfigurableEntityBase"/>.
        /// </summary>
        /// <param name="installation">
        /// The <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.BizTalkInstallation"/> that this object
        /// belongs to.
        /// </param>
        /// <param name="name" />        
        protected BizTalkNonConfigurableEntityBase(BizTalkInstallation installation, string name)
            : base(installation, name)
        {
        }

        #endregion
    }
}

