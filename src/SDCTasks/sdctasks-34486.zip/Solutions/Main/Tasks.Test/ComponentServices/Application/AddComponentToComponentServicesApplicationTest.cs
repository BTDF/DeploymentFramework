/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date><Date/>
  <Description>Implementation of the Service Task <Description/>
  <Copyright><![CDATA[
    Copyright � 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/
namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks.ComponentServices;
    using Microsoft.Build.Framework;
    using System.Reflection;
    using Microsoft.Sdc.Tasks.Configuration.ComponentServices;

    /// <summary>
    /// Unit test for the AddComponentToComponentServicesApplicationTest Task
    /// </summary>
    [TestClass]
    public class AddComponentToComponentServicesApplicationTest
    {
        public AddComponentToComponentServicesApplicationTest()
        {
        }

        [TestMethod]
        [Ignore]//("Please compelte with bug #")]
        public void TestAddComponentToComponentServicesApplication()
        {
            string applicationName = "MicrosoftSDCTestComponent";
            string path = "Microsoft.Sdc.Tasks.Configuration.Test.ComAssembly.dll";
            if (Application.Exists(applicationName))
            {
                Assert.Fail("Unable to test COM+ application add as the application already exists");
            }

            ComponentServices.Application.AddComponent task = new ComponentServices.Application.AddComponent();
           

            //task.ApplicationName = applicationName;
            task.Path = path;

            task.ActivationString = "Local";
            task.Identity = "Interactive User";
            task.Runtime = "1.1";
            bool taskReturnValue = task.Execute();
            Assert.IsTrue( taskReturnValue);

            //Check the COM+ Application is now updated

            Application app = Application.Load(applicationName);


            bool b = app.AccessChecksEnabled;

            Assert.IsTrue( app.AccessChecksEnabled);
            Assert.AreEqual(app.Activation, Activation.Local);
            Assert.IsTrue( !app.RunForever);
            Assert.AreEqual(app.ShutdownAfter, 3);
            //Now delete it
            Application.Delete(applicationName);
            if (Application.Exists(applicationName))
            {
                Assert.Fail("Unable to delete COM+ application");
            }

        }
    }
}




