//-------------------------------------------------------------------------------------
// <copyright file="AddSendPort.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Adds a SendPort in a BizTalk Server.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.SendPortGroup
{
    #region Using directives

    using System;
    using System.Collections.Generic;
    using System.Text;
    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;

    #endregion

    /// <summary>
    /// AddSendPort
    /// </summary>
    public class AddSendPort : BizTalk2004TaskBase
    {
        private string name;
        private string sendport;

        /// <summary>
        /// AddSendPort
        /// </summary>
        public AddSendPort()
        {
        }

        /// <summary>
        /// Name
        /// </summary>
        [Required]
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        /// <summary>
        /// SendPort
        /// </summary>
        [Required]
        public string SendPort
        {
            get { return this.sendport; }
            set { this.sendport = value; }
        }

        /// <summary>
        /// InternalExecute
        /// </summary>
        protected override void InternalExecute()
        {
            BizTalkInstallation installation = this.GetInstallation();
            Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SendPortGroup sendportGroup = Microsoft.Sdc.Tasks.BizTalk2004.Configuration.SendPortGroup.Load(installation, this.name);

            if (!sendportGroup.SendPorts.Contains(this.sendport))
            {
                sendportGroup.SendPorts.Add(installation.SendPorts[this.sendport]);
            }
            else
            {
                throw new InvalidOperationException(string.Format("SendPortGroup {0} already contains SendPort {1}.", this.name, this.sendport));
            }
        }
    }
}

