//-----------------------------------------------------------------------
// <copyright file="EventSourceExistsTest.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Steven Sloggett</author>
// <email>v-stslog</email>
// <date>2006-11-16</date>
// <summary>Tests checking an event source for existance.</summary>
//-----------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Test
{
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Sdc.Tasks.Configuration;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Unit tests for checking an event source for existance.
    /// </summary>
    [TestClass]
    public class EventSourceExistsTest
    {
        /// <summary>
        /// Creates unit tests for checking an event source for existance.
        /// </summary>
        public EventSourceExistsTest()
        {
        }      

        /// <summary>
        /// Tests that an event source is not found when it does not exist.
        /// </summary>
        [TestMethod]
        public void TestEventSourceDoesNotExist()
        {
            string logName = "Application";
            string source = Guid.NewGuid().ToString();

            // Ensure that the event source is not detected
            Tasks.EventSource.Exists eventSourceExistsTask = new Tasks.EventSource.Exists();
            eventSourceExistsTask.LogName = logName;
            eventSourceExistsTask.Source = source;
            bool eventSourceExistsTaskReturnValue = eventSourceExistsTask.Execute();
            Assert.IsTrue(eventSourceExistsTaskReturnValue, "Existence of the event source should be examined.");
            Assert.IsFalse(eventSourceExistsTask.DoesExist, "Existence of the event source should not be detected.");
        }

        /// <summary>
        /// Tests that an event source is found when it exists.
        /// </summary>
        [TestMethod]
        public void TestEventSourceExists()
        {
            string logName = "Application";
            string source = Guid.NewGuid().ToString();

            // Create a new event source
            Tasks.EventSource.Create createEventSourceTask = new Tasks.EventSource.Create();
            createEventSourceTask.LogName = logName;
            createEventSourceTask.Source = source;
            bool createEventSourceTaskReturnValue = createEventSourceTask.Execute();
            Assert.IsTrue(createEventSourceTaskReturnValue, "Event source should be created.");

            try
            {
                // Ensure that the event source is detected
                Tasks.EventSource.Exists eventSourceExistsTask = new Tasks.EventSource.Exists();
                eventSourceExistsTask.LogName = logName;
                eventSourceExistsTask.Source = source;
                bool eventSourceExistsTaskReturnValue = eventSourceExistsTask.Execute();
                Assert.IsTrue(eventSourceExistsTaskReturnValue, "Existence of the event source should be examined.");
                Assert.IsTrue(eventSourceExistsTask.DoesExist, "Existence of the event source should be detected.");
            }
            finally
            {
                // Keep the test atomic by removing the event source
                System.Diagnostics.EventLog.DeleteEventSource(source);
            }
        }
    }
}
