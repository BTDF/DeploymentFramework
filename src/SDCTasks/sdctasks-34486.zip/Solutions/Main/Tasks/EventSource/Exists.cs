//-----------------------------------------------------------------------
// <copyright file="Exists.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
// <author>Steven Sloggett</author>
// <email>v-stslog</email>
// <date>2006-11-16</date>
// <summary>Checks whether an event source exists.</summary>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.EventSource
{
    using System;
    using Microsoft.Build.Framework;

    /// <summary>
    /// Checks whether an event source exists.
    /// </summary>
    /// <remarks>
    /// <code><![CDATA[<EventSource.Exists Source="source" LogName="logName" />]]></code>
    /// <para>where:</para>
    /// <para><i>source (Required)</i></para>
    /// <para>The source name by which the application is registered on the local computer.</para>
    /// <para><i>logName (Required)</i></para>
    /// <para>The name of the log the source's entries are written to. Possible values include: Application, Security, System, or a custom event log.</para>
    /// <para><i>DoesExist (Output)</i></para>
    /// <para><b>true</b> if the event source does exist, or <b>false</b> otherwise.</para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test">
    ///         <EventSource.Exists
    ///             Source="MyEventSource"
    ///             LogName="Application">
    ///             <Output TaskParameter="DoesExist" PropertyName="MyEventSourceExists" />
    ///         </EventSource.Exists>
    ///         <EventSource.Create
    ///             Condition="'$(MyEventSourceExists)' == 'false'"
    ///             Source="MyEventSource"
    ///             LogName="Application" />
    ///     </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    public class Exists : TaskBase
    {
        /// <summary>
        /// States whether the event source exists.
        /// </summary>
        private bool doesExist = false;

        /// <summary>
        /// The source name by which the application is registered on the local computer.
        /// </summary>
        private string source = String.Empty;

        /// <summary>
        /// The name of the log the source's entries are written to.
        /// </summary>
        private string logName = String.Empty;

        /// <summary>
        /// Gets or sets a value indicating whether the event source [does exist].
        /// </summary>
        /// <value><c>true</c> if the event source [does exist]; otherwise, <c>false</c>.</value>
        [Output]
        public bool DoesExist
        {
            get
            {
                return this.doesExist;
            }

            protected set
            {
                this.doesExist = value;
            }
        }

        /// <summary>
        /// The source name by which the application is registered on the local computer.
        /// </summary>
        /// <value>The source parameter can be any string, although often it will be the name of your application or a component of your application. The source must be unique on the local computer.</value>
        [Required]
        public string Source
        {
            get
            {
                return (this.source ?? String.Empty);
            }

            set
            {
                this.source = value;
            }
        }

        /// <summary>
        /// The name of the log the source's entries are written to.
        /// </summary>
        /// <value>Possible values include: Application, Security, System, or a custom event log.</value>
        [Required]
        public string LogName
        {
            get
            {
                return (this.logName ?? String.Empty);
            }

            set
            {
                this.logName = value;
            }
        }

        /// <summary>
        /// Performs the action of this task.
        /// </summary>
        protected override void InternalExecute()
        {
            this.DoesExist = System.Diagnostics.EventLog.SourceExists(this.source);
        }
    }
}
