//-------------------------------------------------------------------------------------
// <copyright file="UserAccountFlags.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      UserAccountFlags
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.Configuration.ActiveDirectory
{
    using System;
    /// <summary>
    /// Summary description for userAccountFlags.
    /// </summary>
    [Flags]
    internal enum UserAccountFlags
    {
        ADS_UF_SCRIPT = 0X0001,
        ADS_UF_ACCOUNTDISABLE = 0X0002,
        ADS_UF_HOMEDIR_REQUIRED = 0X0008,
        ADS_UF_LOCKOUT = 0X0010,
        ADS_UF_PASSWD_NOTREQD = 0X0020,
        ADS_UF_PASSWD_CANT_CHANGE = 0X0040,
        ADS_UF_ENCRYPTED_TEXT_PASSWORD_ALLOWED = 0X0080,
        ADS_UF_TEMP_DUPLICATE_ACCOUNT = 0X0100,
        ADS_UF_NORMAL_ACCOUNT = 0X0200,
        ADS_UF_INTERDOMAIN_TRUST_ACCOUNT = 0X0800,
        ADS_UF_WORKSTATION_TRUST_ACCOUNT = 0X1000,
        ADS_UF_SERVER_TRUST_ACCOUNT = 0X2000,
        ADS_UF_DONT_EXPIRE_PASSWD = 0X10000,
        ADS_UF_MNS_LOGON_ACCOUNT = 0X20000,
        ADS_UF_SMARTCARD_REQUIRED = 0X40000,
        ADS_UF_TRUSTED_FOR_DELEGATION = 0X80000,
        ADS_UF_NOT_DELEGATED = 0X100000,
        ADS_UF_USE_DES_KEY_ONLY = 0x200000,
        ADS_UF_DONT_REQUIRE_PREAUTH = 0x400000,
        ADS_UF_PASSWORD_EXPIRED = 0x800000,
        ADS_UF_TRUSTED_TO_AUTHENTICATE_FOR_DELEGATION = 0x1000000
    }
}
