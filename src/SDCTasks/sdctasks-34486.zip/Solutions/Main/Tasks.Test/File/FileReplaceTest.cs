using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;

namespace Microsoft.Sdc.Tasks.Test
{
    /// <summary>
    /// Summary description for FileReplaceTest
    /// </summary>
    [TestClass]
    public class FileReplaceTest
    {
        private const string fileContent = "abcdefgABCDEFG\r\n0123456789\r\n";

        public FileReplaceTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void TestFileReplaceASCIIAndTextExpression()
        {
            string expectedResult = "xyzdefgABCDEFG\r\n0123456789\r\n";
            string fileName = "TestFileReplaceASCIIAndTextExpression.txt";
            CreateFile(fileName, fileContent);
            File.Replace replaceTask = new Microsoft.Sdc.Tasks.File.Replace();
            replaceTask.Path = fileName;
            replaceTask.OldValue = "abc";
            replaceTask.NewValue = "xyz";
            replaceTask.Execute();
            string result = ReadFile(fileName);
            Assert.AreEqual(expectedResult, result);
        }

        [TestMethod]
        public void TestFileReplaceASCIIAndTextExpressionIgnoreCase01()
        {
            string expectedResult = "xyzdefgxyzDEFG\r\n0123456789\r\n";
            string fileName = "TestFileReplaceASCIIAndTextExpressionIgnoreCase01.txt";
            CreateFile(fileName, fileContent);
            File.Replace replaceTask = new Microsoft.Sdc.Tasks.File.Replace();
            replaceTask.Path = fileName;
            replaceTask.OldValue = "abc";
            replaceTask.NewValue = "xyz";
            replaceTask.IgnoreCase = true;
            replaceTask.Execute();
            string result = ReadFile(fileName);
            Assert.AreEqual(expectedResult, result);
        }

        [TestMethod]
        public void TestFileReplaceASCIIAndTextExpressionIgnoreCase02()
        {
            string expectedResult = "abcdefgABCDEFG\r\n012345678ReplacementText";
            string fileName = "TestFileReplaceASCIIAndTextExpressionIgnoreCase02.txt";
            CreateFile(fileName, fileContent);
            File.Replace replaceTask = new Microsoft.Sdc.Tasks.File.Replace();
            replaceTask.Path = fileName;
            replaceTask.OldValue = "9\r\n";
            replaceTask.NewValue = "ReplacementText";
            replaceTask.IgnoreCase = true;
            replaceTask.Execute();
            string result = ReadFile(fileName);
            Assert.AreEqual(expectedResult, result);
        }

        [TestMethod]
        public void TestFileReplaceASCIIAndTextExpressionIgnoreCase03()
        {
            string expectedResult = "abcdefgABCDEFG\r\n012345678)";
            string fileName = "TestFileReplaceASCIIAndTextExpressionIgnoreCase03.txt";
            CreateFile(fileName, fileContent);
            File.Replace replaceTask = new Microsoft.Sdc.Tasks.File.Replace();
            replaceTask.Path = fileName;
            replaceTask.OldValue = "9\r\n";
            replaceTask.NewValue = ")";
            replaceTask.IgnoreCase = true;
            replaceTask.Execute();
            string result = ReadFile(fileName);
            Assert.AreEqual(expectedResult, result);
        }

        [TestMethod]
        public void TestFileReplaceASCIIAndRegularExpression()
        {
            string expectedResult = "abcdefgABCDEFG\r\nNew Line\r\n0123456789\r\n";
            string fileName = "TestFileReplaceASCIIAndRegularExpression.txt";
            CreateFile(fileName, fileContent);
            File.Replace replaceTask = new Microsoft.Sdc.Tasks.File.Replace();
            replaceTask.Path = fileName;
            replaceTask.RegularExpression = @"G\s+";
            replaceTask.NewValue = "G\r\nNew Line\r\n";
            replaceTask.Execute();
            string result = ReadFile(fileName);
            Assert.AreEqual(expectedResult, result);
        }

        [TestMethod]
        public void TestFileReplaceASCIIAndRegularExpressionIgnoreCase()
        {
            string expectedResult = "abcdefgABCDEFG\r\nNew Line\r\n0123456789\r\n";
            string fileName = "TestFileReplaceASCIIAndRegularExpressionIgnoreCase.txt";
            CreateFile(fileName, fileContent);
            File.Replace replaceTask = new Microsoft.Sdc.Tasks.File.Replace();
            replaceTask.Path = fileName;
            replaceTask.RegularExpression = @"g\s+";
            replaceTask.NewValue = "G\r\nNew Line\r\n";
            replaceTask.IgnoreCase = true;
            replaceTask.Execute();
            string result = ReadFile(fileName);
            Assert.AreEqual(expectedResult, result);
        }

        [TestMethod]
        public void TestFileReplaceUnicodeAndTextExpression()
        {
            string expectedResult = "xyzdefgABCDEFG\r\n0123456789\r\n";
            string fileName = "TestFileReplaceUnicodeAndTextExpression.txt";
            CreateUnicodeFile(fileName, fileContent);
            File.Replace replaceTask = new Microsoft.Sdc.Tasks.File.Replace();
            replaceTask.Path = fileName;
            replaceTask.OldValue = "abc";
            replaceTask.NewValue = "xyz";
            replaceTask.Execute();
            string result = ReadFile(fileName);
            Assert.AreEqual(expectedResult, result);
        }

        [TestMethod]
        public void TestFileReplaceUnicodeAndTextExpressionIgnoreCase()
        {
            string expectedResult = "xyzdefgxyzDEFG\r\n0123456789\r\n";
            string fileName = "TestFileReplaceUnicodeAndTextExpressionIgnoreCase.txt";
            CreateUnicodeFile(fileName, fileContent);
            File.Replace replaceTask = new Microsoft.Sdc.Tasks.File.Replace();
            replaceTask.Path = fileName;
            replaceTask.OldValue = "abc";
            replaceTask.NewValue = "xyz";
            replaceTask.IgnoreCase = true;
            replaceTask.Execute();
            string result = ReadFile(fileName);
            Assert.AreEqual(expectedResult, result);
        }

        [TestMethod]
        public void TestFileReplaceUnicodeAndRegularExpression01()
        {
            string expectedResult = "abcdefgABCDEFG\r\nNew Line\r\n0123456789\r\n";
            string fileName = "TestFileReplaceUnicodeAndRegularExpression01.txt";
            CreateUnicodeFile(fileName, fileContent);
            File.Replace replaceTask = new Microsoft.Sdc.Tasks.File.Replace();
            replaceTask.Path = fileName;
            replaceTask.RegularExpression = @"G\s+";
            replaceTask.NewValue = "G\r\nNew Line\r\n";
            replaceTask.Execute();
            string result = ReadFile(fileName);
            Assert.AreEqual(expectedResult, result);
        }

        [TestMethod]
        public void TestFileReplaceUnicodeAndRegularExpression02()
        {
            string expectedResult = "abcdefgABCDEFG, 0123456789, ";
            string fileName = "TestFileReplaceUnicodeAndRegularExpression02.txt";
            CreateUnicodeFile(fileName, fileContent);
            File.Replace replaceTask = new Microsoft.Sdc.Tasks.File.Replace();
            replaceTask.Path = fileName;
            replaceTask.RegularExpression = @"\s+";
            replaceTask.NewValue = ", ";
            replaceTask.Execute();
            string result = ReadFile(fileName);
            Assert.AreEqual(expectedResult, result);
        }

        [TestMethod]
        public void TestFileReplaceUnicodeAndRegularExpressionIgnoreCase()
        {
            string expectedResult = "abcdefgABCDEFG\r\nNew Line\r\n0123456789\r\n";
            string fileName = "TestFileReplaceUnicodeAndRegularExpressionIgnoreCase.txt";
            CreateUnicodeFile(fileName, fileContent);
            File.Replace replaceTask = new Microsoft.Sdc.Tasks.File.Replace();
            replaceTask.Path = fileName;
            replaceTask.RegularExpression = @"g\s+";
            replaceTask.NewValue = "G\r\nNew Line\r\n";
            replaceTask.IgnoreCase = true;
            replaceTask.Execute();
            string result = ReadFile(fileName);
            Assert.AreEqual(expectedResult, result);
        }

        #region static helper functions

        private static void CreateUnicodeFile(string path, string content)
        {
            CreateFile(path, content, Encoding.Unicode);
        }

        private static void CreateFile(string path, string content)
        {
            CreateFile(path, content, Encoding.ASCII);
        }

        private static void CreateFile(string path, string content, Encoding encoding)
        {
            using (StreamWriter textFileWriter = new StreamWriter(path, false, encoding))
            {
                textFileWriter.Write(content);
                textFileWriter.Close();
            }
        }

        private static string ReadFile(string path)
        {
            string content = string.Empty;
            using (StreamReader textFileReader = new StreamReader(path, true))
            {
                content = textFileReader.ReadToEnd();
                textFileReader.Close();
            }
            return content;
        }

        #endregion static helper functions
    }
}
