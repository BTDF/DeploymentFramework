﻿namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
    #region Using directives

    using System;
    using System.Collections;
    using System.Text;
    using System.Reflection;

    #endregion

    internal class BtsSendPort : BtsBaseObject
    {
        /// <summary>
        /// Internal Constructor
        /// </summary>
        /// <param name="actualBtsObject">The actual Microsoft.Biztalk.ExplorerOM.BtsSendPort object that object will call.</param>
        /// <param name="catalogExplorer">The Microsoft.Sdc.Tasks.Configuration.BtsCatalogExplorer object.</param>
        internal BtsSendPort(object actualBtsObject, BtsCatalogExplorer catalogExplorer)
        {
            this.btsCatalogExplorer = catalogExplorer;
            this.actualBtsObject = actualBtsObject;
        }

        /// <summary>
        /// Gets or sets the custom data for a send port.
        /// </summary>
        /// <value></value>
        public string CustomData
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("CustomData", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
            set
            {
                this.actualBtsObject.GetType().InvokeMember("CustomData", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? value : string.Empty });
            }
        }

        /// <summary>
        /// Gets or sets the encryption certificate that is used to encrypt data sent through this port.
        /// </summary>
        /// <value></value>
        public BtsCertificateInfo EncryptionCert
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("EncryptionCert", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (value != null) ? new BtsCertificateInfo(value, this.btsCatalogExplorer) : null;
            }
            set
            {
                this.actualBtsObject.GetType().InvokeMember("EncryptionCert", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? ((BtsCertificateInfo)value).actualBtsObject : null });
            }
        }

        /// <summary>
        /// Gets the name of the optional filter expression used on this send port. 
        /// </summary>
        /// <value></value>
        public string Filter
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("Filter", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
            set
            {
                this.actualBtsObject.GetType().InvokeMember("Filter", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? value : string.Empty });
            }
        }

        /// <summary>
        /// Gets the collection of inbound transforms of a two-way send port.
        /// </summary>
        /// <value></value>
        public System.Collections.IList InboundTransforms
        {
            get
            {
                return (System.Collections.IList)this.actualBtsObject.GetType().InvokeMember("InboundTransforms", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

        }

        /// <summary>
        /// Determines whether the send port is dynamic or static.
        /// </summary>
        /// <value></value>
        public bool IsDynamic
        {
            get
            {
                return (bool)this.actualBtsObject.GetType().InvokeMember("IsDynamic", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

        }

        /// <summary>
        /// Determines whether the port is two-way.
        /// </summary>
        /// <value></value>
        public bool IsTwoWay
        {
            get
            {
                return (bool)this.actualBtsObject.GetType().InvokeMember("IsTwoWay", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

        }

        /// <summary>
        /// Gets or sets the name of the send port.
        /// </summary>
        /// <value></value>
        public string Name
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("Name", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
            set
            {
                this.actualBtsObject.GetType().InvokeMember("Name", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? value : string.Empty });
            }
        }

        /// <summary>
        /// Gets the collection of outbound transforms of a send port.
        /// </summary>
        public System.Collections.IList OutboundTransforms
        {
            get
            {
                return (System.Collections.IList)this.actualBtsObject.GetType().InvokeMember("OutboundTransforms", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }

        }

        /// <summary>
        /// Gets the primary transport of the static send port.
        /// </summary>
        /// <value></value>
        public BtsTransportInfo PrimaryTransport
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("PrimaryTransport", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (value != null) ? new BtsTransportInfo(value, this.btsCatalogExplorer) : null;
            }

        }

        /// <summary>
        /// Gets or sets the priority of the send port.
        /// </summary>
        public int Priority
        {
            get
            {
                return (int)this.actualBtsObject.GetType().InvokeMember("Priority", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
            set
            {
                this.actualBtsObject.GetType().InvokeMember("Priority", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { value });
            }

        }

        /// <summary>
        /// Gets or sets the receive pipeline used to receive a response when a message is sent out through this port.
        /// </summary>
        /// <value></value>
        public BtsPipeline ReceivePipeline
        {

            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("ReceivePipeline", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (value != null) ? new BtsPipeline(value, this.btsCatalogExplorer) : null;
            }
            set
            {
                this.actualBtsObject.GetType().InvokeMember("ReceivePipeline", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? ((BtsPipeline)value).actualBtsObject : null });
            }

        }

        /// <summary>
        /// Gets or sets the custom configuration information specific to the current instance of the receive pipeline. 
        /// </summary>
        /// <value></value>
        public string ReceivePipelineData
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("ReceivePipelineData", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
            set
            {
                this.actualBtsObject.GetType().InvokeMember("ReceivePipelineData", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? value : string.Empty });
            }

        }

        /// <summary>
        /// Gets the secondary transport of the static send port.
        /// </summary>
        /// <value></value>
        public BtsTransportInfo SecondaryTransport
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("SecondaryTransport", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (value != null) ? new BtsTransportInfo(value, this.btsCatalogExplorer) : null;
            }

        }

        /// <summary>
        /// Gets or sets the send pipeline used to send data sent through this port.
        /// </summary>
        /// <value></value>
        public BtsPipeline SendPipeline
        {

            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("SendPipeline", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (value != null) ? new BtsPipeline(value, this.btsCatalogExplorer) : null;
            }
            set
            {
                this.actualBtsObject.GetType().InvokeMember("SendPipeline", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? ((BtsPipeline)value).actualBtsObject : null });
            }

        }

        /// <summary>
        /// Gets or sets the custom configuration specific to this instance of the usage of the pipeline.
        /// </summary>
        /// <value></value>
        public string SendPipelineData
        {
            get
            {
                return (string)this.actualBtsObject.GetType().InvokeMember("SendPipelineData", BindingFlags.GetProperty, null, this.actualBtsObject, null);
            }
            set
            {
                this.actualBtsObject.GetType().InvokeMember("SendPipelineData", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { (value != null) ? value : string.Empty });
            }
        }

        /// <summary>
        /// Gets or sets the status of the send port. 
        /// </summary>
        /// <value></value>
        public PortStatus Status
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("Status", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (PortStatus)Enum.Parse(typeof(PortStatus), value.ToString());
            }
            set
            {
                object actualValue = Enum.Parse(this.btsCatalogExplorer.BizTalkExplorerOMAssembly.GetType("Microsoft.BizTalk.ExplorerOM.PortStatus"), value.ToString());
                this.actualBtsObject.GetType().InvokeMember("Status", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { actualValue });
            }
        }

        /// <summary>
        /// Gets or sets the field to track documents for the send port.
        /// </summary>
        /// <value></value>
        public TrackingTypes Tracking
        {
            get
            {
                object value = this.actualBtsObject.GetType().InvokeMember("Tracking", BindingFlags.GetProperty, null, this.actualBtsObject, null);
                return (TrackingTypes)Enum.Parse(typeof(TrackingTypes), value.ToString());
            }

            set
            {
                object actualValue = Enum.Parse(this.btsCatalogExplorer.BizTalkExplorerOMAssembly.GetType("Microsoft.BizTalk.ExplorerOM.TrackingTypes"), value.ToString());
                this.actualBtsObject.GetType().InvokeMember("Tracking", BindingFlags.SetProperty, null, this.actualBtsObject, new object[] { actualValue });
            }

        }
    }
}
