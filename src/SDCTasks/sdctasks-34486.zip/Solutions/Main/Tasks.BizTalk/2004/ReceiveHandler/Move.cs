//-------------------------------------------------------------------------------------
// <copyright file="Create.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Creates a host in a BizTalk Server.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.ReceiveHandler
{
    #region Using directives

    using System;

    using Microsoft.Build.Framework;
    using Microsoft.Sdc.Tasks.BizTalk2004.Configuration;
    using Microsoft.Sdc.Tasks;

    #endregion


    #region Class Comments
    /// <summary>
    /// Creates a host in a BizTalk Server.
    /// </summary>
    /// <remarks>
    /// <code>
    /// <![CDATA[<BizTalk2004.ReceiveHandler.Create 
    ///                Name="HostName"
    ///                GroupName="BizTalk Application Users"
    ///                HostType="InProcess"
    ///                HostServerName="Servername"
    ///                HostUsername="Name"
    ///                HostPassword="password"
    ///                Trusted="false"
    ///                Tracking="false"
    ///                IsDefault="false"
    ///                />]]>
    /// </code>
    /// <para>where:</para>
    /// <para><i>Name (Required)</i></para>
    /// <para>
    /// The name of the host to create.
    /// </para>
    /// <para><i>GroupName</i></para>
    /// <para>
    /// The name of the group that the host runs under 
    /// </para>
    /// <para><i>HostType</i></para>
    /// <para>
    /// The type of host to create - InProcess or Isolated
    /// </para>
    /// <para><i>HostServerName</i></para>
    /// <para>
    /// The server where an instance of the host should be created.
    /// </para>
    /// <para><i>Username </i></para>
    /// <para>
    ///  The username of the user that the instance will run as.
    ///</para>
    /// <para><i>Password </i></para>
    /// <para>
    ///  The password for the user.
    /// </para>
    /// <para><i>Trusted </i></para>
    /// <para>
    ///  (Boolean) True if the host is to be a trusted host.
    /// </para>
    /// <para><i>Tracking </i></para>
    /// <para>
    ///  (Boolean) True if the host is to be a tracking host.
    /// </para>
    /// <para><i>IsDefault </i></para>
    /// <para>
    ///  (Boolean) True if the host is to be the default host.
    /// </para>
    /// <para><i>server</i></para>
    /// <para>
    /// The logical name of the server hosting the BizTalk management database. If neither this nor the
    /// database name are specified then the installation will default to the local installation.
    /// </para>
    /// <para><i>database</i></para>
    /// <para>
    /// The name of the BizTalk management database. If neither this nor the server name are specified 
    /// then the installation will default to the local installation.
    /// </para>
    /// <para><i>username</i></para>
    /// <para>
    /// The username to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// <para><i>password</i></para>
    /// <para>
    /// The password to use to connect to the database if using SQL Server security. The default is to
    /// connect using Windows Integrated security.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code><![CDATA[
    /// <Project>
    ///     <Target Name="Test" >
    ///            <BizTalk2004.ReceiveHandler.Create 
    ///                Name="ReceivePort 1"
    ///                TwoWay="false"
    ///                InboundMaps="TestMap, TempSolution.TestMaps, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
    ///            />
    /// 
    ///            <BizTalk2004.ReceivePort.Create 
    ///                Name="ReceivePort 2"
    ///                TwoWay="true"
    ///                AuthenticationType="RequiredDropMessage"
    ///                TrackingTypes="AfterReceivePipeline, AfterSendPipeline"
    ///                SendPipeline="Microsoft.BizTalk.DefaultPipelines.XMLTransmit, Microsoft.BizTalk.DefaultPipelines, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
    ///                InboundMaps="TestMap, TempSolution.TestMaps, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35; TestMap3, TempSolution.TestMaps, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
    ///                OutboundMaps="TestMap2, TempSolution.TestMaps, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
    ///                />
    ///      </Target>
    /// </Project>
    /// ]]></code>    
    /// </example>
    #endregion
    public class Move : BizTalk2004TaskBase
    {
        private string newHostName;
        private string transportType;
        private string oldHostName;

        /// <summary>
        /// The name of the host to move the handler to.
        /// </summary>
        /// <value>The name of the new host.</value>
        [Required]
        public string NewHostName
        {
            get { return this.newHostName; }
            set { this.newHostName = value; }
        }

        /// <summary>
        /// The name of the host to move the handler from.
        /// </summary>
        /// <value>The name of the old host.</value>
        public string OldHostName
        {
            get { return this.oldHostName; }
            set { this.oldHostName = value; }
        }

        /// <summary>
        /// The transport type, e.g. FILE, SQL, SOAP etc
        /// </summary>
        /// <value></value>
        [Required]
        public string TransportType
        {
            get { return this.transportType; }
            set { this.transportType = value; }
        }


        /// <summary>
        /// Initializes a new instance of the Create class.
        /// </summary>
        public Move()
        {

        }

        /// <summary>
        /// Performs the action for this task
        /// </summary>
        protected override void InternalExecute()
        {
            //getting the installation and moving the handler
            BizTalkInstallation installation = this.GetInstallation();
            if (this.oldHostName != null && this.oldHostName.Length > 0)
            {
                ReceiveHandler.MoveHost(installation, this.transportType, this.newHostName, this.oldHostName);
            }
            else
            {
                ReceiveHandler.MoveHost(installation, this.transportType, this.newHostName);
            }
        }
    }
}
        
