﻿
namespace Microsoft.Sdc.Tasks.Test
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;
    using System.Text;
    using System.Collections.Generic;
    using Microsoft.Sdc.Tasks;
    using Microsoft.Build.Framework;
    /// <summary>
    ///This is a test class for Microsoft.Sdc.Tasks.SetEnvironmentVariable and is intended
    ///to contain all Microsoft.Sdc.Tasks.SetEnvironmentVariable Unit Tests
    ///</summary>
    [TestClass()]
    public class SetEnvironmentVariableTest
    {
        private TestContext testContextInstance;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get { return this.testContextInstance; }
            set { this.testContextInstance = value; }
        }
       
        /// <summary>
        ///A test for InternalExecute ()
        ///</summary>
        [DeploymentItem("Microsoft.Sdc.Tasks.dll")]
        [TestMethod()]
        public void SetEnvironmentVariableExecuteTest()
        {
            SetEnvironmentVariable task = new SetEnvironmentVariable();
            
            task.Variable = "Bob";
            task.Value = "dave";
            task.Target = EnvironmentVariableTarget.Machine.ToString();

            bool taskReturnValue = task.Execute();

            //Test the return value
            Assert.IsTrue(taskReturnValue, "Task returned false");
        }
    }
}