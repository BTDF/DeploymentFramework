/*
<?xml version="1.0" encoding="iso-8859-1"?>
<FileInfo>
  <Author>Andy Reeves</Author>
  <Date />
  <Description />
  <Copyright><![CDATA[
    Copyright � 2001 - 2003 Microsoft Corporation. All rights reserved.
    THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
    PARTICULAR PURPOSE.
    ]]></Copyright>
</FileInfo>
*/

namespace Microsoft.Sdc.Tasks.Configuration.Web {
    using System;
    using System.DirectoryServices;
    using System.ComponentModel;
    using System.Text;
    using System.Collections;
    using System.Globalization;
    
    /// <summary>
    /// Summary description for AppPool.
    /// </summary>
    internal class AppPool {       

        DirectoryEntry      de;
        string              name;
        string              machineName = "localhost";
        Identity            identity;
        AppPoolState        state;
        Recycling           recycling;
        Performance         performance;
        Health              health;

        public AppPool() {
        }

        private AppPool(DirectoryEntry entry) {
            this.de = entry;
            machineName = de.Path.Substring(6).Split('/')[0];
                        
            
            //Read all the properties
            ComWrapper appPool = new ComWrapper(de.NativeObject);
            Identity.Name = appPool.GetProperty("WAMUserName").ToString();
            Identity.Type = (AppPoolIdentityType)Enum.Parse(typeof(AppPoolIdentityType),appPool.GetProperty("AppPoolIdentityType").ToString());
            state = (AppPoolState)Enum.Parse(typeof(AppPoolState),appPool.GetProperty("AppPoolState").ToString());
            
            Recycling.RestartTime = Convert.ToInt32(appPool.GetProperty("PeriodicRestartTime"));
            Recycling.RestartRequests = Convert.ToInt32(appPool.GetProperty("PeriodicRestartRequests"));
            Recycling.SetRestartScheduleArray((Array)appPool.GetProperty("PeriodicRestartSchedule"));
            Recycling.MaximumVirtualMemory = Convert.ToInt32(appPool.GetProperty("PeriodicRestartMemory")) / 1024;
            Recycling.MaximumUsedMemory = Convert.ToInt32(appPool.GetProperty("PeriodicRestartPrivateMemory")) / 1024;

            Performance.IdleTimeout = Convert.ToInt32(appPool.GetProperty("IdleTimeout"));
            Performance.RequestQueueLimit = Convert.ToInt32(appPool.GetProperty("AppPoolQueueLength"));
            Performance.CpuMaximumUse = Convert.ToInt32(appPool.GetProperty("CPULimit")) / 1000;
            Performance.CpuRefreshInterval = Convert.ToInt32(appPool.GetProperty("CPUResetInterval"));
            Performance.CpuAction = (CpuAction)Enum.Parse(typeof(CpuAction),appPool.GetProperty("CPUAction").ToString());
            Performance.WorkerProcesses = Convert.ToInt32(appPool.GetProperty("MaxProcesses"));
            
            Health.PingEnabled = Convert.ToBoolean(appPool.GetProperty("PingingEnabled"));
            Health.PingInterval = Convert.ToInt32(appPool.GetProperty("PingInterval"));
            Health.RapidFailProtectionEnabled = Convert.ToBoolean(appPool.GetProperty("RapidFailProtection"));
            Health.RapidFailProtectionMaximumFailures = Convert.ToInt32(appPool.GetProperty("RapidFailProtectionMaxCrashes"));
            Health.RapidFailProtectionInterval = Convert.ToInt32(appPool.GetProperty("RapidFailProtectionInterval"));
            Health.StartupTimeLimit = Convert.ToInt32(appPool.GetProperty("StartupTimeLimit"));
            Health.ShutdownTimeLimit = Convert.ToInt32(appPool.GetProperty("ShutdownTimeLimit"));
        }

        public AppPool(string name): this(name, "localhost") {
        }

        public AppPool(string name, string machineName) {
            this.name = name;
            this.machineName = machineName;
        }
        
        public static AppPool Load(string name) {
            return Load(name, "localhost");
        }

        public static AppPool Load(string name, string machineName) {
            DirectoryEntry web = new DirectoryEntry("IIS://" + machineName + "/W3SVC/AppPools/" + name);    
            return new AppPool(web);
        }

        static public bool Exists(string name) {
            return Exists(name, "localhost");
        }

        static public bool Exists(string name, string machineName) {
            try {
                if (DirectoryEntry.Exists("IIS://" + machineName + "/W3SVC/AppPools/" + name)) {
                    return true;
                }
            }
            catch {
                return false;
            }
            return false;
        }

        public static void Delete(string name, string machineName) {
            try {
                DirectoryEntry pools = new DirectoryEntry("IIS://" + machineName + "/W3SVC/AppPools");  
            
                object[] args = {"IIsApplicationPool", name};
                pools.Invoke("Delete", args);
            }
            catch(Exception e) {
                throw new ApplicationException(String.Format(CultureInfo.InvariantCulture, "Unable to delete app pool '{0}'. It can only be deleted if it has no webs running in it", name), e);
            }
        }

        public static void Delete(string name) {
            Delete(name, "localhost");
        }

        DirectoryEntry EnsureAppPool() {
            DirectoryEntry de;
            DirectoryEntry appPools = new DirectoryEntry("IIS://" + machineName + "/W3SVC/AppPools");
            try { 
                de = appPools.Children.Add(name, "IIsApplicationPool");
                                
                de.CommitChanges();
                appPools.CommitChanges();
            }
            catch(Exception e) {
                throw new ApplicationException("App Pool already exists.", e);
            }
            return de;
        }

        object[] CreateRestartScheduleFromRestartTimeArray(RestartTimeCollection value) {

            object[] temp = new object[0];
            if (value == null) {
                return temp;
            }
            temp = new object[value.Count];

            for(int i=0; i < value.Count; i++) {
                temp[i] = value[i].ToString();
            }
            return temp;
        }

        public void Save() {
            const int ADS_PROPERTY_UPDATE = 2;

            if (de == null) {
                de = EnsureAppPool();
            }

            ComWrapper app = new ComWrapper(de.NativeObject);

            app.CallMethod("Put", new object[] {"AppPoolIdentityType", Identity.Type});
            if (Identity.passwordSpecified) 
            {
                app.CallMethod("Put", new object[] {"WAMUserName", Identity.Name});
                app.CallMethod("Put", new object[] {"WAMUserPass", Identity.Password});
            }

            app.CallMethod("Put", new object[] {"PeriodicRestartTime", Recycling.RestartTime}); 
            app.CallMethod("Put", new object[] {"PeriodicRestartRequests", Recycling.RestartRequests});         
            app.CallMethod("PutEx", new object[] {ADS_PROPERTY_UPDATE, "PeriodicRestartSchedule", CreateRestartScheduleFromRestartTimeArray(Recycling.RestartSchedule)});
            app.CallMethod("Put", new object[] {"PeriodicRestartMemory", Recycling.MaximumVirtualMemory * 1024});
            app.CallMethod("Put", new object[] {"PeriodicRestartPrivateMemory", Recycling.MaximumUsedMemory * 1024});   

            app.CallMethod("Put", new object[] {"IdleTimeout", Performance.IdleTimeout});   
            app.CallMethod("Put", new object[] {"AppPoolQueueLength", Performance.RequestQueueLimit});  
            app.CallMethod("Put", new object[] {"CPULimit", Performance.CpuMaximumUse * 1000}); 
            app.CallMethod("Put", new object[] {"CPUResetInterval", Performance.CpuRefreshInterval});   
            app.CallMethod("Put", new object[] {"CPUAction", Performance.CpuAction});   
            app.CallMethod("Put", new object[] {"MaxProcesses", Performance.WorkerProcesses});
    
            app.CallMethod("Put", new object[] {"PingingEnabled", Health.PingEnabled});                 
            app.CallMethod("Put", new object[] {"StartupTimeLimit", Health.StartupTimeLimit});          
            app.CallMethod("Put", new object[] {"ShutdownTimeLimit", Health.ShutdownTimeLimit});
            app.CallMethod("Put", new object[] {"PingInterval", Health.PingInterval});
            app.CallMethod("Put", new object[] {"RapidFailProtection", Health.RapidFailProtectionEnabled});
            app.CallMethod("Put", new object[] {"RapidFailProtectionMaxCrashes", Health.RapidFailProtectionMaximumFailures});
            app.CallMethod("Put", new object[] {"RapidFailProtectionInterval", Health.RapidFailProtectionInterval});
                    
            de.CommitChanges();
        }

        public void Recycle() {
            ComWrapper app = new ComWrapper(de.NativeObject);
            app.CallMethod("Recycle");
        }

        public void Start() {
            ComWrapper app = new ComWrapper(de.NativeObject);
            app.CallMethod("Start");
        }
        public void Stop() {
            ComWrapper app = new ComWrapper(de.NativeObject);
            app.CallMethod("Stop");
        }

        public string MachineName {
            get {
                return (machineName == null ? String.Empty : machineName);
            }
            set {
                machineName = value;
            }
        }

        public string Name {
            get {
                return (name == null ? String.Empty : name);
            }
            set {
                name = value;
            }
        }

        public Recycling Recycling {
            get {
                if (recycling == null) {
                    recycling = new Recycling();
                }
                return recycling;
            }           
        }

        public AppPoolState State {
            get {
                return state;
            }           
        }

        public Performance Performance {
            get {
                if (performance == null) {
                    performance = new Performance();
                }
                return performance ;
            }
        }

        public Microsoft.Sdc.Tasks.Configuration.Web.Health Health {
            get {
                if (health == null) {
                    health = new Health();
                }
                return health ;
            }
        }

        public Microsoft.Sdc.Tasks.Configuration.Web.Identity Identity {
            get {
                if (identity == null) {
                    identity = new Identity();
                }
                return identity ;
            }           
        }
    }
    
    
}
