//-------------------------------------------------------------------------------------
// <copyright file="ReceiveLocation.cs" company="Microsoft">
//      Copyright (c) 2003 Microsoft Corporation. All rights reserved.
//      THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
//      EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
//      WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>
//      Represents a combination of a specific address where the inbound message arrives and the pipeline processes the message.
// </summary>  
//-------------------------------------------------------------------------------------

namespace Microsoft.Sdc.Tasks.BizTalk2004.Configuration
{
	#region Using directives

	using System;

	#endregion

	/// <summary>
	/// HttpTransport Wrapper class.
	/// </summary>
	internal class HttpTransport : TransportData
	{

		/// <summary>
		/// Name of the Transport Type
		/// </summary>
		public const string Name = "HTTP";

		#region Constructor

		/// <summary>
		/// Creates a new instance of the Http Transport Object
		/// </summary>
		/// <param name="parentType"> A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.TransportDataParentType"/> specifying the parent type.</param>
		public HttpTransport(TransportDataParentType parentType)
		{
			this.ParentType = parentType;
		}

		/// <summary>
		/// Creates a new instance of the Http Transport Object
		/// </summary>
		/// <param name="parentType"> A <see cref="Microsoft.Sdc.Tasks.BizTalk2004.Configuration.TransportDataParentType"/> specifying the parent type</param>
		/// <param name="transportDataXml">A string containing the TransportData Xml.</param>
		public HttpTransport(TransportDataParentType parentType, string transportDataXml)
		{
			this.ParentType = parentType;
			this.InitializeFromXml(transportDataXml);
		}
		
		#endregion

		#region common properties

		/// <summary>
		/// Specifies whether the HTTP adapter will issue the SSO ticket to messages that arrive/depart.
		/// </summary>
		public bool UseSSO
		{
			get
			{
				return (bool) this.Items["UseSSO"].Value;
			}
			set
			{
				if(!this.Items.Contains("UseSSO"))
					this.Items.Add(new TransportDataItem("UseSSO", typeof(bool), value));
				else
					this.Items["UseSSO"].Value = value;
			}
		}



		#endregion

		#region Receive Location properties

		/// <summary>
		/// Content type of the HTTP response messages that the HTTP adapter sends back to clients from this receive location. This property is valid only for request-response receive ports and is ignored for one-way receive ports.
		/// </summary>
		public string ResponseContentType
		{
			get
			{
				return this.Items["ResponseContentType"].Value.ToString();
			}
			set
			{
				if (this.ParentType == TransportDataParentType.ReceiveLocation)
				{
					if(!this.Items.Contains("ResponseContentType"))
						this.Items.Add(new TransportDataItem("ResponseContentType", typeof(string), value));
					else
						this.Items["ResponseContentType"].Value = value;
				}
				else
					throw new InvalidOperationException("The ResponseContentType property can only be set for a receive location.");
			}
		}


		/// <summary>
		/// Specifies that the request message received on this location will be routed either to a send port or back to the receive location to be sent as a response. This property is valid only for request-response receive ports. It is ignored for one-way receive ports.
		/// </summary>
		public bool LoopBack
		{
			get
			{
				return (bool) this.Items["LoopBack"].Value;
			}
			set
			{

				if (this.ParentType == TransportDataParentType.ReceiveLocation)
				{
					if(!this.Items.Contains("LoopBack"))
						this.Items.Add(new TransportDataItem("LoopBack", typeof(bool), value));
					else
						this.Items["LoopBack"].Value = value;
				}
				else
					throw new InvalidOperationException("The LoopBack property can only be set for a receive location.");

			}

		}

		
		/// <summary>
		/// Specifies that the correlation token of submitted message that the HTTP adapter sends on HTTP response to the client if the submission is successful. This property is valid only for one-way receive ports and is ignored for request-response receive ports.
		/// </summary>
		public bool ReturnCorrelationHandle
		{
			get
			{
				return (bool) this.Items["ReturnCorrelationHandle"].Value;
			}
			set
			{

				if (this.ParentType == TransportDataParentType.ReceiveLocation)
				{
					if(!this.Items.Contains("ReturnCorrelationHandle"))
						this.Items.Add(new TransportDataItem("ReturnCorrelationHandle", typeof(bool), value));
					else
						this.Items["ReturnCorrelationHandle"].Value = value;
				}
				else
					throw new InvalidOperationException("The ReturnCorrelationHandle property can only be set for a receive location.");

			}

		}

		

		#endregion 

		#region Send Port properties

		/// <summary>
		/// Time-out period of waiting for a response from the server. If set to zero (0), the system calculates the time-out based on the request message size.
		/// </summary>
		public int RequestTimeout
		{
			get 
			{
				return Convert.ToInt32(this.Items["RequestTimeout"].Value);
			}
			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("RequestTimeout"))
						this.Items.Add(new TransportDataItem("RequestTimeout", typeof(int), value));
					else
						this.Items["RequestTimeout"].Value = value;
				}
				else
					throw new InvalidOperationException("The RequestTimeout property can only be set for a send port.");
			}
		}


		/// <summary>
		/// Content type of the request messages.
		/// </summary>
		public string ContentType
		{
			get 
			{
				return this.Items["ContentType"].Value.ToString();
			}
			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("ContentType"))
						this.Items.Add(new TransportDataItem("ContentType", typeof(string), value));
					else
						this.Items["ContentType"].Value = value;
				}
				else
					throw new InvalidOperationException("The ContentType property can only be set for a send port.");
			}
		}


		/// <summary>
		/// Maximum number of times that the HTTP adapter can redirect the request.
		/// </summary>
		public int MaxRedirects
		{
			get 
			{
				return Convert.ToInt32(this.Items["MaxRedirects"].Value);
			}
			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("MaxRedirects"))
						this.Items.Add(new TransportDataItem("MaxRedirects", typeof(int), value));
					else
						this.Items["MaxRedirects"].Value = value;
				}
				else
					throw new InvalidOperationException("The MaxRedirects property can only be set for a send port.");
			}
		}

		
		/// <summary>
		/// Specifies whether HTTP send port will use the proxy configuration for the send handler.
		/// </summary>
		public bool UseHandlerProxySettings
		{
			get 
			{
				return (bool) this.Items["UseHandlerProxySettings"].Value;
			}
			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("UseHandlerProxySettings"))
						this.Items.Add(new TransportDataItem("UseHandlerProxySettings", typeof(bool), value));
					else
						this.Items["UseHandlerProxySettings"].Value = value;
				}
				else
					throw new InvalidOperationException("The UseHandlerProxySettings property can only be set for a send port.");
			}
		}


		/// <summary>
		/// Specifies whether the HTTP adapter will use the proxy server.
		/// </summary>
		public bool UseProxy
		{
			get 
			{
				return (bool) this.Items["UseProxy"].Value;
			}
			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("UseProxy"))
						this.Items.Add(new TransportDataItem("UseProxy", typeof(bool), value));
					else
						this.Items["UseProxy"].Value = value;
				}
				else
					throw new InvalidOperationException("The UseProxy property can only be set for a send port.");
			}
		}


		/// <summary>
		/// Specifies the proxy server name. 
		/// </summary>
		public string ProxyName
		{
			get 
			{
				return this.Items["ProxyName"].Value.ToString();
			}
			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("ProxyName"))
						this.Items.Add(new TransportDataItem("ProxyName", typeof(string), value));
					else
						this.Items["ProxyName"].Value = value;
				}
				else
					throw new InvalidOperationException("The ProxyName property can only be set for a send port.");
			}
		}

		
		/// <summary>
		/// Specifies the proxy server port.
		/// </summary>
		public int ProxyPort
		{
			get 
			{
				return Convert.ToInt32(this.Items["ProxyPort"].Value);
			}
			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("ProxyPort"))
						this.Items.Add(new TransportDataItem("ProxyPort", typeof(int), value));
					else
						this.Items["ProxyPort"].Value = value;
				}
				else
					throw new InvalidOperationException("The ProxyPort property can only be set for a send port.");
			}
		}


		/// <summary>
		/// Specifies the user name for authentication with the proxy server. 
		/// </summary>
		public string ProxyUsername
		{
			get 
			{
				return this.Items["ProxyUsername"].Value.ToString();
			}
			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("ProxyUsername"))
						this.Items.Add(new TransportDataItem("ProxyUsername", typeof(string), value));
					else
						this.Items["ProxyUsername"].Value = value;
				}
				else
					throw new InvalidOperationException("The ProxyUsername property can only be set for a send port.");
			}
		}


		/// <summary>
		/// Specifies the user password for authentication with the proxy server. 
		/// </summary>
		public string ProxyPassword
		{
			get 
			{
				return this.Items["ProxyPassword"].Value.ToString();
			}
			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("ProxyPassword"))
						this.Items.Add(new TransportDataItem("ProxyPassword", typeof(string), value));
					else
						this.Items["ProxyPassword"].Value = value;
				}
				else
					throw new InvalidOperationException("The ProxyPassword property can only be set for a send port.");
			}
		}


		/// <summary>
		/// Type of authentication to use with the destination server.
		/// </summary>
		/// <value>
		///One of the following:
		/// Anonymous (Default)
		/// Basic
		/// Digest 
		/// Kerberos 
		///</value>
		public string AuthenticationScheme
		{
			get 
			{
				return this.Items["AuthenticationScheme"].Value.ToString();
			}
			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("AuthenticationScheme"))
						this.Items.Add(new TransportDataItem("AuthenticationScheme", typeof(string), (value==string.Empty)?"Anonymous":value));
					else
						this.Items["AuthenticationScheme"].Value = (value==string.Empty)?"Anonymous":value;
				}
				else
					throw new InvalidOperationException("The AuthenticationScheme property can only be set for a send port.");
			}
		}

		
		/// <summary>
		/// User name to use for authentication with the server. 
		/// </summary>
		public string Username
		{
			get 
			{
				return this.Items["Username"].Value.ToString();
			}
			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("Username"))
						this.Items.Add(new TransportDataItem("Username", typeof(string), value));
					else
						this.Items["Username"].Value = value;
				}
				else
					throw new InvalidOperationException("The Username property can only be set for a send port.");
			}
		}

	
		/// <summary>
		/// User password to use for authentication with the server. 
		/// </summary>
		public string Password
		{
			get 
			{
				return this.Items["Password"].Value.ToString();
			}
			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("Password"))
						this.Items.Add(new TransportDataItem("Password", typeof(string), value));
					else
						this.Items["Password"].Value = value;
				}
				else
					throw new InvalidOperationException("The Password property can only be set for a send port.");
			}
		}

		
		/// <summary>
		/// Thumbprint of client the SSL certificate.
		/// </summary>
		public string Certificate
		{
			get 
			{
				return this.Items["Certificate"].Value.ToString();
			}
			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("Certificate"))
						this.Items.Add(new TransportDataItem("Certificate", typeof(string), value));
					else
						this.Items["Certificate"].Value = value;
				}
				else
					throw new InvalidOperationException("The Certificate property can only be set for a send port.");
			}
		}


		/// <summary>
		/// Name of the affiliate application to use for SSO.
		/// </summary>
		public string AffiliateApplicationName
		{
			get 
			{
				return this.Items["AffiliateApplicationName"].Value.ToString();
			}
			set
			{
				if (this.ParentType == TransportDataParentType.SendPort)
				{
					if(!this.Items.Contains("AffiliateApplicationName"))
						this.Items.Add(new TransportDataItem("AffiliateApplicationName", typeof(string), value));
					else
						this.Items["AffiliateApplicationName"].Value = value;
				}
				else
					throw new InvalidOperationException("The AffiliateApplicationName property can only be set for a send port.");
			}
		}


		#endregion 

	}
}

