//-----------------------------------------------------------------------
// <copyright file="Configure.cs" company="Microsoft">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
// </copyright>
//-----------------------------------------------------------------------
namespace Microsoft.Sdc.Tasks.BizTalk2006.SendPortGroup
{
    using System;
    using Microsoft.BizTalk.ExplorerOM;

    /// <summary>
    /// Configures an already existing Send Port Group.
    /// </summary>
    public class Configure : Microsoft.Sdc.Tasks.BizTalk2004.SendPortGroup.Configure
    {
        private string application;

        /// <summary>
        /// The application that this send port belongs to. If this is not specified, the BizTalk 2004 code 
        /// is executed.
        /// </summary>
        public string Application
        {
            get { return this.application; }
            set { this.application = value; }
        }

        /// <summary>
        /// Executes the task.
        /// </summary>
        protected override void InternalExecute()
        {
            if (string.IsNullOrEmpty(this.Application))
            {
                base.InternalExecute();
            }
            else
            {
                BtsCatalogExplorer explorer = this.GetBtsCatalogExplorer(this.Server, this.Database);

                Application app = explorer.Applications[this.Application];
                if (app != null)
                {
                    SendPortGroup group = app.SendPortGroups[this.Name];
                    if (group != null)
                    {
                        if (!string.IsNullOrEmpty(this.NewName) && this.NewName != this.Name)
                        {
                            group.Name = this.NewName;
                        }

                        group.Filter = (!string.IsNullOrEmpty(this.Filter)) ? this.Filter : group.Filter;
                        explorer.SaveChanges();
                    }
                    else
                    {
                        Log.LogError(string.Format(System.Globalization.CultureInfo.InvariantCulture, "SendPortGroup not found: {0} in Application: {1}", this.Name, this.Application));
                        return;
                    }
                }
                else
                {
                    Log.LogError(string.Format(System.Globalization.CultureInfo.InvariantCulture, "Application not found: {0}", this.Application));
                    return;
                }
            }
        }
    }
}
